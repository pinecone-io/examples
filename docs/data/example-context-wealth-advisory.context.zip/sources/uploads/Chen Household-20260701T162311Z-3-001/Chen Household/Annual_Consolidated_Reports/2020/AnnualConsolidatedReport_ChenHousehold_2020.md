CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2020

COVID Year — IPS Amendment, Defensive Repositioning & 529 Accounts Opened (EventID-2020-01 | DecisionID-2020-044 | Story Arc 1)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2020 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 10, 2021 |
| Document ID: | DOC-AnnualConsolidatedReport-2020-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

There is no other way to describe 2020: it was unlike any year in living memory. A global pandemic, a 34% market crash in five weeks, an unprecedented monetary and fiscal policy response, and then — remarkably — a full recovery and a new market high before year-end. For most long-term investors, staying invested through the noise produced excellent outcomes. For the Chen household, it also produced something lasting: clarity about your true risk tolerance.

When Alex called in late February to say ‘I can’t sleep at night watching this,’ that was important information. We convened an emergency review in March, formally retested your risk questionnaire, and made a deliberate, documented decision to reduce equity exposure from 70% to 60% and increase fixed income and cash. This wasn’t a panic reaction — it was a considered policy change aligned with what we learned about your real emotional tolerance for drawdowns.

I’m also genuinely pleased to report that — after four years — the 529 accounts for Maya and Eli are open. ACCT-529A and ACCT-529B were funded in May 2020. It’s never too late, and the compounding clock is now running.

Your portfolio ended 2020 at $792,000, up $60,000 from year-start despite everything the market threw at us. That resilience is a direct result of your discipline and our partnership.

Warmly,

Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2020

Market Environment

| U.S. Equity (S&P 500): | $+18.4%  (crashed −34% to March 23 low; fully recovered by August) |
| --- | --- |
| International Equity (MSCI EAFE): | +8.2%  (weaker recovery; COVID disruptions abroad) |
| U.S. Bonds (Bloomberg Agg): | $+7.5%  (flight to safety + Fed rate cuts drove gains) |
| Fed Funds Rate: | 1.75% → 0.00–0.25%  (emergency cuts to zero; March 2020) |
| Key Events: | COVID-19 pandemic; CARES Act ($2T stimulus); zero-rate policy; re-risking in H2 |
| IPS Change (mid-year): | 70/28/2 (IPS-2016) → 60/35/5 (IPS-2020) effective June 15, 2020 |

Story Arc 1 — ‘From Confidence to Caution’

The COVID volatility event (EventID-2020-01) is the beginning of Story Arc 1: a documented chain of decisions that begins with emotional distress in Q1 2020, runs through a formal risk reassessment, results in an IPS amendment, and generates a measurable tax outcome. Every link in this chain is documented and cross-referenceable:

EventID-2020-01 → DOC-RiskQuestionnaire-2020-001 (score: 68→54) → DOC-IPSAmendment-2020-001 (60/35/5) → DecisionID-2020-044 (trade execution) → ACCT-TX01 statements → 1099Bundle_TY20 → DOC-TaxReturnSummary-2020-001 ($12K LT gains)

Household Milestones

• February–March 2020: COVID market crash triggers emergency review (MtgID-2020Q1-02)

• May 2020: Risk questionnaire updated — score drops from 68 to 54/100 (DOC-RiskQuestionnaire-2020-001)

• June 15, 2020: IPS Amendment signed — allocation shifts to 60/35/5 (DOC-IPSAmendment-2020-001)

• June 15–30, 2020: Defensive repositioning trades executed (DecisionID-2020-044)

• May 2020: ACCT-529A (Maya) and ACCT-529B (Eli) OPENED — RecID-2020-02 — 4 years in the making

• Muni bond sleeve (MUNIX) expanded in ACCT-TX01 — RecID-2020-01 (tax-efficient income)

Quarterly AUM Progression

| Quarter | End AUM | Net Flow | Allocation (E/FI/C) | Key Notes |
| --- | --- | --- | --- | --- |
| 2020-Q1 | $665,000 | +$12,000 | 74 / 24 / 2 | COVID crash −$67K; equity drifted up before IPS change |
| 2020-Q2 | $705,000 | +$10,000 | 62 / 33 / 5 | IPS-2020 implemented mid-Q2; repositioning trades executed |
| 2020-Q3 | $740,000 | +$11,000 | 60 / 35 / 5 | Market recovery in progress; new allocation holding |
| 2020-Q4 | $792,000 | +$12,000 | 61 / 34 / 5 | Strong Q4 close; 529 accounts growing; AUM at new high |

SECTION 2 — FINANCIAL GOALS DASHBOARD

[ON TRACK (RESILIENT)] GoalID-2016-01 — Retirement Readiness: AUM $792,000 at year-end — up from $732,000 despite a historic crash. Funded ratio improving. IPS-2020 (60/35/5) reduces sequence risk while maintaining growth. Projection confidence: Moderate-Good (updated for new risk profile). New max drawdown tolerance: ~15–18% (vs. 20–25% prior).

[OPENED — IN PROGRESS] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya) and ACCT-529B (Eli) opened May 2020 — GoalID-2016-02 finally activated. Year-end balances minimal (initial contributions). Age-based moderate portfolio (529-AGE-MOD) selected. Maya: ~11 years to projected enrollment; Eli: ~14 years. Contribution schedule to be set in 2021.

[ON TRACK] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH ~$50,000 (5–6 months expenses). COVID reinforced importance of liquid reserves. Cash sleeve increased to 5% target in IPS-2020 — GoalID-2016-03 now formally embedded in IPS.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2020

| Beginning AUM (January 1, 2020): | $732,000 |
| --- | --- |
| Net Contributions (full year): | $45,000 |
| COVID Drawdown (peak Q1): | (−67,000)  — Q1 trough; subsequently fully recovered |
| Investment Return (net, full year): | $+21,000  (modest net gain despite severe mid-year volatility) |
| Advisory Fees Paid: | ($6,000)  (1.00% flat on avg. AUM ~$720K) |
| End AUM (December 31, 2020): | $792,000 |
| Total Household AUM Growth: | $+60,000  (+8.2%)  — solid given the year’s volatility |

Asset Allocation vs. Policy (Year-End 2020)

| Asset Class | IPS Target (2020) | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK + USCIX) | 60% target | ~61% | Within ±4% band (IPS-2020) |
| Fixed Income (UCBIX + UTIPX + MUNIX) | 35% target | ~34% | Within band |
| Cash / STBIX | 5% target | ~5% | On target |
| NLTK Single Stock | <7% IPS-2020 limit | ~5% | Within revised limit |
| TOTAL Household Portfolio | 100% | 100% | IPS-2020 targets met |

Account-Level Summary (Year-End 2020)

| Account | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Joint | Equity + muni + NLTK; MUNIX sleeve added | $390,000 |
| ACCT-IRA1 | Alex Trad. IRA | Expanded bonds + TIPS + equity | $285,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM tilt | $67,000 |
| ACCT-CASH | Cash Mgmt (HYSA) | Emergency fund (5% target) | $50,000 |
| ACCT-529A | Maya Education (529) | Age-Based Moderate — opened May 2020 | ~$0 (initial) |
| ACCT-529B | Eli Education (529) | Age-Based Moderate — opened May 2020 | ~$0 (initial) |
| Household Total |  |  | $792,000 |

Performance Attribution (Full Year 2020)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | ~+19% | Recovery from crash; new 60% target reduces total equity P&L |
| International Equity (IDEIX) | ~+8% | Lagged U.S.; pandemic disruptions abroad |
| Fixed Income (UCBIX + UTIPX + MUNIX) | ~+7% | Strong; rate cuts + flight to safety |
| Cash / STBIX | ~+0.5% | Near-zero Fed funds; minimal yield |
| Overall Portfolio (net of fees) | ~+6.5% | Strong result given volatility; IPS-2020 proved defensively effective |

Defensive Repositioning Summary — DecisionID-2020-044

| Decision Window: | June 15–30, 2020 |
| --- | --- |
| Trigger: | EventID-2020-01  |  DOC-RiskQuestionnaire-2020-001 |
| Trades Executed: | UECIX → UCBIX/UTIPX; IDEIX → UCBIX; REITX trim (ACCT-TX01) |
| Tax Outcome (TY2020): | ~$12,000 LT capital gains realized  (see DOC-TaxReturnSummary-2020-001) |
| Wash Sale Compliance: | Confirmed; 30-day waiting period observed where applicable |
| New MUNIX Sleeve: | Added to ACCT-TX01 per RecID-2020-01; tax-exempt income in taxable account |

SECTION 4 — TAX PLANNING RECAP

| Tax Year: | 2020 |
| --- | --- |
| Filing Status: | MFJ |
| AGI (approx.): | $263,600 |
| Deduction Method: | Standard Deduction ($24,800) — elected |
| Net Capital Gains: | $12,000  (LT gains from DecisionID-2020-044 repositioning) |
| Tax Topic: | TaxTopicID-2020-01 — Reallocation gains and tax budgeting |
| NIIT (3.8%): | $518  (AGI $263,600; NII = $13,600) |
| CARES Act Notes: | Enhanced charitable deduction (100% AGI) not utilized (standard elected) |
| Federal Tax (approx.): | $40,909  |  Effective rate: 15.5% |
| State Tax (MN): | $18,388  |  Effective rate: ~7.7% |
| Full detail: | See DOC-TaxReturnSummary-2020-001 |

SECTION 5 — RECOMMENDATIONS & ACTION ITEMS

| Fund 529 accounts (ACCT-529A, ACCT-529B): | Set annual contribution schedule Q1 2021 — GoalID-2016-02 |
| --- | --- |
| Update beneficiary forms: | ACCT-IRA1 / ACCT-RIRA alignment with trust still pending — TaskID assigned |
| IPS-2020 first full-year review: | Q2 2021 — confirm 60/35/5 remains appropriate post-recovery |
| NLTK concentration: | <7% limit per IPS-2020; vest schedule review Q1 2021 |
| Estate planning: | Trust updated; Westfield & Baker LLP annual review recommended |
| NIIT planning: | AGI consistently above $250K; review NII sources for tax efficiency |

SECTION 6 — DOCUMENT CROSS-REFERENCES

| IPS (amended): | DOC-IPSAmendment-2020-001  (prior: DOC-IPS-2016-001) |
| --- | --- |
| Risk Questionnaire (updated): | DOC-RiskQuestionnaire-2020-001  (score: 54/100) |
| Life Event: | EventID-2020-01  (COVID volatility / IPS trigger) |
| Trade Decision: | DecisionID-2020-044 |
| Recommendations: | RecID-2020-01 (muni sleeve)  |  RecID-2020-02 (open 529s) |
| Meeting Notes + Transcripts: | MtgID-2020Q1-02 (emergency) through MtgID-2020Q4-01 |
| Tax Return Summary: | DOC-TaxReturnSummary-2020-001  |  TaxTopicID-2020-01 |
| Knowledge Files: | KF-Market-Volatility-Playbook.md  |  KF-CARES-Act-Summary.md |
| Prior Report: | DOC-AnnualConsolidatedReport-2019-001 |
| Next Report: | DOC-AnnualConsolidatedReport-2021-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
