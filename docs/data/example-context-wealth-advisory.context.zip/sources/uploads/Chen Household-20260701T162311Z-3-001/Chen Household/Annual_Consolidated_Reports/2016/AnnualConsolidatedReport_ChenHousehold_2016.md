CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2016

Foundation Year — Relationship Established with Clearwater Wealth Partners

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2016 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 15, 2017 |
| Document ID: | DOC-AnnualConsolidatedReport-2016-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

It is our privilege to present your first Annual Consolidated Report as clients of Clearwater Wealth Partners. When you joined us in February 2016 with $410,000 in investable assets, we set out to build a foundation aligned with your three most important goals: retirement at approximately age 60, funding a meaningful share of Maya’s and Eli’s education, and maintaining a robust emergency liquidity reserve.

Despite a mid-year Brexit shock and significant post-election volatility in Q4, markets delivered a solid +10% return for the year. Your portfolio, positioned at 70% Equity / 28% Fixed / 2% Cash per your Investment Policy Statement, grew from $410,000 to $486,000 — a combination of investment growth and your disciplined $48,000 in contributions. We enter 2017 with positive momentum and important planning conversations ahead, particularly around tax reform proposals gaining traction in Washington.

Thank you for placing your trust in us. We look forward to a strong year ahead. Warmly,

Morgan Park, CFP® | Advisor, Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2016

Market Environment

| U.S. Equity (S&P 500): | $+10.0%  (post-election rally drove Q4 surge) |
| --- | --- |
| International Equity (MSCI EAFE): | +1.0%  (Brexit shock dampened returns) |
| U.S. Bonds (Bloomberg Agg): | $+2.6%  (modest positive; rates rose in Dec) |
| Fed Funds Rate: | 0.25% → 0.50%  (one 25 bps hike, December 2016) |
| Key Events: | Brexit vote (June); U.S. presidential election (Nov); Oil price recovery |
| IPS Allocation in Effect: | DOC-IPS-2016-001  |  70% Equity / 28% Fixed / 2% Cash |

Household Milestones

• February 2016: Relationship established with Clearwater Wealth Partners; initial AUM $410,000

• February 2016: Investment Policy Statement (IPS) signed — DOC-IPS-2016-001

• February 2016: Risk questionnaire completed — Score 68/100 ‘Moderate Growth’

• February 2016: Three financial goals formally established (GoalID-2016-01 through -03)

• Q4 2016: First annual review meeting held — MtgID-2016Q4-01

• Q4 2016: 529 education account opening recommended for 2017

SECTION 2 — FINANCIAL GOALS DASHBOARD

Goals are evaluated annually using a simplified funded ratio and qualitative progress indicators.

[ON TRACK] GoalID-2016-01 — Retirement Readiness: Baseline established. Target: retire ~age 60 with ~$185K/yr (today’s dollars). Current funded ratio: ~38% of target (early stage). Projection confidence: Moderate. Timeline: ~24 years. IPS-2016 allocation appropriate for accumulation phase.

[ESTABLISHED] GoalID-2016-02 — Education Funding (529s): Goal recorded; 529 accounts not yet opened (recommendation made Q4 2016). Maya (age 5) has ~13 years to college; Eli (age 2) has ~16 years. Action: open ACCT-529A and ACCT-529B in 2017.

[ON TRACK] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH balance: ~$37,000 (est. ~3–4 months expenses). Target: 6–9 months. Building toward target through ongoing contributions.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2016

| Beginning AUM (January 1, 2016): | $410,000 |
| --- | --- |
| Net Contributions: | $48,000 |
| Investment Return (+8.0%): | $+32,800 (approx.) |
| Advisory Fees Paid: | ($4,300) |
| End AUM (December 31, 2016): | $486,000 |
| Total Household AUM Growth: | $+76,000  (+18.5%) |

Asset Allocation vs. Policy (Year-End 2016)

| Asset Class | IPS Target | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | 70% target | ~70% | On target |
| Fixed Income (UCBIX + MUNIX) | 28% target | ~28% | On target |
| Cash / Short-Term (STBIX) | 2% target | ~2% | On target |
| TOTAL Household Portfolio | 100% | 100% | Within drift bands |

Account-Level Summary (Year-End 2016)

| Account ID | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Joint Taxable Brokerage | Core equity + fixed + cash sleeve | ~$255,000 |
| ACCT-IRA1 | Alex Traditional IRA | Core bonds + equity sleeve | ~$175,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM growth tilt | ~$56,000 |
| ACCT-CASH | Cash Management (HYSA) | Emergency fund + liquidity | ~$37,000 (est.) |
| Household Total |  |  | $486,000 |

Performance Attribution (Full Year 2016)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity sleeve | ~+11% | Slight outperformance vs. S&P 500 +10% |
| International Equity (IDEIX) | ~+1% | Muted — Brexit dampened EAFE returns |
| Fixed Income (UCBIX + MUNIX) | ~+3% | Positive; benefited from pre-hike duration |
| Cash / STBIX | ~+0.5% | Low but capital-preserving |
| Overall Portfolio (net of fees) | ~+7.1% | Solid first year; IPS-2016 allocation appropriate |

SECTION 4 — TAX PLANNING RECAP

| Tax Year: | 2016 |
| --- | --- |
| Filing Status: | Married Filing Jointly (MFJ) |
| AGI (approx.): | $209,700 |
| Deduction Method: | Standard Deduction ($12,600) — elected |
| Net Capital Gains: | $3,500 (long-term, from routine rebalancing) |
| Federal Tax (approx.): | $35,183  |  Effective rate: 16.8% |
| State Tax (MN, approx.): | $13,025  |  Effective rate: 7.2% |
| Advisory Fees (not deductible): | $4,300  (investment expense deduction phase-out applies) |
| Full tax detail: | See DOC-TaxReturnSummary-2016-001 |

Charitable giving of $2,500 recorded but standard deduction elected; no itemization benefit in 2016. Clearwater recommends monitoring itemized deduction opportunities as income grows.

SECTION 5 — RECOMMENDATIONS & ACTION ITEMS

| Open 529 accounts for Maya & Eli: | Priority for Q1 2017 — GoalID-2016-02 |
| --- | --- |
| Accounts: ACCT-529A (Maya), ACCT-529B (Eli) |  |
| Monitor TCJA tax reform proposals: | Q4 2016 — planning memo to follow in 2017 |
| Annual IPS review: | Scheduled Q1 2017 — DOC-IPS-2016-001 to be reviewed |
| Risk questionnaire refresh: | Next scheduled: 2020 or upon major life event |
| Estate planning consultation: | Recommended for 2017–2018 as AUM grows |
| Beneficiary designations: | Review and confirm all accounts in Q1 2017 |

SECTION 6 — DOCUMENT CROSS-REFERENCES

| Investment Policy Statement: | DOC-IPS-2016-001 |
| --- | --- |
| Risk Questionnaire (baseline): | DOC-RiskQuestionnaire-2016-001 |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001  (1.00% flat fee) |
| Q4 Meeting Notes: | MtgID-2016Q4-01 |
| Tax Return Summary: | DOC-TaxReturnSummary-2016-001 |
| Goals (registered): | GoalID-2016-01, GoalID-2016-02, GoalID-2016-03 |
| Next Report: | DOC-AnnualConsolidatedReport-2017-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
