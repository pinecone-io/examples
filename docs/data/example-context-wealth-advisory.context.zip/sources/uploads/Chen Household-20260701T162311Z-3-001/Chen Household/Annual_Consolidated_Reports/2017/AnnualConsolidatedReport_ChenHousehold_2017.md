CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2017

Strong Growth Year — 401(k) Rollover & TCJA Tax Reform Planning

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2017 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 14, 2018 |
| Document ID: | DOC-AnnualConsolidatedReport-2017-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

2017 was an exceptional year on virtually every front. Equities surged 19%, your portfolio grew from $486,000 to $595,000, and you completed a key housekeeping milestone: the rollover of Alex’s prior employer 401(k) into your IRA — simplifying your retirement picture and giving us more control over investment allocation within those assets.

The year’s biggest planning event arrived in December with the signing of the Tax Cuts and Jobs Act. This landmark legislation nearly doubles the standard deduction, eliminates personal exemptions, lowers marginal rates, and caps the state and local tax deduction at $10,000. We have already begun modeling the impact for your household and will share a detailed planning memo early in 2018.

Retirement progress improved materially, and we’re tracking well toward all three of your foundational goals. Looking ahead, we expect Alex’s equity compensation to begin in 2018, which will introduce new planning dimensions around concentration risk and tax timing.

Warmly,

Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2017

Market Environment

| U.S. Equity (S&P 500): | $+19.4%  (broad-based, low-volatility bull market) |
| --- | --- |
| International Equity (MSCI EAFE): | $+25.0%  (strong year; USD weakening helped) |
| U.S. Bonds (Bloomberg Agg): | $+3.5%  (positive; Fed hiked 3× but gradually) |
| Fed Funds Rate: | 0.50% → 1.50%  (three 25 bps hikes in 2017) |
| Key Events: | TCJA signed Dec 22; Bitcoin mania; Trade war concerns begin |
| VIX Environment: | Historically low — record calm equity markets |
| IPS Allocation in Effect: | DOC-IPS-2016-001  |  70% Equity / 28% Fixed / 2% Cash |

Household Milestones

• Q3 2017: Alex’s prior-employer 401(k) directly rolled over to ACCT-401R (non-taxable)

• Q3 2017: ACCT-401R (Rollover IRA) to be consolidated into ACCT-IRA1 by March 31, 2018

• Q4 2017: TCJA signed — planning memo initiated (TaskID-2017Q4-001)

• Q4 2017: Annual review meeting — MtgID-2017Q4-01

• Q4 2017: 529 accounts (ACCT-529A, ACCT-529B) — recommendation still pending opening in 2018

SECTION 2 — FINANCIAL GOALS DASHBOARD

[ON TRACK ↑] GoalID-2016-01 — Retirement Readiness: Funded ratio improving. AUM $595,000 vs. $486,000 prior year (+22%). Strong equity performance and consistent contributions driving progress. Target retirement at ~age 60 (approx. 2043). Projection confidence: Moderate-Good. 401(k) rollover simplifies future planning.

[PENDING] GoalID-2016-02 — Education Funding (529s): 529 accounts not yet opened — carried forward from 2016 recommendation. Opening ACCT-529A (Maya, age 6) and ACCT-529B (Eli, age 3) remains a Q1 2018 priority. TCJA note: 529s now permitted for K-12 expenses up to $10K/yr under new law.

[BUILDING] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH estimated ~$44,000 — approaching 4–5 months target. Continued contributions to close the gap toward 6–9 months. On track.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2017

| Beginning AUM (January 1, 2017): | $486,000 |
| --- | --- |
| Net Contributions: | $52,000 |
| Investment Return (+12.0%): | $+64,800 (approx. on beginning balance) |
| Advisory Fees Paid: | ($5,100) |
| End AUM (December 31, 2017): | $595,000 |
| Total Household AUM Growth: | $+109,000  (+22.4%) |
| Note: | 401(k) rollover included in ACCT-IRA1 balance — non-taxable event |

Asset Allocation vs. Policy (Year-End 2017)

| Asset Class | IPS Target | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | 70% target | ~70% | On target |
| Fixed Income (UCBIX + UTIPX + MUNIX) | 28% target | ~28% | On target |
| Cash / STBIX | 2% target | ~2% | On target |
| TOTAL Household Portfolio | 100% | 100% | Within drift bands |

Account-Level Summary (Year-End 2017)

| Account | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Joint | Equity + fixed + cash | ~$320,000 |
| ACCT-IRA1 | Alex Trad. IRA | Core bonds + equity (incl. rollover) | ~$215,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM tilt | ~$60,000 |
| ACCT-CASH | Cash Mgmt (HYSA) | Emergency fund | ~$52,000 (est.) |
| ACCT-401R | Rollover IRA | Pending consolidation into IRA1 by Q1 2018 | Included above |
| Household Total |  |  | $595,000 |

Performance Attribution (Full Year 2017)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity (UECIX) | ~+20% | Broadly in-line with S&P 500 surge |
| International Equity (IDEIX) | ~+24% | Strong; benefited from USD weakness |
| Fixed Income (UCBIX + MUNIX) | ~+4% | Positive despite three Fed hikes |
| Cash / STBIX | ~+0.8% | Low but appropriate for reserve |
| Overall Portfolio (net of fees) | ~+11.1% | Strong year; allocation validated |

SECTION 4 — TAX PLANNING RECAP

| Tax Year: | 2017 |
| --- | --- |
| Filing Status: | MFJ |
| AGI (approx.): | $219,550 |
| Deduction Method: | Standard Deduction ($12,700) — last pre-TCJA year with exemptions |
| Personal Exemptions Claimed: | 4 × $4,050 = $16,200  (eliminated starting 2018 under TCJA) |
| Net Capital Gains: | $4,200  (rebalancing) |
| Federal Tax (approx.): | $38,917  |  Effective rate: 17.7% |
| State Tax (MN, approx.): | $14,299  |  Effective rate: 7.5% |
| TCJA Note: | New law effective TY2018; standard deduction rises to $24,000 MFJ — planning memo in progress |
| Full tax detail: | See DOC-TaxReturnSummary-2017-001 |

SECTION 5 — RECOMMENDATIONS & ACTION ITEMS

| Open 529 accounts (ACCT-529A, ACCT-529B): | Q1 2018 — CRITICAL; overdue from 2016 recommendation |
| --- | --- |
| TCJA impact modeling: | TaskID-2017Q4-001 — planning memo by Feb 2018 |
| Consolidate ACCT-401R into ACCT-IRA1: | By March 31, 2018 — complete non-taxable rollover |
| Prepare for equity comp (NLTK RSUs): | Alex’s promotion in 2018 will trigger RSU vesting — see EventID-2018-01 |
| Estate planning: | Recommend formal consultation in 2018–2019 (Westfield & Baker LLP) |
| Beneficiary review: | Confirm all account designations; note DOC-BeneficiaryForm-2018-001 to be filed |

SECTION 6 — DOCUMENT CROSS-REFERENCES

| IPS: | DOC-IPS-2016-001 |
| --- | --- |
| Meeting Notes (all quarters): | MtgID-2017Q1-01 through MtgID-2017Q4-01 |
| Annual Strategy Deck: | DOC-StrategyDeck-2017-001 |
| TCJA Planning Memo: | TaskID-2017Q4-001  |  KF-TCJA-Summary.md |
| Tax Return Summary: | DOC-TaxReturnSummary-2017-001 |
| Prior Report: | DOC-AnnualConsolidatedReport-2016-001 |
| Next Report: | DOC-AnnualConsolidatedReport-2018-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
