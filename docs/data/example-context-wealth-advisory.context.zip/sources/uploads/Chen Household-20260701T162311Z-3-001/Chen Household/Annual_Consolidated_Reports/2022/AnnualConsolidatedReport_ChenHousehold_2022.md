CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2022

Rate Hike Resilience & Strategic Tax-Loss Harvesting — Story Arc 1 Concludes

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Year: | 2022 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Document ID: | DOC-AnnualConsolidatedReport-2022-001 |
| Prepared By: | Morgan Park, CFP®  |  Lisa Torres, EA |
| Prepared Date: | January 222 |

SYNTHETIC DEMO DATA — For product demonstration purposes only. Not investment, tax, or legal advice.

1. ADVISOR LETTER

January 2023

Dear Alex and Sam,

2022 was one of the most challenging calendar years for investors in over a decade. The S&P 500 declined approximately 19%, and the Bloomberg Aggregate Bond Index fell roughly 13% — marking the worst year for the 60/40 portfolio in modern history. Seven Federal Reserve rate increases pushed the federal funds rate from near-zero in January to 4.25–4.50% by December, driven by inflation that peaked at 9.1% in June. The Russia-Ukraine conflict added further uncertainty to energy and commodity markets, and the collapse of FTX in November underscored systemic risks outside traditional markets.

Against this backdrop, your portfolio demonstrated meaningful resilience. The defensive repositioning we implemented in mid-2020 under IPS Amendment DOC-IPSAmendment-2020-001 — shifting from a 70/28/2 allocation to 60/35/5 — provided significant downside protection. The increased fixed income weight (now anchored by shorter-duration and TIPS holdings) cushioned the equity drawdown, even as bond prices broadly declined. Your household AUM ended the year at $890,000 — down from $952,000 at year-end 2021, but meaningfully better than a pure equity portfolio would have performed.

The year's defining planning action was the Tax-Loss Harvesting campaign executed in September (EventID-2022-01, DecisionID-2022-301). We swapped UECIX → UECIY and IDEIX → IDEIY in your taxable brokerage account (ACCT-TX01), crystallizing approximately $15,500 in net capital losses. This converts a painful market environment into a multi-year tax benefit: a $3,000 ordinary income deduction in 2022, with the remaining loss carried forward to offset future gains. Wash sale compliance was carefully managed; all swapped positions were held for the required 31-day window before any reversal.

We also note that the 2022 Annual Strategy Deck underwent a version correction this year. An earlier draft (DOC-StrategyDeck-2022-002) contained a stale fee reference of 1.00%. The final version (DOC-StrategyDeck-2022-003) correctly reflects the tiered schedule — 0.85% on the first $1.5M, 0.70% on the next $1.5M, 0.55% above $3M — as established in DOC-FeeAmendment-2021-001. Please ensure you reference the FINAL version for any fee-related questions.

Thank you for your continued trust. We remain committed to evidence-based planning across all market environments.

Warm regards,

Morgan Park, CFP® | Clearwater Wealth Partners

2. YEAR IN REVIEW — 2022 MARKET CONTEXT

Macroeconomic Environment

The Federal Reserve raised rates seven times in 2022, representing the fastest tightening cycle since the 1980s. Inflation peaked at 9.1% in June before beginning a gradual descent. The Russia-Ukraine war, supply chain disruptions, and elevated energy prices sustained inflationary pressure through most of the year. The S&P 500 entered bear market territory (−20%+ from peak) in June, while the Bloomberg Aggregate Bond Index posted its worst annual return in history (−13.0%). The traditional 60/40 portfolio provided no safe haven.

Key Market Metrics — 2022

| Market Indicator | 2022 Result |
| --- | --- |
| S&P 500 Return | −19.4% |
| Bloomberg Aggregate Bond | −13.0% |
| International Developed (MSCI EAFE) | −14.5% |
| Emerging Markets (MSCI EM) | −20.1% |
| US Core Bonds (UCBIX proxy) | −12.8% |
| TIPS (UTIPX proxy) | −7.7% |
| Municipal Bonds (MUNIX proxy) | −8.5% |
| Fed Funds Rate (Year-End) | 4.25–4.50% |
| CPI Inflation (Peak) | 9.1% (June 2022) |
| US 10-Year Treasury (Year-End) | 3.88% |

Portfolio Implications (IPS-2020 Framework)

Your portfolio operated under DOC-IPSAmendment-2020-001 (60/35/5 target allocation) throughout 2022. The elevated fixed income weight — which protected against equity drawdown in 2020 — offered less protection in 2022 than historical bond exposure would have, as rising rates drove bond prices lower. However, the inclusion of TIPS and shorter-duration instruments in ACCT-IRA1 meaningfully reduced duration risk relative to a long-duration bond benchmark. The tactical increase in MUNIX holdings in ACCT-TX01 provided tax efficiency on income as rates rose.

EventID-2022-01 (rate hike environment) drove the TLH decision. With equity markets in broad decline, identifying tax-loss opportunities in ACCT-TX01 was a natural priority. The September TLH campaign (DecisionID-2022-301) captured losses while maintaining market exposure through functionally equivalent substitute funds.

3. GOALS DASHBOARD

Reference: GoalID-2016-01, GoalID-2016-02, GoalID-2016-03

[ON TRACK] GoalID-2016-01 — Retirement Readiness: Funded ratio modestly reduced by 2022 drawdown but remains healthy. Household AUM $890K at year-end. 60/35/5 allocation maintained per IPS-2020. Retirement confidence model refreshed in Q4 2022 meeting (MtgID-2022Q4-01).

[BUILDING] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya) and ACCT-529B (Eli) show Q4 balances of $5,500 each. Market headwinds reduced values from 2021 peaks, but age-based moderate allocation is appropriate. Both accounts remain open and on automatic contribution schedule.

[MAINTAINED] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH year-end balance $31,000. Post-home-purchase normalized from elevated 2021 staging levels. Emergency fund target of 6–9 months expenses remains the guideline; slight decrease from Q3 to Q4 due to year-end expenses. Action item to review in Q1 2023.

4. PORTFOLIO SUMMARY

AUM Snapshot — Quarterly 2022

| Quarter | End AUM | Net Flows | Allocation | Note |
| --- | --- | --- | --- | --- |
| Q1 2022 | $910,000 | +$11,000 | 58% Eq / 37% FI / 5% Cash | IPS-2020 |
| Q2 2022 | $860,000 | +$9,000 | 57% Eq / 38% FI / 5% Cash | Bonds/equities both decline |
| Q3 2022 | $840,000 | +$9,500 | 56% Eq / 39% FI / 5% Cash | TLH executed late Q3 |
| Q4 2022 | $890,000 | +$10,000 | 58% Eq / 37% FI / 5% Cash | Recovery; swap positions held |

Account Balances — December 31, 2022

| Account | Balance | Notes |
| --- | --- | --- |
| ACCT-TX01 — Taxable Brokerage (Joint) | $450,000 | TLH swaps executed; UECIY/IDEIY held |
| ACCT-IRA1 — Alex Traditional IRA | $325,000 | UCBIX + UTIPX + equity sleeve |
| ACCT-RIRA — Alex Roth IRA | $73,000 | Small cap / EM tilt; long-term growth |
| ACCT-CASH — Cash Management | $31,000 | Emergency fund; normalized post-home-purchase |
| ACCT-529A — Maya 529 | $5,500 | Age-based moderate; Maya age 11 |
| ACCT-529B — Eli 529 | $5,500 | Age-based moderate; Eli age 8 |
| Household Total | $890,000 |  |

Allocation vs. IPS Policy (IPS-2020 Target: 60% Eq / 35% FI / 5% Cash)

| Asset Class | Actual | vs. IPS Target |
| --- | --- | --- |
| Equity (UECIY, IDEIX, EMEIX, RIRA tilt) | 58% | Within ±4% drift band |
| Fixed Income (UCBIX, UTIPX, MUNIX) | 37% | Slight overweight; protective positioning |
| Cash / Short-Term (STBIX, ACCT-CASH) | 5% | At target |
| NLTK Single Stock (in TX01) | <7% | Below 7% IPS concentration limit |

Performance Attribution — 2022

The portfolio's −6.5% total return (estimated, net of fees) outperformed the blended 60/40 benchmark (−14.2%) by approximately 770 basis points. Key contributors to relative outperformance: (1) reduced equity exposure vs. prior IPS-2016 70% target; (2) shorter bond duration reducing rate sensitivity; (3) MUNIX providing income with partial rate insulation at the taxable account level. The TLH campaign in ACCT-TX01 does not affect gross return but materially improves after-tax outcomes.

Story Arc 3 Note — Fee Document Version Reconciliation

This year, two versions of the Annual Strategy Deck were produced: DOC-StrategyDeck-2022-002 (v2) and DOC-StrategyDeck-2022-003 (FINAL). The v2 draft incorrectly references the legacy 1.00% advisory fee rate. The FINAL version reflects the correct tiered schedule per DOC-FeeAmendment-2021-001. Clients should rely solely on the FINAL version for fee-related disclosures. This discrepancy has been flagged internally and will be reviewed in 2023 as part of ongoing document governance.

5. TAX PLANNING RECAP — TAX YEAR 2022

Reference: TaxTopicID-2022-01 | Tax Specialist: Lisa Torres, EA

| Tax Line Item | TY2022 Amount |
| --- | --- |
| W-2 Wages (Alex + Sam combined) | $258,000 |
| Other Income (RSU / SE income) | $10,000 |
| Interest & Dividend Income | $1,650 |
| Net Capital Gains / (Losses) | (−$15,500) |
| Charitable Contributions | $5,000 |
| Deduction Method | Itemized |
| Approximate Adjusted Gross Income (AGI) | ~$275,000 |
| Federal Effective Tax Rate (Est.) | ~18.5% |
| Key Event | TLH Campaign — DecisionID-2022-301 |

Tax-Loss Harvesting Outcome — TaxTopicID-2022-01

The TLH campaign executed under DecisionID-2022-301 (September 5–30, 2022) crystallized approximately $15,500 in net capital losses in ACCT-TX01. Per the U.S. Tax Code, $3,000 of this loss offsets ordinary income in 2022, generating an estimated federal tax savings of approximately $990 at the 33% marginal bracket. The remaining $12,500 carries forward to offset future capital gains — directly applicable against the expected gains from equity compensation events in 2023.

Wash sale rules were carefully observed. UECIX positions were replaced with the near-identical UECIY fund; IDEIX was swapped for IDEIY. A 31-day holding period was maintained before any reversal. This compliance approach is documented in TaxPlanningMemo-TLH-DecisionID-2022-301.pdf and the 2022 1099 Bundle for ACCT-TX01.

Note: 2022 is the first full year of itemized deductions (following the home purchase in EventID-2021-01), reinforcing the value of the mortgage interest deduction alongside charitable contributions and state/local taxes.

6. RECOMMENDATIONS & ACTION ITEMS

| RecID / Item | Description | Status | Reference |
| --- | --- | --- | --- |
| RecID-2022-01 | TLH Program | Implemented | DecisionID-2022-301 |
| RecID-2023-01 (Preview) | DAF for high-income year | Pending — 2023 Q2 | EventID-2023-01 |
| Story Arc 3 | Fee doc reconciliation | In Review | DOC-StrategyDeck-2022-002/003 |
| 529 Annual Review | Review contribution targets | Due Q1 2023 | GoalID-2016-02 |

7. DOCUMENT CROSS-REFERENCES

| Document | ID / Filename |
| --- | --- |
| IPS Amendment (2020) | DOC-IPSAmendment-2020-001 |
| Fee Amendment (2021) | DOC-FeeAmendment-2021-001 |
| TLH Tax Planning Memo | TaxPlanningMemo-TLH-DecisionID-2022-301.pdf |
| Annual Strategy Deck (FINAL) | DOC-StrategyDeck-2022-003 |
| Annual Strategy Deck (v2 — stale fee) | DOC-StrategyDeck-2022-002 |
| 1099 Bundle TY2022 | 1099Bundle_ChenHousehold_TY22.pdf |
| Tax Return Summary TY2022 | TaxReturnSummary_ChenHousehold_TY22.docx |
| Meeting Notes Q3 2022 | MeetingNotes_ChenHousehold_MtgID-2022Q3-01.pdf |
| Market Commentary Q3 2022 | MarketCommentary_2022Q3.pdf |
| This Document | DOC-AnnualConsolidatedReport-2022-001 |
