CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2018

Equity Compensation Begins — Volatility Returns & NLTK Concentration Introduced (EventID-2018-01)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2018 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 13, 2019 |
| Document ID: | DOC-AnnualConsolidatedReport-2018-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

2018 was a year of important firsts and a timely reminder of how markets can behave. Alex’s promotion brought the first tranche of NLTK Restricted Stock Units — a meaningful addition to your total compensation and a new planning dimension we will actively manage together. At the same time, equity markets fell roughly 6% for the year, with a sharp December selloff that tested investor resolve across the board.

Despite the headwinds, your portfolio ended the year at $608,000 — up from $595,000 a year ago — largely due to your continued $55,000 in contributions and the defensiveness built into your fixed income sleeve. Your allocation to UCBIX and MUNIX provided meaningful ballast when equities declined in Q4.

The NLTK equity comp introduces two priorities for 2019: (1) developing a systematic diversification plan to prevent excessive concentration in a single employer stock, and (2) ongoing tax planning around the RSU vest schedule. We also note that 2018 was the first year your AGI exceeded $250,000 — bringing the Net Investment Income Tax into scope for the first time.

Warmly,

Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2018

Market Environment

| U.S. Equity (S&P 500): | −6.2%  (first negative year since 2008; Q4 alone −14%) |
| --- | --- |
| International Equity (MSCI EAFE): | −13.4%  (trade war fears; dollar strength) |
| U.S. Bonds (Bloomberg Agg): | −1.0%  (rates rising; four Fed hikes in 2018) |
| Fed Funds Rate: | 1.50% → 2.50%  (four 25 bps hikes; fastest pace in a decade) |
| Key Events: | Trade war (China); Q4 equity selloff; volatility spike (VIX >36 in Dec) |
| Portfolio Impact: | Fixed income sleeve cushioned equity decline; portfolio down modestly net-of-contributions |
| IPS Allocation in Effect: | DOC-IPS-2016-001  |  70% Equity / 28% Fixed / 2% Cash |

Household Milestones

• EventID-2018-01: Alex promoted; NLTK RSU grant initiated (first vest Q2 2018)

• NLTK shares (480 retained) now held in ACCT-TX01; concentration ~4% of taxable portfolio

• Q1 2018: ACCT-401R fully consolidated into ACCT-IRA1 (completed March 2018)

• TCJA fully effective: standard deduction $24,000 MFJ, personal exemptions eliminated

• Q4 meeting: Reviewed volatility response, NLTK concentration plan, estate planning need

• Insurance review completed: coverage adequate for current household structure

SECTION 2 — FINANCIAL GOALS DASHBOARD

[ON TRACK (RESILIENT)] GoalID-2016-01 — Retirement Readiness: AUM $608,000 despite negative equity markets — testament to contributions and fixed income ballast. Funded ratio continuing to build. NLTK equity comp will accelerate progress if managed prudently. Horizon: ~22 years to target retirement age.

[PENDING — URGENT] GoalID-2016-02 — Education Funding (529s): 529 accounts still not opened. Maya now age 7; Eli age 4. Time horizon shortening. ACCT-529A and ACCT-529B opening scheduled for Q1 2019 — overdue from original 2016 recommendation. Tax-advantaged growth window is narrowing.

[ON TRACK] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH estimated ~$45,000 (approx. 4–5 months expenses). Approaching target range of 6–9 months. NLTK concentration review may require temporarily higher cash reserves as vesting events occur.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2018

| Beginning AUM (January 1, 2018): | $595,000 |
| --- | --- |
| Net Contributions: | $55,000 |
| Investment Return (−6.0% net): | (−35,700)  (approx. on beginning balance) |
| Advisory Fees Paid: | ($6,200) |
| End AUM (December 31, 2018): | $608,000 |
| Total Household AUM Growth: | $+13,000  (+2.2%)  — contributions exceeded losses |

Asset Allocation vs. Policy (Year-End 2018)

| Asset Class | IPS Target | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK + USCIX) | 70% target | ~69% | Within drift band |
| Fixed Income (UCBIX + UTIPX + MUNIX) | 28% target | ~29% | Within drift band |
| Cash / STBIX | 2% target | ~2% | On target |
| NLTK Single Stock (within equity sleeve) | <10% IPS limit | ~4% | Within limit |
| TOTAL Household Portfolio | 100% | 100% | All within drift bands |

Account-Level Summary (Year-End 2018)

| Account | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Joint | Equity + fixed + NLTK shares | ~$330,000 |
| ACCT-IRA1 | Alex Trad. IRA (incl. rollover) | Bonds + equity (fully consolidated) | ~$220,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM tilt | ~$58,000 |
| ACCT-CASH | Cash Mgmt (HYSA) | Emergency fund | ~$45,000 (est.) |
| Household Total |  |  | $608,000 |

NLTK Equity Concentration Summary

| NLTK Shares Held (ACCT-TX01): | 480 shares |
| --- | --- |
| Estimated Value (year-end 2018): | ~$24,000 (approx.) |
| % of Taxable Portfolio (ACCT-TX01): | ~7% |
| % of Total Household AUM: | ~4% |
| IPS Single-Stock Concentration Limit: | <10%  (DOC-IPS-2016-001) |
| Status: | Within policy limit; monitoring required as future tranches vest |
| Reference: | EventID-2018-01  |  KF-RSU-Taxation.md  |  KF-Concentration-Risk.md |

Performance Attribution (Full Year 2018)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | ~−7% | In-line with broad market decline |
| International Equity (IDEIX) | ~−13% | Trade war + USD headwinds |
| Fixed Income (UCBIX + UTIPX) | ~−1% | Rising rates hurt; MUNIX provided partial offset |
| Cash / STBIX | ~+1.5% | Benefited from Fed hikes; money market yields improved |
| Overall Portfolio (net of fees) | ~−4.5% | Better than blended benchmark; fixed income cushioned |

SECTION 4 — TAX PLANNING RECAP

| Tax Year: | 2018  —  TCJA Year One |
| --- | --- |
| Filing Status: | MFJ |
| AGI (approx.): | $260,500 |
| Deduction Method: | Standard Deduction ($24,000)  —  TCJA doubled MFJ deduction |
| NLTK RSU Vest (in W-2): | $25,000 FMV at vest included in Alex’s W-2 |
| Net Capital Gains: | $6,000  (LT rebalancing + ST shares sold at vest) |
| NIIT (first year): | $394  (AGI $260,500 > $250,000 MFJ threshold) |
| Child Tax Credit (TCJA): | $4,000  ($2,000/child — doubled under new law) |
| Federal Tax (approx.): | $41,263  |  Effective rate: 15.8% |
| State Tax (MN): | $17,355  |  MN does not conform to TCJA; separate MN deduction schedule |
| Full tax detail: | See DOC-TaxReturnSummary-2018-001 |

MN Non-Conformity Note: Minnesota did not adopt the TCJA increased standard deduction. MN uses its own deduction and rate schedule. Lisa Torres, EA handles MN-specific modeling.

SECTION 5 — RECOMMENDATIONS & ACTION ITEMS

| Open 529 accounts — IMMEDIATE PRIORITY: | Q1 2019 — GoalID-2016-02 (3rd consecutive year carried over) |
| --- | --- |
| NLTK diversification plan: | Develop systematic reduction strategy; annual vest schedule review — KF-Concentration-Risk.md |
| Estate planning consultation: | EventID-2019-01 expected — revocable trust formation in 2019 |
| Beneficiary designations: | DOC-BeneficiaryForm-2018-001 filed; review for trust alignment post-trust creation |
| Insurance adequacy: | Completed; no changes required |
| NIIT planning: | AGI above $250K MFJ threshold; monitor NII sources as portfolio grows |
| Risk questionnaire: | Next formal review 2020 or upon major life event |

SECTION 6 — DOCUMENT CROSS-REFERENCES

| IPS: | DOC-IPS-2016-001 |
| --- | --- |
| Life Event (equity comp): | EventID-2018-01 |
| Meeting Notes (Q4): | MtgID-2018Q4-01 |
| Trade Proposal (rebalance): | DOC-TradeProposal-2018Q4-001 |
| Beneficiary Form: | DOC-BeneficiaryForm-2018-001  (note: outdated contingent to be updated post-trust) |
| Tax Return Summary: | DOC-TaxReturnSummary-2018-001 |
| Knowledge Files: | KF-RSU-Taxation.md  |  KF-Concentration-Risk.md  |  KF-TCJA-Summary.md |
| Prior Report: | DOC-AnnualConsolidatedReport-2017-001 |
| Next Report: | DOC-AnnualConsolidatedReport-2019-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
