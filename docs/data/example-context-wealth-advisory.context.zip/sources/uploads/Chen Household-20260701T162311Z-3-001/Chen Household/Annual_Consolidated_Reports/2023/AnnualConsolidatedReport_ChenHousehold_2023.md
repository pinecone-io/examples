CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2023

Liquidity Event, DAF Establishment & Diversification — Story Arc 2 Begins

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Year: | 2023 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Document ID: | DOC-AnnualConsolidatedReport-2023-001 |
| Prepared By: | Morgan Park, CFP®  |  Lisa Torres, EA |
| Prepared Date: | January 223 |

SYNTHETIC DEMO DATA — For product demonstration purposes only. Not investment, tax, or legal advice.

1. ADVISOR LETTER

January 2024

Dear Alex and Sam,

2023 was a landmark year for your financial plan — arguably the most complex and consequential since you began working with Clearwater Wealth Partners in 2016. The S&P 500 recovered strongly with a +24% total return, the Federal Reserve paused rate hikes after July (last increase was the 11th since March 2022), and disinflation continued toward the 2% target. The AI investment boom, driven by the mainstream adoption of large language models, rewarded technology and innovation-oriented holdings. The regional banking crisis in March (Silicon Valley Bank, Signature Bank) created brief volatility but did not alter the macro trajectory.

The defining event of your year was a significant NLTK equity compensation vesting (EventID-2023-01). A large RSU vest increased your NLTK single-stock exposure substantially, pushing concentration well above the 7% IPS limit. We acted quickly: the three-phase diversification plan under DecisionID-2023-349 reduced NLTK exposure in ACCT-TX01 between April and June, while simultaneously funding the Clearwater Giving Fund DAF with $25,000 in appreciated securities. The DAF contribution serves double duty — accelerating charitable giving and generating a significant itemized deduction in a high-income year where your AGI spiked to approximately $426,000.

This is the pivotal year where your household AUM crossed the $1,000,000 milestone — ending 2023 at $1,140,000. The crossing reflects both the liquidity event inflows and strong market appreciation. Equally important, it marks the activation of the second tier of your advisory fee schedule (0.70% on the increment above $1.5M, once reached).

The 2022 capital loss carryforward of ~$12,500 partially offset the $42,000 in realized gains from the NLTK diversification and down-payment-related trading, reducing your net taxable gains to approximately $29,500. Even so, this is a high-income year requiring estimated tax payments and careful Q4 planning — all coordinated with Lisa Torres, EA.

A referral from Alex's professional network, Alex Navarro (ProspectID-2023-01), was introduced in Q2. Initial conversations are underway; a formal discovery meeting is planned for early 2024.

Looking ahead to 2024: estate planning urgency rises — details in Section 3.

Warm regards,

Morgan Park, CFP® | Clearwater Wealth Partners

2. YEAR IN REVIEW — 2023 MARKET CONTEXT

Macroeconomic Environment

After 2022's historic selloff, 2023 delivered a strong reversal. Equity markets surged, led by technology and AI-adjacent names. The Fed's final rate hike in July 2023 signaled the end of the tightening cycle, and investors began pricing in eventual rate cuts in 2024. Inflation continued to moderate (from 6% in January to ~3.4% in December). The SVB crisis in March raised systemic concerns briefly, but swift regulatory action contained contagion. The debt ceiling standoff in May–June added short-term volatility before resolution.

Key Market Metrics — 2023

| Market Indicator | 2023 Result |
| --- | --- |
| S&P 500 Return | +24.2% |
| Bloomberg Aggregate Bond | +5.5% |
| International Developed (MSCI EAFE) | +18.2% |
| Emerging Markets (MSCI EM) | +9.8% |
| US Core Bonds (UCBIX proxy) | +5.2% |
| TIPS (UTIPX proxy) | +3.9% |
| Municipal Bonds (MUNIX proxy) | +6.4% |
| Fed Funds Rate (Year-End) | 5.25–5.50% |
| CPI Inflation (Year-End) | ~3.4% |
| US 10-Year Treasury (Year-End) | 3.97% |

Portfolio Implications (IPS-2020 Framework)

Your portfolio operated under DOC-IPSAmendment-2020-001 (60/35/5 target) through most of 2023. The strong equity market drove allocation drift toward the equity overweight band by Q4 (reaching 62% equity vs. 60% target). The NLTK liquidity event required active management to prevent concentration from breaching the 7% IPS limit. The three-phase diversification under DecisionID-2023-349 — April through June — reduced NLTK from a ~9% concentration post-vest to approximately 5% by year-end, now within the single-stock limit. The DAF contribution ($25,000 in appreciated NLTK shares) accelerated giving and avoided recognition of the embedded gain.

3. GOALS DASHBOARD

Reference: GoalID-2016-01, GoalID-2016-02, GoalID-2016-03, GoalID-2023-01

[IMPROVING] GoalID-2016-01 — Retirement Readiness: Household AUM $1,140,000. Liquidity event materially improved retirement confidence projections. Updated projection modeled in Q4 meeting (MtgID-2023Q4-01): confidence level increased from ~72% to ~84% (30-year horizon, $185K/yr target). Bucket strategy discussion previewed for 2025 implementation.

[BUILDING] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya, age 12) balance $7,500; ACCT-529B (Eli, age 9) balance $7,500. Strong market performance offset by Q3 NLTK concentration reduction (partially funded via TX01 rebalancing). 529 tune-up conversation held at MtgID-2023Q3-01 — contribution targets reviewed; current pace not fully funded for full four-year costs. 2024 action item: increase annual contributions.

[MONITORING] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH year-end balance $25,000. Lower than target 6–9 months expenses (~$35–50K range) due to reallocation activity and higher spending tied to NLTK vest proceeds. Action item: rebuild cash buffer in H1 2024.

[ESTABLISHED] GoalID-2023-01 — Values-Based Giving Plan: Clearwater Giving Fund (DAF) opened Q2 2023. Initial contribution: $25,000 in appreciated NLTK shares (avoiding embedded capital gain). Charitable deduction claimed on 2023 return under DAF bunching strategy. Planned distributions to education-focused nonprofits in 2024–2025. Reference: RecID-2023-01, DecisionID-2023-349.

4. PORTFOLIO SUMMARY

AUM Snapshot — Quarterly 2023

| Quarter | End AUM | Net Flows | Allocation | Note |
| --- | --- | --- | --- | --- |
| Q1 2023 | $920,000 | +$10,500 | 58% Eq / 37% FI / 5% Cash | TLH positions held; monitoring wash sale window |
| Q2 2023 | $1,020,000 | +$55,000 | 60% Eq / 35% FI / 5% Cash | RSU vest inflows; NLTK spike; DAF funded |
| Q3 2023 | $1,080,000 | +$20,000 | 61% Eq / 34% FI / 5% Cash | Concentration reduction phase 2–3 |
| Q4 2023 | $1,140,000 | +$15,000 | 62% Eq / 33% FI / 5% Cash | AUM milestone; equity drift top of band |

Account Balances — December 31, 2023

| Account | Balance | Notes |
| --- | --- | --- |
| ACCT-TX01 — Taxable Brokerage (Joint) | $620,000 | NLTK reduced to ~5%; UECIY→UECIX swap complete |
| ACCT-IRA1 — Alex Traditional IRA | $395,000 | UCBIX + UTIPX + rebalanced equity sleeve |
| ACCT-RIRA — Alex Roth IRA | $85,000 | Small cap / EM tilt; strong 2023 equity gains |
| ACCT-CASH — Cash Management | $25,000 | Below target; rebuild action in 2024 |
| ACCT-529A — Maya 529 | $7,500 | Age-based moderate; strong recovery from 2022 lows |
| ACCT-529B — Eli 529 | $7,500 | Age-based moderate; on track |
| Clearwater Giving Fund (DAF) | ~$25,000 | (Not in AUM; administered separately by Clearwater Giving Fund) |
| Household AUM Total | $1,140,000 | Crosses $1M milestone in 2023 |

Allocation vs. IPS Policy (IPS-2020 Target: 60% Eq / 35% FI / 5% Cash)

| Asset Class | Actual | vs. IPS Target |
| --- | --- | --- |
| Equity (UECIX restored, IDEIX, EMEIX, RIRA tilt, NLTK ~5%) | 62% | At top of ±4% drift band |
| Fixed Income (UCBIX, UTIPX, MUNIX) | 33% | Slight underweight — monitor Q1 2024 |
| Cash / Short-Term (STBIX, ACCT-CASH) | 5% | At target |
| NLTK Single Stock (in TX01) | ~5% | Below 7% IPS limit — within policy |

NLTK Concentration Reduction — DecisionID-2023-349

Three-phase execution (April 10 – June 30, 2023): Phase 1 — sell NLTK to fund DAF contribution ($25,000 in appreciated shares, zero capital gains recognition); Phase 2 — sell NLTK proceeds reinvested into UECIX (diversification); Phase 3 — final NLTK trim to bring exposure below 7% IPS limit. Total NLTK reduction: ~$38,000 in proceeds. The 2022 capital loss carryforward ($12,500) was applied against Phase 2 gains. Residual net taxable gains: ~$29,500.

5. TAX PLANNING RECAP — TAX YEAR 2023

Reference: TaxTopicID-2023-01 | Tax Specialist: Lisa Torres, EA

| Tax Line Item | TY2023 Amount |
| --- | --- |
| W-2 Wages (Alex + Sam combined) | $262,000 |
| Other Income (RSU / equity comp vest) | $120,000 |
| Interest & Dividend Income | $2,100 |
| Net Capital Gains | $42,000 |
| Less: 2022 Capital Loss Carryforward | (−$12,500) |
| Charitable Contributions (DAF) | $25,000 |
| Deduction Method | Itemized |
| Approximate Adjusted Gross Income (AGI) | ~$426,000 |
| Federal Effective Tax Rate (Est.) | ~27.5% |
| Key Event | RSU Vest + DAF — EventID-2023-01 |

DAF Bunching Strategy — TaxTopicID-2023-01

With AGI spiking to ~$426,000 due to the RSU vest, 2023 was the optimal year to maximize charitable deductions. The Clearwater Giving Fund DAF contribution of $25,000 in appreciated NLTK shares provides a full fair-market-value deduction without recognizing the embedded capital gain on those shares — a dual tax benefit worth an estimated $8,700 in avoided gain tax plus the deduction value at the marginal rate. Lisa Torres, EA, coordinated estimated Q3 and Q4 payments to avoid underpayment penalties given the income spike.

The 2022 capital loss carryforward ($12,500) was strategically applied against the largest short-term gain tranche from the NLTK diversification, reducing net capital gain tax exposure by an estimated $3,000+. The remaining net gain of ~$29,500 was taxed at favorable long-term rates where applicable.

6. RECOMMENDATIONS & ACTION ITEMS

| RecID / Item | Description | Status | Reference |
| --- | --- | --- | --- |
| RecID-2023-01 | DAF establishment | Implemented | GoalID-2023-01 / DecisionID-2023-349 |
| 2024 Preview | Estate/beneficiary audit | Due Q1 2024 | EventID-2024-01 (upcoming) |
| GoalID-2016-02 | Increase 529 contributions | Due Q1 2024 | ACCT-529A, ACCT-529B |
| GoalID-2016-03 | Rebuild ACCT-CASH buffer | Due H1 2024 | Target $40–50K |
| ProspectID-2023-01 | Alex Navarro discovery meeting | Due Q1 2024 | MtgID-2023Q2-01 |
| Story Arc 3 | Fee version reconciliation — ongoing | Monitor 2024 | DOC-FeeAmendment-2021-001 |

7. DOCUMENT CROSS-REFERENCES

| Document | ID / Filename |
| --- | --- |
| IPS Amendment (2020) | DOC-IPSAmendment-2020-001 |
| Fee Amendment (2021) | DOC-FeeAmendment-2021-001 |
| Trust Document (2019) | DOC-Trust-2019-001 |
| DAF Establishment Packet | DAFEstablishmentPacket_ClearwaterGivingFund_2023.pdf |
| Tax Planning Memo (High-Income Year) | TaxPlanningMemo_HighIncomeYear_TaxTopicID-2023-01.pdf |
| Trade Proposal — NLTK Diversification | TradeProposal_ChenHousehold_DecisionID-2023-349.pdf |
| 1099 Bundle TY2023 | 1099Bundle_ChenHousehold_TY23.pdf |
| Tax Return Summary TY2023 | TaxReturnSummary_ChenHousehold_TY23.docx |
| Referral Intake Note — Alex Navarro | ReferralIntakeNote_Navarro_ProspectID-2023-01.pdf |
| Meeting Notes Q2 2023 | MeetingNotes_ChenHousehold_MtgID-2023Q2-01.pdf |
| This Document | DOC-AnnualConsolidatedReport-2023-001 |
