CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2024

Estate Planning Audit & Beneficiary Correction — Story Arc 2 Continues

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Year: | 2024 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Document ID: | DOC-AnnualConsolidatedReport-2024-001 |
| Prepared By: | Morgan Park, CFP®  |  Lisa Torres, EA  |  Logan Hart, JD |
| Prepared Date: | January 2024 |

SYNTHETIC DEMO DATA — For product demonstration purposes only. Not investment, tax, or legal advice.

1. ADVISOR LETTER

January 2025

Dear Alex and Sam,

2024 was a year defined by personal urgency and meaningful planning action. The S&P 500 continued its strong performance (+23%), the Federal Reserve began cutting rates in September following two years of restrictive policy, and inflation approached its 2% target. For your household, however, the most significant development was not in the markets — it was the family health event in early 2024 (EventID-2024-01) that prompted a thorough review of your estate structure, beneficiary designations, and healthcare directives.

The estate audit revealed a meaningful discrepancy: DOC-BeneficiaryForm-2018-001 (on file for ACCT-IRA1 and ACCT-RIRA) listed Alex's parent as the contingent beneficiary — a designation that predated your revocable trust (DOC-Trust-2019-001) and your 2024 planning priorities. The updated DOC-BeneficiaryForm-2024-001 now designates the Chen Family Revocable Trust as the contingent beneficiary for both retirement accounts, with the surviving spouse as primary — consistent with your estate plan as structured by Westfield & Baker LLP. This correction was completed and confirmed in MtgID-2024Q3-01.

Healthcare directives were also updated for both Alex and Sam to reflect current wishes. Logan Hart, JD reviewed all estate documents for consistency, and a formal trust summary letter was issued. These updates were captured under RecID-2024-01.

From a portfolio standpoint, your AUM grew to $1,285,000 at year-end, supported by strong equity markets and consistent contributions. Allocation remained stable at 62/33/5 throughout the year, within the IPS-2020 drift parameters. The 529 accounts showed meaningful progress: ACCT-529A (Maya, now 13) grew to $17,500 and ACCT-529B (Eli, now 10) to $17,500.

Warm regards,

Morgan Park, CFP® | Clearwater Wealth Partners

2. YEAR IN REVIEW — 2024 MARKET CONTEXT

Macroeconomic Environment

The Federal Reserve pivoted to rate cuts in September 2024, beginning with a 50-basis-point reduction — the first cut since 2020. Two additional cuts followed before year-end, bringing the federal funds rate to 4.25–4.50% by December. Inflation moderated to near the 2% target. U.S. equities continued their strong run, with broad participation across sectors driven by resilient corporate earnings and AI investment. Election year volatility was brief and contained. Strong employment and consumer spending supported economic expansion.

Key Market Metrics — 2024

| Market Indicator | 2024 Result |
| --- | --- |
| S&P 500 Return | +23.3% |
| Bloomberg Aggregate Bond | +5.5% |
| International Developed (MSCI EAFE) | +3.8% |
| Emerging Markets (MSCI EM) | +7.5% |
| US Core Bonds (UCBIX proxy) | +5.0% |
| TIPS (UTIPX proxy) | +4.2% |
| Municipal Bonds (MUNIX proxy) | +4.8% |
| Fed Funds Rate (Year-End) | 4.25–4.50% |
| CPI Inflation (Year-End) | ~2.7% |
| US 10-Year Treasury (Year-End) | 4.57% |

Portfolio Implications (IPS-2020 Framework)

IPS-2020 (60/35/5 target) remained in effect through 2024. With equity markets up 23%, natural drift continued pushing allocation toward the top of the equity band (62% actual vs. 60% target — within ±4% tolerance). No rebalancing was triggered. The Fed rate cuts drove bond prices modestly higher, which benefited UCBIX and UTIPX positions in ACCT-IRA1. Rate cuts also improved the total return outlook on MUNIX (municipal bond) holdings in ACCT-TX01. ACCT-CASH benefited from elevated money market rates through the first three quarters before declining modestly in Q4 as rates fell.

3. GOALS DASHBOARD

Reference: GoalID-2016-01, GoalID-2016-02, GoalID-2016-03, GoalID-2023-01

[STRONG] GoalID-2016-01 — Retirement Readiness: Household AUM $1,285,000. Updated retirement projection (Q4 2024): projected confidence level ~88% (30-year horizon, $185K/yr target in today's dollars). Bucket strategy preview discussed in Q4 meeting — formal IPS amendment planned for Q1 2025. Alex age 41; Sam age 40. Approximate retirement timeline: ~2043.

[BUILDING] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya, age 13) balance $17,500 — 2029 enrollment target. ACCT-529B (Eli, age 10) balance $17,500 — 2032 enrollment target. Contribution pace accelerated in 2024 per action item from 2023 ACR. Projected shortfall vs. full four-year cost (~$250K); annual contribution analysis to be refreshed in 2025.

[MAINTAINED] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH year-end balance $25,000. Stable but below the 6–9 month target range of $40–50K. Integration with 2025 bucket strategy planned: ACCT-CASH will form part of Bucket 1 under IPS-2025.

[ACTIVE] GoalID-2023-01 — Values-Based Giving Plan: Clearwater Giving Fund DAF: annual charitable grants totaling $6,000 distributed in 2024 to education-focused nonprofits. Fund balance maintained for multi-year giving. 2025 distribution plan to be coordinated with tax planning and charitable bunching strategy.

4. PORTFOLIO SUMMARY

AUM Snapshot — Quarterly 2024

| Quarter | End AUM | Net Flows | Allocation | Note |
| --- | --- | --- | --- | --- |
| Q1 2024 | $1,170,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Steady growth; estate audit begins |
| Q2 2024 | $1,205,000 | +$12,000 | 61% Eq / 34% FI / 5% Cash | Estate review in progress |
| Q3 2024 | $1,230,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Beneficiary correction complete |
| Q4 2024 | $1,285,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Fed cuts begin; bucket planning previewed |

Account Balances — December 31, 2024

| Account | Balance | Notes |
| --- | --- | --- |
| ACCT-TX01 — Taxable Brokerage (Joint) | $700,000 | NLTK ~4%; UECIX + MUNIX + IDEIX |
| ACCT-IRA1 — Alex Traditional IRA | $430,000 | UCBIX + UTIPX + equity sleeve; beneficiary corrected |
| ACCT-RIRA — Alex Roth IRA | $95,000 | Small cap / EM tilt; beneficiary corrected |
| ACCT-CASH — Cash Management | $25,000 | Emergency fund; below target |
| ACCT-529A — Maya 529 | $17,500 | Age-based moderate; Maya age 13 |
| ACCT-529B — Eli 529 | $17,500 | Age-based moderate; Eli age 10 |
| Household Total | $1,285,000 |  |

Estate Update — Beneficiary Correction (EventID-2024-01)

| Estate Item | Detail |
| --- | --- |
| Previous Designation (ACCT-IRA1 & RIRA) | DOC-BeneficiaryForm-2018-001: Alex's parent as contingent |
| Corrected Designation | DOC-BeneficiaryForm-2024-001: Spouse primary; Chen Family Revocable Trust contingent |
| Trust Document Reference | DOC-Trust-2019-001 |
| Estate Attorney | Logan Hart, JD  |  Westfield & Baker LLP |
| Action Closed | MtgID-2024Q3-01  |  RecID-2024-01 |

5. TAX PLANNING RECAP — TAX YEAR 2024

Reference: Lisa Torres, EA

| Tax Line Item | TY2024 Amount |
| --- | --- |
| W-2 Wages (Alex + Sam combined) | $270,000 |
| Other Income (RSU / equity comp) | $15,000 |
| Interest & Dividend Income | $2,250 |
| Net Capital Gains | $14,500 |
| Charitable Contributions (DAF grants) | $6,000 |
| Deduction Method | Itemized |
| Approximate Adjusted Gross Income (AGI) | ~$302,000 |
| Federal Effective Tax Rate (Est.) | ~22.0% |
| Key Planning Note | Normalized income year; continued itemized deductions |

2024 is a relative 'normalization' year following the elevated AGI of 2023 ($426K). With no large RSU vest, income reverts to a more predictable profile. Capital gains of $14,500 reflect normal rebalancing activity in ACCT-TX01. Itemized deductions include mortgage interest (EventID-2021-01 home purchase), state/local taxes, and the $6,000 in DAF distributions. Continued coordination with Lisa Torres, EA on estimated payments and Q4 planning.

6. RECOMMENDATIONS & ACTION ITEMS

| RecID / Item | Description | Status | Reference |
| --- | --- | --- | --- |
| RecID-2024-01 | Estate refresh + beneficiary correction | Complete Q3 2024 | EventID-2024-01 |
| DOC-IPSAmendment-2025-001 | IPS bucket strategy amendment | Due Q1 2025 | DecisionID-2025-112 |
| GoalID-2016-02 | 529 college funding analysis | Due Q1 2025 | ACCT-529A, ACCT-529B |
| GoalID-2016-03 | Integrate ACCT-CASH into Bucket 1 | Due Q1 2025 | IPS-2025 |
| RecID-2025-02 | Social Security claiming analysis | Planned 2025 Q3 | GoalID-2016-01 |
| ProspectID-2025-01 Preview | Taylor Chen (sibling) — discovery | 2025 Q1 | MtgID-2024Q4-01 |

7. DOCUMENT CROSS-REFERENCES

| Document | ID / Filename |
| --- | --- |
| IPS Amendment (2020) | DOC-IPSAmendment-2020-001 |
| Fee Amendment (2021) | DOC-FeeAmendment-2021-001 |
| Trust Document (2019) | DOC-Trust-2019-001 |
| Old Beneficiary Form (IRA — MISMATCH) | DOC-BeneficiaryForm-2018-001 |
| Corrected Beneficiary Form | DOC-BeneficiaryForm-2024-001 |
| Estate Planning Review | EstatePlanningReview_ChenHousehold_EventID-2024-01.pdf |
| Trust/Attorney Summary Letter | TrustSummaryLetter_HawthorneColeLLP_2024.pdf |
| Tax Return Summary TY2024 | TaxReturnSummary_ChenHousehold_TY24.docx |
| Meeting Notes Q3 2024 | MeetingNotes_ChenHousehold_MtgID-2024Q3-01.pdf |
| This Document | DOC-AnnualConsolidatedReport-2024-001 |
