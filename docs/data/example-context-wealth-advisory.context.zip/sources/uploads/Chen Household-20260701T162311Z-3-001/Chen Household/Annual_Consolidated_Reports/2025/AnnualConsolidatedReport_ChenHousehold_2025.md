CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2025

Bucket Strategy Implementation & Retirement Horizon Planning — Story Arc 2 Concludes

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Year: | 2025 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Document ID: | DOC-AnnualConsolidatedReport-2025-001 |
| Prepared By: | Morgan Park, CFP®  |  Lisa Torres, EA |
| Prepared Date: | January 2025 |

SYNTHETIC DEMO DATA — For product demonstration purposes only. Not investment, tax, or legal advice.

1. ADVISOR LETTER

January 2026

Dear Alex and Sam,

2025 marks a meaningful transition in your financial plan: from the reactive management of the past five years — COVID repositioning, home purchase, a concentrated liquidity event, and an estate audit — to a forward-looking, structured framework designed to carry you toward retirement with clarity and confidence. We are now firmly in what we call the 'Post-Liquidity Stewardship Phase.'

The defining planning action of 2025 was the adoption of IPS Amendment DOC-IPSAmendment-2025-001 (effective March 1, 2025) and the implementation of the bucket strategy under DecisionID-2025-112. Bucket 1 (0–24 months): ACCT-CASH + STBIX, holding approximately $45,000 in near-term liquidity. Bucket 2 (2–7 years): UCBIX + UTIPX in ACCT-IRA1, providing medium-term stability. Bucket 3 (7+ years): equities + REITX across ACCT-TX01 and ACCT-RIRA, capturing long-term growth. This framework explicitly addresses sequence-of-returns risk and was informed by the updated DOC-RiskQuestionnaire-2025-001 (score 58/100, 'Moderate with bucket preference').

Maya Chen is now 14 and college enrollment in 2029 is within the 529 planning horizon. ACCT-529A stands at $22,500 at year-end — a strong improvement but still below the full four-year cost projection. Contributions were increased. Eli (age 11) has a longer runway; ACCT-529B at $22,500 is on a reasonable trajectory. A formal college funding analysis was delivered in Q2 2025.

Social Security claiming analysis (RecID-2025-02) was delivered in Q3 2025. Key finding: both Alex and Sam are optimal candidates for delayed claiming to age 70, maximizing the lifetime benefit given life expectancy and projected income needs.

In Q4, a question arose regarding fee billing consistency (EventID-2026-01 setup): you noted a discrepancy between the fee reference in a prior-year strategy deck and your current billing statements. Morgan has confirmed this was a documentation artifact from DOC-StrategyDeck-2022-002 (a stale draft that was superseded by the FINAL version). Full resolution is underway and will be documented in the Q1 2026 meeting.

A referral from Alex's sibling, Taylor Chen (ProspectID-2025-01), has entered the discovery process. An initial meeting was completed in Q3 2025; a follow-up checklist was sent.

Warm regards,

Morgan Park, CFP® | Clearwater Wealth Partners

2. YEAR IN REVIEW — 2025 MARKET CONTEXT

Macroeconomic Environment

2025 was characterized by Fed policy normalization — continued gradual rate reductions as inflation held near target and economic growth moderated. The AI transformation in financial services accelerated, with broader adoption across advisory, compliance, and client reporting workflows. Regulatory focus on fee transparency and documentation quality intensified. Markets delivered moderate positive returns, with equities outperforming fixed income as rate cuts provided a tailwind. Maya Chen (born 2011) approaches college age (~2029 enrollment), making 529 planning increasingly time-sensitive.

Key Market Metrics — 2025 (Estimates)

| Market Indicator | 2025 Result |
| --- | --- |
| S&P 500 Return (Est.) | +12–15% |
| Bloomberg Aggregate Bond (Est.) | +4–6% |
| International Developed (Est.) | +8–10% |
| US Core Bonds (UCBIX proxy, Est.) | +4.5% |
| TIPS (UTIPX proxy, Est.) | +3.8% |
| Fed Funds Rate (Year-End, Est.) | ~3.25–3.50% |
| CPI Inflation (Year-End, Est.) | ~2.2% |

Portfolio Implications (IPS-2025 Bucket Framework)

IPS-2025 (effective March 1) introduced the bucket framework while maintaining a similar overall target of 62% equity / 33% fixed / 5% cash. The key innovation is the explicit time-segmentation: Bucket 1 serves as the near-term spending reserve (insulating the plan from sequence-of-returns risk), Bucket 2 provides medium-term stability, and Bucket 3 is optimized for long-term growth. The single-stock concentration limit was tightened to <5% (from 7% under IPS-2020), reflecting the reduced role of NLTK in the portfolio.

3. GOALS DASHBOARD

Reference: GoalID-2016-01, GoalID-2016-02, GoalID-2016-03, GoalID-2023-01

[STRONG] GoalID-2016-01 — Retirement Readiness: Household AUM $1,450,000. Bucket strategy implemented (IPS-2025). Updated projection: ~91% confidence level (30-year horizon, $185K/yr target). SS claiming analysis delivered (RecID-2025-02): delay both Alex and Sam to age 70 for maximum benefit. Estimated retirement date: 2043 (Alex) / 2044 (Sam) if current trajectory maintained.

[BUILDING] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya, age 14) balance $22,500 — 2029 enrollment ~4 years away. Contribution increase implemented. Projected shortfall vs. ~$250K target remains; current trajectory covers approximately 60% of projected costs at current market assumptions. ACCT-529B (Eli, age 11) balance $22,500 — 2032 enrollment. Age-based allocation gradually de-risking for Maya.

[ACHIEVED] GoalID-2016-03 — Emergency Liquidity / Bucket 1: ACCT-CASH balance $45,000 at year-end, integrated into Bucket 1 (0–24 months) per IPS-2025. Target of 6–9 months expenses met. STBIX supplement held in ACCT-TX01 for Bucket 1 overflow. Goal formally migrated into bucket framework.

[ACTIVE] GoalID-2023-01 — Values-Based Giving Plan: Clearwater Giving Fund DAF: $7,500 in charitable grants distributed in 2025 to education and community-focused nonprofits. DAF balance maintained for future distributions. Continued coordination with Lisa Torres, EA on charitable bunching opportunities in high-income projection years.

4. PORTFOLIO SUMMARY

AUM Snapshot — Quarterly 2025

| Quarter | End AUM | Net Flows | Allocation | Note |
| --- | --- | --- | --- | --- |
| Q1 2025 | $1,315,000 | +$12,000 | 61% Eq / 34% FI / 5% Cash | IPS-2025 effective March 1; bucket structure implemented |
| Q2 2025 | $1,360,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | 529 analysis delivered; SS analysis begun |
| Q3 2025 | $1,395,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | SS claiming analysis delivered (RecID-2025-02) |
| Q4 2025 | $1,450,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Fee question surfaced; Taylor Chen referral follow-up |

Account Balances — December 31, 2025

| Account / Bucket | Balance | Notes |
| --- | --- | --- |
| ACCT-TX01 — Taxable Brokerage (Joint) — Bucket 3 | $760,000 | Equities + MUNIX + NLTK <5%; Bucket 3 core |
| ACCT-IRA1 — Alex Traditional IRA — Bucket 2 | $490,000 | UCBIX + UTIPX; Bucket 2 medium-term stability |
| ACCT-RIRA — Alex Roth IRA — Bucket 3 | $105,000 | Small cap / EM / REITX; long-term growth |
| ACCT-CASH — Cash Mgmt — Bucket 1 | $45,000 | Bucket 1 near-term reserve; 6–9 months expenses |
| ACCT-529A — Maya 529 | $22,500 | Age-based; 2029 enrollment; gradually de-risking |
| ACCT-529B — Eli 529 | $22,500 | Age-based moderate; 2032 enrollment |
| Household Total | $1,450,000 |  |

IPS-2025 Bucket Allocation Summary

| Bucket | Balance | Description |
| --- | --- | --- |
| Bucket 1 (0–24 mo): ACCT-CASH + STBIX | ~$45,000 | Near-term spending; insulates against sequence risk |
| Bucket 2 (2–7 yr): UCBIX + UTIPX | ~$490,000 | Medium-term stability; IRA1 core holdings |
| Bucket 3 (7+ yr): Equities + REITX | ~$915,000 | Long-term growth; TX01 + RIRA |
| Household Total | $1,450,000 | 62% Eq / 33% FI / 5% Cash — within IPS-2025 targets |

5. TAX PLANNING RECAP — TAX YEAR 2025

Reference: TaxTopicID-2025-01 | Tax Specialist: Lisa Torres, EA

| Tax Line Item | TY2025 Amount |
| --- | --- |
| W-2 Wages (Alex + Sam combined) | $276,000 |
| Other Income (RSU / equity comp) | $20,000 |
| Interest & Dividend Income | $2,400 |
| Net Capital Gains | $16,000 |
| Charitable Contributions (DAF grants) | $7,500 |
| Deduction Method | Itemized |
| Approximate Adjusted Gross Income (AGI) | ~$314,000 |
| Federal Effective Tax Rate (Est.) | ~22.5% |
| Key Planning Note | Muni bond income tax efficiency in TX01; bucket tax-efficiency review |

Tax Efficiency under IPS-2025 — TaxTopicID-2025-01

The bucket strategy introduces specific tax placement considerations reviewed with Lisa Torres, EA in Q1 2025. Key principles: (1) ACCT-TX01 prioritizes municipal bonds (MUNIX) for income tax efficiency; (2) ACCT-IRA1 holds taxable bonds (UCBIX, UTIPX) to maximize tax-deferred compounding; (3) ACCT-RIRA holds higher-growth assets (small cap, EM, REITX) for tax-free treatment of largest gains. This asset location review reduced estimated annual tax drag by approximately $1,200–$1,800 per year relative to less tax-optimized placement.

6. RECOMMENDATIONS & ACTION ITEMS

| RecID / Item | Description | Status | Reference |
| --- | --- | --- | --- |
| RecID-2025-01 | Bucket strategy implementation | Implemented Q1 2025 | DecisionID-2025-112 |
| RecID-2025-02 | Social Security claiming analysis | Delivered Q3 2025 | GoalID-2016-01 |
| GoalID-2016-02 | 529 Maya funding gap analysis | Delivered Q2 2025 | ACCT-529A — 2029 |
| EventID-2026-01 | Fee billing discrepancy resolution | In Progress — Q1 2026 | DOC-StrategyDeck-2022-002 |
| ProspectID-2025-01 | Taylor Chen discovery | Follow-up checklist sent | MtgID-2025Q3-01 |
| TaskID-2026Q2-818 | Update retirement projections | Due 2026-06-15 | GoalID-2016-01 |

7. DOCUMENT CROSS-REFERENCES

| Document | ID / Filename |
| --- | --- |
| IPS Amendment (2025) — Bucket Strategy | DOC-IPSAmendment-2025-001 |
| Risk Questionnaire (2025) | DOC-RiskQuestionnaire-2025-001 |
| College Funding Analysis | CollegeFundingAnalysis_ChenHousehold_2025.pdf |
| Social Security Claiming Analysis | SocialSecurityAnalysis_ChenHousehold_RecID-2025-02.pdf |
| Fee Amendment (2021) | DOC-FeeAmendment-2021-001 |
| Strategy Deck (FINAL — correct fee) | DOC-StrategyDeck-2022-003 |
| Strategy Deck (v2 — stale fee reference) | DOC-StrategyDeck-2022-002 |
| Tax Return Summary TY2025 | TaxReturnSummary_ChenHousehold_TY25.docx |
| Meeting Notes Q4 2025 | MeetingNotes_ChenHousehold_MtgID-2025Q4-01.pdf |
| This Document | DOC-AnnualConsolidatedReport-2025-001 |
