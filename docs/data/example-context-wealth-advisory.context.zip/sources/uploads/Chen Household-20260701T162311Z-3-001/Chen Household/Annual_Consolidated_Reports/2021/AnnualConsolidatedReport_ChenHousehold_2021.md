CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2021

Home Purchase Year — First Itemized Return, Down Payment Gains & Fee Amendment (EventID-2021-01 | DecisionID-2021-141 | DOC-FeeAmendment-2021-001 | Story Arc 3 Setup)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2021 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 9, 2022 |
| Document ID: | DOC-AnnualConsolidatedReport-2021-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

The keys to 3215 Lakeview Circleive. After months of planning, liquidity staging, and mortgage structuring, you closed on your home in July 2021 — and it changed everything about how we think about your balance sheet. The down payment staging required careful tax-aware liquidation from ACCT-TX01, generating $18,500 in capital gains. But with a full-year mortgage in 2022, itemized deductions will meaningfully exceed the standard deduction — one of the silver linings of homeownership.

Markets continued their strong post-COVID run: the S&P 500 gained 27%, housing boomed, and inflation — long dormant — began showing up everywhere. Your portfolio grew from $792,000 to $952,000, even after the $55,000 outflow for the down payment in Q3. That’s a remarkable result that reflects both market performance and your commitment to consistent contributions.

This year I also want to flag an important housekeeping matter: in June we executed a fee schedule amendment (DOC-FeeAmendment-2021-001) transitioning from a flat 1.00% advisory fee to a tiered structure — 0.85% on the first $1.5M, 0.70% on the next $1.5M, and 0.55% above $3M. As your wealth grows, this structure saves you money meaningfully.

The 529 accounts are funded, the home is purchased, and the trust is in place. 2021 was the year everything came together.

Warmly,

Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2021

Market Environment

| U.S. Equity (S&P 500): | $+28.7%  (broad bull market; best year since 2019) |
| --- | --- |
| International Equity (MSCI EAFE): | $+11.3%  (positive; lagged U.S.; supply chain + COVID) |
| U.S. Bonds (Bloomberg Agg): | (−1.5%)  (rising inflation expectations; rates rising) |
| Fed Funds Rate: | 0.00–0.25%  (unchanged; taper talk began Q4) |
| Key Themes: | Reopening; inflation emergence; housing boom; meme stock mania; taper talk |
| IPS Allocation in Effect: | DOC-IPSAmendment-2020-001  |  60% Equity / 35% Fixed / 5% Cash |

Household Milestones

• July 2021: Home purchased at 3215 Lakeview Circle, Wayzata, MN 55391 — EventID-2021-01

• July 10, 2021: Down payment staging trades executed — DecisionID-2021-141 ($18,500 LT cap gains)

• Mortgage originated: Lakeside Mortgage Co.; ~$530K loan; TaxTopicID-2021-01

• June 20, 2021: Fee schedule amendment executed — DOC-FeeAmendment-2021-001 (tiered; effective July 1)

• Q3 AUM impact: −55,000 net outflow for down payment; portfolio absorbed it without allocation drift

• 529 accounts growing: ACCT-529A (Maya) and ACCT-529B (Eli) receiving regular contributions

• Q4: First full year of inflation concern reflected in bond sleeve discussion (bonds slightly negative)

Quarterly AUM Progression

| Quarter | End AUM | Net Flow | Allocation (E/FI/C) | Key Notes |
| --- | --- | --- | --- | --- |
| 2021-Q1 | $825,000 | +$12,500 | 60 / 35 / 5 | Strong start; reopening optimism |
| 2021-Q2 | $870,000 | +$10,000 | 58 / 37 / 5 | Cash staging begins for home purchase |
| 2021-Q3 | $905,000 | −55,000 | 59 / 36 / 5 | Down payment outflow July; markets offset loss |
| 2021-Q4 | $952,000 | +$10,000 | 60 / 35 / 5 | Strong Q4; back at target; 529s funded |

SECTION 2 — FINANCIAL GOALS DASHBOARD

[ON TRACK ↑] GoalID-2016-01 — Retirement Readiness: AUM $952,000 (year-end) despite $55K outflow for down payment — resilient. Portfolio crossed $900K milestone in Q3. Funded ratio improving toward target. Home equity now adds to household net worth (not counted in AUM). Horizon: ~20 years to target retirement.

[IN PROGRESS ↑] GoalID-2016-02 — Education Funding (529s): ACCT-529A: $7,000 year-end balance (Maya, age 10, ~10 years to enrollment). ACCT-529B: $7,000 year-end balance (Eli, age 7, ~13 years to enrollment). Contribution schedule active. Age-Based Moderate (529-AGE-MOD) portfolio in both accounts.

[RESTRUCTURED] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH $50,000 year-end. Home purchase partially drew down liquidity buffer; rebuilding to 6–9 months post-purchase. Mortgage payment impact on monthly cash flow modeled in RecID-2021-01 cashflow worksheet. Target: restore to $60–70K by year-end 2022.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2021

| Beginning AUM (January 1, 2021): | $792,000 |
| --- | --- |
| Net Contributions: | $32,500  (reduced; cash directed toward home purchase) |
| Down Payment Outflow (July 2021): | ($55,000)  — DecisionID-2021-141; ACCT-TX01 liquidations |
| Investment Return (net, full year): | $+188,500  (approx.; strong equity + growth year) |
| Advisory Fees Paid: | ($6,000)  (blended: 1.00% Jan–Jun; ~0.85% Jul–Dec) |
| End AUM (December 31, 2021): | $952,000 |
| Total Household AUM Growth: | $+160,000  (+20.2%)  incl. $55K outflow |

Fee Schedule Change — Story Arc 3 Setup

| Prior Fee Schedule: | 1.00% flat (DOC-AdvisoryAgreement-2016-001; effective since 2016) |
| --- | --- |
| New Fee Schedule: | Tiered — 0.85% (first $1.5M) / 0.70% ($1.5M–$3M) / 0.55% (above $3M) |
| Amendment Executed: | June 20, 2021  |  DOC-FeeAmendment-2021-001 |
| Effective Date: | July 1, 2021 |
| 2021 Fees (approx.): | ~$7,600  (blended half-year transition) |
| Important Note: | A stale 1.00% fee reference will appear in DOC-StrategyDeck-2022-002 (v2) — |
| → This is a known document inconsistency: | DOC-StrategyDeck-2022-003 (FINAL) correctly shows tiered schedule |
| Advisory note (Story Arc 3): | AI demo: compare v2 vs. FINAL deck to surface inconsistency |

Asset Allocation vs. Policy (Year-End 2021)

| Asset Class | IPS Target | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK + USCIX) | 60% target | ~60% | On target |
| Fixed Income (UCBIX + UTIPX + MUNIX) | 35% target | ~35% | On target |
| Cash / STBIX | 5% target | ~5% | On target |
| NLTK Single Stock | <7% IPS-2020 limit | ~5% | Within limit; vest schedule monitored |
| TOTAL Household Portfolio | 100% | 100% | IPS-2020 targets achieved |

Account-Level Summary (Year-End 2021)

| Account | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Joint | Equity + muni + NLTK (post-down-payment) | $480,000 |
| ACCT-IRA1 | Alex Trad. IRA | Core bonds + TIPS + equity | $330,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM tilt | $78,000 |
| ACCT-CASH | Cash Mgmt | Emergency fund (rebuilding) | $50,000 |
| ACCT-529A | Maya Education | Age-Based Moderate | $7,000 |
| ACCT-529B | Eli Education | Age-Based Moderate | $7,000 |
| Household Total |  |  | $952,000 |

Performance Attribution (Full Year 2021)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | ~+28% | Broadly in line with S&P 500 +28.7% |
| International Equity (IDEIX) | ~+11% | Positive; lagged U.S. |
| Fixed Income (UCBIX + MUNIX + UTIPX) | ~−1% | Rising inflation; bond prices under pressure |
| Cash / STBIX | ~+0.4% | Near-zero Fed; minimal yield |
| 529-AGE-MOD (ACCT-529A/B) | ~+12% | First year of growth; age-based moderate |
| Overall Portfolio (net of fees) | ~+15.2% | Excellent; equity surge offset bond headwinds |

SECTION 4 — HOME PURCHASE SUMMARY — EVENTID-2021-01

| Property: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |
| Purchase Close Date: | July 2021 |
| Mortgage Lender: | Lakeside Mortgage Co. |
| Loan Amount (approx.): | ~$530,000 |
| Down Payment Source: | ACCT-TX01 liquidations + ACCT-CASH drawdown |
| Down Payment Trade Decision: | DecisionID-2021-141  (Window: July 10, 2021) |
| Capital Gains Realized: | $18,500 net  ($2,500 ST + $16,000 LT)  — see Schedule D |
| Tax Impact: | $18,500 cap gains + NIIT on NII; first itemized deduction year |
| Mortgage Interest Deductible (2021): | $11,800 (6 months)  — Schedule A |
| Recommendation: | RecID-2021-01 — Cashflow worksheet + home readiness plan |
| Knowledge File: | KF-Home-Purchase-Liquidity.md |

SECTION 5 — TAX PLANNING RECAP

| Tax Year: | 2021  —  FIRST ITEMIZED YEAR |
| --- | --- |
| Filing Status: | MFJ |
| AGI (approx.): | $282,300 |
| Deduction Method: | Itemized  ($26,300)  — exceeds standard deduction of $25,100 |
| Mortgage Interest (6 months): | $11,800 |
| SALT (capped): | $10,000 |
| Charitable contributions: | $4,500 |
| Net Capital Gains: | $18,500  (highest since inception; down payment staging) |
| Tax Topic: | TaxTopicID-2021-01  — Home purchase itemization and cash planning |
| NIIT: | $1,233  (NII = $20,300; AGI over threshold = $32,300) |
| Federal Tax (approx.): | $45,225  |  Effective rate: 16.0% |
| State Tax (MN): | $20,480  |  Effective rate: ~8.0% |
| Full detail: | See DOC-TaxReturnSummary-2021-001 |

2022 projection: With a full 12 months of mortgage interest (~$23,600/yr), total itemized deductions will reach approximately $37,600 — well above the $25,900 standard deduction (2022 MFJ). Itemization benefit grows materially in future years.

SECTION 6 — RECOMMENDATIONS & ACTION ITEMS

| Rebuild ACCT-CASH emergency fund: | Target $60–70K by year-end 2022; mortgage payment now in cashflow |
| --- | --- |
| Increase 529 contributions: | Set annual targets for ACCT-529A / ACCT-529B for 2022 |
| IPS-2020 annual review: | Confirm 60/35/5 appropriate as inflation becomes a factor |
| NLTK concentration: | Annual vest schedule review; maintain <7% IPS limit; diversification plan |
| Itemization: | Full year of mortgage interest in 2022 will significantly increase deduction benefit |
| Beneficiary forms: | Trust alignment for ACCT-IRA1 / ACCT-RIRA still pending correction |
| Fee amendment documentation: | Confirm DOC-FeeAmendment-2021-001 reflected in billing for H2 2021 |

SECTION 7 — DOCUMENT CROSS-REFERENCES

| IPS (current): | DOC-IPSAmendment-2020-001  (60/35/5) |
| --- | --- |
| Fee Amendment: | DOC-FeeAmendment-2021-001  (tiered schedule; effective July 1, 2021) |
| Life Event (home purchase): | EventID-2021-01 |
| Trade Decision (down payment): | DecisionID-2021-141 |
| Recommendation (cashflow): | RecID-2021-01 |
| Tax Topic: | TaxTopicID-2021-01 |
| Meeting Notes + Transcripts: | MtgID-2021Q1-01 through MtgID-2021Q4-01 |
| Tax Return Summary: | DOC-TaxReturnSummary-2021-001 |
| Knowledge Files: | KF-Home-Purchase-Liquidity.md  |  KF-Fee-Schedule-Compliance.md |
| Story Arc 3 Note: | DOC-StrategyDeck-2022-002 (v2 stale) vs. DOC-StrategyDeck-2022-003 (FINAL correct) |
| Prior Report: | DOC-AnnualConsolidatedReport-2020-001 |
| Next Report: | DOC-AnnualConsolidatedReport-2022-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
