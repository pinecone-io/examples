CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2019

Trust Formation Year — Chen Family Revocable Trust Established (EventID-2019-01)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Type: | Annual Consolidated Client Report |
| Reporting Period: | January 1 – December 31, 2019 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Date Issued: | February 12, 2020 |
| Document ID: | DOC-AnnualConsolidatedReport-2019-001 |

SYNTHETIC DEMO DATA ONLY — For product demonstration purposes. Not investment, tax, or legal advice. All figures are fictitious. Dataset: NWP-DEMO-HH-CHEN-001.

LETTER FROM YOUR ADVISOR

Dear Alex and Sam,

2019 delivered one of the strongest market years in recent memory — the S&P 500 gained 29% — and your portfolio responded in kind, growing from $595,000 to $732,000. More meaningfully, this was the year you took a foundational step in protecting what you’ve built: the Chen Family Revocable Trust was established in September, formalizing your estate structure and setting the stage for beneficiary coordination across all accounts.

The Fed shifted course dramatically — cutting rates three times after hiking seven times over the prior two years. This policy pivot helped fuel the equity rally and provided a tailwind for the bond sleeve as well. On the planning front, we are increasingly aware that your NLTK equity position requires a thoughtful, multi-year diversification strategy, and we have begun laying the groundwork for that conversation.

One priority I want to flag directly: opening the 529 education savings accounts for Maya and Eli has been carried forward for three consecutive years. With Maya now age 8, the window of tax-advantaged growth is narrowing. We will make this a first-quarter 2020 action item with no further delays. I appreciate your patience and look forward to catching up in our Q1 meeting.

Warmly,

Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001

SECTION 1 — YEAR IN REVIEW: 2019

Market Environment

| U.S. Equity (S&P 500): | $+31.5%  (strongest year since 2013; broad-based rally) |
| --- | --- |
| International Equity (MSCI EAFE): | $+22.4%  (Fed pivot + trade truce boosted intl.) |
| U.S. Bonds (Bloomberg Agg): | $+8.7%  (rate cuts drove bond price appreciation) |
| Fed Funds Rate: | 2.50% → 1.75%  (three 25 bps cuts; policy pivot reversal) |
| Key Themes: | Fed pivot; yield curve inversion (brief); U.S.–China trade truce; low unemployment |
| IPS Allocation in Effect: | DOC-IPS-2016-001  |  70% Equity / 28% Fixed / 2% Cash |

Household Milestones

• September 10, 2019: Chen Family Revocable Trust established — EventID-2019-01

• Trust managed by Westfield & Baker LLP; Morgan Park designated as advisor of record

• Beneficiary designations partially updated; DOC-BeneficiaryForm-2018-001 flagged for correction (outdated contingent)

• Meeting transcripts introduced this year — full quarterly transcripts now on file (MtgID-2019Q1-01 through Q4-01)

• Alex’s consulting income ($10K) introduced new SE tax dimension in 2019

• 529 accounts: STILL pending — escalated to mandatory Q1 2020 action

Quarterly AUM Progression

| Quarter | End AUM | Net Flow | Allocation (E/FI/C) | Key Notes |
| --- | --- | --- | --- | --- |
| 2019-Q1 | $642,000 | +$12,000 | 71 / 27 / 2 | Steady recovery from 2018 Q4 selloff |
| 2019-Q2 | $668,000 | +$12,500 | 72 / 26 / 2 | Equity drift above target; within drift band |
| 2019-Q3 | $684,000 | +$13,000 | 70 / 28 / 2 | Rebalance trim executed; back to target |
| 2019-Q4 | $732,000 | +$13,500 | 71 / 27 / 2 | Strong Q4 close; trust established in Sept |

SECTION 2 — FINANCIAL GOALS DASHBOARD

[ON TRACK ↑↑] GoalID-2016-01 — Retirement Readiness: AUM $732,000 — strongest year-over-year gain since inception (+$137K). Funded ratio meaningfully improving. Projection confidence: Good. NLTK equity comp adding to trajectory; diversification plan in development. Horizon: ~21 years to target retirement.

[URGENT — NOT YET OPENED] GoalID-2016-02 — Education Funding (529s): Fourth consecutive year carried forward. Maya age 8 (est. ~11 years to college); Eli age 5 (~14 years). Opening ACCT-529A and ACCT-529B is a mandatory Q1 2020 action item — no further delays. Every year of delay forfeits tax-free compounding.

[ON TRACK] GoalID-2016-03 — Emergency Liquidity: ACCT-CASH estimated ~$52,000 — approximately 5 months expenses. Within target range of 6–9 months. Trust structure does not change liquidity profile.

SECTION 3 — PORTFOLIO SUMMARY

AUM Snapshot — Year-End 2019

| Beginning AUM (January 1, 2019): | $595,000 |
| --- | --- |
| Net Contributions (full year): | $51,000 |
| Investment Return (~15.5% net): | $+92,000  (approx.; includes full year of growth) |
| Advisory Fees Paid: | ($6,000)  (1.00% flat on avg. AUM ~$660K) |
| End AUM (December 31, 2019): | $732,000 |
| Total Household AUM Growth: | $+137,000  (+23.0%) |

Asset Allocation vs. Policy (Year-End 2019)

| Asset Class | IPS Target | Actual | Status |
| --- | --- | --- | --- |
| U.S. Equity (UECIX + NLTK + USCIX) | 70% target | ~71% | Slight drift; within ±5% band |
| Fixed Income (UCBIX + UTIPX + MUNIX) | 28% target | ~27% | Slight drift; within band |
| Cash / STBIX | 2% target | ~2% | On target |
| NLTK Single Stock | <10% IPS limit | ~5% | Within policy; monitoring active |
| TOTAL Household Portfolio | 100% | 100% | All within IPS drift bands |

Account-Level Summary (Year-End 2019)

| Account | Type | Strategy | Balance |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Joint | Equity + fixed + NLTK + cash sleeve | $350,000 |
| ACCT-IRA1 | Alex Trad. IRA | Core bonds + TIPS + equity sleeve | $270,000 |
| ACCT-RIRA | Alex Roth IRA | Small cap + EM growth tilt | $60,000 |
| ACCT-CASH | Cash Mgmt (HYSA) | Emergency fund | $52,000 |
| ACCT-529A / 529B | Education (not yet opened) | Pending — Q1 2020 | $0 / $0 |
| Household Total |  |  | $732,000 |

Performance Attribution (Full Year 2019)

| Sleeve | Return | Commentary |
| --- | --- | --- |
| U.S. Equity (UECIX + NLTK) | ~+31% | Broadly in line with S&P surge |
| International Equity (IDEIX) | ~+22% | Strong; policy pivot + trade truce |
| Fixed Income (UCBIX + MUNIX + UTIPX) | ~+9% | Rate cuts drove bond appreciation |
| Cash / STBIX | ~+2.2% | Improving; Fed still cutting |
| Overall Portfolio (net of fees) | ~+16.5% | Excellent year; IPS allocation delivered |

SECTION 4 — ESTATE PLANNING UPDATE

Chen Family Revocable Trust — EventID-2019-01

| Trust Name: | Chen Family Revocable Trust |
| --- | --- |
| Date Established: | September 10, 2019 |
| Document Reference: | DOC-Trust-2019-001 |
| Attorney: | Westfield & Baker LLP |
| Tax Treatment: | Grantor / disregarded entity — all income on Form 1040; no Form 1041 required |
| Primary Beneficiary: | Spouse (Alex and Sam, reciprocally) |
| Contingent Beneficiaries (intended): | Trust / children (Maya and Eli) |
| Beneficiary Form Status: | DOC-BeneficiaryForm-2018-001 has OUTDATED contingent (Alex’s parent listed) |
| → Action Required: | Update beneficiary forms to align with trust — TaskID assigned |
| Accounts to be Updated: | ACCT-IRA1, ACCT-RIRA (primary / contingent alignment with trust) |

Note: The beneficiary mismatch on DOC-BeneficiaryForm-2018-001 is a known item. Correction has been recommended but not yet completed. This will be revisited in 2024 following a health-related estate urgency event (EventID-2024-01). Reference: KF-Beneficiary-Best-Practices.md.

SECTION 5 — TAX PLANNING RECAP

| Tax Year: | 2019 |
| --- | --- |
| Filing Status: | MFJ |
| AGI (approx.): | $254,693  (includes $10K consulting / SE income) |
| Deduction Method: | Standard Deduction ($24,400) — elected |
| Net Capital Gains: | $7,500  (long-term rebalancing) |
| Self-Employment Tax: | $1,413  (consulting income — Schedule C / SE) |
| NIIT (3.8%): | $181  (AGI slightly above $250K MFJ threshold) |
| Federal Tax (approx.): | $40,538  |  Effective rate: 15.9% |
| State Tax (MN): | $17,502  |  MN effective rate: ~7.6% |
| Full detail: | See DOC-TaxReturnSummary-2019-001 |

SECTION 6 — RECOMMENDATIONS & ACTION ITEMS

| Open 529 accounts — MANDATORY Q1 2020: | ACCT-529A (Maya), ACCT-529B (Eli) — GoalID-2016-02 — URGENT |
| --- | --- |
| Update beneficiary forms: | Align ACCT-IRA1 / ACCT-RIRA with trust — correct DOC-BeneficiaryForm-2018-001 |
| Develop NLTK diversification plan: | Multi-year systematic reduction plan — KF-Concentrated-Stock-Strategies.md |
| Risk questionnaire: | Due for formal refresh in 2020 — DOC-RiskQuestionnaire-2020-001 |
| Annual IPS review: | Q1 2020 — DOC-IPS-2016-001 approaching 4 years; confirm continued appropriateness |
| Consulting income: | If Alex expects SE income again in 2020, consider quarterly estimated payments |

SECTION 7 — DOCUMENT CROSS-REFERENCES

| IPS: | DOC-IPS-2016-001 |
| --- | --- |
| Risk Questionnaire: | DOC-RiskQuestionnaire-2016-001  (refresh due 2020) |
| Revocable Trust: | DOC-Trust-2019-001  |  EventID-2019-01 |
| Beneficiary Form (outdated): | DOC-BeneficiaryForm-2018-001 |
| Meeting Notes + Transcripts: | MtgID-2019Q1-01 through MtgID-2019Q4-01 |
| Tax Return Summary: | DOC-TaxReturnSummary-2019-001 |
| Knowledge Files: | KF-Revocable-Trust-Basics.md  |  KF-Concentrated-Stock-Strategies.md |
| Prior Report: | DOC-AnnualConsolidatedReport-2018-001 |
| Next Report: | DOC-AnnualConsolidatedReport-2020-001 |

This is a synthetic demonstration document prepared by Clearwater Wealth Partners. It does not constitute investment, tax, or legal advice. All names, account numbers, and financial figures are fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
