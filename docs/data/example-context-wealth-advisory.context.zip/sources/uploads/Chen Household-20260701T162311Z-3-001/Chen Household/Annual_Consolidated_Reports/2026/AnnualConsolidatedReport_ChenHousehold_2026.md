CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL CONSOLIDATED REPORT

Year Ending December 31, 2026

Fee Resolution, Documentation Integrity & Transition Readiness — Story Arc 3 Concludes

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Report Year: | 2026 |
| Advisor: | Morgan Park, CFP®  (ADV-PARK-001) |
| Tax Specialist: | Lisa Torres, EA |
| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| Document ID: | DOC-AnnualConsolidatedReport-2026-001 |
| Prepared By: | Morgan Park, CFP®  |  Lisa Torres, EA |
| Prepared Date: | January 2026 |

SYNTHETIC DEMO DATA — For product demonstration purposes only. Not investment, tax, or legal advice.

1. ADVISOR LETTER

January 2027

Dear Alex and Sam,

As we close the books on 2026, we do so with a sense of meaningful accomplishment — not just in portfolio performance, but in the discipline, documentation integrity, and governance standards that define the Clearwater Wealth Partners partnership. Your household AUM reached $1,650,000 at year-end, and every aspect of your financial plan — investment policy, estate structure, tax coordination, charitable giving, and fee schedule — is now fully aligned and documented correctly.

The most significant administrative event of 2026 was the resolution of the fee billing discrepancy surfaced in Q4 2025 (EventID-2026-01). Our internal review confirmed that DOC-StrategyDeck-2022-002 (a superseded draft) contained a stale reference to the legacy 1.00% flat fee — which was replaced by the tiered schedule in DOC-FeeAmendment-2021-001 (effective July 1, 2021). Billing statements for 2022–2025 confirm the correct blended tiered rate was charged throughout. A fee credit of $1,250 was issued in Q1 2026 as a goodwill acknowledgment for any confusion the document discrepancy may have caused. This resolution is confirmed in MtgID-2026Q1-01. Note: internal approval documentation is maintained in the restricted operations folder and is not included in this client report.

TaskID-2026Q1-801 (client summary letter re fee resolution) was delivered March 1, 2026. The transition readiness checklist (TaskID-2026Q3-836) was completed in Q3. Retirement projection update (TaskID-2026Q2-818) was delivered in Q2, confirming the trajectory.

Looking back across the full decade: you joined Clearwater Wealth Partners in 2016 with $410,000 in assets. You now hold $1,650,000 — a 4x+ growth driven by consistent saving, disciplined investing through multiple market cycles (2018 selloff, 2020 COVID crash, 2022 bear market), a major liquidity event, and increasingly sophisticated tax and estate planning. Maya enters college in 2029; retirement planning is on track. The plan is strong.

Warm regards,

Morgan Park, CFP® | Clearwater Wealth Partners

2. YEAR IN REVIEW — 2026 MARKET CONTEXT

Macroeconomic Environment

2026 is characterized by continued normalization. The AI transformation in wealth management has moved from experimentation to operational deployment — AI-assisted document review, compliance checking, and client reporting are now standard across leading advisory firms. The SEC and FINRA have intensified focus on billing accuracy and fee transparency, making documentation governance a competitive differentiator. Markets continue delivering moderate positive returns, with reduced volatility as the rate cycle stabilizes.

Key Market Metrics — 2026 (Estimates)

| Market Indicator | 2026 Result |
| --- | --- |
| S&P 500 Return (Est.) | +10–13% |
| Bloomberg Aggregate Bond (Est.) | +3–5% |
| International Developed (Est.) | +7–9% |
| US Core Bonds (UCBIX proxy, Est.) | +3.8% |
| TIPS (UTIPX proxy, Est.) | +3.2% |
| Fed Funds Rate (Year-End, Est.) | ~2.75–3.00% |
| CPI Inflation (Year-End, Est.) | ~2.1% |

Portfolio Implications (IPS-2025 Bucket Framework Continues)

The IPS-2025 bucket framework continues without modification. The portfolio performed consistent with a moderate-growth profile. Bucket 1 was partially replenished during the year to maintain the near-term spending reserve. Bucket 3 benefited from continued equity appreciation. The single-stock NLTK position remains below the 5% IPS limit. Asset location discipline (munis in taxable, bonds in IRA, growth in Roth) continued to optimize after-tax returns.

3. GOALS DASHBOARD

Reference: GoalID-2016-01, GoalID-2016-02, GoalID-2016-03, GoalID-2023-01

[ON TRACK] GoalID-2016-01 — Retirement Readiness: Household AUM $1,650,000. Transition readiness checklist completed Q3 2026 (TaskID-2026Q3-836). Retirement projection update delivered Q2 2026 (TaskID-2026Q2-818): ~92% confidence level, $185K/yr target. Social Security delay strategy (age 70 for both Alex and Sam) remains optimal. ~17 years to target retirement.

[BUILDING] GoalID-2016-02 — Education Funding (529s): ACCT-529A (Maya, age 15) balance $45,000 — 2029 enrollment 3 years away. Meaningful progress; trajectory now covers approximately 75% of projected four-year cost. Increased annual contributions maintained. ACCT-529B (Eli, age 12) balance $45,000 — 2032 enrollment on solid track.

[MAINTAINED] GoalID-2016-03 — Emergency Liquidity / Bucket 1: ACCT-CASH $35,000 at year-end (slight drawdown from 2025 for planned expenses). STBIX supplement in TX01 maintained for Bucket 1 total near-term reserve ~$40K. Within the Bucket 1 target range.

[ACTIVE] GoalID-2023-01 — Values-Based Giving Plan: Clearwater Giving Fund DAF: $8,000 in charitable grants in 2026. Multi-year giving plan progressing. Annual coordination with Lisa Torres, EA for charitable bunching optimization. DAF balance replenished via annual contributions.

4. PORTFOLIO SUMMARY

AUM Snapshot — Quarterly 2026

| Quarter | End AUM | Net Flows | Allocation | Note |
| --- | --- | --- | --- | --- |
| Q1 2026 | $1,485,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Fee resolution; client summary letter issued |
| Q2 2026 | $1,535,000 | +$12,000 | 62% Eq / 33% FI / 5% Cash | Retirement projection update delivered |
| Q3 2026 | $1,585,000 | +$12,000 | 61% Eq / 34% FI / 5% Cash | Transition readiness checklist completed |
| Q4 2026 | $1,650,000 | +$12,000 | 61% Eq / 34% FI / 5% Cash | Year-end; all story arcs concluded |

Account Balances — December 31, 2026

| Account / Bucket | Balance | Notes |
| --- | --- | --- |
| ACCT-TX01 — Taxable Brokerage (Joint) — Bucket 3 | $850,000 | Equities + MUNIX; NLTK <5%; primary Bucket 3 |
| ACCT-IRA1 — Alex Traditional IRA — Bucket 2 | $555,000 | UCBIX + UTIPX; Bucket 2 stability core |
| ACCT-RIRA — Alex Roth IRA — Bucket 3 | $120,000 | Small cap / EM / REITX; tax-free long-term growth |
| ACCT-CASH — Cash Mgmt — Bucket 1 | $35,000 | Bucket 1 near-term reserve |
| ACCT-529A — Maya 529 | $45,000 | Age-based; Maya age 15; 2029 enrollment |
| ACCT-529B — Eli 529 | $45,000 | Age-based moderate; Eli age 12; 2032 enrollment |
| Household Total | $1,650,000 | 10-year growth: $410K → $1.65M |

Story Arc 3 Conclusion — Fee Governance Resolution (EventID-2026-01)

| Fee Resolution Item | Detail |
| --- | --- |
| Issue Identified | Q4 2025: DOC-StrategyDeck-2022-002 referenced stale 1.00% flat fee |
| Applicable Fee Schedule | DOC-FeeAmendment-2021-001: 0.85% / 0.70% / 0.55% tiered (eff. 2021-07-01) |
| Billing Review Outcome | 2022–2025 statements confirm correct blended tiered rate charged |
| Resolution | Fee credit of $1,250 issued Q1 2026 as goodwill acknowledgment |
| Public Documentation | MtgID-2026Q1-01 transcript + client summary letter (TaskID-2026Q1-801) |
| Internal Documentation | Restricted: DOC-InternalOnly-2026Q1-001/002 (not in this client report) |
| Final Strategy Deck Reference | Always reference DOC-StrategyDeck-2022-003 (FINAL) for correct fees |

5. TAX PLANNING RECAP — TAX YEAR 2026

Reference: Lisa Torres, EA

| Tax Line Item | TY2026 Amount |
| --- | --- |
| W-2 Wages (Alex + Sam combined) | $282,000 |
| Other Income (RSU / equity comp) | $20,000 |
| Interest & Dividend Income | $2,550 |
| Net Capital Gains | $18,000 |
| Charitable Contributions (DAF grants) | $8,000 |
| Deduction Method | Itemized |
| Approximate Adjusted Gross Income (AGI) | ~$330,000 |
| Federal Effective Tax Rate (Est.) | ~22.8% |
| Key Planning Note | Stable income year; continued itemized deductions + DAF grants |

2026 is a stable, predictable income year. The itemized deduction framework — mortgage interest, state/local taxes, and charitable contributions via the Clearwater Giving Fund DAF — continues to provide meaningful tax efficiency. Lisa Torres, EA continues coordination on estimated payments and year-end planning. Looking ahead: Roth conversion opportunities may emerge as income patterns normalize in pre-retirement years.

6. TEN-YEAR HOUSEHOLD SUMMARY (2016–2026)

A decade of consistent planning, evidence-based investing, and adaptive decision-making.

| Year | AUM Change | Milestone |
| --- | --- | --- |
| 2016 | $410,000 → $486,000 | Foundation: IPS established; goals set |
| 2017 | $486,000 → $595,000 | Growth: IRA rollover; tax reform planning |
| 2018 | $595,000 → $608,000 | Resilience: equity comp begins; Q4 volatility navigated |
| 2019 | $608,000 → $732,000 | Estate: revocable trust created; strong recovery year |
| 2020 | $732,000 → $792,000 | Arc 1: COVID repositioning; IPS amended; 529s opened |
| 2021 | $792,000 → $952,000 | Arc 1/3: Home purchase; first itemized year; fee amendment |
| 2022 | $952,000 → $890,000 | Arc 1 end: TLH campaign; cap loss carryforward created |
| 2023 | $890,000 → $1,140,000 | Arc 2: Liquidity event; AUM crosses $1M; DAF established |
| 2024 | $1,140,000 → $1,285,000 | Arc 2: Estate audit; beneficiary correction complete |
| 2025 | $1,285,000 → $1,450,000 | Arc 2 end: Bucket strategy; SS analysis; college planning |
| 2026 | $1,450,000 → $1,650,000 | Arc 3 end: Fee resolution; governance; transition readiness |

7. RECOMMENDATIONS & ACTION ITEMS

| TaskID / Item | Description | Status | Reference |
| --- | --- | --- | --- |
| TaskID-2026Q1-801 | Client summary letter — fee resolution | Complete 2026-03-01 | EventID-2026-01 |
| TaskID-2026Q2-818 | Retirement projection update | Complete 2026-Q2 | GoalID-2016-01 |
| TaskID-2026Q3-836 | Transition readiness checklist | Complete 2026-Q3 | GoalID-2016-01 |
| GoalID-2016-02 | 529 Maya final 3-year plan | Due 2027 Q1 | ACCT-529A — 2029 |
| GoalID-2023-01 | 2027 DAF distribution plan | Due 2027 Q1 | Clearwater Giving Fund |
| Ongoing | Annual IPS review (IPS-2025 in effect) | Q1 2027 | DOC-IPSAmendment-2025-001 |

8. DOCUMENT CROSS-REFERENCES

| Document | ID / Filename |
| --- | --- |
| Advisory Agreement (2016) | DOC-AdvisoryAgreement-2016-001 |
| IPS Original (2016) | DOC-IPS-2016-001 |
| IPS Amendment (2020) | DOC-IPSAmendment-2020-001 |
| IPS Amendment (2025 — Bucket Strategy) | DOC-IPSAmendment-2025-001 |
| Fee Amendment (2021) | DOC-FeeAmendment-2021-001 |
| Trust Document (2019) | DOC-Trust-2019-001 |
| Corrected Beneficiary Form (2024) | DOC-BeneficiaryForm-2024-001 |
| Fee Resolution — Q1 2026 Meeting Transcript | MeetingTranscript_ChenHousehold_MtgID-2026Q1-01.pdf |
| Client Summary Letter — Fee Resolution | ClientSummaryLetter_FeeResolution_TaskID-2026Q1-801.pdf |
| Strategy Deck 2022 FINAL (correct fee) | DOC-StrategyDeck-2022-003 |
| Tax Return Summary TY2026 | TaxReturnSummary_ChenHousehold_TY26.docx |
| This Document | DOC-AnnualConsolidatedReport-2026-001 |
