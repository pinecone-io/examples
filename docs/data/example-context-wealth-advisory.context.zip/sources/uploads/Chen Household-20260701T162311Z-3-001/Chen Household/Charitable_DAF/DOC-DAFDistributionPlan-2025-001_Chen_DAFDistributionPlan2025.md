| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | DAF Distribution Plan — Tax Year 2025DOC-DAFDistributionPlan-2025-001March 15, 2025HH-CHEN-001 |
| --- | --- |

| CLEARWATER GIVING FUND — 2025 DISTRIBUTION PLAN  |  PRE-RETIREMENT PHASE  |  HH-CHEN-001 |
| --- |

| Fund Name | Chen Family Charitable Fund  |  NGF-CHEN-2023-001 |
| --- | --- |

| Tax Year | 2025  (3 years to Alex’s retirement target: 2028–2030) |
| --- | --- |

| Decision Context | DecisionID-2025-112 — Bucket strategy; IPS-2025 amendment (RecID-2025-01) |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan (Year 3 of ongoing giving) |
| --- | --- |

| New Contribution | $7,500 cash (early 2025 top-up; itemized deduction TY 2025) |
| --- | --- |

| 2025 Grant Target | $7,500 (distributed from DAF to designated charities in 2025) |
| --- | --- |

| Fund Balance BOY | ~$21,200 (EOY 2024 estimated balance) |
| --- | --- |

| SECTION 1 — 2025 CONTEXT: PRE-RETIREMENT CHARITABLE ALIGNMENT |
| --- |

This distribution plan is prepared in March 2025 concurrent with the adoption of the IPS-2025 Bucket Strategy amendment (DecisionID-2025-112, RecID-2025-01). With Alex’s retirement target 3 years away and a portfolio approaching $1.3M AUM, the 2025 charitable planning session focused on two themes: (1) sustaining and growing the annual giving rhythm, and (2) beginning to integrate charitable intent with the broader legacy and estate plan.

The $7,500 DAF top-up in 2025 qualifies for itemized deduction (mortgage interest $16,250, SALT $10,000 cap, and this DAF contribution $7,500 are the three major itemized items). The deduction is fully absorbed within the 2025 estimated AGI of approximately $314,000.

| ℹ  STRATEGIC NOTE  Pre-Retirement Giving Strategy Note: As Alex approaches retirement, the household’s tax situation will shift significantly. Post-retirement, with W-2 income replaced by Social Security ($38K Alex + $18K Sam) and portfolio distributions, the marginal tax rate will likely decrease. This makes the 2025–2027 window particularly valuable for tax-deductible DAF contributions under the current itemized deduction framework. |
| --- |

| SECTION 2 — 2025 CONTRIBUTION: $7,500 CASH TOP-UP |
| --- |

| Contribution Type | Cash — electronic transfer |
| --- | --- |

| Amount | $7,500 |
| --- | --- |

| Contribution Date | March 15, 2025 |
| --- | --- |

| Deductibility | Itemized charitable deduction, TY 2025 (60% of AGI limit for cash) |
| --- | --- |

| 2025 AGI (est.) | ~$314,000 (W-2 $276K + RSU $20K + inv. income + cap gains; itemized deductions apply) |
| --- | --- |

| AGI Limit Check | $314,000 × 60% = $188,400 limit  >  $7,500  ✔ Fully deductible in 2025 |
| --- | --- |

| Itemized Deduction Context | Mortgage interest $16,250 + SALT $10,000 + DAF $7,500 = $33,750 total (exceeds standard $30,000 MFJ) |
| --- | --- |

| SECTION 3 — 2025 GRANT DISTRIBUTION PLAN |
| --- |

The following grants are planned for distribution in 2025 from the Clearwater Giving Fund. Distributions reflect an expanded giving footprint as the household’s financial position solidifies in the pre-retirement phase.

| Organization | Cause Area | 2025 Grant | 2024 Grant | Rationale |
| --- | --- | --- | --- | --- |
| Evanston Community Foundation | Community Development | $3,500 | $3,000 | Increased; community investment in retirement location |
| Greater Chicago Food Depository | Food Security | $2,000 | $2,000 | Maintained; consistent commitment |
| Lurie Children’s Hospital Foundation | Children’s Health | $1,500 | $1,000 | Increased; reflects values priority following EventID-2024-01 |
| Chicago Literacy Alliance | Education & Literacy | $500 | $0 | New addition 2025; GoalID-2016-02 education value alignment |
| TOTAL 2025 GRANTS | — | $7,500 | $6,000 | +$1,500 vs 2024; reflects growth in fund balance |

| SECTION 4 — FUND BALANCE PROJECTION (2025) |
| --- |

| Event | Amount | Running Balance |
| --- | --- | --- |
| EOY 2024 (opening balance) | $21,200 (est.) | $21,200 |
| Q1 2025 — $7,500 contribution | +$7,500 | $28,700 |
| 2025 — Market growth (est. 7%) | +$1,500 | $30,200 |
| 2025 — Grant distributions | −$7,500 | $22,700 |
| EOY 2025 (est.) | — | ~$22,700 |

| SECTION 5 — LEGACY & ESTATE INTEGRATION PLANNING |
| --- |

With retirement approaching, Morgan Park recommends beginning a formal review of the DAF’s role in the Chen household’s legacy plan. The following items are flagged for discussion at the 2025 Q2 annual planning meeting:

Designated successor advisers for the Clearwater Giving Fund (currently Alex primary, Sam secondary)

Alignment of DAF charitable mission statement with the MFRL-2019-001 trust’s values-based provisions

Review of whether a charitable remainder trust (CRT) structure could supplement the DAF post-retirement

Assessment of DAF’s 529 education goal synergy (GoalID-2016-02: Maya 2029, Eli 2032)

| ✔  PRE-RETIREMENT CHARITABLE POSITIONING: The DAF balance of ~$22,700 (EOY 2025 est.) represents approximately 3 years of giving at the current $7,500–$8,000/year rate, providing a sustained charitable endowment into retirement. Morgan Park recommends maintaining a minimum fund balance of $15,000–$20,000 to support post-retirement charitable distributions when the deductibility calculus changes. |
| --- |

| SECTION 6 — CROSS-REFERENCES |
| --- |

| Reference | Description |
| --- | --- |
| DecisionID-2025-112 | Bucket strategy adoption; IPS-2025 amendment |
| RecID-2025-01 | Bucket strategy (Implemented) |
| GoalID-2023-01 | Values-based giving plan (ongoing Year 3) |
| GoalID-2016-01 | Retirement savings goal — target 2028–2030 |
| GoalID-2016-02 | Education funding — Maya 2029, Eli 2032 |
| DOC-IPSAmendment-2025-001 | IPS-2025 bucket strategy amendment |
| DOC-DAFAnnualReview-2024-001 | 2024 annual review (prior document) |
| DOC-DAFYearEndSummary-2026-001 | 2026 year-end summary (subsequent document) |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | March 15, 2025 |
| Document ID: | see header |

| DOC-DAFDistributionPlan-2025-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
