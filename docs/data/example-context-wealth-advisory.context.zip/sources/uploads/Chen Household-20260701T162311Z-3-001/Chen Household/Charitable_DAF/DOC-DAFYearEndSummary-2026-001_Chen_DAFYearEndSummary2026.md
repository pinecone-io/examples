| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | DAF Year-End Summary — Tax Year 2026DOC-DAFYearEndSummary-2026-001December 10, 2026HH-CHEN-001 |
| --- | --- |

| CLEARWATER GIVING FUND — YEAR-END SUMMARY  |  TAX YEAR 2026  |  HH-CHEN-001 |
| --- |

| Fund Name | Chen Family Charitable Fund  |  NGF-CHEN-2023-001 |
| --- | --- |

| Tax Year | 2026  (Alex retirement target: 2028–2030; 2–4 years away) |
| --- | --- |

| Event Context | EventID-2026-01 — Fee billing discrepancy resolved Q1 2026; stewardship focus |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan (Year 4 of ongoing giving) |
| --- | --- |

| New Contribution | $8,000 cash (Q4 2026 top-up; itemized deduction TY 2026) |
| --- | --- |

| 2026 Grants | $8,000 (distributed to designated charities in 2026) |
| --- | --- |

| Fund Balance EOY | ~$24,000 (est.; reflects contributions, grants, and market appreciation) |
| --- | --- |

| SECTION 1 — 2026 OVERVIEW: STEWARDSHIP & INTEGRITY FOCUS |
| --- |

Tax year 2026 is a year of institutional and personal stewardship for the Chen household. The resolution of the fee billing discrepancy (EventID-2026-01) in Q1 2026 — while entirely unrelated to the charitable strategy — reinforced the household’s appreciation for transparent, values-aligned advising. The Q1 resolution meeting (MtgID-2026Q1-01) included a discussion of the household’s holistic financial health, including charitable goals.

With retirement 2–4 years away, Alex and Sam are increasingly thinking about the legacy dimensions of their financial plan. The 2026 charitable strategy reflects a mature, intentional approach: sustained annual giving, continued DAF growth, and preliminary conversations about longer-term legacy giving structures.

| ℹ  FIRM CONTEXT NOTE  Stewardship Context (2026): The AI-assisted documentation review in 2026 (EventID-2026-01) demonstrated the importance of accurate, correlated financial records. Morgan Park notes that the DAF’s clean documentation history across 2023–2026 represents best-in-class record-keeping for charitable intent — providing a clear audit trail for tax, estate, and legacy planning purposes. |
| --- |

| SECTION 2 — 2026 CONTRIBUTION: $8,000 CASH TOP-UP |
| --- |

| Contribution Type | Cash — electronic transfer |
| --- | --- |

| Amount | $8,000 |
| --- | --- |

| Contribution Date | November 20, 2026 |
| --- | --- |

| Deductibility | Itemized charitable deduction, TY 2026 (60% of AGI limit for cash) |
| --- | --- |

| 2026 AGI (est.) | ~$330,000 (W-2 $282K + other $20K + investment income + cap gains $18K) |
| --- | --- |

| AGI Limit Check | $330,000 × 60% = $198,000 limit  >  $8,000  ✔ Fully deductible in 2026 |
| --- | --- |

| SECTION 3 — 2026 GRANT DISTRIBUTIONS |
| --- |

| Organization | Cause Area | 2026 Grant | 2025 Grant | 3-Year Total |
| --- | --- | --- | --- | --- |
| Evanston Community Foundation | Community Development | $3,500 | $3,500 | $10,500 |
| Greater Chicago Food Depository | Food Security | $2,500 | $2,000 | $8,000 |
| Lurie Children’s Hospital Foundation | Children’s Health | $1,500 | $1,500 | $4,500 |
| Chicago Literacy Alliance | Education & Literacy | $500 | $500 | $1,000 |
| TOTAL 2026 GRANTS | — | $8,000 | $7,500 | $24,000 |

| SECTION 4 — FOUR-YEAR GIVING SUMMARY (2023–2026) |
| --- |

| Year | Contribution | Grants Paid | Tax Deduction | Est. Tax Savings | Fund Balance EOY |
| --- | --- | --- | --- | --- | --- |
| 2023 | $25,000 (NLTK in-kind) | $9,000 | $25,000 | ~$15,843 | ~$16,800 |
| 2024 | $6,000 (cash) | $6,000 | $6,000 | ~$2,578 | ~$21,200 |
| 2025 | $7,500 (cash) | $7,500 | $7,500 | ~$3,222 | ~$22,700 |
| 2026 | $8,000 (cash) | $8,000 | $8,000 | ~$3,440 | ~$24,000 |
| TOTAL 2023–2026 | $46,500 contributed | $30,500 granted | $46,500 deducted | ~$25,083 | — |

| ✔  FOUR-YEAR IMPACT: Over 2023–2026, the Chen household contributed $46,500 to the Clearwater Giving Fund and distributed $30,500 in charitable grants. Total estimated tax savings across the 4-year period: approximately $25,083. The DAF approach — particularly the 2023 in-kind NLTK stock donation — significantly outperformed direct cash giving on an after-tax basis. |
| --- |

| SECTION 5 — 2027–2028 FORWARD LOOK (RETIREMENT TRANSITION) |
| --- |

As Alex approaches retirement (target: 2028–2030 per GoalID-2016-01), the DAF strategy will require adjustment. Morgan Park recommends the following planning actions for 2027:

Maximize DAF contributions while Alex’s W-2 income remains high (2027 may be the last full high-income year if retirement in 2028)

Evaluate whether a Qualified Charitable Distribution (QCD) from ACCT-IRA1 becomes more tax-efficient post-age-70½

Formally document the DAF’s charitable mission statement and incorporate a letter of intent into the MFRL-2019-001 trust

Review Lurie Children’s Hospital as a potential legacy (bequest) beneficiary alongside DAF distributions

Assess whether the DAF balance ($24K+ EOY 2026) should be grown through a one-time larger contribution before retirement income compression

| SECTION 6 — FUND BALANCE HISTORY (2023–2026) |
| --- |

| Year-End | Opening Balance | Contributions | Grants | Market Growth | Closing Balance |
| --- | --- | --- | --- | --- | --- |
| 2023 | $0 | +$25,000 | −$9,000 | +$800 | $16,800 |
| 2024 | $16,800 | +$6,000 | −$6,000 | +$4,400 | $21,200 |
| 2025 | $21,200 | +$7,500 | −$7,500 | +$1,500 | $22,700 |
| 2026 | $22,700 | +$8,000 | −$8,000 | +$1,300 | $24,000 |

| SECTION 7 — CROSS-REFERENCES |
| --- |

| Reference | Description |
| --- | --- |
| EventID-2026-01 | Fee billing discrepancy resolution — stewardship context |
| GoalID-2023-01 | Values-based giving plan (Year 4) |
| GoalID-2016-01 | Retirement savings goal — target 2028–2030 |
| DOC-Trust-2019-001 | MFRL-2019-001 trust — DAF mission integration (future action) |
| DOC-DAFDistributionPlan-2025-001 | 2025 distribution plan (prior document) |
| DOC-IPSAmendment-2025-001 | IPS-2025 bucket strategy — AUM context for giving capacity |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | December 10, 2026 |
| Document ID: | see header |

| DOC-DAFYearEndSummary-2026-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
