| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | DAF Grant Recommendation — Q4 2023DOC-DAFGrantLetter-2023-001November 20, 2023HH-CHEN-001 |
| --- | --- |

| CLEARWATER GIVING FUND — GRANT RECOMMENDATIONS  |  Q4 2023  |  HH-CHEN-001 |
| --- |

| Fund Name | Chen Family Charitable Fund  |  NGF-CHEN-2023-001 |
| --- | --- |

| DAF Sponsor | Clearwater Giving Fund / Fidelity Charitable  |  CUST-FI-001 |
| --- | --- |

| Grant Period | Q4 2023 (November – December 2023) |
| --- | --- |

| Total Grants Rec. | $9,000 |
| --- | --- |

| Fund Balance (BOG) | $25,000 initial contribution + ~$800 market appreciation = $25,800 |
| --- | --- |

| Fund Balance (EOG) | $25,800 − $9,000 grants = ~$16,800 (estimated EOY 2023) |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan |
| --- | --- |

| Event Context | EventID-2023-01 — RSU liquidity event; DAF established May 2023 |
| --- | --- |

| SECTION 1 — GRANT RECOMMENDATIONS |
| --- |

Alex and Sam Chen have reviewed their charitable priorities for 2023 and recommend the following grants from the Chen Family Charitable Fund. All recipient organizations are IRS 501(c)(3) public charities confirmed eligible to receive DAF distributions.

| Organization | Cause Area | Grant Amount | EIN | Notes |
| --- | --- | --- | --- | --- |
| Evanston Community Foundation | Community Development | $4,000 | 36-3579975 | Local giving priority; Evanston/North Shore community |
| Greater Chicago Food Depository | Food Security & Hunger | $3,500 | 36-2899780 | Regional food access; high-need families |
| Ann & Robert H. Lurie Children’s Hospital Foundation | Children’s Health | $1,500 | 36-2170820 | Added Q4 2023 — reflects family values, children’s care |
| TOTAL GRANTS | — | $9,000 | — | First distribution from Clearwater Giving Fund |

| SECTION 2 — FUND BALANCE SUMMARY |
| --- |

| Date / Event | Description | Amount | Running Balance |
| --- | --- | --- | --- |
| May 18, 2023 | Initial contribution — 500 NLTK shares (FMV $25,000) | +$25,000 | $25,000 |
| May–Oct 2023 | Market appreciation (Fidelity Balanced Pool, est. 3.2%) | +$800 | $25,800 |
| Nov–Dec 2023 | Q4 2023 grants (this letter) | −$9,000 | $16,800 |
| EOY 2023 (est.) | Estimated year-end balance | — | $16,800 |

| SECTION 3 — 2023 GIVING IMPACT SUMMARY |
| --- |

| Metric | 2023 Value |
| --- | --- |
| Total contributed to DAF | $25,000 (NLTK in-kind, May 2023) |
| Total granted to charities | $9,000 (Q4 2023 distributions) |
| Charitable deduction claimed (est.) | $25,000 (itemized; Tax Year 2023) |
| Federal income tax savings (est.) | ~$9,250 (37% marginal rate) |
| State income tax savings (est.) | ~$1,238 (Illinois 4.95%) |
| Capital gains avoided (NLTK) | ~$5,355 (in-kind vs. sell-and-donate) |
| Total estimated 2023 tax benefit | ~$15,843 |

| ✔  GRANTING PLAN INITIATED: This letter authorizes the first grant distributions from the Chen Family Charitable Fund. The balance of ~$16,800 will continue to grow in the Fidelity Charitable Balanced Pool and support the household’s ongoing giving strategy. Morgan Park will review giving priorities annually in Q4 meetings consistent with GoalID-2023-01. |
| --- |

| SECTION 4 — CROSS-REFERENCES |
| --- |

| Reference | Description |
| --- | --- |
| GoalID-2023-01 | Values-based giving plan — annual grant reviews |
| EventID-2023-01 | RSU liquidity event / NLTK concentration spike (trigger) |
| RecID-2023-01 | DAF recommendation (Implemented 2023) |
| DOC-DAFEstablishment-2023-001 | DAF opening packet — fund account and contribution details |
| DOC-DAFTaxStrategy-2023-001 | Tax strategy memo — DAF bunching analysis |
| DOC-DAFAnnualReview-2024-001 | 2024 annual review (subsequent document) |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | November 20, 2023 |
| Document ID: | see header |

| DOC-DAFGrantLetter-2023-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
