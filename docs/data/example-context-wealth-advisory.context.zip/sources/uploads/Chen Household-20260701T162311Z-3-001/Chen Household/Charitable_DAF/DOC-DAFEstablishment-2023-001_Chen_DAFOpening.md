| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | DAF Account Opening — Clearwater Giving FundDOC-DAFEstablishment-2023-001May 18, 2023HH-CHEN-001 |
| --- | --- |

| DONOR-ADVISED FUND ESTABLISHMENT PACKET  |  CLEARWATER GIVING FUND  |  MAY 2023 |
| --- |

| Client Household | Chen Household (Alex & Sam Chen)  |  HH-CHEN-001 |
| --- | --- |

| Adviser | Morgan Park, CFP®  |  ADV-PARK-001  |  Clearwater Wealth Partners |
| --- | --- |

| DAF Sponsor | Clearwater Giving Fund (Fidelity Charitable Gift Fund)  |  CUST-FI-001 |
| --- | --- |

| Account Opened | May 18, 2023 |
| --- | --- |

| Event Trigger | EventID-2023-01 — RSU liquidity event + NLTK concentration reduction |
| --- | --- |

| Decision Reference | DecisionID-2023-349 — Diversify NLTK + Fund DAF |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan |
| --- | --- |

| Recommendation | RecID-2023-01 — DAF for high-income-year giving (Implemented) |
| --- | --- |

| SECTION 1 — PURPOSE & STRATEGIC RATIONALE |
| --- |

In May 2023, Alex Chen experienced a significant RSU vesting event (EventID-2023-01) resulting in a large NLTK concentration in ACCT-TX01. The resulting liquidity event elevated the household's 2023 estimated AGI to approximately $426,000 — one of the highest-income years in the household's planning history. This created a time-sensitive opportunity to deploy charitable giving in a tax-efficient manner.

Morgan Park recommended establishing a Donor-Advised Fund (DAF) with Clearwater Giving Fund (via Fidelity Charitable) rather than making direct cash gifts. This approach allows:

Contribution of appreciated NLTK shares directly — eliminating embedded capital gains (~$22,500 LTCG avoided)

Immediate charitable deduction in the high-income year (2023, ~$426K AGI), maximizing the after-tax value

Decoupling the tax deduction year from the grant distribution year — grants to charities can occur over time

Creating a sustainable, values-aligned giving vehicle for the Chen household (GoalID-2023-01)

| ⚠  KEY TAX NOTE  Tax Strategy Context: At an estimated AGI of $426,000, Alex and Sam are subject to the 37% federal marginal rate + 4.95% Illinois state tax, plus the 3.8% Net Investment Income Tax (NIIT) on investment income. Donating appreciated NLTK stock (rather than cash) to the DAF allows the household to avoid capital gains tax on the embedded gain while claiming a full fair-market-value deduction. |
| --- |

| SECTION 2 — INITIAL CONTRIBUTION DETAILS |
| --- |

| Contribution Type | Appreciated Stock (in-kind transfer — NLTK shares) |
| --- | --- |

| Security | NLTK — Clearwater Tech Common Stock (ACCT-TX01 sleeve) |
| --- | --- |

| Shares Transferred | 500 shares |
| --- | --- |

| Fair Market Value | $50.00 / share  ×  500 shares  =  $25,000 (May 18, 2023) |
| --- | --- |

| Cost Basis | $5.00 / share  ×  500 shares  =  $2,500 |
| --- | --- |

| Embedded LTCG | $22,500 (long-term capital gain avoided by in-kind donation) |
| --- | --- |

| Charitable Deduction | $25,000 (FMV; deductible up to 30% of AGI for appreciated stock) |
| --- | --- |

| AGI Limit Check | $426,000 AGI × 30% = $127,800 limit  >  $25,000 deduction  ✔ No carryforward needed |
| --- | --- |

| Custodian / Platform | Fidelity Charitable — National Donor-Advised Fund |
| --- | --- |

| Account Number | NGF-CHEN-2023-001 |
| --- | --- |

| ✔  CAPITAL GAINS AVOIDED: By donating NLTK shares in-kind rather than selling and donating proceeds, the household avoids $22,500 in long-term capital gains. At the 20% LTCG rate + 3.8% NIIT, this represents approximately $5,355 in tax savings on the embedded gain alone, in addition to the $25,000 federal + state income tax deduction. |
| --- |

| SECTION 3 — DAF ACCOUNT STRUCTURE |
| --- |

| Parameter | Detail | Notes |
| --- | --- | --- |
| DAF Sponsor | Clearwater Giving Fund / Fidelity Charitable | National sponsor; CUST-FI-001 custodian relationship |
| Account Name | Chen Family Charitable Fund | Household-chosen name for fund |
| Account Reference | NGF-CHEN-2023-001 | Internal cross-reference ID |
| Investment Option | Fidelity Charitable Balanced Pool | Moderate growth during accumulation |
| Successor Advisers | Alex Chen (primary); Sam Chen | DOC-Trust-2019-001 trust alignment |
| Charitable Purpose | Community, food security, children’s health, education | GoalID-2023-01 values framework |

| SECTION 4 — ANTICIPATED GRANTING PLAN |
| --- |

The DAF is designed as a long-term charitable vehicle. Initial granting is anticipated to begin in late Q4 2023. Target organizations align with the Chen household’s values priorities: community development, food security, children’s health, and education.

| Priority Area | Target Organization(s) | Anticipated Annual Grant |
| --- | --- | --- |
| Community Development | Evanston Community Foundation | $3,000–$5,000 |
| Food Security | Greater Chicago Food Depository | $2,000–$4,000 |
| Children’s Health | Ann & Robert H. Lurie Children’s Hospital | $1,000–$2,000 |
| Education | Chicago Literacy Alliance | $500–$1,500 |
| Environmental / Future | TBD — joint decision Alex & Sam | TBD |

| Annual top-up contributions are anticipated in subsequent years (2024–2026) to maintain DAF balance and sustain giving goals. Each annual contribution generates a current-year charitable deduction under the itemized deduction regime (applicable 2021+). |
| --- |

| SECTION 5 — CROSS-REFERENCES & ACTION LOG |
| --- |

| Reference ID | Type | Description |
| --- | --- | --- |
| EventID-2023-01 | Life Event | RSU liquidity event / NLTK concentration spike |
| DecisionID-2023-349 | Decision | Diversify NLTK + fund DAF; window Apr 10–Jun 30, 2023 |
| GoalID-2023-01 | Planning Goal | Values-based giving plan; created 2023-05-18 |
| RecID-2023-01 | Recommendation | DAF for high-income-year giving (Implemented) |
| TaxTopicID-2023-01 | Tax Topic | High-income year; DAF bunching strategy |
| ACCT-TX01 | Account | Source of NLTK shares; brokerage account |
| DOC-DAFTaxStrategy-2023-001 | Document | Companion tax strategy memo |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | May 18, 2023 |
| Document ID: | see header |

| DOC-DAFEstablishment-2023-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
