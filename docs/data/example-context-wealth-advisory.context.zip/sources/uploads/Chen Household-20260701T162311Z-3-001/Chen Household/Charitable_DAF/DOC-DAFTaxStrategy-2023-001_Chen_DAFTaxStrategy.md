| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | Charitable Tax Strategy Memo — High-Income YearDOC-DAFTaxStrategy-2023-001June 15, 2023HH-CHEN-001 |
| --- | --- |

| CHARITABLE GIVING & DAF BUNCHING STRATEGY  |  TAX YEAR 2023  |  CHEN HOUSEHOLD |
| --- |

| Client | Chen Household (Alex & Sam Chen)  |  HH-CHEN-001 |
| --- | --- |

| Tax Year | 2023 |
| --- | --- |

| Event Trigger | EventID-2023-01 — RSU liquidity event + NLTK concentration spike |
| --- | --- |

| Decision Ref | DecisionID-2023-349 — Diversify NLTK + Fund DAF |
| --- | --- |

| Tax Topic | TaxTopicID-2023-01 — High-income year; DAF bunching strategy |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan |
| --- | --- |

| Rec Reference | RecID-2023-01 — DAF for high-income-year giving |
| --- | --- |

| SECTION 1 — 2023 INCOME OVERVIEW (HIGH-INCOME YEAR) |
| --- |

Tax year 2023 is a significant income spike year for the Chen household due to a large RSU vesting event (EventID-2023-01) that resulted in an estimated $120,000 in other/equity compensation income. This, combined with base W-2 income of $262,000, investment income of $2,100, and net capital gains of approximately $42,000 (after partial 2022 TLH carryforward offset), drives an estimated 2023 AGI of approximately $426,000.

| Income Category | 2023 Estimate | 2022 Actual | Change |
| --- | --- | --- | --- |
| Alex W-2 Base Salary | $262,000 | $258,000 | +$4,000 |
| RSU / Equity Compensation | $120,000 | $10,000 | +$110,000 |
| Interest & Dividend Income | $2,100 | $1,650 | +$450 |
| Net Realized Capital Gains (est.) | $42,000 | -$15,500 | +$57,500 |
| TOTAL ESTIMATED AGI | $426,100 | $254,150 | +$171,950 |

| ℹ  NOTE  Capital loss carryforward from 2022 TLH campaign (TaxTopicID-2022-01) partially offsets 2023 gains. Without the 2022 carryforward (~$12,000), 2023 net cap gains would have been approximately $54,000. |
| --- |

| SECTION 2 — DAF BUNCHING STRATEGY ANALYSIS |
| --- |

The 'charitable bunching' strategy involves accelerating multiple years of charitable giving into a single high-income tax year to maximize the itemized deduction benefit. In 2023, the household’s elevated AGI of ~$426K makes itemization particularly valuable.

| Scenario | 2023 Charitable Deduction | 2024–2025 Deduction | NPV Tax Savings |
| --- | --- | --- | --- |
| Option A: Spread giving ($6K–$8K/yr) | $6,000–$8,000 | $6,000–$8,000 each year | Lower — deductions in lower-income years |
| Option B: DAF Bunching $25K in 2023 | $25,000 (full FMV) | Grants from DAF (no addl. deduction) | HIGHER — full deduction at 37%+4.95% marginal rate |
| Option B vs A — Incremental Tax Savings | +$17,000–$19,000 | Grants from DAF | ~$8,000–$9,000 additional federal + state savings |

| SECTION 3 — IN-KIND STOCK DONATION ANALYSIS (NLTK SHARES) |
| --- |

Rather than selling NLTK shares and donating proceeds, donating the shares in-kind to the DAF provides a dual tax benefit: (1) avoidance of capital gains tax on the embedded gain, and (2) a full fair-market-value charitable deduction.

| Factor | Sell & Donate Cash | Donate NLTK Shares In-Kind | Advantage |
| --- | --- | --- | --- |
| Shares | 500 NLTK | 500 NLTK | — |
| FMV @ donation | $25,000 | $25,000 | — |
| Cost Basis | $2,500 | $2,500 | — |
| Embedded LTCG | $22,500 | $22,500 | — |
| Capital Gains Tax Paid | ~$5,355 (20%+3.8%NIIT) | $0.00 | In-Kind saves $5,355 |
| Charitable Deduction | $25,000 (cash donated) | $25,000 (FMV) | Equal deduction |
| After-Tax Value to DAF | $25,000 − $5,355 = $19,645 | $25,000 | In-Kind: +$5,355 |

| SECTION 4 — TAX IMPACT SUMMARY: 2023 |
| --- |

| Tax Item | Amount | Marginal Rate | Tax Savings |
| --- | --- | --- | --- |
| Federal Income Tax (37% marginal on $25K deduction) | $25,000 | 37% | ~$9,250 |
| Illinois State Income Tax (4.95% flat) | $25,000 | 4.95% | ~$1,238 |
| NLTK Embedded Gain Avoided (20% LTCG + 3.8% NIIT) | $22,500 | 23.8% | ~$5,355 |
| TOTAL ESTIMATED TAX SAVINGS — 2023 | — | — | ~$15,843 |

| ✔  RECOMMENDATION IMPLEMENTED (RecID-2023-01): DAF established May 18, 2023 with $25,000 NLTK in-kind contribution. Estimated total 2023 tax savings: approximately $15,800. The Clearwater Giving Fund (NGF-CHEN-2023-001) is now positioned as the household’s primary charitable vehicle for 2023 and future years, consistent with GoalID-2023-01. |
| --- |

| SECTION 5 — MULTI-YEAR GIVING FRAMEWORK |
| --- |

With the DAF established, the household enters a sustainable giving rhythm: annual top-up contributions (generating current-year deductions) and ongoing grants to cause areas. This strategy maintains itemized deduction eligibility in future years (2024–2026) while decoupling the giving decision from the tax-planning calendar.

| Year | New Contribution to DAF | Charitable Deduction | Estimated Tax Savings | Notes |
| --- | --- | --- | --- | --- |
| 2023 (actual) | $25,000 NLTK in-kind | $25,000 | ~$15,843 | Bunching year; high-AGI optimization |
| 2024 (est.) | $6,000 cash | $6,000 | ~$2,578 | Ongoing; itemized deduction year |
| 2025 (est.) | $7,500 cash | $7,500 | ~$3,222 | Pre-retirement; bucket strategy year |
| 2026 (est.) | $8,000 cash | $8,000 | ~$3,440 | Continued stewardship; Arc 3 context |

| 2024–2026 savings estimates use projected federal rate of ~37%+4.95% IL. Actual savings depend on taxable income, available deductions, and AMT exposure in each year. This memo should be revisited annually in Q4 tax planning meetings. |
| --- |

| SECTION 6 — CROSS-REFERENCES |
| --- |

| Reference | Description |
| --- | --- |
| EventID-2023-01 | RSU vesting / NLTK liquidity event trigger |
| DecisionID-2023-349 | NLTK diversification + DAF funding decision |
| TaxTopicID-2023-01 | High-income year tax planning discussion |
| GoalID-2023-01 | Values-based giving plan |
| RecID-2023-01 | DAF recommendation (Implemented) |
| DOC-DAFEstablishment-2023-001 | DAF opening packet — Clearwater Giving Fund |
| DOC-DAFGrantLetter-2023-001 | First grant recommendations (Q4 2023) |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | June 15, 2023 |
| Document ID: | see header |

| DOC-DAFTaxStrategy-2023-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
