| CLEARWATER WEALTH PARTNERSCharitable Planning DivisionADV-PARK-001 | Morgan Park CFP® | DAF Annual Review & Grant Plan — Tax Year 2024DOC-DAFAnnualReview-2024-001November 15, 2024HH-CHEN-001 |
| --- | --- |

| CLEARWATER GIVING FUND — ANNUAL REVIEW  |  TAX YEAR 2024  |  HH-CHEN-001 |
| --- |

| Fund Name | Chen Family Charitable Fund  |  NGF-CHEN-2023-001 |
| --- | --- |

| Tax Year | 2024 |
| --- | --- |

| Event Context | EventID-2024-01 — Family health event; estate/beneficiary review |
| --- | --- |

| Goal Reference | GoalID-2023-01 — Values-based giving plan (Year 2 of ongoing giving) |
| --- | --- |

| New Contribution | $6,000 cash (Q4 2024 top-up; itemized deduction claimed TY 2024) |
| --- | --- |

| 2024 Grants | $6,000 (grants from DAF to designated charities) |
| --- | --- |

| Fund Balance EOY | ~$13,200 (est.; after 2024 contribution, grants, and market growth) |
| --- | --- |

| SECTION 1 — ANNUAL REVIEW NARRATIVE |
| --- |

This annual review marks the second year of operation for the Chen Family Charitable Fund. The 2024 giving cycle takes on added significance following a close family health event in Q1 2024 (EventID-2024-01), which prompted Alex and Sam to revisit their estate planning, healthcare directives, and — as discussed in the Q4 annual meeting — the long-term legacy and charitable intent underlying the DAF.

The health event reinforced the household’s commitment to values-based giving, particularly in the area of children’s health. Lurie Children’s Hospital Foundation has been elevated as a priority recipient for 2024 and beyond.

| ⚠  CONTEXT NOTE  2024 Context: The family health event (EventID-2024-01) prompted the full estate audit completed in Q3 2024 (RecID-2024-01 closed). As part of the broader estate review, Morgan Park and the Chens discussed integrating the DAF into the trust structure over the long term — particularly if the household’s charitable intent grows. No structural changes are recommended at this time; the DAF continues as a standalone vehicle. |
| --- |

| SECTION 2 — 2024 CONTRIBUTION: $6,000 CASH TOP-UP |
| --- |

| Contribution Type | Cash — electronic transfer from Alex’s checking account |
| --- | --- |

| Amount | $6,000 |
| --- | --- |

| Contribution Date | November 15, 2024 |
| --- | --- |

| Deductibility | Itemized charitable deduction, TY 2024 — up to 60% of AGI for cash |
| --- | --- |

| 2024 AGI (est.) | $302,000 (W-2 $270K + other $15K + int/div $2.25K + cap gains $14.5K) |
| --- | --- |

| AGI Limit Check | $302,000 × 60% = $181,200 limit  >  $6,000  ✔ Fully deductible in 2024 |
| --- | --- |

| SECTION 3 — 2024 GRANT RECOMMENDATIONS |
| --- |

| Organization | Cause Area | 2024 Grant | 2023 Grant | Notes |
| --- | --- | --- | --- | --- |
| Evanston Community Foundation | Community Development | $3,000 | $4,000 | Consistent priority; slight reduction vs 2023 |
| Greater Chicago Food Depository | Food Security | $2,000 | $3,500 | Reduction; redirected to children’s health |
| Lurie Children’s Hospital Foundation | Children’s Health | $1,000 | $1,500 | Elevated priority following EventID-2024-01 health event |
| TOTAL 2024 GRANTS | — | $6,000 | $9,000 | Reduced granting; EOY balance maintained ~$13K |

| Total 2024 grants are lower than 2023 to preserve DAF balance as a growing charitable endowment. Accumulated balance supports larger future grants as the household approaches retirement (target 2028–2030) and legacy planning intensifies. |
| --- |

| SECTION 4 — FUND BALANCE HISTORY |
| --- |

| Period | Opening Balance | Contributions | Grants Paid | Market Growth (est.) | Closing Balance |
| --- | --- | --- | --- | --- | --- |
| 2023 (full year) | $0 | +$25,000 | −$9,000 | +$800 | $16,800 |
| 2024 Q1–Q3 | $16,800 | — | — | +$3,900 | $20,700 |
| 2024 Q4 (this doc) | $20,700 | +$6,000 | −$6,000 | +$500 | $21,200 |
| EOY 2024 (est.) | — | — | — | — | ~$21,200 |

| SECTION 5 — MULTI-YEAR GIVING SUMMARY |
| --- |

| Year | Contribution | Grants Paid | Tax Deduction | Fund Balance EOY |
| --- | --- | --- | --- | --- |
| 2023 | $25,000 NLTK in-kind | $9,000 | $25,000 | ~$16,800 |
| 2024 | $6,000 cash | $6,000 | $6,000 | ~$21,200 |
| 2025 | $7,500 (projected) | $7,500 | $7,500 | ~$22,000 (est.) |
| 2026 | $8,000 (projected) | $8,000 | $8,000 | ~$23,000 (est.) |

| SECTION 6 — RETIREMENT & LEGACY INTEGRATION NOTE |
| --- |

As the Chen household moves toward Alex’s retirement target of 2028–2030 (GoalID-2016-01), the DAF will increasingly serve as a legacy vehicle. Morgan Park recommends reviewing the DAF’s integration with the MFRL-2019-001 trust at the 2025 annual meeting, particularly around succession of fund advisory rights and potential charitable bequest provisions.

| SECTION 7 — CROSS-REFERENCES |
| --- |

| Reference | Description |
| --- | --- |
| EventID-2024-01 | Family health event — triggered estate review + giving priority shift |
| RecID-2024-01 | Estate refresh + POA/health directive review (Complete 2024-Q3) |
| GoalID-2023-01 | Values-based giving plan (ongoing) |
| GoalID-2016-01 | Retirement goal — target 2028–2030 |
| DOC-Trust-2019-001 | Chen Family Revocable Living Trust — beneficiary alignment |
| DOC-DAFGrantLetter-2023-001 | 2023 first grants (prior document) |
| DOC-DAFDistributionPlan-2025-001 | 2025 distribution plan (subsequent document) |

| Prepared By: | Morgan Park, CFP® — ADV-PARK-001 |
| --- | --- |
| Firm: | Clearwater Wealth Partners |
| Date: | November 15, 2024 |
| Document ID: | see header |

| DOC-DAFAnnualReview-2024-001  |  v1.0  |  Confidential  |  Clearwater Wealth Partners  |  HH-CHEN-001 |
| --- |
