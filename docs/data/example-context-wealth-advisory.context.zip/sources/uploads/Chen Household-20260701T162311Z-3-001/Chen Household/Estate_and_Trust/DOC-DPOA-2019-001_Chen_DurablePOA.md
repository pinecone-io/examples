| CLEARWATER WEALTH PARTNERSChen Family — Estate & Trust Documents  |  HH-CHEN-001 | DOC-DPOA-2019-001September 10, 2019EXECUTED |
| --- | --- |

DURABLE POWER OF ATTORNEY Financial, Healthcare, and Asset Management (Alex Chen & Sam Chen — Mutual)

| EVENT TRIGGER: EventID-2019-01 — Executed concurrently with trust and wills. This instrument grants mutual durable financial and healthcare powers of attorney between Alex Chen and Sam Chen. Effective immediately; not springing. Linked: DOC-Trust-2019-001, DOC-Will-2019-001, DOC-Will-2019-002. See DOC-TrustAmendment-2024-001 for 2024 healthcare directive updates (EventID-2024-01). |
| --- |

| PART A — ALEX CHEN AS PRINCIPAL |
| --- |

I, Alex Chen ("Principal"), residing at 8912 Birchwood Drive, Naperville, Illinois 60563, being of sound mind, hereby appoint Sam Chen ("Agent") as my attorney-in-fact to act in my name, place, and stead in any way which I myself could do with respect to the following matters, to the extent permitted by law:

| Principal: | Alex Chen  (DOB: 1981-03-22) |
| --- | --- |

| Primary Agent: | Sam Chen (Spouse)  — Effective Immediately |
| --- | --- |

| Successor Agent: | Maya Chen (upon age 25)  |  then: Westfield & Baker LLP, Trust Dept. |
| --- | --- |

| Type: | DURABLE — remains effective upon Principal's incapacity |
| --- | --- |

| Governing Law: | Illinois Power of Attorney Act (755 ILCS 45/) |
| --- | --- |

| FINANCIAL POWERS GRANTED (ALEX → SAM) |
| --- |

| ☑  Investment Management | Buy, sell, exchange, transfer, and manage investment accounts including ACCT-TX01, ACCT-IRA1, and accounts held at Clearwater Wealth Partners / Fidelity Institutional (CUST-FI-001). |
| --- | --- |

| ☑  Banking Operations | Open, close, deposit, withdraw, and manage checking, savings, and money market accounts at any financial institution. |
| --- | --- |

| ☑  Real Property | Purchase, sell, lease, mortgage, and manage real property in the Grantors' names or in the Trust. Execute deeds, titles, and transfer documents. |
| --- | --- |

| ☑  Tax Matters | Sign tax returns, respond to IRS inquiries, negotiate tax settlements, and engage tax professionals on Principal's behalf. |
| --- | --- |

| ☑  Trust Administration | Exercise all powers as Co-Trustee of DOC-Trust-2019-001, including funding, amendment authorization, and distribution decisions. |
| --- | --- |

| ☑  Retirement Accounts | Direct contributions, distributions, beneficiary designations (with adviser notification), and rollovers for ACCT-IRA1 and ACCT-RIRA. |
| --- | --- |

| ☑  Business / Employment | Manage business interests, execute employment agreements, exercise stock options and RSU elections (re: EventID-2018-01 equity comp). |
| --- | --- |

| ☑  Insurance | Maintain, modify, and claim benefits under any life, health, disability, and property insurance policies. |
| --- | --- |

| HEALTHCARE POWERS GRANTED (ALEX → SAM) |
| --- |

In addition to the financial powers above, Sam Chen is authorized as Healthcare Agent for Alex Chen with the following powers:

• Make all healthcare decisions if Alex Chen is unable to communicate wishes.

• Consent to, refuse, or withdraw any medical treatment, surgery, or life-prolonging procedure.

• Hire and discharge healthcare providers; access all medical records (HIPAA authorization included).

• Direct admission to or discharge from any hospital, nursing facility, or hospice.

• Make anatomical gifts and direct disposition of remains per Principal's expressed wishes.

ADVANCE DIRECTIVE — ALEX CHEN: I direct that if I have an incurable condition from which I will not recover, and if I am unable to make healthcare decisions, my Agent shall honor my expressed preference to avoid artificially prolonged dying. I authorize comfort care. I do NOT wish life-sustaining treatment to be initiated or continued if it merely prolongs dying. DNR directive appended as Schedule C.

| PART B — SAM CHEN AS PRINCIPAL |
| --- |

I, Sam Chen ("Principal"), hereby appoint Alex Chen ("Agent") as my attorney-in-fact on identical terms as set forth in Part A, with Sam Chen in the role of Principal and Alex Chen in the role of Agent. All powers, limitations, and healthcare directives in Part A apply mutually and reciprocally.

| Principal: | Sam Chen  (DOB: 1981-11-03) |
| --- | --- |

| Primary Agent: | Alex Chen (Spouse)  — Effective Immediately |
| --- | --- |

| Successor Agent: | Eli Chen (upon age 25)  |  then: Westfield & Baker LLP, Trust Dept. |
| --- | --- |

| Type: | DURABLE — remains effective upon Principal's incapacity |
| --- | --- |

ADVANCE DIRECTIVE — SAM CHEN: I share the same values and preferences as stated in Part A for Alex Chen. My Agent is authorized to make all healthcare decisions on my behalf in accordance with my expressed wishes and the spirit of this document. DNR directive appended as Schedule D.

| 2024 UPDATE NOTICE:  Both healthcare directives were reviewed and updated in connection with EventID-2024-01 (family health event). See DOC-TrustAmendment-2024-001 (executed 2024-09-15) for updated advance directive language, Physician Orders for Life-Sustaining Treatment (POLST) alignment, and expanded healthcare agent instructions. RecID-2024-01 marked complete. |
| --- |

| GENERAL PROVISIONS |
| --- |

| Durability: | This POA is durable under the Illinois Power of Attorney Act (755 ILCS 45/2-4) and remains effective despite subsequent disability or incapacity of the Principal. |
| --- | --- |

| Third-Party Reliance: | Third parties relying on this instrument in good faith shall be protected from liability. A photocopy or electronic copy is as effective as the original. |
| --- | --- |

| Revocation: | This POA may be revoked in writing at any time while the Principal has legal capacity. Revocation is effective upon delivery of a signed written notice to the Agent. |
| --- | --- |

| Compensation: | The Agent shall not receive compensation for services as Attorney-in-Fact unless expressly agreed upon in a separate writing. |
| --- | --- |

| Successor Agent Activation: | A Successor Agent may act only upon presenting a written statement, signed under penalty of perjury, that the primary Agent is unable or unwilling to serve. |
| --- | --- |

| SIGNATURES AND EXECUTION |
| --- |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Alex Chen | Sam Chen |
| Principal (Alex Chen) | Agent (Sam Chen) |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Sam Chen | Alex Chen |
| Principal (Sam Chen) | Agent (Alex Chen) |

Date of Execution: September 10, 2019

Prepared by: Westfield & Baker LLP | 312 S. Michigan Ave, Suite 1400, Chicago, IL 60604

Attorney: Patricia Hawthorne, J.D., LL.M. (Estate & Trust Law) | p.hawthorne@hawthornecolellp.com

| DOC-DPOA-2019-001  |  Durable Power of Attorney — Alex & Sam Chen  |  Clearwater Wealth Partners  |  HH-CHEN-001 | CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED |
| --- | --- |
