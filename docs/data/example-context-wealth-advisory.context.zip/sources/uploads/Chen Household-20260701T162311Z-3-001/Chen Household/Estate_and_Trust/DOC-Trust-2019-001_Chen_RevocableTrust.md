| CLEARWATER WEALTH PARTNERSChen Family — Estate & Trust Documents  |  HH-CHEN-001 | DOC-Trust-2019-001September 10, 2019EXECUTED |
| --- | --- |

CHEN FAMILY REVOCABLE LIVING TRUST AGREEMENT

| EVENT TRIGGER: EventID-2019-01 — Revocable trust created as part of comprehensive estate foundation review. Drafted by Patricia Hawthorne, J.D., LL.M., Westfield & Baker LLP. Linked documents: DOC-Will-2019-001 (Alex pour-over will), DOC-Will-2019-002 (Sam pour-over will), DOC-DPOA-2019-001 (Durable Power of Attorney), DOC-BeneficiaryUpdate-2019-001. |
| --- |

| ARTICLE I — RECITALS AND TRUST IDENTIFICATION |
| --- |

This Chen Family Revocable Living Trust Agreement (the "Trust Agreement" or "Trust") is entered into on September 10, 2019, between Alex Chen and Sam Chen, husband and wife, residing at 8912 Birchwood Drive, Naperville, Illinois 60563 (individually and collectively, the "Grantors" and initial "Trustees").

The Trust shall be known as the CHEN FAMILY REVOCABLE LIVING TRUST, established for the benefit of the Grantors during their lifetimes and, upon the death of both Grantors, for the benefit of their issue and such other persons as may be designated herein.

| Trust Name: | Chen Family Revocable Living Trust |
| --- | --- |

| Trust ID: | MFRL-2019-001  |  TIN: Applied For (SS-4 filed 2019-09-10) |
| --- | --- |

| Date Established: | September 10, 2019  (Effective Date) |
| --- | --- |

| State of Governing Law: | Illinois (755 ILCS 5/ — Probate Act; 760 ILCS 5/ — Trusts & Trustees Act) |
| --- | --- |

| Linked Event: | EventID-2019-01 (Revocable Trust Creation & Estate Refresh) |
| --- | --- |

| Wealth Adviser: | Morgan Park, CFP® — Clearwater Wealth Partners (ADV-PARK-001) |
| --- | --- |

| Drafting Attorney: | Patricia Hawthorne, J.D., LL.M. — Westfield & Baker LLP |
| --- | --- |

| ARTICLE II — TRUSTEE SUCCESSION |
| --- |

Section 2.1 — Initial Trustees. Alex Chen and Sam Chen shall serve as Co-Trustees of this Trust during their joint lifetimes. Either Co-Trustee may act independently on routine administrative matters; extraordinary actions (sale of real property, amendment of the Trust, removal of a successor trustee) require joint written consent.

Section 2.2 — Successor Trustee Upon First Death. Upon the death or permanent incapacity of one Co-Trustee, the surviving Co-Trustee shall serve as sole Trustee with all powers granted herein. No court appointment shall be necessary.

Section 2.3 — Successor Trustee Upon Both Deaths or Joint Incapacity. If both Alex Chen and Sam Chen are deceased or incapacitated, the following persons are appointed Successor Trustees in the order listed:

| Priority | Name | Relationship |
| --- | --- | --- |
| 1st | Maya Chen (upon reaching age 25) | Child of Grantors |
| 2nd | Eli Chen (upon reaching age 25) | Child of Grantors |
| 3rd | First National Bank & Trust, N.A. | Corporate Successor Trustee |

| ARTICLE III — BENEFICIARIES |
| --- |

Section 3.1 — Primary Beneficiaries During Grantors' Lifetimes. During the joint lifetimes of both Grantors, the Grantors themselves are the sole primary beneficiaries of this Trust. The Grantors retain the right to use, enjoy, and consume Trust property as they deem appropriate.

Section 3.2 — Beneficiaries Upon Death of Both Grantors. Upon the death of the surviving Grantor, the Trust estate shall be distributed as follows:

| Beneficiary | DOB | Share | Distribution Conditions |
| --- | --- | --- | --- |
| Maya Chen | 2011-08-19 | 50% | Held in sub-trust to age 25; 1/3 at 30; balance at 35 |
| Eli Chen | 2014-03-07 | 50% | Held in sub-trust to age 25; 1/3 at 30; balance at 35 |
| Per Stirpes | — | 100% | If a child predeceases, share passes to their issue per stirpes |

| ARTICLE IV — TRUST PROPERTY AND FUNDING |
| --- |

Section 4.1 — Initial Funding. The Grantors hereby transfer and convey to the Trustees all property described in Schedule A attached hereto, to be held, administered, and distributed in accordance with the terms of this Trust Agreement.

Section 4.2 — Investment Accounts — Clearwater Wealth Partners (Fidelity Institutional Custody). The following investment accounts are designated for re-titling into the Trust name upon execution:

| Account ID | Account Type | Current Titling | New Trust Titling |
| --- | --- | --- | --- |
| ACCT-TX01 | Joint Taxable Brokerage | Alex & Sam Chen JTWROS | Chen Family Revocable Living Trust |
| ACCT-IRA1 | Traditional IRA | Alex Chen (Individual) | Remains individual — beneficiary updated |
| ACCT-RIRA | Roth IRA | Alex Chen (Individual) | Remains individual — beneficiary updated |

| ⚠  BENEFICIARY DESIGNATION ACTION ITEM:  IRA and Roth IRA accounts (ACCT-IRA1, ACCT-RIRA) cannot be held in Trust name. Separate Beneficiary Designation Forms (TaskID-2019Q2-001) must be filed with custodian to align designations with trust beneficiary intentions. See DOC-BeneficiaryUpdate-2019-001. |
| --- |

Section 4.3 — Real Property. The Grantors' primary residence (8912 Birchwood Drive, Evanston, IL) will be transferred by quit-claim deed into the Trust upon completion of title search. Note: As of the 2019 execution date, the Chens remain renters; real property clause is prospective and will activate upon home purchase. See EventID-2021-01 (home purchase, 2021-Q3).

| ARTICLE V — REVOCABILITY, AMENDMENT, AND TRUSTEE POWERS |
| --- |

Section 5.1 — Revocability. This Trust is fully revocable during the joint lifetime of both Grantors. Either Grantor, acting alone, may revoke the Trust in whole by delivering a signed, notarized revocation instrument to the Trustee. Upon revocation, all Trust property shall revert to the Grantors as community property.

Section 5.2 — Amendment. This Trust may be amended in whole or in part at any time during the lifetime of both Grantors by a signed, dated written amendment executed by both Grantors and delivered to the Trustee. Amendments shall be incorporated herein as a schedule unless otherwise specified. See DOC-TrustAmendment-2024-001 for the First Amendment.

Section 5.3 — Investment Powers. The Trustees are authorized to: (a) retain any property transferred to the Trust; (b) invest in stocks, bonds, mutual funds, ETFs, and other securities as permitted under the Illinois Prudent Investor Rule (760 ILCS 5/5); (c) delegate investment management to a licensed investment adviser (currently: Morgan Park, CFP®, Clearwater Wealth Partners, ADV-PARK-001); (d) maintain diversified portfolio per IPS-2016 and amendments.

Section 5.4 — Distribution Powers. The Trustees may accumulate or distribute Trust income and principal to or for the benefit of the Grantors during their lifetimes as the Trustees determine appropriate. No court approval is required for discretionary distributions to Grantors.

| ARTICLE VI — EVENT-DRIVEN REVIEW PROVISIONS |
| --- |

The Trustees and the wealth adviser (ADV-PARK-001) shall initiate a review of this Trust Agreement upon occurrence of any of the following triggering events:

| Trigger Event | Review Scope | Reference |
| --- | --- | --- |
| Birth or adoption of a child | Beneficiary schedule; sub-trust terms; distribution ages | Article III |
| Death or divorce of a Grantor | Trustee succession; beneficiary confirmation; asset re-titling | Article II, IV |
| Acquisition of real property | Re-titling into Trust; homestead exemption review | Article IV §4.3 |
| Increase in net worth > $500K | Estate tax exposure analysis; irrevocable trust consideration | Article V §5.3 |
| Health event or incapacity | DPOA activation; healthcare directive review; trustee succession | DOC-DPOA-2019-001 |
| Changes to Illinois/federal estate tax law | Trust structure review; portability election review | Article VI |
| New investment account opened | Beneficiary designation alignment; re-titling review | Article IV §4.2 |

Scheduled Review: This Trust Agreement shall be reviewed no less than every five (5) years or upon any triggering event above. First mandatory review: September 2024. (See DOC-TrustAmendment-2024-001.)

| SIGNATURES AND EXECUTION |
| --- |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Alex Chen | Sam Chen |
| Grantor & Co-Trustee | Grantor & Co-Trustee |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Patricia Hawthorne, J.D., LL.M. | Lisa Caruso, Notary — Cook County, IL |
| Drafting Attorney | Notary Public |

Date of Execution: September 10, 2019

Prepared by: Westfield & Baker LLP | 312 S. Michigan Ave, Suite 1400, Chicago, IL 60604

Attorney: Patricia Hawthorne, J.D., LL.M. (Estate & Trust Law) | p.hawthorne@hawthornecolellp.com

| DOC-Trust-2019-001  |  Chen Family Revocable Living Trust  |  Clearwater Wealth Partners  |  HH-CHEN-001 | CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED |
| --- | --- |
