| CLEARWATER WEALTH PARTNERSChen Family — Estate & Trust Documents  |  HH-CHEN-001 | DOC-Will-2019-001September 10, 2019EXECUTED |
| --- | --- |

LAST WILL AND TESTAMENT OF ALEX CHEN (Pour-Over Will with Trust Coordination)

| EVENT TRIGGER: EventID-2019-01 — Estate foundation established 2019-09-10. This Pour-Over Will directs all probate assets into the Chen Family Revocable Living Trust (DOC-Trust-2019-001) at death. Companion document: DOC-Will-2019-002 (Sam Chen). Attorney: Westfield & Baker LLP. Adviser on file: Morgan Park, CFP® (ADV-PARK-001). |
| --- |

| DECLARATION AND IDENTIFICATION |
| --- |

I, Alex Chen, a resident of Naperville, DuPage County, Illinois, being of lawful age, sound mind, and disposing memory, do hereby make, publish, and declare this instrument as my Last Will and Testament, revoking all prior wills and codicils previously made by me.

| Testator: | Alex Chen |
| --- | --- |

| Date of Birth: | 1981-03-22 |
| --- | --- |

| Residence: | 8912 Birchwood Drive, Naperville, Illinois 60563 |
| --- | --- |

| Spouse: | Sam Chen (married 2007-09-22, Cook County, IL) |
| --- | --- |

| Children: | Maya Chen (b. 2011-03-15)  |  Eli Chen (b. 2014-09-22) |
| --- | --- |

| Document ID: | DOC-Will-2019-001  |  Linked Trust: DOC-Trust-2019-001 |
| --- | --- |

| ARTICLE I — PAYMENT OF DEBTS AND EXPENSES |
| --- |

I direct my Personal Representative to pay my legally enforceable debts, funeral and burial expenses, and the costs of administering my estate as soon as reasonably practicable after my death, to the extent my estate has sufficient assets to do so.

| ARTICLE II — PERSONAL PROPERTY BEQUESTS |
| --- |

Section 2.1 — Tangible Personal Property. All tangible personal property that I own at my death, including but not limited to household furnishings, jewelry, clothing, vehicles, and personal effects, I give to my spouse, Sam Chen, outright and free of trust. If my spouse does not survive me, such property shall pass to my children in equal shares, to be divided as they may agree.

Section 2.2 — Digital Assets. All digital accounts, cryptocurrency holdings, online business interests, and intellectual property shall pass pursuant to the Revised Uniform Fiduciary Access to Digital Assets Act (RUFADAA) as enacted in Illinois (755 ILCS 10/), and shall be directed to the residuary estate.

| ARTICLE III — POUR-OVER PROVISION (RESIDUARY ESTATE) |
| --- |

Section 3.1 — Pour-Over to Trust. All the rest, residue, and remainder of my estate, both real and personal, wherever situated, that I own or am entitled to at the time of my death and not otherwise effectively disposed of by this Will or any other instrument ("Residuary Estate"), I give, devise, and bequeath to the then-acting Trustee(s) of the CHEN FAMILY REVOCABLE LIVING TRUST dated September 10, 2019, as amended from time to time, to be added to the Trust estate and administered and distributed as provided in that Trust.

Section 3.2 — Trust Identified. The Trust referred to in Section 3.1 is identified as MFRL-2019-001, executed concurrently herewith. If the Trust is not in existence at the time of my death, the Residuary Estate shall be distributed pursuant to the intestacy laws of Illinois.

| POUR-OVER COORDINATION:  Non-probate assets (ACCT-IRA1, ACCT-RIRA, life insurance) pass by beneficiary designation — NOT through this Will. It is critical that beneficiary designations on file with Fidelity Institutional remain aligned with trust intent. See TaskID-2019Q2-001 and DOC-BeneficiaryUpdate-2019-001. |
| --- |

| ARTICLE IV — PERSONAL REPRESENTATIVE |
| --- |

Section 4.1 — Appointment. I appoint Sam Chen as Personal Representative of my estate. If Sam Chen is unable or unwilling to serve, I appoint Maya Chen (upon reaching age 25) as successor Personal Representative.

Section 4.2 — Powers. My Personal Representative shall have all powers granted to personal representatives under the Illinois Probate Act (755 ILCS 5/) including the power to sell, lease, mortgage, and otherwise manage estate assets without court approval.

| ARTICLE V — GUARDIAN OF MINOR CHILDREN |
| --- |

In the event my spouse does not survive me and my children are minors at the time of my death, I nominate and appoint Sam Chen's sibling, Alex Sam (if willing and able), as Guardian of the person of my minor children. If no named guardian can serve, the court shall appoint a guardian giving due consideration to the welfare of my children.

| ARTICLE VI — NO-CONTEST CLAUSE |
| --- |

If any beneficiary of this Will or the Chen Family Revocable Living Trust contests the probate of this Will or any provision hereof, or institutes legal proceedings to modify or set aside this Will, such beneficiary shall forfeit any and all interests provided for under this Will and the Trust, and such forfeited interest shall pass as if such beneficiary had predeceased me without issue.

| SIGNATURES AND EXECUTION |
| --- |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Alex Chen | Marcus Webb — Chicago, IL |
| Testator | Witness No. 1 |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Sandra Ortiz — Chicago, IL | Lisa Caruso, Notary — Cook County, IL |
| Witness No. 2 | Notary Public |

Date of Execution: September 10, 2019

Prepared by: Westfield & Baker LLP | 312 S. Michigan Ave, Suite 1400, Chicago, IL 60604

Attorney: Patricia Hawthorne, J.D., LL.M. (Estate & Trust Law) | p.hawthorne@hawthornecolellp.com

| DOC-Will-2019-001  |  Last Will & Testament — Alex Chen  |  Clearwater Wealth Partners  |  HH-CHEN-001 | CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED |
| --- | --- |
