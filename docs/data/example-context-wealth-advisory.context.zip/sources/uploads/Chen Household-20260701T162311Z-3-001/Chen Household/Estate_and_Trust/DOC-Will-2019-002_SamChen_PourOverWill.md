| CLEARWATER WEALTH PARTNERSChen Family — Estate & Trust Documents  |  HH-CHEN-001 | DOC-Will-2019-002September 10, 2019EXECUTED |
| --- | --- |

LAST WILL AND TESTAMENT OF SAM CHEN (Pour-Over Will with Trust Coordination)

| EVENT TRIGGER: EventID-2019-01 — Companion document to DOC-Will-2019-001 (Alex Chen). Both pour-over wills executed concurrently on 2019-09-10. All residuary assets directed to Chen Family Revocable Living Trust (DOC-Trust-2019-001). Attorney: Westfield & Baker LLP. Adviser: Morgan Park, CFP® (ADV-PARK-001). |
| --- |

| DECLARATION AND IDENTIFICATION |
| --- |

I, Sam Chen, a resident of Naperville, DuPage County, Illinois, being of lawful age, sound mind, and disposing memory, do hereby make, publish, and declare this instrument as my Last Will and Testament, revoking all prior wills and codicils previously made by me.

| Testator: | Sam Chen |
| --- | --- |

| Date of Birth: | 1981-11-03 |
| --- | --- |

| Residence: | 8912 Birchwood Drive, Naperville, Illinois 60563 |
| --- | --- |

| Spouse: | Alex Chen (married 2007-09-22, Cook County, IL) |
| --- | --- |

| Children: | Maya Chen (b. 2011-03-15)  |  Eli Chen (b. 2014-09-22) |
| --- | --- |

| Document ID: | DOC-Will-2019-002  |  Linked Trust: DOC-Trust-2019-001 |
| --- | --- |

| ARTICLE I — PAYMENT OF DEBTS AND EXPENSES |
| --- |

I direct my Personal Representative to pay my legally enforceable debts, funeral and burial expenses, and the costs of administering my estate as soon as reasonably practicable after my death, to the extent my estate has sufficient assets to do so.

| ARTICLE II — PERSONAL PROPERTY BEQUESTS |
| --- |

Section 2.1 — Tangible Personal Property. All tangible personal property that I own at my death, including household furnishings, jewelry, clothing, vehicles, and personal effects, I give to my spouse, Alex Chen, outright and free of trust. If my spouse does not survive me, such property shall pass to my children in equal shares as they may agree.

Section 2.2 — Specific Bequest — Jewelry. My collection of heirloom jewelry (to be catalogued and attached as Schedule B) shall pass to Maya Chen upon reaching age 21, or to Eli Chen if Maya Chen has predeceased. This bequest supersedes Section 2.1.

| ARTICLE III — POUR-OVER PROVISION (RESIDUARY ESTATE) |
| --- |

Section 3.1 — Pour-Over to Trust. All the rest, residue, and remainder of my estate, real and personal, wherever situated, that I own or am entitled to at the time of my death ("Residuary Estate"), I give, devise, and bequeath to the then-acting Trustee(s) of the CHEN FAMILY REVOCABLE LIVING TRUST dated September 10, 2019, as amended, to be added to the Trust estate and administered pursuant to that Trust instrument (MFRL-2019-001).

Section 3.2 — Roth IRA Coordination. My Roth IRA (ACCT-RIRA, custodied at Fidelity Institutional) passes by beneficiary designation outside this Will. As of the date of execution, the beneficiary designation on file requires review and update per TaskID-2019Q2-001. See DOC-BeneficiaryUpdate-2019-001 for current status.

| ⚠  OPEN ACTION ITEM:  ACCT-RIRA beneficiary designation update deferred to 2019-Q2 (TaskID-2019Q2-001). Designation as of execution date remains as originally filed in 2016 (DOC-BeneficiaryDesig-2016-001). Adviser note: align Roth IRA beneficiary with trust intent at next client meeting. See ActionID-2019Q1-003. |
| --- |

| ARTICLE IV — PERSONAL REPRESENTATIVE |
| --- |

Section 4.1 — Appointment. I appoint Alex Chen as Personal Representative of my estate. If Alex Chen is unable or unwilling to serve, I appoint Maya Chen (upon reaching age 25) as successor Personal Representative.

Section 4.2 — Powers. My Personal Representative shall have all powers granted to personal representatives under the Illinois Probate Act (755 ILCS 5/) including the power to sell, lease, and manage estate assets without court approval.

| ARTICLE V — GUARDIAN OF MINOR CHILDREN |
| --- |

In the event my spouse does not survive me and our children are minors, I nominate and appoint Alex Chen's sibling (if willing and able) as Guardian of the person of my minor children, giving due consideration to the children's established relationships and best interests. The Guardian shall receive reasonable compensation from the estate.

| ARTICLE VI — SIMULTANEOUS DEATH |
| --- |

If Alex Chen and I die in a common accident or within 30 days of each other, it shall be deemed that Alex Chen predeceased me for purposes of this Will and the distribution of my estate. The Trust shall control distribution per DOC-Trust-2019-001, Article III.

| SIGNATURES AND EXECUTION |
| --- |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Sam Chen | Marcus Webb — Chicago, IL |
| Testator | Witness No. 1 |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Sandra Ortiz — Chicago, IL | Lisa Caruso, Notary — Cook County, IL |
| Witness No. 2 | Notary Public |

Date of Execution: September 10, 2019

Prepared by: Westfield & Baker LLP | 312 S. Michigan Ave, Suite 1400, Chicago, IL 60604

Attorney: Patricia Hawthorne, J.D., LL.M. (Estate & Trust Law) | p.hawthorne@hawthornecolellp.com

| DOC-Will-2019-002  |  Last Will & Testament — Sam Chen  |  Clearwater Wealth Partners  |  HH-CHEN-001 | CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED |
| --- | --- |
