| CLEARWATER WEALTH PARTNERSChen Family — Estate & Trust Documents  |  HH-CHEN-001 | DOC-TrustAmendment-2024-001September 15, 2024EXECUTED |
| --- | --- |

FIRST AMENDMENT TO THE CHEN FAMILY REVOCABLE LIVING TRUST (Healthcare Directives, Estate Refresh & Beneficiary Alignment)

| EVENT TRIGGER: EventID-2024-01 — Family health event (close relative illness, 2024-Q1) triggered comprehensive estate and beneficiary audit. RecID-2024-01: Estate refresh + POA/health directive review (completed 2024-Q3). Cross-references: DOC-Trust-2019-001 (original trust), DOC-BeneficiaryAudit-2024-001 (mismatch resolution), DOC-DPOA-2019-001 (updated directives), DOC-IPSAmendment-2025-001 (pre-retirement planning). |
| --- |

| RECITALS AND AMENDMENT IDENTIFICATION |
| --- |

This First Amendment ("Amendment") to the Chen Family Revocable Living Trust dated September 10, 2019 ("Original Trust", MFRL-2019-001) is entered into as of September 15, 2024, by Alex Chen and Sam Chen, Co-Grantors and Co-Trustees.

RECITALS: The Co-Grantors desire to amend the Original Trust to (a) update advance healthcare directives, (b) add pre-retirement income planning provisions, (c) clarify beneficiary alignment across all seven household accounts, and (d) formalize the resolution of the open beneficiary mismatch identified in the 2024 estate audit. Except as expressly amended herein, all terms and provisions of the Original Trust shall remain in full force.

| Amendment No.: | First Amendment — Amendment Date: September 15, 2024 |
| --- | --- |

| Original Trust: | DOC-Trust-2019-001  |  Chen Family Revocable Living Trust  |  2019-09-10 |
| --- | --- |

| Triggering Event: | EventID-2024-01 — Family health event; estate urgency; beneficiary audit |
| --- | --- |

| Recommendation: | RecID-2024-01 — Estate refresh + POA/health directive review (Complete 2024-Q3) |
| --- | --- |

| Household AUM: | ~$1,285,000  (2024-Q4 per Clearwater Wealth Partners reporting) |
| --- | --- |

| Drafting Attorney: | Patricia Hawthorne, J.D., LL.M. — Westfield & Baker LLP |
| --- | --- |

| Adviser Notified: | Morgan Park, CFP® (ADV-PARK-001) — Pre-retirement planning integrated |
| --- | --- |

| SECTION 1 — ESTATE AUDIT FINDINGS (EventID-2024-01) |
| --- |

In connection with EventID-2024-01, Westfield & Baker LLP and Morgan Park, CFP® conducted a comprehensive estate and beneficiary audit across all household accounts. The following table summarizes audit findings as of 2024-Q3:

| Account ID | Account Type | Audit Finding | Status |
| --- | --- | --- | --- |
| ACCT-TX01 | Joint Taxable | Re-titled to Trust 2019-09-10 ✓; TOD beneficiary aligned with trust | ✅  Clear |
| ACCT-IRA1 | Traditional IRA | Primary: Sam Chen ✓; Contingent: Chen Family Trust ✓; Updated 2019-Q2 | ✅  Clear |
| ACCT-RIRA | Roth IRA | ⚠ MISMATCH: Contingent still shows 2016 direct designation (ActionID-2019Q1-003 never completed). Corrected per DOC-BeneficiaryAudit-2024-001. | ✅  Fixed |
| ACCT-401R | Rollover IRA | Primary: Sam Chen ✓; Contingent: Chen Family Trust ✓; confirmed 2024-Q2 | ✅  Clear |
| ACCT-529A | 529 — Maya | Account owner: Alex Chen; opened 2020; no beneficiary mismatch applicable | ✅  Clear |
| ACCT-529B | 529 — Eli | Account owner: Sam Chen; opened 2020; no beneficiary mismatch applicable | ✅  Clear |
| ACCT-CASH | Cash Reserve | TOD beneficiary: Maya 50% / Eli 50% per stirpes; updated 2019-Q2 ✓ | ✅  Clear |
| HOME | Real Property | Re-titled to Trust upon home purchase 2021-Q3 (EventID-2021-01); deed recorded Cook County | ✅  Clear |

| ✅  RESOLUTION CONFIRMED: All seven accounts (ACCT-TX01, ACCT-IRA1, ACCT-RIRA, ACCT-401R, ACCT-529A, ACCT-529B, ACCT-CASH) and real property now align with the Chen Family Revocable Living Trust beneficiary intent. ActionID-2019Q1-003 CLOSED. Audit completed 2024-Q3. Next scheduled review: 2029. |
| --- |

| SECTION 2 — UPDATED ADVANCE HEALTHCARE DIRECTIVES |
| --- |

Section 2.1 — Amendment to DOC-DPOA-2019-001. The advance healthcare directive sections in DOC-DPOA-2019-001 are hereby updated and superseded by this Amendment. The following updated provisions apply to both Alex Chen and Sam Chen:

| DNR / POLST Alignment | Both Grantors have executed and signed Physician Orders for Life-Sustaining Treatment (POLST) forms effective September 15, 2024. POLST forms are filed with Northwestern Medicine and attached hereto as Schedule E. DNR directives align with POLST instructions. |
| --- | --- |

| Healthcare Agent Confirmation | Sam Chen remains primary Healthcare Agent for Alex Chen. Alex Chen remains primary Healthcare Agent for Sam Chen. Maya Chen (currently age 13) is designated as Tertiary Healthcare Agent upon reaching age 18. Westfield & Baker LLP (Trust Dept.) serves as Healthcare Advocate of last resort. |
| --- | --- |

| Life Support Preferences | Updated to reflect both Grantors' current preference: if in a persistent vegetative state with no reasonable expectation of recovery, artificial nutrition and hydration shall be withdrawn at the Agent's direction after a 30-day period with attending physician confirmation. |
| --- | --- |

| HIPAA Authorization | Both Grantors grant their respective Agents unrestricted access to all medical records, treatment plans, and healthcare provider communications under HIPAA (45 C.F.R. §164.502(g)). Authorization extends to all providers consulted in connection with EventID-2024-01. |
| --- | --- |

| Mental Health Directive | New provision added: Each Grantor authorizes their Agent to consent to involuntary mental health evaluation and short-term treatment if a licensed physician determines the Grantor lacks capacity to make healthcare decisions due to mental illness or cognitive decline. |
| --- | --- |

| SECTION 3 — PRE-RETIREMENT AND INCOME PLANNING PROVISIONS |
| --- |

In anticipation of Alex Chen's target retirement in 2028–2030 (GoalID-2016-02) and the adoption of a bucket investment strategy (DOC-IPSAmendment-2025-001, DecisionID-2025-112), the following provisions are hereby added to the Trust:

Section 3.1 — Retirement Income Sub-Trust

Upon Alex Chen's retirement, the Trustees may designate up to $120,000 of Trust assets as a "Retirement Income Reserve" (corresponding to IPS-2025 Bucket 1) to be held in cash equivalents and short-duration bonds for the purpose of providing 24 months of living expense distributions without requiring equity liquidation.

Section 3.2 — Required Minimum Distributions

The Trustees shall ensure timely RMD distributions from ACCT-IRA1 and ACCT-401R commencing at Alex Chen's required beginning date under current law. RMDs shall be reviewed annually with the household's CPA and wealth adviser (ADV-PARK-001) to minimize tax impact.

Section 3.3 — Social Security Coordination

The Trustees shall consult with the wealth adviser regarding optimal Social Security claiming strategy for both Alex and Sam Chen (RecID-2025-02, analysis delivered 2025-Q3). Social Security income shall be factored into Trust distribution planning.

Section 3.4 — DAF Continuation

The Clearwater Donor Advised Fund (GoalID-2023-01, opened 2023-05) shall continue annual distributions of $5,000–$10,000. The Trustees may contribute appreciated securities from ACCT-TX01 to maximize charitable deduction efficiency.

| SECTION 4 — EVENT-DRIVEN REVIEW SCHEDULE (UPDATED) |
| --- |

Article VI of the Original Trust is hereby updated to reflect completed and prospective review events:

| Event / Year | EventID / RecID | Action Taken | Status |
| --- | --- | --- | --- |
| Trust Creation (2019) | EventID-2019-01 | Original Trust + Wills + DPOA executed | ✅  Complete |
| Home Purchase (2021) | EventID-2021-01 | Primary residence re-titled to Trust; deed recorded | ✅  Complete |
| Beneficiary Open Item (2019–2024) | ActionID-2019Q1-003 | ACCT-RIRA mismatch corrected per DOC-BeneficiaryAudit-2024-001 | ✅  Resolved |
| Health Event / Estate Audit (2024) | EventID-2024-01 / RecID-2024-01 | Full estate audit; DPOA updated; POLST filed; this Amendment executed | ✅  Complete |
| Bucket Strategy / IPS (2025) | DecisionID-2025-112 | Trust retirement income provisions aligned with IPS-2025 | ✅  Complete |
| College Funding Review (2029) | GoalID-2016-04 (Maya) | 529 ACCT-529A review; sub-trust provisions if needed | ⏳  Scheduled |
| Mandatory 5-Year Review (2029) | Trust Article VI | Full trust review: estate tax; trustee succession; beneficiaries | ⏳  Scheduled |

| SECTION 5 — FORWARD-LOOKING PROVISIONS AND NOTES |
| --- |

Estate Tax Exposure (2024)

Current combined household net worth estimated at ~$2.1M (investment accounts + real property + retirement assets). Federal estate tax exemption as of 2024: $13.61M per individual. No estate tax exposure under current law. Review if TCJA sunset provisions reduce exemption after 2025.

Portability Election

Upon the death of the first Grantor, the surviving Grantor (or their attorney) shall timely file a federal estate tax return (Form 706) to elect portability of the deceased Grantor's unused estate tax exemption (DSUE), even if no estate tax is due.

Generation-Skipping Transfer

No GST trust is currently required given household size. If household net worth exceeds $5M, Westfield & Baker LLP shall recommend a dynasty trust or GST-exempt trust for the children's sub-trust shares under Article III.

College Funding

Maya Chen will reach college age approximately 2029 (DOB 2011-03-15). The 529 plan (ACCT-529A, GoalID-2016-04) is projected to provide 65–80% of estimated 4-year costs per Clearwater Wealth Partners 529 projection analysis (to be delivered 2025-Q2).

| SIGNATURES AND EXECUTION |
| --- |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Alex Chen | Sam Chen |
| Grantor & Co-Trustee | Grantor & Co-Trustee |

| ______________________________________ | ______________________________________ |
| --- | --- |
| Patricia Hawthorne, J.D., LL.M. | Morgan Park, CFP® — Clearwater Wealth Partners |
| Drafting Attorney | Acknowledging Adviser |

Date of Execution: September 15, 2024

Prepared by: Westfield & Baker LLP | 312 S. Michigan Ave, Suite 1400, Chicago, IL 60604

Attorney: Patricia Hawthorne, J.D., LL.M. (Estate & Trust Law) | p.hawthorne@hawthornecolellp.com

| DOC-TrustAmendment-2024-001  |  First Amendment — Chen Family Revocable Living Trust  |  Clearwater Wealth Partners  |  HH-CHEN-001 | CONFIDENTIAL — ATTORNEY-CLIENT PRIVILEGED |
| --- | --- |
