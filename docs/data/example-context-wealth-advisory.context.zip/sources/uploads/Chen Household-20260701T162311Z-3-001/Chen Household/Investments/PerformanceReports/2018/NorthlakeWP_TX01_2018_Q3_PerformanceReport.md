CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2018Quarter 3, 2018 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2018 Portfolio | Q3 2018 Blend Bench. | Excess Return | YTD 2018 Portfolio | YTD 2018 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.95% | +4.99% | -2.04% | +4.25% | +7.01% |
| Benchmark Return | +4.99% | +7.18% | -0.12% | — | — |

▪ Beginning Value: $334,097 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $346,986

▪ Dividends & Interest: $2,169 ▪ Market Gain / (Loss): $7,928 ▪ Advisory Fees: ($208)

MARKET COMMENTARY

Q3 2018 was the best quarter of the year for U.S. equities, with the S&P 500 surging 7.7% on exceptional earnings growth (S&P 500 earnings grew ~25% YoY due to tax reform). GDP growth hit 4.2% in Q2, its highest level since 2014. Trade tensions with China remained elevated. International equities lagged significantly as EM currencies weakened. The Fed raised rates in September. Your portfolio's domestic equity concentration was well-rewarded during this period of exceptional U.S. outperformance.

| Benchmark | Q3 2018 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +7.18% | 70% | +5.03% |
| Bloomberg US Aggregate (Fixed Income) | -0.12% | 30% | -0.04% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $12,349 | $12,826 | +$476 | +3.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $29,168 | $30,293 | +$1,125 | +3.9% |
| MFS Mid Cap Growth | MFEKX | US Equity | $23,003 | $23,890 | +$887 | +3.9% |
| American Funds AMCAP | AMCPX | US Equity | $34,767 | $36,108 | +$1,341 | +3.9% |
| American Funds Growth | AGTHX | US Equity | $31,129 | $32,330 | +$1,201 | +3.9% |
| American Funds New World | ANCFX | Intl Equity | $19,355 | $20,101 | +$747 | +3.9% |
| American Funds Income | AMRMX | US Equity | $11,509 | $11,952 | +$444 | +3.9% |
| American Funds Investment | AIVSX | US Equity | $33,646 | $34,944 | +$1,298 | +3.9% |
| American Funds New Persp. | ANWPX | Intl Equity | $15,432 | $16,027 | +$595 | +3.9% |
| American Funds Balanced | AMFFX | US Equity | $10,668 | $11,079 | +$412 | +3.9% |
| American Funds Bond | ABNDX | Fixed Income | $20,901 | $21,708 | +$806 | +3.9% |
| American High Income Trust | AHITX | Fixed Income | $16,978 | $17,633 | +$655 | +3.9% |
| American Funds New Econ. | ANEFX | US Equity | $10,107 | $10,497 | +$390 | +3.9% |
| iShares Core S&P 500 | IVV | US Equity | $40,096 | $41,643 | +$1,547 | +3.9% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,959 | $18,652 | +$693 | +3.9% |
| SPDR Gold Shares | GLD | Alternatives | $7,031 | $7,302 | +$271 | +3.9% |
| TOTAL PORTFOLIO |  |  | $334,097 | $346,986 | +$12,889 | +3.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $334,097.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,888.00 |
| Interest Income | $281.00 |
| Market Appreciation / (Depreciation) | $7,928.00 |
| Advisory & Management Fees | ($208.00) |
| Net Change for Period | $12,889.00 |
| Ending Account Value | $346,986.00 |

Advisor Commentary: Portfolio performance of +2.95% was behind the blended benchmark (+4.99%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2017 | +3.27% | +4.17% |
| Q1 2018 | -0.25% | -0.08% |
| Q2 2018 | +1.52% | +2.01% |
| Q3 2018 | +2.95% | +4.99% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
