CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2022Quarter 2, 2022 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2022 Portfolio | Q2 2022 Blend Bench. | Excess Return | YTD 2022 Portfolio | YTD 2022 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -11.93% | -11.73% | -0.21% | -15.10% | -16.36% |
| Benchmark Return | -11.73% | -16.55% | -4.49% | — | — |

▪ Beginning Value: $439,625 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $389,988

▪ Dividends & Interest: $2,212 ▪ Market Gain / (Loss): $-54,618 ▪ Advisory Fees: ($231)

MARKET COMMENTARY

Q2 2022 was the worst quarter for U.S. equities since Q2 2008, with the S&P 500 falling 16.1% and entering a bear market. The Fed hiked rates 125 basis points in the quarter alone (including a rare 75bp hike). Bonds fell another 4.7%. Inflation peaked at 9.1% in June — the highest since 1981. Growth stocks bore the brunt of the repricing. Your portfolio declined substantially, though your diversified approach limited losses relative to growth-heavy or tech-concentrated portfolios. Remaining disciplined during drawdowns is essential to long-term wealth accumulation.

| Benchmark | Q2 2022 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -16.55% | 60% | -9.93% |
| Bloomberg US Aggregate (Fixed Income) | -4.49% | 40% | -1.80% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 16% | ████████  16% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $12,685 | $11,253 | $-1,432 | -11.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $37,229 | $33,025 | $-4,203 | -11.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $34,133 | $30,279 | $-3,854 | -11.3% |
| American Funds AMCAP | AMCPX | US Equity | $49,891 | $44,258 | $-5,633 | -11.3% |
| American Funds Growth | AGTHX | US Equity | $43,948 | $38,986 | $-4,962 | -11.3% |
| American Funds New World | ANCFX | Intl Equity | $27,151 | $24,085 | $-3,066 | -11.3% |
| American Funds Income | AMRMX | US Equity | $15,786 | $14,004 | $-1,782 | -11.3% |
| American Funds Investment | AIVSX | US Equity | $46,532 | $41,278 | $-5,254 | -11.3% |
| American Funds New Persp. | ANWPX | Intl Equity | $21,208 | $18,813 | $-2,394 | -11.3% |
| American Funds Balanced | AMFFX | US Equity | $14,231 | $12,624 | $-1,607 | -11.3% |
| American Funds Bond | ABNDX | Fixed Income | $18,370 | $16,296 | $-2,074 | -11.3% |
| American High Income Trust | AHITX | Fixed Income | $15,269 | $13,545 | $-1,724 | -11.3% |
| American Funds New Econ. | ANEFX | US Equity | $13,197 | $11,707 | $-1,490 | -11.3% |
| iShares Core S&P 500 | IVV | US Equity | $62,041 | $55,036 | $-7,005 | -11.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,786 | $14,004 | $-1,782 | -11.3% |
| SPDR Gold Shares | GLD | Alternatives | $12,168 | $10,795 | $-1,374 | -11.3% |
| TOTAL PORTFOLIO |  |  | $439,625 | $389,988 | $-49,637 | -11.3% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $439,625.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,914.00 |
| Interest Income | $298.00 |
| Market Appreciation / (Depreciation) | $-54,618.00 |
| Advisory & Management Fees | ($231.00) |
| Net Change for Period | $-49,637.00 |
| Ending Account Value | $389,988.00 |

Advisor Commentary: Portfolio performance of -11.93% was in line with the blended benchmark (-11.73%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2021 | +2.60% | +0.18% |
| Q4 2021 | +5.51% | +5.62% |
| Q1 2022 | -3.60% | -5.25% |
| Q2 2022 | -11.93% | -11.73% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
