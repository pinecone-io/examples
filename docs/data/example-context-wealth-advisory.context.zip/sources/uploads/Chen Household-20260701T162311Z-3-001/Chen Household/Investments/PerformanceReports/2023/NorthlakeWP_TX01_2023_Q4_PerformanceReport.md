CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2023Quarter 4, 2023 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2023 Portfolio | Q4 2023 Blend Bench. | Excess Return | YTD 2023 Portfolio | YTD 2023 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.69% | +9.71% | -6.03% | +10.19% | +17.30% |
| Benchmark Return | +9.71% | +11.69% | +6.75% | — | — |

▪ Beginning Value: $595,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $620,000

▪ Dividends & Interest: $3,742 ▪ Market Gain / (Loss): $18,510 ▪ Advisory Fees: ($252)

MARKET COMMENTARY

Q4 2023 delivered exceptional returns as the Fed signaled the end of rate hikes and the beginning of a cutting cycle in 2024. The S&P 500 surged 11.7%, bonds gained 6.8% (the Bloomberg Agg's best quarter since 2008), and the 60/40 portfolio had its best quarter in years. The 'Magnificent 7' tech stocks drove much of the equity gain. Both stock and bond allocations contributed meaningfully to portfolio returns. Your portfolio closed 2023 at its highest ever value, reflecting both strong investment returns and the RSU contribution earlier in the year.

| Benchmark | Q4 2023 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +11.69% | 60% | +7.01% |
| Bloomberg US Aggregate (Fixed Income) | +6.75% | 40% | +2.70% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $17,065 | $17,782 | +$717 | +4.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $50,111 | $52,216 | +$2,105 | +4.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $45,984 | $47,916 | +$1,932 | +4.2% |
| American Funds AMCAP | AMCPX | US Equity | $70,772 | $73,746 | +$2,974 | +4.2% |
| American Funds Growth | AGTHX | US Equity | $62,505 | $65,131 | +$2,626 | +4.2% |
| American Funds New World | ANCFX | Intl Equity | $38,491 | $40,108 | +$1,617 | +4.2% |
| American Funds Income | AMRMX | US Equity | $21,455 | $22,356 | +$901 | +4.2% |
| American Funds Investment | AIVSX | US Equity | $66,125 | $68,903 | +$2,778 | +4.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $30,487 | $31,768 | +$1,281 | +4.2% |
| American Funds Balanced | AMFFX | US Equity | $19,131 | $19,934 | +$804 | +4.2% |
| American Funds Bond | ABNDX | Fixed Income | $19,647 | $20,473 | +$826 | +4.2% |
| American High Income Trust | AHITX | Fixed Income | $16,032 | $16,706 | +$674 | +4.2% |
| American Funds New Econ. | ANEFX | US Equity | $17,834 | $18,584 | +$749 | +4.2% |
| iShares Core S&P 500 | IVV | US Equity | $88,589 | $92,311 | +$3,722 | +4.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,290 | $16,975 | +$684 | +4.2% |
| SPDR Gold Shares | GLD | Alternatives | $14,483 | $15,091 | +$609 | +4.2% |
| TOTAL PORTFOLIO |  |  | $595,000 | $620,000 | +$25,000 | +4.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $595,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,114.00 |
| Interest Income | $628.00 |
| Market Appreciation / (Depreciation) | $18,510.00 |
| Advisory & Management Fees | ($252.00) |
| Net Change for Period | $25,000.00 |
| Ending Account Value | $620,000.00 |

Advisor Commentary: Portfolio performance of +3.69% was behind the blended benchmark (+9.71%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2023 | +5.15% | +5.40% |
| Q2 2023 | -4.39% | +4.83% |
| Q3 2023 | +5.70% | -3.24% |
| Q4 2023 | +3.69% | +9.71% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
