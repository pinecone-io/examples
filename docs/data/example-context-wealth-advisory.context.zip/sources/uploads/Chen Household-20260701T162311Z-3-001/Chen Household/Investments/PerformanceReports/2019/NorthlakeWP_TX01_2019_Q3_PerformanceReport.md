CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2019Quarter 3, 2019 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2019 Portfolio | Q3 2019 Blend Bench. | Excess Return | YTD 2019 Portfolio | YTD 2019 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.41% | +1.92% | -0.51% | +12.16% | +16.51% |
| Benchmark Return | +1.92% | +1.72% | +2.40% | — | — |

▪ Beginning Value: $368,569 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $376,801

▪ Dividends & Interest: $2,336 ▪ Market Gain / (Loss): $3,114 ▪ Advisory Fees: ($218)

MARKET COMMENTARY

Q3 2019 was a volatile but modestly positive quarter. Recession fears emerged as the yield curve inverted, bond yields fell dramatically (10-year Treasury touched 1.5%), and manufacturing data weakened. The Fed cut rates in July and September — the first cuts since 2008. Equity markets were choppy but ultimately gained 1.7%. Bonds surged with the 10-year Treasury falling sharply from 2.0% to 1.5%. Your fixed income holdings were a notable positive, partially offsetting the muted equity returns.

| Benchmark | Q3 2019 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +1.72% | 70% | +1.20% |
| Bloomberg US Aggregate (Fixed Income) | +2.40% | 30% | +0.72% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $10,839 | $11,081 | +$242 | +2.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $32,930 | $33,665 | +$735 | +2.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $26,950 | $27,552 | +$602 | +2.2% |
| American Funds AMCAP | AMCPX | US Equity | $39,835 | $40,724 | +$890 | +2.2% |
| American Funds Growth | AGTHX | US Equity | $35,927 | $36,729 | +$802 | +2.2% |
| American Funds New World | ANCFX | Intl Equity | $22,342 | $22,841 | +$499 | +2.2% |
| American Funds Income | AMRMX | US Equity | $13,140 | $13,434 | +$293 | +2.2% |
| American Funds Investment | AIVSX | US Equity | $38,689 | $39,553 | +$864 | +2.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $17,974 | $18,375 | +$401 | +2.2% |
| American Funds Balanced | AMFFX | US Equity | $11,985 | $12,252 | +$268 | +2.2% |
| American Funds Bond | ABNDX | Fixed Income | $19,355 | $19,787 | +$432 | +2.2% |
| American High Income Trust | AHITX | Fixed Income | $15,212 | $15,551 | +$340 | +2.2% |
| American Funds New Econ. | ANEFX | US Equity | $11,294 | $11,546 | +$252 | +2.2% |
| iShares Core S&P 500 | IVV | US Equity | $48,125 | $49,200 | +$1,075 | +2.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,362 | $16,728 | +$365 | +2.2% |
| SPDR Gold Shares | GLD | Alternatives | $7,612 | $7,782 | +$170 | +2.2% |
| TOTAL PORTFOLIO |  |  | $368,569 | $376,801 | +$8,232 | +2.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $368,569.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,018.00 |
| Interest Income | $318.00 |
| Market Appreciation / (Depreciation) | $3,114.00 |
| Advisory & Management Fees | ($218.00) |
| Net Change for Period | $8,232.00 |
| Ending Account Value | $376,801.00 |

Advisor Commentary: Portfolio performance of +1.41% was behind the blended benchmark (+1.92%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2018 | -6.43% | -9.08% |
| Q1 2019 | +6.91% | +10.21% |
| Q2 2019 | +3.45% | +3.71% |
| Q3 2019 | +1.41% | +1.92% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
