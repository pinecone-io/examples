CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2022Quarter 4, 2022 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2022 Portfolio | Q4 2022 Blend Bench. | Excess Return | YTD 2022 Portfolio | YTD 2022 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.94% | +5.13% | -2.19% | -17.12% | -16.47% |
| Benchmark Return | +5.13% | +7.37% | +1.77% | — | — |

▪ Beginning Value: $372,734 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $386,751

▪ Dividends & Interest: $2,436 ▪ Market Gain / (Loss): $8,818 ▪ Advisory Fees: ($237)

MARKET COMMENTARY

Q4 2022 provided welcome relief as markets reversed course. The S&P 500 gained 7.6% on hopes of slowing inflation and a potential Fed pause. Bonds gained 1.8% as rate-hike expectations moderated. Tax-loss harvesting opportunities were implemented strategically this quarter to offset capital gains and optimize the portfolio's after-tax positioning. The full year 2022 was the worst since 2008 for equities (-18.1%) and the worst ever on record for bonds (-13.0%). Your portfolio's Q4 recovery and tax optimization efforts positioned it well for 2023.

| Benchmark | Q4 2022 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +7.37% | 60% | +4.42% |
| Bloomberg US Aggregate (Fixed Income) | +1.77% | 40% | +0.71% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 16% | ████████  16% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $10,755 | $11,160 | +$404 | +3.8% |
| American Funds EuroPacific | SEEGX | Intl Equity | $31,564 | $32,751 | +$1,187 | +3.8% |
| MFS Mid Cap Growth | MFEKX | US Equity | $28,940 | $30,028 | +$1,088 | +3.8% |
| American Funds AMCAP | AMCPX | US Equity | $42,300 | $43,890 | +$1,591 | +3.8% |
| American Funds Growth | AGTHX | US Equity | $37,261 | $38,662 | +$1,401 | +3.8% |
| American Funds New World | ANCFX | Intl Equity | $23,020 | $23,886 | +$866 | +3.8% |
| American Funds Income | AMRMX | US Equity | $13,384 | $13,888 | +$503 | +3.8% |
| American Funds Investment | AIVSX | US Equity | $39,452 | $40,935 | +$1,484 | +3.8% |
| American Funds New Persp. | ANWPX | Intl Equity | $17,981 | $18,657 | +$676 | +3.8% |
| American Funds Balanced | AMFFX | US Equity | $12,065 | $12,519 | +$454 | +3.8% |
| American Funds Bond | ABNDX | Fixed Income | $15,575 | $16,161 | +$586 | +3.8% |
| American High Income Trust | AHITX | Fixed Income | $12,946 | $13,433 | +$487 | +3.8% |
| American Funds New Econ. | ANEFX | US Equity | $11,189 | $11,610 | +$421 | +3.8% |
| iShares Core S&P 500 | IVV | US Equity | $52,601 | $54,580 | +$1,978 | +3.8% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,384 | $13,888 | +$503 | +3.8% |
| SPDR Gold Shares | GLD | Alternatives | $10,317 | $10,705 | +$388 | +3.8% |
| TOTAL PORTFOLIO |  |  | $372,734 | $386,751 | +$14,017 | +3.8% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $372,734.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,988.00 |
| Interest Income | $448.00 |
| Market Appreciation / (Depreciation) | $8,818.00 |
| Advisory & Management Fees | ($237.00) |
| Net Change for Period | $14,017.00 |
| Ending Account Value | $386,751.00 |

Advisor Commentary: Tax-loss harvesting executed this quarter: losses were captured in underperforming positions while maintaining market exposure through similar (not substantially identical) replacement securities. This strategy is expected to provide meaningful tax savings.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2022 | -3.60% | -5.25% |
| Q2 2022 | -11.93% | -11.73% |
| Q3 2022 | -5.17% | -5.00% |
| Q4 2022 | +2.94% | +5.13% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
