CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2026Quarter 2, 2026 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2026 Portfolio | Q2 2026 Blend Bench. | Excess Return | YTD 2026 Portfolio | YTD 2026 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.19% | +3.52% | -1.33% | +3.80% | +6.02% |
| Benchmark Return | +3.52% | +4.88% | +0.98% | — | — |

▪ Beginning Value: $775,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $795,000

▪ Dividends & Interest: $4,758 ▪ Market Gain / (Loss): $12,530 ▪ Advisory Fees: ($288)

MARKET COMMENTARY

Q2 2026 delivered solid returns, with the S&P 500 advancing 4.9% and bonds gaining 1.0%. Consumer confidence improved and the labor market remained healthy. Corporate earnings growth moderated from 2024's elevated pace but remained positive. The Fed held rates steady. International equities also performed well, with European markets benefiting from improved economic momentum. Your portfolio's diversified positioning captured gains across asset classes, and consistent monthly contributions continued to add to the portfolio's long-term compounding.

| Benchmark | Q2 2026 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +4.88% | 65% | +3.17% |
| Bloomberg US Aggregate (Fixed Income) | +0.98% | 35% | +0.34% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,014 | $19,505 | +$491 | +2.6% |
| American Funds EuroPacific | SEEGX | Intl Equity | $65,494 | $67,184 | +$1,690 | +2.6% |
| MFS Mid Cap Growth | MFEKX | US Equity | $61,496 | $63,083 | +$1,587 | +2.6% |
| American Funds AMCAP | AMCPX | US Equity | $93,477 | $95,889 | +$2,412 | +2.6% |
| American Funds Growth | AGTHX | US Equity | $84,731 | $86,917 | +$2,187 | +2.6% |
| American Funds New World | ANCFX | Intl Equity | $52,495 | $53,850 | +$1,355 | +2.6% |
| American Funds Income | AMRMX | US Equity | $27,511 | $28,221 | +$710 | +2.6% |
| American Funds Investment | AIVSX | US Equity | $87,735 | $89,999 | +$2,264 | +2.6% |
| American Funds New Persp. | ANWPX | Intl Equity | $41,005 | $42,063 | +$1,058 | +2.6% |
| American Funds Balanced | AMFFX | US Equity | $24,507 | $25,139 | +$632 | +2.6% |
| American Funds Bond | ABNDX | Fixed Income | $20,514 | $21,043 | +$529 | +2.6% |
| American High Income Trust | AHITX | Fixed Income | $16,765 | $17,198 | +$433 | +2.6% |
| American Funds New Econ. | ANEFX | US Equity | $23,507 | $24,114 | +$607 | +2.6% |
| iShares Core S&P 500 | IVV | US Equity | $118,971 | $122,041 | +$3,070 | +2.6% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,015 | $17,454 | +$439 | +2.6% |
| SPDR Gold Shares | GLD | Alternatives | $20,764 | $21,299 | +$536 | +2.6% |
| TOTAL PORTFOLIO |  |  | $775,000 | $795,000 | +$20,000 | +2.6% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $775,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $4,118.00 |
| Interest Income | $640.00 |
| Market Appreciation / (Depreciation) | $12,530.00 |
| Advisory & Management Fees | ($288.00) |
| Net Change for Period | $20,000.00 |
| Ending Account Value | $795,000.00 |

Advisor Commentary: Portfolio performance of +2.19% was behind the blended benchmark (+3.52%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2025 | +1.66% | +4.60% |
| Q4 2025 | +2.99% | +1.98% |
| Q1 2026 | +1.58% | +2.42% |
| Q2 2026 | +2.19% | +3.52% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
