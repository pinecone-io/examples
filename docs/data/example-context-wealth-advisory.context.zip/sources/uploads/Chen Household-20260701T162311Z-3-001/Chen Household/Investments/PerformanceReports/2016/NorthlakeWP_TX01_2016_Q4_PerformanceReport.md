CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2016Quarter 4, 2016 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2016 Portfolio | Q4 2016 Blend Bench. | Excess Return | YTD 2016 Portfolio | YTD 2016 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.94% | +1.68% | +1.26% | +6.15% | +6.64% |
| Benchmark Return | +1.68% | +3.71% | -3.06% | — | — |

▪ Beginning Value: $263,267 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $274,052

▪ Dividends & Interest: $1,549 ▪ Market Gain / (Loss): $6,428 ▪ Advisory Fees: ($192)

MARKET COMMENTARY

The post-election 'Trump rally' defined Q4 2016, with markets surging on expectations of fiscal stimulus, tax cuts, and deregulation. The S&P 500 gained 3.8% for the quarter and 10.5% for the full year. However, rising rate expectations drove a sharp selloff in bonds: the Bloomberg U.S. Aggregate fell 3.0% as 10-year Treasury yields jumped from 1.6% to 2.4%. Your portfolio's equity holdings drove strong performance, while fixed income acted as a headwind. The Fed raised rates in December for the second time since the financial crisis.

| Benchmark | Q4 2016 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +3.71% | 70% | +2.60% |
| Bloomberg US Aggregate (Fixed Income) | -3.06% | 30% | -0.92% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,248 | $8,586 | +$338 | +4.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $22,654 | $23,582 | +$928 | +4.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $17,856 | $18,588 | +$732 | +4.1% |
| American Funds AMCAP | AMCPX | US Equity | $27,685 | $28,819 | +$1,134 | +4.1% |
| American Funds Growth | AGTHX | US Equity | $23,797 | $24,772 | +$975 | +4.1% |
| American Funds New World | ANCFX | Intl Equity | $15,570 | $16,208 | +$638 | +4.1% |
| American Funds Income | AMRMX | US Equity | $9,968 | $10,376 | +$408 | +4.1% |
| American Funds Investment | AIVSX | US Equity | $26,546 | $27,633 | +$1,087 | +4.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $12,140 | $12,637 | +$497 | +4.1% |
| American Funds Balanced | AMFFX | US Equity | $8,934 | $9,300 | +$366 | +4.1% |
| American Funds Bond | ABNDX | Fixed Income | $16,942 | $17,636 | +$694 | +4.1% |
| American High Income Trust | AHITX | Fixed Income | $13,626 | $14,184 | +$558 | +4.1% |
| American Funds New Econ. | ANEFX | US Equity | $8,253 | $8,591 | +$338 | +4.1% |
| iShares Core S&P 500 | IVV | US Equity | $30,657 | $31,913 | +$1,256 | +4.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,426 | $15,017 | +$591 | +4.1% |
| SPDR Gold Shares | GLD | Alternatives | $5,966 | $6,210 | +$244 | +4.1% |
| TOTAL PORTFOLIO |  |  | $263,267 | $274,052 | +$10,785 | +4.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $263,267.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,388.00 |
| Interest Income | $161.00 |
| Market Appreciation / (Depreciation) | $6,428.00 |
| Advisory & Management Fees | ($192.00) |
| Net Change for Period | $10,785.00 |
| Ending Account Value | $274,052.00 |

Advisor Commentary: Strong full-year performance of +11.3%, slightly ahead of the blended benchmark. Annual rebalancing completed this quarter to maintain target allocation.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2016 | -1.23% | -0.24% |
| Q2 2016 | +1.62% | +2.33% |
| Q3 2016 | +2.74% | +2.75% |
| Q4 2016 | +2.94% | +1.68% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
