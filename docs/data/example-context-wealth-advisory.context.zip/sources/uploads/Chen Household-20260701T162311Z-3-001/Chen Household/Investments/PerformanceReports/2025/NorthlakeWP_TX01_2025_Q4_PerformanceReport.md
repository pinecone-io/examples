CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2025Quarter 4, 2025 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2025 Portfolio | Q4 2025 Blend Bench. | Excess Return | YTD 2025 Portfolio | YTD 2025 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.99% | +1.98% | +1.01% | +6.78% | +7.68% |
| Benchmark Return | +1.98% | +2.25% | +1.48% | — | — |

▪ Beginning Value: $735,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $760,000

▪ Dividends & Interest: $4,582 ▪ Market Gain / (Loss): $17,700 ▪ Advisory Fees: ($282)

MARKET COMMENTARY

Markets closed 2025 with a positive quarter, though at a more subdued pace. The S&P 500 gained 2.3% and bonds gained 1.5%. Full-year 2025 equity returns were solid despite Q1 volatility. The Fed remained cautious, making just one additional rate cut. Corporate earnings remained the anchor of equity valuations. Your portfolio ended 2025 near all-time highs, reflecting nearly a decade of disciplined, diversified investing. Continued monthly contributions and reinvestment of income have meaningfully added to cumulative wealth.

| Benchmark | Q4 2025 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +2.25% | 65% | +1.46% |
| Bloomberg US Aggregate (Fixed Income) | +1.48% | 35% | +0.52% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,963 | $20,642 | +$679 | +3.4% |
| American Funds EuroPacific | SEEGX | Intl Equity | $62,129 | $64,243 | +$2,113 | +3.4% |
| MFS Mid Cap Growth | MFEKX | US Equity | $58,090 | $60,066 | +$1,976 | +3.4% |
| American Funds AMCAP | AMCPX | US Equity | $88,128 | $91,126 | +$2,998 | +3.4% |
| American Funds Growth | AGTHX | US Equity | $79,797 | $82,511 | +$2,714 | +3.4% |
| American Funds New World | ANCFX | Intl Equity | $49,501 | $51,185 | +$1,684 | +3.4% |
| American Funds Income | AMRMX | US Equity | $26,279 | $27,173 | +$894 | +3.4% |
| American Funds Investment | AIVSX | US Equity | $83,079 | $85,905 | +$2,826 | +3.4% |
| American Funds New Persp. | ANWPX | Intl Equity | $38,650 | $39,965 | +$1,315 | +3.4% |
| American Funds Balanced | AMFFX | US Equity | $22,992 | $23,774 | +$782 | +3.4% |
| American Funds Bond | ABNDX | Fixed Income | $20,220 | $20,908 | +$688 | +3.4% |
| American High Income Trust | AHITX | Fixed Income | $16,428 | $16,987 | +$559 | +3.4% |
| American Funds New Econ. | ANEFX | US Equity | $22,235 | $22,991 | +$756 | +3.4% |
| iShares Core S&P 500 | IVV | US Equity | $111,360 | $115,148 | +$3,788 | +3.4% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,685 | $17,253 | +$568 | +3.4% |
| SPDR Gold Shares | GLD | Alternatives | $19,463 | $20,125 | +$662 | +3.4% |
| TOTAL PORTFOLIO |  |  | $735,000 | $760,000 | +$25,000 | +3.4% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $735,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,914.00 |
| Interest Income | $668.00 |
| Market Appreciation / (Depreciation) | $17,700.00 |
| Advisory & Management Fees | ($282.00) |
| Net Change for Period | $25,000.00 |
| Ending Account Value | $760,000.00 |

Advisor Commentary: Portfolio performance of +2.99% was ahead of the blended benchmark (+1.98%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2025 | +0.29% | -2.21% |
| Q2 2025 | +1.70% | +3.23% |
| Q3 2025 | +1.66% | +4.60% |
| Q4 2025 | +2.99% | +1.98% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
