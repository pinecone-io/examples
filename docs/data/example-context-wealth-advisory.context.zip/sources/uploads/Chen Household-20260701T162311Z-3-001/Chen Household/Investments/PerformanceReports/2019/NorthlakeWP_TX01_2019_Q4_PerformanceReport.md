CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2019Quarter 4, 2019 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2019 Portfolio | Q4 2019 Blend Bench. | Excess Return | YTD 2019 Portfolio | YTD 2019 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +5.40% | +6.19% | -0.79% | +18.22% | +23.72% |
| Benchmark Return | +6.19% | +8.82% | +0.07% | — | — |

▪ Beginning Value: $376,801 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $400,232

▪ Dividends & Interest: $2,438 ▪ Market Gain / (Loss): $18,214 ▪ Advisory Fees: ($221)

MARKET COMMENTARY

A strong finish capped an exceptional year for financial markets. The S&P 500 gained 9.1% in Q4 and 31.5% for the full year 2019 — its best annual return since 2013. A Phase 1 trade deal with China removed a key overhang. The Fed held rates steady after three cuts. Bonds held most of the year's gains despite some reversal. Your portfolio ended 2019 at its highest value to date, with equity gains the primary driver and consistent income generation contributing throughout the year.

| Benchmark | Q4 2019 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +8.82% | 70% | +6.17% |
| Bloomberg US Aggregate (Fixed Income) | +0.07% | 30% | +0.02% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $11,081 | $11,770 | +$689 | +6.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $33,665 | $35,759 | +$2,093 | +6.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $27,552 | $29,265 | +$1,713 | +6.2% |
| American Funds AMCAP | AMCPX | US Equity | $40,724 | $43,257 | +$2,532 | +6.2% |
| American Funds Growth | AGTHX | US Equity | $36,729 | $39,013 | +$2,284 | +6.2% |
| American Funds New World | ANCFX | Intl Equity | $22,841 | $24,262 | +$1,420 | +6.2% |
| American Funds Income | AMRMX | US Equity | $13,434 | $14,269 | +$835 | +6.2% |
| American Funds Investment | AIVSX | US Equity | $39,553 | $42,012 | +$2,460 | +6.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $18,375 | $19,518 | +$1,143 | +6.2% |
| American Funds Balanced | AMFFX | US Equity | $12,252 | $13,014 | +$762 | +6.2% |
| American Funds Bond | ABNDX | Fixed Income | $19,787 | $21,017 | +$1,230 | +6.2% |
| American High Income Trust | AHITX | Fixed Income | $15,551 | $16,518 | +$967 | +6.2% |
| American Funds New Econ. | ANEFX | US Equity | $11,546 | $12,264 | +$718 | +6.2% |
| iShares Core S&P 500 | IVV | US Equity | $49,200 | $52,260 | +$3,059 | +6.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,728 | $17,768 | +$1,040 | +6.2% |
| SPDR Gold Shares | GLD | Alternatives | $7,782 | $8,265 | +$484 | +6.2% |
| TOTAL PORTFOLIO |  |  | $376,801 | $400,232 | +$23,431 | +6.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $376,801.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,104.00 |
| Interest Income | $334.00 |
| Market Appreciation / (Depreciation) | $18,214.00 |
| Advisory & Management Fees | ($221.00) |
| Net Change for Period | $23,431.00 |
| Ending Account Value | $400,232.00 |

Advisor Commentary: Portfolio performance of +5.40% was behind the blended benchmark (+6.19%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2019 | +6.91% | +10.21% |
| Q2 2019 | +3.45% | +3.71% |
| Q3 2019 | +1.41% | +1.92% |
| Q4 2019 | +5.40% | +6.19% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
