CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2024Quarter 1, 2024 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2024 Portfolio | Q1 2024 Blend Bench. | Excess Return | YTD 2024 Portfolio | YTD 2024 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.74% | +6.61% | -3.88% | +2.74% | +6.61% |
| Benchmark Return | +6.61% | +10.59% | -0.78% | — | — |

▪ Beginning Value: $620,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $640,000

▪ Dividends & Interest: $3,928 ▪ Market Gain / (Loss): $13,329 ▪ Advisory Fees: ($257)

MARKET COMMENTARY

Q1 2024 continued the equity rally as AI enthusiasm intensified and earnings growth remained robust. The S&P 500 gained 10.6% — its best Q1 since 2019. Rate cut expectations were pushed back as inflation proved stickier than anticipated; the Fed held rates steady. Bonds declined modestly (-0.8%) as the yield curve repriced. International equities also performed well. Your equity holdings drove strong portfolio performance, and the expanded portfolio following the 2023 RSU contribution amplified the dollar impact of percentage gains.

| Benchmark | Q1 2024 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +10.59% | 65% | +6.88% |
| Bloomberg US Aggregate (Fixed Income) | -0.78% | 35% | -0.27% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $17,782 | $18,893 | +$1,111 | +6.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $52,216 | $54,553 | +$2,337 | +4.5% |
| MFS Mid Cap Growth | MFEKX | US Equity | $47,916 | $50,358 | +$2,442 | +5.1% |
| American Funds AMCAP | AMCPX | US Equity | $73,746 | $76,687 | +$2,941 | +4.0% |
| American Funds Growth | AGTHX | US Equity | $65,131 | $68,997 | +$3,866 | +5.9% |
| American Funds New World | ANCFX | Intl Equity | $40,108 | $42,663 | +$2,555 | +6.4% |
| American Funds Income | AMRMX | US Equity | $22,356 | $22,859 | +$503 | +2.3% |
| American Funds Investment | AIVSX | US Equity | $68,903 | $72,026 | +$3,124 | +4.5% |
| American Funds New Persp. | ANWPX | Intl Equity | $31,768 | $33,346 | +$1,578 | +5.0% |
| American Funds Balanced | AMFFX | US Equity | $19,934 | $20,058 | +$123 | +0.6% |
| American Funds Bond | ABNDX | Fixed Income | $20,473 | $18,431 | $-2,041 | -10.0% |
| American High Income Trust | AHITX | Fixed Income | $16,706 | $14,936 | $-1,770 | -10.6% |
| American Funds New Econ. | ANEFX | US Equity | $18,584 | $19,126 | +$542 | +2.9% |
| iShares Core S&P 500 | IVV | US Equity | $92,311 | $96,034 | +$3,724 | +4.0% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,975 | $14,931 | $-2,044 | -12.0% |
| SPDR Gold Shares | GLD | Alternatives | $15,091 | $16,101 | +$1,009 | +6.7% |
| TOTAL PORTFOLIO |  |  | $620,000 | $640,000 | +$20,000 | +3.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $620,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,214.00 |
| Interest Income | $714.00 |
| Market Appreciation / (Depreciation) | $13,329.00 |
| Advisory & Management Fees | ($257.00) |
| Net Change for Period | $20,000.00 |
| Ending Account Value | $640,000.00 |

Advisor Commentary: Portfolio performance of +2.74% was behind the blended benchmark (+6.61%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2023 | -4.39% | +4.83% |
| Q3 2023 | +5.70% | -3.24% |
| Q4 2023 | +3.69% | +9.71% |
| Q1 2024 | +2.74% | +6.61% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
