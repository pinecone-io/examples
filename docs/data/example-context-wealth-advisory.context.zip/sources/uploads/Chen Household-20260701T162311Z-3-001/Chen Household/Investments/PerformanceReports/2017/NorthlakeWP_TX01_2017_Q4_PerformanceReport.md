CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2017Quarter 4, 2017 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2017 Portfolio | Q4 2017 Blend Bench. | Excess Return | YTD 2017 Portfolio | YTD 2017 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.27% | +4.17% | -0.90% | +13.54% | +15.09% |
| Benchmark Return | +4.17% | +6.11% | -0.35% | — | — |

▪ Beginning Value: $310,720 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $323,942

▪ Dividends & Interest: $1,919 ▪ Market Gain / (Loss): $8,504 ▪ Advisory Fees: ($201)

MARKET COMMENTARY

Markets capped an exceptional 2017 with another strong quarter. Congress passed the Tax Cuts and Jobs Act in December, boosting corporate earnings forecasts for 2018. The S&P 500 gained 6.1% for Q4 and 21.8% for the full year. International equities also delivered double-digit gains. Bonds delivered modest positive returns for the quarter. The Fed raised rates in December, completing three hikes for the year. Your portfolio closed 2017 in excellent shape, reflecting the strong equity market environment and consistent income generation.

| Benchmark | Q4 2017 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +6.11% | 70% | +4.28% |
| Bloomberg US Aggregate (Fixed Income) | -0.35% | 30% | -0.10% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 27% | █████████████  27% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $9,248 | $9,642 | +$394 | +4.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $26,988 | $28,137 | +$1,148 | +4.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $21,551 | $22,468 | +$917 | +4.3% |
| American Funds AMCAP | AMCPX | US Equity | $33,850 | $35,290 | +$1,440 | +4.3% |
| American Funds Growth | AGTHX | US Equity | $29,354 | $30,603 | +$1,249 | +4.3% |
| American Funds New World | ANCFX | Intl Equity | $18,476 | $19,262 | +$786 | +4.3% |
| American Funds Income | AMRMX | US Equity | $11,378 | $11,862 | +$484 | +4.3% |
| American Funds Investment | AIVSX | US Equity | $31,720 | $33,070 | +$1,350 | +4.3% |
| American Funds New Persp. | ANWPX | Intl Equity | $15,159 | $15,804 | +$645 | +4.3% |
| American Funds Balanced | AMFFX | US Equity | $10,195 | $10,629 | +$434 | +4.3% |
| American Funds Bond | ABNDX | Fixed Income | $18,239 | $19,015 | +$776 | +4.3% |
| American High Income Trust | AHITX | Fixed Income | $14,690 | $15,315 | +$625 | +4.3% |
| American Funds New Econ. | ANEFX | US Equity | $9,717 | $10,130 | +$413 | +4.3% |
| iShares Core S&P 500 | IVV | US Equity | $38,350 | $39,982 | +$1,632 | +4.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,395 | $16,050 | +$655 | +4.3% |
| SPDR Gold Shares | GLD | Alternatives | $6,409 | $6,682 | +$273 | +4.3% |
| TOTAL PORTFOLIO |  |  | $310,720 | $323,942 | +$13,222 | +4.3% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $310,720.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,701.00 |
| Interest Income | $218.00 |
| Market Appreciation / (Depreciation) | $8,504.00 |
| Advisory & Management Fees | ($201.00) |
| Net Change for Period | $13,222.00 |
| Ending Account Value | $323,942.00 |

Advisor Commentary: Portfolio performance of +3.27% was behind the blended benchmark (+4.17%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2017 | +3.52% | +4.49% |
| Q2 2017 | +2.95% | +2.60% |
| Q3 2017 | +3.16% | +3.05% |
| Q4 2017 | +3.27% | +4.17% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
