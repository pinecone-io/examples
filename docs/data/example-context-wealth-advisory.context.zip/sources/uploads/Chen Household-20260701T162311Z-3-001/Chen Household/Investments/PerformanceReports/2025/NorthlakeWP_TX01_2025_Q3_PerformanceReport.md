CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2025Quarter 3, 2025 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2025 Portfolio | Q3 2025 Blend Bench. | Excess Return | YTD 2025 Portfolio | YTD 2025 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.66% | +4.60% | -2.94% | +3.68% | +5.59% |
| Benchmark Return | +4.60% | +5.90% | +2.19% | — | — |

▪ Beginning Value: $720,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $735,000

▪ Dividends & Interest: $4,496 ▪ Market Gain / (Loss): $7,783 ▪ Advisory Fees: ($279)

MARKET COMMENTARY

Q3 2025 delivered solid broad-market returns despite ongoing macroeconomic uncertainty. The S&P 500 advanced 5.9%, supported by resilient consumer spending and solid corporate earnings. Fixed income gained 2.2% as the Fed made one additional rate cut. International equities also performed well, with a weakening dollar providing a tailwind for non-U.S. holdings. Your portfolio continued to compound steadily toward long-term financial goals, with a well-diversified allocation capturing returns across multiple asset classes.

| Benchmark | Q3 2025 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +5.90% | 65% | +3.84% |
| Bloomberg US Aggregate (Fixed Income) | +2.19% | 35% | +0.77% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,555 | $19,963 | +$407 | +2.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $60,861 | $62,129 | +$1,268 | +2.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $56,904 | $58,090 | +$1,186 | +2.1% |
| American Funds AMCAP | AMCPX | US Equity | $86,330 | $88,128 | +$1,799 | +2.1% |
| American Funds Growth | AGTHX | US Equity | $78,169 | $79,797 | +$1,629 | +2.1% |
| American Funds New World | ANCFX | Intl Equity | $48,491 | $49,501 | +$1,010 | +2.1% |
| American Funds Income | AMRMX | US Equity | $25,743 | $26,279 | +$536 | +2.1% |
| American Funds Investment | AIVSX | US Equity | $81,384 | $83,079 | +$1,695 | +2.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $37,861 | $38,650 | +$789 | +2.1% |
| American Funds Balanced | AMFFX | US Equity | $22,523 | $22,992 | +$469 | +2.1% |
| American Funds Bond | ABNDX | Fixed Income | $19,807 | $20,220 | +$413 | +2.1% |
| American High Income Trust | AHITX | Fixed Income | $16,093 | $16,428 | +$335 | +2.1% |
| American Funds New Econ. | ANEFX | US Equity | $21,781 | $22,235 | +$454 | +2.1% |
| iShares Core S&P 500 | IVV | US Equity | $109,088 | $111,360 | +$2,273 | +2.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,345 | $16,685 | +$341 | +2.1% |
| SPDR Gold Shares | GLD | Alternatives | $19,065 | $19,463 | +$397 | +2.1% |
| TOTAL PORTFOLIO |  |  | $720,000 | $735,000 | +$15,000 | +2.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $720,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,814.00 |
| Interest Income | $682.00 |
| Market Appreciation / (Depreciation) | $7,783.00 |
| Advisory & Management Fees | ($279.00) |
| Net Change for Period | $15,000.00 |
| Ending Account Value | $735,000.00 |

Advisor Commentary: Portfolio performance of +1.66% was behind the blended benchmark (+4.60%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2024 | +5.59% | -2.60% |
| Q1 2025 | +0.29% | -2.21% |
| Q2 2025 | +1.70% | +3.23% |
| Q3 2025 | +1.66% | +4.60% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
