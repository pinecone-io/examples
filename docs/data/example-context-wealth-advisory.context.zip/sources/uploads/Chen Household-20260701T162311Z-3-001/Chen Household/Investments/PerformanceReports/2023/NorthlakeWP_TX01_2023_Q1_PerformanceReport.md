CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2023Quarter 1, 2023 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2023 Portfolio | Q1 2023 Blend Bench. | Excess Return | YTD 2023 Portfolio | YTD 2023 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +5.15% | +5.40% | -0.25% | +5.15% | +5.40% |
| Benchmark Return | +5.40% | +7.03% | +2.96% | — | — |

▪ Beginning Value: $386,751 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $409,755

▪ Dividends & Interest: $2,626 ▪ Market Gain / (Loss): $17,618 ▪ Advisory Fees: ($240)

MARKET COMMENTARY

After a brutal 2022, markets rebounded sharply in Q1 2023. The S&P 500 gained 7.5%, led by the Nasdaq (+20.5%) and growth stocks recovering from 2022's deep discounting. The Silicon Valley Bank failure in March temporarily rattled markets, but swift regulatory action contained contagion. The Fed hiked rates twice more but signaled approaching the end of its tightening cycle. Short-term yields remained highly attractive above 5%. Your portfolio recovered meaningfully from 2022 lows, with both equity and income components contributing positively.

| Benchmark | Q1 2023 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +7.03% | 60% | +4.22% |
| Bloomberg US Aggregate (Fixed Income) | +2.96% | 40% | +1.18% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $11,160 | $11,752 | +$592 | +5.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $32,751 | $34,509 | +$1,758 | +5.4% |
| MFS Mid Cap Growth | MFEKX | US Equity | $30,028 | $31,668 | +$1,640 | +5.5% |
| American Funds AMCAP | AMCPX | US Equity | $43,890 | $48,738 | +$4,848 | +11.0% |
| American Funds Growth | AGTHX | US Equity | $38,662 | $43,045 | +$4,383 | +11.3% |
| American Funds New World | ANCFX | Intl Equity | $23,886 | $26,507 | +$2,622 | +11.0% |
| American Funds Income | AMRMX | US Equity | $13,888 | $14,775 | +$887 | +6.4% |
| American Funds Investment | AIVSX | US Equity | $40,935 | $45,538 | +$4,602 | +11.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $18,657 | $20,995 | +$2,338 | +12.5% |
| American Funds Balanced | AMFFX | US Equity | $12,519 | $13,175 | +$656 | +5.2% |
| American Funds Bond | ABNDX | Fixed Income | $16,161 | $13,530 | $-2,631 | -16.3% |
| American High Income Trust | AHITX | Fixed Income | $13,433 | $11,041 | $-2,392 | -17.8% |
| American Funds New Econ. | ANEFX | US Equity | $11,610 | $12,282 | +$672 | +5.8% |
| iShares Core S&P 500 | IVV | US Equity | $54,580 | $61,008 | +$6,428 | +11.8% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,888 | $11,219 | $-2,669 | -19.2% |
| SPDR Gold Shares | GLD | Alternatives | $10,705 | $9,974 | $-731 | -6.8% |
| TOTAL PORTFOLIO |  |  | $386,751 | $409,755 | +$23,004 | +5.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $386,751.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,114.00 |
| Interest Income | $512.00 |
| Market Appreciation / (Depreciation) | $17,618.00 |
| Advisory & Management Fees | ($240.00) |
| Net Change for Period | $23,004.00 |
| Ending Account Value | $409,755.00 |

Advisor Commentary: Portfolio performance of +5.15% was in line with the blended benchmark (+5.40%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2022 | -11.93% | -11.73% |
| Q3 2022 | -5.17% | -5.00% |
| Q4 2022 | +2.94% | +5.13% |
| Q1 2023 | +5.15% | +5.40% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
