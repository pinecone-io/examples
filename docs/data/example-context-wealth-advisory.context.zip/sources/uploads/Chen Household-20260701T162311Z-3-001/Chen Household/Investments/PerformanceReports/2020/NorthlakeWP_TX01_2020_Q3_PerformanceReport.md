CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2020Quarter 3, 2020 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2020 Portfolio | Q3 2020 Blend Bench. | Excess Return | YTD 2020 Portfolio | YTD 2020 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +6.01% | +5.00% | +1.01% | +2.41% | +5.45% |
| Benchmark Return | +5.00% | +8.72% | -0.59% | — | — |

▪ Beginning Value: $393,002 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $419,696

▪ Dividends & Interest: $2,102 ▪ Market Gain / (Loss): $21,814 ▪ Advisory Fees: ($222)

MARKET COMMENTARY

The recovery continued in Q3 2020, though at a more moderate pace. The S&P 500 gained 8.9%, boosted by megacap technology stocks. The Fed adopted Average Inflation Targeting, signaling rates would remain near zero for the foreseeable future. Fiscal stimulus discussions stalled in Congress, creating uncertainty. September saw a sharp tech-led correction, though markets recovered most losses. Your portfolio continued to benefit from the equity recovery, with growth-oriented fund holdings contributing meaningfully to performance.

| Benchmark | Q3 2020 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +8.72% | 60% | +5.23% |
| Bloomberg US Aggregate (Fixed Income) | -0.59% | 40% | -0.24% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,728 | $9,321 | +$593 | +6.8% |
| American Funds EuroPacific | SEEGX | Intl Equity | $34,868 | $37,236 | +$2,368 | +6.8% |
| MFS Mid Cap Growth | MFEKX | US Equity | $30,405 | $32,470 | +$2,065 | +6.8% |
| American Funds AMCAP | AMCPX | US Equity | $44,435 | $47,454 | +$3,018 | +6.8% |
| American Funds Growth | AGTHX | US Equity | $40,393 | $43,137 | +$2,744 | +6.8% |
| American Funds New World | ANCFX | Intl Equity | $24,242 | $25,889 | +$1,647 | +6.8% |
| American Funds Income | AMRMX | US Equity | $13,408 | $14,318 | +$911 | +6.8% |
| American Funds Investment | AIVSX | US Equity | $41,243 | $44,045 | +$2,801 | +6.8% |
| American Funds New Persp. | ANWPX | Intl Equity | $19,779 | $21,123 | +$1,343 | +6.8% |
| American Funds Balanced | AMFFX | US Equity | $12,553 | $13,406 | +$853 | +6.8% |
| American Funds Bond | ABNDX | Fixed Income | $18,933 | $20,219 | +$1,286 | +6.8% |
| American High Income Trust | AHITX | Fixed Income | $14,470 | $15,453 | +$983 | +6.8% |
| American Funds New Econ. | ANEFX | US Equity | $11,920 | $12,730 | +$810 | +6.8% |
| iShares Core S&P 500 | IVV | US Equity | $52,299 | $55,851 | +$3,552 | +6.8% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,954 | $17,037 | +$1,084 | +6.8% |
| SPDR Gold Shares | GLD | Alternatives | $9,370 | $10,006 | +$636 | +6.8% |
| TOTAL PORTFOLIO |  |  | $393,002 | $419,696 | +$26,694 | +6.8% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $393,002.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,014.00 |
| Interest Income | $88.00 |
| Market Appreciation / (Depreciation) | $21,814.00 |
| Advisory & Management Fees | ($222.00) |
| Net Change for Period | $26,694.00 |
| Ending Account Value | $419,696.00 |

Advisor Commentary: Portfolio performance of +6.01% was ahead of the blended benchmark (+5.00%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2019 | +5.40% | +6.19% |
| Q1 2020 | -14.82% | -10.56% |
| Q2 2020 | +13.42% | +12.29% |
| Q3 2020 | +6.01% | +5.00% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
