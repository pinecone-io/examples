CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2020Quarter 1, 2020 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2020 Portfolio | Q1 2020 Blend Bench. | Excess Return | YTD 2020 Portfolio | YTD 2020 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -14.82% | -10.56% | -4.26% | -14.82% | -10.56% |
| Benchmark Return | -10.56% | -19.75% | +3.22% | — | — |

▪ Beginning Value: $400,232 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $343,690

▪ Dividends & Interest: $2,100 ▪ Market Gain / (Loss): $-61,418 ▪ Advisory Fees: ($224)

MARKET COMMENTARY

COVID-19 transformed Q1 2020 into one of the most dramatic quarters in market history. The S&P 500 fell 19.6% — the fastest bear market entry on record — as global lockdowns brought economic activity to a halt. Credit markets seized, oil prices collapsed, and the Fed launched emergency rate cuts (two cuts totaling 150 bps), bringing rates to zero. Congress passed a $2.2 trillion CARES Act stimulus package. Bonds provided protection, gaining 3.2% as a flight to safety drove Treasury yields to historic lows. Your portfolio declined meaningfully but retained meaningful value relative to equity-only benchmarks, reflecting the benefit of diversification in a true crisis scenario.

| Benchmark | Q1 2020 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -19.75% | 60% | -11.85% |
| Bloomberg US Aggregate (Fixed Income) | +3.22% | 40% | +1.29% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $11,770 | $7,633 | $-4,137 | -35.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $35,759 | $30,493 | $-5,266 | -14.7% |
| MFS Mid Cap Growth | MFEKX | US Equity | $29,265 | $26,590 | $-2,675 | -9.1% |
| American Funds AMCAP | AMCPX | US Equity | $43,257 | $38,860 | $-4,397 | -10.2% |
| American Funds Growth | AGTHX | US Equity | $39,013 | $35,325 | $-3,688 | -9.5% |
| American Funds New World | ANCFX | Intl Equity | $24,262 | $21,200 | $-3,061 | -12.6% |
| American Funds Income | AMRMX | US Equity | $14,269 | $11,725 | $-2,544 | -17.8% |
| American Funds Investment | AIVSX | US Equity | $42,012 | $36,068 | $-5,944 | -14.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $19,518 | $17,297 | $-2,220 | -11.4% |
| American Funds Balanced | AMFFX | US Equity | $13,014 | $10,978 | $-2,036 | -15.6% |
| American Funds Bond | ABNDX | Fixed Income | $21,017 | $16,558 | $-4,460 | -21.2% |
| American High Income Trust | AHITX | Fixed Income | $16,518 | $12,655 | $-3,864 | -23.4% |
| American Funds New Econ. | ANEFX | US Equity | $12,264 | $10,424 | $-1,840 | -15.0% |
| iShares Core S&P 500 | IVV | US Equity | $52,260 | $45,736 | $-6,523 | -12.5% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,768 | $13,952 | $-3,816 | -21.5% |
| SPDR Gold Shares | GLD | Alternatives | $8,265 | $8,194 | $-71 | -0.9% |
| TOTAL PORTFOLIO |  |  | $400,232 | $343,690 | $-56,542 | -14.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $400,232.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,988.00 |
| Interest Income | $112.00 |
| Market Appreciation / (Depreciation) | $-61,418.00 |
| Advisory & Management Fees | ($224.00) |
| Net Change for Period | $-56,542.00 |
| Ending Account Value | $343,690.00 |

Advisor Commentary: COVID-19 pandemic caused historic market volatility. The portfolio declined but remained well-positioned for recovery. No panic selling occurred — a disciplined approach that proved prescient given the rapid Q2 rebound.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2019 | +3.45% | +3.71% |
| Q3 2019 | +1.41% | +1.92% |
| Q4 2019 | +5.40% | +6.19% |
| Q1 2020 | -14.82% | -10.56% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
