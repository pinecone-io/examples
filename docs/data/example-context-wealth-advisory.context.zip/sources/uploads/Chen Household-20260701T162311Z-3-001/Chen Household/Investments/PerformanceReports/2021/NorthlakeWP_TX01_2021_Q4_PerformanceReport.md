CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2021Quarter 4, 2021 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2021 Portfolio | Q4 2021 Blend Bench. | Excess Return | YTD 2021 Portfolio | YTD 2021 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +5.51% | +5.62% | -0.10% | +17.64% | +11.97% |
| Benchmark Return | +5.62% | +11.02% | -0.99% | — | — |

▪ Beginning Value: $426,387 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $452,972

▪ Dividends & Interest: $2,390 ▪ Market Gain / (Loss): $21,418 ▪ Advisory Fees: ($223)

MARKET COMMENTARY

Markets ended 2021 on a strong note despite the emergence of the Omicron variant. The S&P 500 gained 11.0% in Q4 and 28.7% for the full year — its third consecutive double-digit annual return. The Fed accelerated its tapering schedule and signaled rate hikes for 2022. Bonds declined modestly as yields rose. Despite the large Q2 withdrawal, your portfolio delivered strong full-year investment returns, reflecting the power of maintaining equity exposure through short-term volatility.

| Benchmark | Q4 2021 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +11.02% | 55% | +6.06% |
| Bloomberg US Aggregate (Fixed Income) | -0.99% | 45% | -0.45% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,563 | $8,035 | +$472 | +6.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $37,959 | $40,325 | +$2,367 | +6.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $34,387 | $36,531 | +$2,144 | +6.2% |
| American Funds AMCAP | AMCPX | US Equity | $52,461 | $55,732 | +$3,271 | +6.2% |
| American Funds Growth | AGTHX | US Equity | $44,514 | $47,290 | +$2,775 | +6.2% |
| American Funds New World | ANCFX | Intl Equity | $27,231 | $28,929 | +$1,698 | +6.2% |
| American Funds Income | AMRMX | US Equity | $14,520 | $15,426 | +$905 | +6.2% |
| American Funds Investment | AIVSX | US Equity | $46,306 | $49,194 | +$2,887 | +6.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $21,474 | $22,812 | +$1,339 | +6.2% |
| American Funds Balanced | AMFFX | US Equity | $13,527 | $14,370 | +$843 | +6.2% |
| American Funds Bond | ABNDX | Fixed Income | $16,503 | $17,532 | +$1,029 | +6.2% |
| American High Income Trust | AHITX | Fixed Income | $12,927 | $13,733 | +$806 | +6.2% |
| American Funds New Econ. | ANEFX | US Equity | $12,732 | $13,526 | +$794 | +6.2% |
| iShares Core S&P 500 | IVV | US Equity | $62,001 | $65,867 | +$3,866 | +6.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,123 | $15,004 | +$881 | +6.2% |
| SPDR Gold Shares | GLD | Alternatives | $8,159 | $8,668 | +$509 | +6.2% |
| TOTAL PORTFOLIO |  |  | $426,387 | $452,972 | +$26,585 | +6.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $426,387.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,318.00 |
| Interest Income | $72.00 |
| Market Appreciation / (Depreciation) | $21,418.00 |
| Advisory & Management Fees | ($223.00) |
| Net Change for Period | $26,585.00 |
| Ending Account Value | $452,972.00 |

Advisor Commentary: Portfolio performance of +5.51% was in line with the blended benchmark (+5.62%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2021 | +3.74% | +1.83% |
| Q2 2021 | +4.75% | +3.92% |
| Q3 2021 | +2.60% | +0.18% |
| Q4 2021 | +5.51% | +5.62% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
