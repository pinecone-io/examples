CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

INVESTMENT POLICY STATEMENT — AMENDMENT

COVID-19 Risk Reassessment | Defensive Allocation Shift | EventID-2020-01

| Document ID DOC-IPSAmendment-2020-001 | Effective Date June 15, 2020 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: EventID-2020-01 — COVID-19 market volatility and economic uncertainty prompted a comprehensive risk tolerance review in May 2020. Alex and Sam Chen completed DOC-RiskQuestionnaire-2020-001 (May 20, 2020), scoring 54/100 (“Moderate / Conservative-Moderate”), a material decline from the 2016 score of 68/100. Client expressed “sleep-at-night” concern regarding equity volatility given household cash needs (emergency fund, anticipated home purchase 2021, and two children’s 529 accounts opened May 2020). This Amendment supersedes the allocation policy in Section 5 of DOC-IPS-2016-001 effective June 15, 2020. Implementation executed under DecisionID-2020-044 (June 15–30, 2020).

1. BASIS FOR AMENDMENT

| Amends: | DOC-IPS-2016-001  (Section 5 — Asset Allocation Policy; Section 7 — Constraints) |
| --- | --- |

| Effective Date: | June 15, 2020 |
| --- | --- |

| Risk Survey: | DOC-RiskQuestionnaire-2020-001  (completed 2020-05-20)  |  Score: 54/100  (“Moderate / Conservative-Moderate”) |
| --- | --- |

| Prior Score: | 68/100 (DOC-RiskQuestionnaire-2016-001, 2016-02-10)  |  Decline: −14 points |
| --- | --- |

| Triggering Event: | EventID-2020-01  |  COVID-19 volatility; market decline ~34% (S&P 500 Feb–Mar 2020) |
| --- | --- |

| AUM at Amendment: | ~$705,000  (2020-Q2, post-recovery from Q1 low of ~$665,000) |
| --- | --- |

| Implementation: | DecisionID-2020-044  |  Reallocation window: 2020-06-15 to 2020-06-30 |
| --- | --- |

| Tax Outcome: | 2020 net capital gains ~$12,000 (mostly long-term) from rebalancing trades |
| --- | --- |

Client articulated the following specific concerns prompting this amendment: (1) the COVID-19 market drawdown of approximately 34% in Q1 2020 exceeded Client’s stated 20–25% maximum drawdown tolerance from DOC-RiskQuestionnaire-2016-001; (2) the opening of ACCT-529A (Maya) and ACCT-529B (Eli) in May 2020 increased the household’s sensitivity to short-term market volatility given education funding obligations; (3) the anticipated home purchase (EventID-2021-01) requires preserving liquidity in ACCT-CASH and reducing forced-liquidation risk in ACCT-TX01; (4) Client used the phrase “I need to be able to sleep at night” to describe desired portfolio behavior, indicating that risk capacity and risk tolerance are now more closely aligned at a lower equity allocation.

2. ALLOCATION CHANGE — BEFORE AND AFTER

| Asset Class | Prior Target (IPS-2016) | New Target (IPS-2020) | Change | Drift Band (New) |
| --- | --- | --- | --- | --- |
| Equity (Total) | 70.0% | 60.0% | −9.0 pp | ±4%  (was ±5%) |
| U.S. Large Cap | 42.0% | 34.0% | −8.0 pp |  |
| U.S. Small Cap | 8.0% | 6.0% | −2.0 pp |  |
| Intl Developed | 12.0% | 12.0% | 0.0 pp |  |
| Emerging Markets | 8.0% | 8.0% | 0.0 pp |  |
| Fixed Income (Total) | 28.0% | 35.0% | +7.0 pp | ±4%  (was ±5%) |
| U.S. Core Bond | 14.0% | 17.0% | +3.0 pp |  |
| TIPS / Treasury | 8.0% | 12.0% | +4.0 pp |  |
| Municipal Bond | 6.0% | 6.0% | 0.0 pp |  |
| Cash & Equivalents | 2.0% | 5.0% | +3.0 pp | ±2%  (unchanged) |
| TOTAL | 100% | 100% | — |  |

⚠ TIGHTER DRIFT BANDS: This amendment reduces drift band tolerance from ±5% to ±4% for Equity and Fixed Income. This reflects Client’s reduced risk tolerance and desire for more active risk management during volatile periods.

3. AMENDED CONSTRAINTS

| Single-Stock Limit: | REDUCED from <10% to <7% of total household AUM  (NLTK equity comp monitoring tightened) |
| --- | --- |

| Equity Sleeve Min.: | 50% (hard floor on equity; prevents over-de-risking in panic scenarios) |
| --- | --- |

| Fixed Income Max.: | 45% (ceiling; prevents over-concentration in bonds at expense of long-term return) |
| --- | --- |

| TIPS Allocation: | Minimum 8% of fixed income sleeve; inflation protection emphasized given COVID fiscal response |
| --- | --- |

| Cash Minimum: | ACCT-CASH to maintain minimum balance of $50,000 (GoalID-2016-03 + pre-home-purchase staging) |
| --- | --- |

4. TAX PLACEMENT — UPDATED GUIDANCE

The increased TIPS and core bond allocations are preferentially held in ACCT-IRA1 (tax-deferred) to shelter interest income from current taxation. The reduced equity allocation in ACCT-TX01 reduces exposure to taxable capital gains events. The increased Cash allocation (5%) is divided between ACCT-TX01 money market (1%) and ACCT-CASH (4% target, supporting GoalID-2016-03 and home purchase staging per EventID-2021-01).

5. IMPLEMENTATION NOTES

| Item | Detail |
| --- | --- |
| DecisionID-2020-044 | Sell UECIX/USCIX in ACCT-TX01; reinvest in UCBIX/UTIPX in ACCT-IRA1; increase STBIX in ACCT-CASH |
| Execution Window | June 15–30, 2020  |  Tax-aware lot selection; prioritize long-term gains; use ACCT-IRA1 for bond reinvestment |
| Tax Impact | Net 2020 realized gains ~$12,000 (mostly LT); acceptable given rebalancing benefit and reduced risk |
| 529 Accounts | ACCT-529A and ACCT-529B opened May 2020; age-based moderate portfolio (529-AGE-MOD); excluded from IPS allocation calc |
| Next Review | Scheduled: Q4 2020 annual strategy review; earlier if EventID-2021-01 (home purchase) is triggered |

6. PROVISIONS UNCHANGED FROM DOC-IPS-2016-001

The following sections of DOC-IPS-2016-001 remain in full force without modification: Section 1 (Purpose), Section 2 (Parties and Accounts), Section 3 (Risk Profile, except risk score updated above), Section 4 (Goals), Section 6 (Tax-Aware Placement, with updates noted above), Section 8 (Benchmarks), Section 9 (Monitoring and Rebalancing), Section 10 (Event-Driven Triggers), Section 11 (Signatures requirements).

7. SIGNATURES

| ____________________________________Primary ClientAlex ChenDate:  June 15, 2020 | ____________________________________Co-ClientSam ChenDate:  June 15, 2020 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  June 15, 2020 |
| --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-IPSAmendment-2020-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
