CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2018Quarter 1, 2018 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2018 Portfolio | Q1 2018 Blend Bench. | Excess Return | YTD 2018 Portfolio | YTD 2018 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -0.25% | -0.08% | -0.18% | -0.25% | -0.08% |
| Benchmark Return | -0.08% | -0.76% | +1.51% | — | — |

▪ Beginning Value: $323,942 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $326,113

▪ Dividends & Interest: $1,992 ▪ Market Gain / (Loss): $-2,618 ▪ Advisory Fees: ($203)

MARKET COMMENTARY

After record-low volatility in 2017, markets experienced a sharp regime shift in Q1 2018. The S&P 500 fell 1.2% amid a spike in the VIX above 50 in early February — the largest single-day volatility surge since 2015. Rising wage inflation data triggered fears of faster Fed tightening. Trade tensions between the U.S. and China emerged as a new risk factor late in the quarter. Your portfolio's diversified structure provided some cushion during the turbulent period.

| Benchmark | Q1 2018 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -0.76% | 70% | -0.53% |
| Bloomberg US Aggregate (Fixed Income) | +1.51% | 30% | +0.45% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $9,642 | $12,054 | +$2,412 | +25.0% |
| American Funds EuroPacific | SEEGX | Intl Equity | $28,137 | $28,471 | +$334 | +1.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $22,468 | $22,453 | $-15 | -0.1% |
| American Funds AMCAP | AMCPX | US Equity | $35,290 | $33,936 | $-1,354 | -3.8% |
| American Funds Growth | AGTHX | US Equity | $30,603 | $30,385 | $-218 | -0.7% |
| American Funds New World | ANCFX | Intl Equity | $19,262 | $18,892 | $-370 | -1.9% |
| American Funds Income | AMRMX | US Equity | $11,862 | $11,233 | $-629 | -5.3% |
| American Funds Investment | AIVSX | US Equity | $33,070 | $32,842 | $-228 | -0.7% |
| American Funds New Persp. | ANWPX | Intl Equity | $15,804 | $15,063 | $-741 | -4.7% |
| American Funds Balanced | AMFFX | US Equity | $10,629 | $10,413 | $-216 | -2.0% |
| American Funds Bond | ABNDX | Fixed Income | $19,015 | $20,402 | +$1,387 | +7.3% |
| American High Income Trust | AHITX | Fixed Income | $15,315 | $16,573 | +$1,257 | +8.2% |
| American Funds New Econ. | ANEFX | US Equity | $10,130 | $9,866 | $-265 | -2.6% |
| iShares Core S&P 500 | IVV | US Equity | $39,982 | $39,138 | $-843 | -2.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,050 | $17,530 | +$1,480 | +9.2% |
| SPDR Gold Shares | GLD | Alternatives | $6,682 | $6,863 | +$181 | +2.7% |
| TOTAL PORTFOLIO |  |  | $323,942 | $326,113 | +$2,171 | +0.7% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $323,942.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,744.00 |
| Interest Income | $248.00 |
| Market Appreciation / (Depreciation) | $-2,618.00 |
| Advisory & Management Fees | ($203.00) |
| Net Change for Period | $2,171.00 |
| Ending Account Value | $326,113.00 |

Advisor Commentary: Portfolio performance of -0.25% was in line with the blended benchmark (-0.08%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2017 | +2.95% | +2.60% |
| Q3 2017 | +3.16% | +3.05% |
| Q4 2017 | +3.27% | +4.17% |
| Q1 2018 | -0.25% | -0.08% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
