CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2019Quarter 1, 2019 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2019 Portfolio | Q1 2019 Blend Bench. | Excess Return | YTD 2019 Portfolio | YTD 2019 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +6.91% | +10.21% | -3.30% | +6.91% | +10.21% |
| Benchmark Return | +10.21% | +13.32% | +2.97% | — | — |

▪ Beginning Value: $327,579 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $353,322

▪ Dividends & Interest: $2,142 ▪ Market Gain / (Loss): $20,814 ▪ Advisory Fees: ($213)

MARKET COMMENTARY

Markets staged a powerful recovery in Q1 2019, with the S&P 500 gaining 13.7% — its best first quarter since 1998. The Fed pivoted sharply to a 'patient' stance, abandoning its prior rate-hike trajectory. Strong Q4 2018 earnings and improving trade-war sentiment fueled optimism. Bonds also performed well as rates declined. Your portfolio benefited broadly, with equity and fixed income holdings both contributing positively to returns. The quarter's strong performance more than recovered the Q4 2018 drawdown.

| Benchmark | Q1 2019 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +13.32% | 70% | +9.32% |
| Bloomberg US Aggregate (Fixed Income) | +2.97% | 30% | +0.89% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $12,108 | $10,390 | $-1,718 | -14.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $28,599 | $31,568 | +$2,969 | +10.4% |
| MFS Mid Cap Growth | MFEKX | US Equity | $22,554 | $25,835 | +$3,281 | +14.5% |
| American Funds AMCAP | AMCPX | US Equity | $34,088 | $38,187 | +$4,099 | +12.0% |
| American Funds Growth | AGTHX | US Equity | $30,522 | $34,440 | +$3,918 | +12.8% |
| American Funds New World | ANCFX | Intl Equity | $18,977 | $21,418 | +$2,441 | +12.9% |
| American Funds Income | AMRMX | US Equity | $11,284 | $12,597 | +$1,313 | +11.6% |
| American Funds Investment | AIVSX | US Equity | $32,989 | $37,088 | +$4,099 | +12.4% |
| American Funds New Persp. | ANWPX | Intl Equity | $15,130 | $17,230 | +$2,100 | +13.9% |
| American Funds Balanced | AMFFX | US Equity | $10,460 | $11,489 | +$1,029 | +9.8% |
| American Funds Bond | ABNDX | Fixed Income | $20,494 | $18,554 | $-1,940 | -9.5% |
| American High Income Trust | AHITX | Fixed Income | $16,647 | $14,582 | $-2,065 | -12.4% |
| American Funds New Econ. | ANEFX | US Equity | $9,910 | $10,827 | +$917 | +9.3% |
| iShares Core S&P 500 | IVV | US Equity | $39,314 | $46,134 | +$6,821 | +17.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,609 | $15,686 | $-1,923 | -10.9% |
| SPDR Gold Shares | GLD | Alternatives | $6,893 | $7,297 | +$403 | +5.8% |
| TOTAL PORTFOLIO |  |  | $327,579 | $353,322 | +$25,743 | +7.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $327,579.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,856.00 |
| Interest Income | $286.00 |
| Market Appreciation / (Depreciation) | $20,814.00 |
| Advisory & Management Fees | ($213.00) |
| Net Change for Period | $25,743.00 |
| Ending Account Value | $353,322.00 |

Advisor Commentary: Portfolio performance of +6.91% was behind the blended benchmark (+10.21%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2018 | +1.52% | +2.01% |
| Q3 2018 | +2.95% | +4.99% |
| Q4 2018 | -6.43% | -9.08% |
| Q1 2019 | +6.91% | +10.21% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
