CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2021Quarter 3, 2021 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2021 Portfolio | Q3 2021 Blend Bench. | Excess Return | YTD 2021 Portfolio | YTD 2021 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.60% | +0.18% | +2.43% | +11.50% | +6.01% |
| Benchmark Return | +0.18% | +0.58% | -0.32% | — | — |

▪ Beginning Value: $412,610 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $426,387

▪ Dividends & Interest: $2,182 ▪ Market Gain / (Loss): $8,814 ▪ Advisory Fees: ($219)

MARKET COMMENTARY

Q3 2021 brought a more modest equity advance as the Delta COVID variant dampened growth expectations. The S&P 500 gained just 0.6%. Supply chain disruptions intensified, and inflation continued running above expectations. The Fed signaled it would begin tapering asset purchases before year-end. Chinese regulatory crackdowns weighed on international equities. Energy prices surged. Your portfolio reflected these crosscurrents, with domestic equity holdings providing modest gains while international exposure lagged.

| Benchmark | Q3 2021 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +0.58% | 55% | +0.32% |
| Bloomberg US Aggregate (Fixed Income) | -0.32% | 45% | -0.14% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,319 | $7,563 | +$244 | +3.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $36,732 | $37,959 | +$1,226 | +3.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $33,276 | $34,387 | +$1,111 | +3.3% |
| American Funds AMCAP | AMCPX | US Equity | $50,766 | $52,461 | +$1,695 | +3.3% |
| American Funds Growth | AGTHX | US Equity | $43,076 | $44,514 | +$1,438 | +3.3% |
| American Funds New World | ANCFX | Intl Equity | $26,351 | $27,231 | +$880 | +3.3% |
| American Funds Income | AMRMX | US Equity | $14,051 | $14,520 | +$469 | +3.3% |
| American Funds Investment | AIVSX | US Equity | $44,810 | $46,306 | +$1,496 | +3.3% |
| American Funds New Persp. | ANWPX | Intl Equity | $20,780 | $21,474 | +$694 | +3.3% |
| American Funds Balanced | AMFFX | US Equity | $13,090 | $13,527 | +$437 | +3.3% |
| American Funds Bond | ABNDX | Fixed Income | $15,970 | $16,503 | +$533 | +3.3% |
| American High Income Trust | AHITX | Fixed Income | $12,509 | $12,927 | +$418 | +3.3% |
| American Funds New Econ. | ANEFX | US Equity | $12,321 | $12,732 | +$411 | +3.3% |
| iShares Core S&P 500 | IVV | US Equity | $59,998 | $62,001 | +$2,003 | +3.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,667 | $14,123 | +$456 | +3.3% |
| SPDR Gold Shares | GLD | Alternatives | $7,895 | $8,159 | +$264 | +3.3% |
| TOTAL PORTFOLIO |  |  | $412,610 | $426,387 | +$13,777 | +3.3% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $412,610.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,114.00 |
| Interest Income | $68.00 |
| Market Appreciation / (Depreciation) | $8,814.00 |
| Advisory & Management Fees | ($219.00) |
| Net Change for Period | $13,777.00 |
| Ending Account Value | $426,387.00 |

Advisor Commentary: Portfolio performance of +2.60% was ahead of the blended benchmark (+0.18%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2020 | +6.31% | +7.08% |
| Q1 2021 | +3.74% | +1.83% |
| Q2 2021 | +4.75% | +3.92% |
| Q3 2021 | +2.60% | +0.18% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
