CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

ADVISORY AGREEMENT AMENDMENT

Services Scope, Accounts, and Event-Driven Review Update — DOC-AdvisoryAgreement-2016-001 as amended by DOC-FeeAmendment-2021-001

| Document ID DOC-AgreementAmendment-2024-001 | Effective Date October 1, 2024 | Amends DOC-AdvisoryAgreement-2016-001 |
| --- | --- | --- |

This Advisory Agreement Amendment ("Amendment") is entered into as of September 20, 2024, effective October 1, 2024, by and between Clearwater Wealth Partners ("Adviser") and Alex Chen and Sam Chen (collectively, "Client"), household reference HH-CHEN-001. This Amendment modifies the Investment Advisory Agreement dated February 1, 2016 (DOC-AdvisoryAgreement-2016-001) as previously amended by the Fee Schedule Amendment dated June 20, 2021 (DOC-FeeAmendment-2021-001). Except as expressly modified herein, all prior terms remain in full force.

1. TRIGGERING EVENTS FOR THIS AMENDMENT

This Amendment was initiated following the Event-Driven Review triggered by the events listed below, each of which has materially affected Client’s financial circumstances, planning objectives, or the breadth of advisory services required:

| Event Reference | Event Description | Date / Status |
| --- | --- | --- |
| EventID-2024-01 | Family health event — estate and beneficiary documents require comprehensive audit; trust alignment with custodial beneficiary designations confirmed; expanded estate planning coordination formally added to advisory scope | 2024-Q3 (active) |
| EventID-2023-01 | Liquidity event (NLTK concentration reduction, 2023-Q2) — post-event AUM increased from ~$920K to ~$1,020K; DAF established (GoalID-2023-01); values-based giving plan requires ongoing advisory coordination | 2023-Q2 (completed) |
| AUM Milestone | Household AUM reached $1,285,000 at 2024-Q4 end, remaining in Tier 1 of the amended fee schedule (DOC-FeeAmendment-2021-001). No fee rate change required; milestone documented for record. | 2024-Q4 ($1,285,000) |
| IPS-2025 Pre-Planning | Bucket strategy discussion initiated (IPS-2025 anticipated effective 2025-03-01); pre-retirement income distribution planning added to advisory mandate in advance of formal IPS amendment | 2024-Q3 (pre-amendment) |

2. FEE SCHEDULE CONFIRMATION (NO CHANGE)

The tiered fee schedule established by DOC-FeeAmendment-2021-001 remains unchanged and in full force. For reference:

| Tier | AUM Band | Annual Fee Rate | 2024-Q4 Est. Fee |
| --- | --- | --- | --- |
| 1 | First $1,500,000 | 0.85% per annum | ~$10,923/yr at $1,285,000 |
| 2 | Next $1,500,000 | 0.70% per annum | (threshold not yet reached) |
| 3 | Assets above $3,000,000 | 0.55% per annum | (threshold not yet reached) |

Estimated household advisory fee at 2024-Q4 AUM of $1,285,000: approximately $10,923 per year (1,285,000 × 0.85%), billed at approximately $2,731 per quarter. The Tier 2 rate of 0.70% will apply automatically to AUM exceeding $1,500,000 without further amendment; Adviser will issue updated fee disclosure at the time of first Tier 2 billing.

3. AMENDED SCOPE OF ADVISORY SERVICES

Section 2 of the original Agreement is amended to expand the scope of advisory services as follows. Services listed in the original Agreement remain in effect; the following are added or clarified:

| Added / Clarified Service | Description and Trigger |
| --- | --- |
| Estate Planning Coordination | Triggered by EventID-2024-01. Adviser will coordinate with estate attorney Westfield & Baker LLP and Clearwater’s estate specialist Logan Hart, JD, to ensure beneficiary designations across all Covered Accounts align with the revocable trust structure (EventID-2019-01). Annual beneficiary audit added to review schedule. |
| DAF / Charitable Giving Strategy | Triggered by GoalID-2023-01. Adviser will incorporate annual giving strategy review into Q4 meetings, including DAF contribution timing, grant recommendations, and tax optimization relative to Alex’s RSU vesting calendar and household income levels. |
| Equity Compensation Planning | Ongoing per EventID-2018-01. Adviser will provide annual equity comp review covering RSU grant schedule, vesting projections, concentration analysis relative to IPS single-stock limit, and tax-aware liquidation/diversification planning. |
| Pre-Retirement Income Planning | Initiated 2024-Q3 in anticipation of IPS-2025 bucket strategy. Adviser will model household income distribution, sequence-of-returns scenarios, and Bucket 1 funding requirements to support the IPS amendment process (DOC-IPSAmendment-2025-001, anticipated Q1 2025). |

4. COVERED ACCOUNTS — CONFIRMED SCOPE

As of the effective date of this Amendment, the complete list of Covered Accounts subject to this Agreement and the advisory fee is confirmed as follows:

| Account ID | Nickname | Registration | Opened / Status |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Brokerage | Joint (Chen) | Feb 2016 — Active |
| ACCT-IRA1 | Alex Trad. IRA | Individual (J.) | Feb 2016 — Active |
| ACCT-RIRA | Alex Roth IRA | Individual (J.) | Feb 2016 — Active |
| ACCT-CASH | Cash Management | Joint (Chen) | Jan 2019 — Active |
| ACCT-529A | 529 Maya | Household | May 2020 — Active |
| ACCT-529B | 529 Eli | Household | May 2020 — Active |
| ACCT-401R | Alex 401k Rollover | Individual (J.) | Aug 2017 — Closed/Merged |

5. UPDATED EVENT-DRIVEN REVIEW TRIGGERS

Section 6 of the original Agreement is supplemented with the following additional mandatory review triggers, reflecting Client’s current life stage and expanded financial planning mandate:

| New Trigger | Condition | Required Action |
| --- | --- | --- |
| Health / Disability Event | Diagnosis, hospitalization, or significant health event affecting either Alex or Sam Chen (EventID-2024-01 is active precedent) | Estate doc review; beneficiary audit; liquidity stress test; disability income gap analysis |
| RSU Vesting Milestone | Quarterly RSU vesting exceeding $50,000 in gross value (Alex’s equity comp, EventID-2018-01) | Concentration analysis; tax withholding review; diversification trade proposal if >10% single-stock threshold |
| DAF Contribution / Grant | Annual charitable giving exceeding $20,000 or opening of new giving vehicle (GoalID-2023-01) | Charitable tax optimization memo; DAF strategy update; review for income bunching opportunity |
| 529 Allocation Shift | Either dependent (Maya DOB 2011, Eli DOB 2014) enters high school or approaches college enrollment | Age-based allocation review; contribution target reassessment; coordinate GoalID-2016-02 progress |
| Retirement Horizon Event | Alex or Sam Chen within 5 years of target retirement age (~60); or material change to retirement timeline | Full IPS review; bucket strategy validation; income distribution modeling; Social Security timing analysis |

6. FINANCIAL PLANNING GOALS — STATUS AND REAFFIRMATION

| Goal ID | Goal Description | 2024 Status |
| --- | --- | --- |
| GoalID-2016-01 | Retirement readiness (target ~age 60, $185K/yr after-tax) | On track — 2023 liquidity event materially improved projections; bucket strategy pre-planning initiated Q3 2024 |
| GoalID-2016-02 | Education funding (529 for Maya & Eli) | Maya: on track. Eli: on track. Contribution targets reviewed 2023-Q3; allocations remain age-based moderate |
| GoalID-2016-03 | Emergency liquidity (6–9 months expenses) | ACCT-CASH maintained at target; will transition into Bucket 1 structure under IPS-2025 (anticipated 2025-Q1) |
| GoalID-2023-01 | Values-based giving plan (DAF strategy) | Active. Annual grant cycle established; Q4 review incorporated into advisory calendar |

7. ANTICIPATED EVENTS AND NEXT ADVISORY ACTIONS

The following anticipated events are noted for planning continuity and will be addressed in future meeting agendas and, where applicable, through additional formal amendments:

DOC-IPSAmendment-2025-001 (anticipated): Bucket strategy IPS amendment expected Q1 2025 (effective 2025-03-01). Target allocation: 62% Equity / 33% Fixed / 5% Cash. Formal amendment document to be executed separately.

ACCT-529 Allocation Review (2025): Maya enters high school age range; age-based allocation to be reviewed in 2025 annual strategy meeting.

EventID-2026-01 (anticipated billing review): Billing display reconciliation per 2025-Q4 fee inquiry. Internal resolution process underway; public-facing resolution to be confirmed in 2026-Q1 client meeting.

EXECUTION PAGE

DOC-AgreementAmendment-2024-001 • Effective October 1, 2024 • Clearwater Wealth Partners / Chen Household (HH-CHEN-001)

IN WITNESS WHEREOF, the parties have executed this Amendment as of the effective date set forth above. This Amendment is incorporated into and forms part of the Investment Advisory Agreement (DOC-AdvisoryAgreement-2016-001) between Clearwater Wealth Partners and the Chen Household (HH-CHEN-001). All other terms and conditions of the original Agreement remain unchanged except as expressly modified herein.

| ______________________________________Signature — Primary ClientAlex ChenDate: October 1, 2024 | ______________________________________Signature — Co-ClientSam ChenDate: October 1, 2024 |
| --- | --- |
| ______________________________________Signature — Adviser RepresentativeMorgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date: October 1, 2024 |  |

SYNTHETIC DEMONSTRATION DOCUMENT — NWP-DEMO-HH-CHEN-001 v1.2 • NOT INVESTMENT, LEGAL, OR TAX ADVICE • Clearwater Wealth Partners • Wayzata, MN 55391
