CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2025Quarter 1, 2025 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2025 Portfolio | Q1 2025 Blend Bench. | Excess Return | YTD 2025 Portfolio | YTD 2025 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +0.29% | -2.21% | +2.50% | +0.29% | -2.21% |
| Benchmark Return | -2.21% | -4.73% | +2.46% | — | — |

▪ Beginning Value: $700,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $705,000

▪ Dividends & Interest: $4,328 ▪ Market Gain / (Loss): $-2,056 ▪ Advisory Fees: ($272)

MARKET COMMENTARY

Q1 2025 opened with increased volatility as markets recalibrated trade policy risk. The announcement of broad tariff measures in late Q1 triggered a sharp equity selloff, with the S&P 500 falling 4.6%. Bonds gained 2.5% as investors sought safety and the Fed signaled potential rate cuts if growth softened. The dollar weakened on trade uncertainty. Your portfolio's fixed income holdings provided meaningful protection, and the diversified structure helped limit overall portfolio decline relative to equity-only benchmarks.

| Benchmark | Q1 2025 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -4.73% | 65% | -3.07% |
| Bloomberg US Aggregate (Fixed Income) | +2.46% | 35% | +0.86% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $20,664 | $19,148 | $-1,516 | -7.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $59,667 | $59,594 | $-74 | -0.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $55,079 | $55,719 | +$640 | +1.2% |
| American Funds AMCAP | AMCPX | US Equity | $83,877 | $84,531 | +$655 | +0.8% |
| American Funds Growth | AGTHX | US Equity | $75,465 | $76,540 | +$1,075 | +1.4% |
| American Funds New World | ANCFX | Intl Equity | $46,663 | $47,481 | +$818 | +1.8% |
| American Funds Income | AMRMX | US Equity | $25,002 | $25,207 | +$204 | +0.8% |
| American Funds Investment | AIVSX | US Equity | $78,779 | $79,688 | +$909 | +1.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $36,472 | $37,073 | +$600 | +1.6% |
| American Funds Balanced | AMFFX | US Equity | $21,938 | $22,054 | +$115 | +0.5% |
| American Funds Bond | ABNDX | Fixed Income | $20,159 | $19,395 | $-765 | -3.8% |
| American High Income Trust | AHITX | Fixed Income | $16,336 | $15,757 | $-578 | -3.5% |
| American Funds New Econ. | ANEFX | US Equity | $20,919 | $21,327 | +$408 | +2.0% |
| iShares Core S&P 500 | IVV | US Equity | $105,038 | $106,815 | +$1,777 | +1.7% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,331 | $16,004 | $-326 | -2.0% |
| SPDR Gold Shares | GLD | Alternatives | $17,610 | $18,668 | +$1,058 | +6.0% |
| TOTAL PORTFOLIO |  |  | $700,000 | $705,000 | +$5,000 | +0.7% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $700,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,614.00 |
| Interest Income | $714.00 |
| Market Appreciation / (Depreciation) | $-2,056.00 |
| Advisory & Management Fees | ($272.00) |
| Net Change for Period | $5,000.00 |
| Ending Account Value | $705,000.00 |

Advisor Commentary: Portfolio performance of +0.29% was ahead of the blended benchmark (-2.21%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2024 | +1.09% | +2.51% |
| Q3 2024 | +1.07% | +5.48% |
| Q4 2024 | +5.59% | -2.60% |
| Q1 2025 | +0.29% | -2.21% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
