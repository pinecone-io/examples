CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2016Quarter 3, 2016 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2016 Portfolio | Q3 2016 Blend Bench. | Excess Return | YTD 2016 Portfolio | YTD 2016 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.74% | +2.75% | -0.01% | +3.12% | +4.88% |
| Benchmark Return | +2.75% | +3.53% | +0.93% | — | — |

▪ Beginning Value: $253,290 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $263,267

▪ Dividends & Interest: $1,556 ▪ Market Gain / (Loss): $5,612 ▪ Advisory Fees: ($191)

MARKET COMMENTARY

Q3 2016 saw continued momentum across global risk assets. U.S. equities advanced on strong corporate earnings and resilient consumer spending data. Emerging markets outperformed as the dollar weakened. Bond yields remained range-bound, supporting fixed income returns. The Fed signaled caution about rate hikes, keeping financial conditions accommodative. Portfolio performance was supported broadly across equity and fixed income holdings. Dividend income remained a consistent contributor to total returns.

| Benchmark | Q3 2016 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +3.53% | 70% | +2.47% |
| Bloomberg US Aggregate (Fixed Income) | +0.93% | 30% | +0.28% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,935 | $8,248 | +$313 | +3.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $21,795 | $22,654 | +$859 | +3.9% |
| MFS Mid Cap Growth | MFEKX | US Equity | $17,180 | $17,856 | +$677 | +3.9% |
| American Funds AMCAP | AMCPX | US Equity | $26,635 | $27,685 | +$1,049 | +3.9% |
| American Funds Growth | AGTHX | US Equity | $22,895 | $23,797 | +$902 | +3.9% |
| American Funds New World | ANCFX | Intl Equity | $14,980 | $15,570 | +$590 | +3.9% |
| American Funds Income | AMRMX | US Equity | $9,590 | $9,968 | +$378 | +3.9% |
| American Funds Investment | AIVSX | US Equity | $25,540 | $26,546 | +$1,006 | +3.9% |
| American Funds New Persp. | ANWPX | Intl Equity | $11,680 | $12,140 | +$460 | +3.9% |
| American Funds Balanced | AMFFX | US Equity | $8,595 | $8,934 | +$339 | +3.9% |
| American Funds Bond | ABNDX | Fixed Income | $16,300 | $16,942 | +$642 | +3.9% |
| American High Income Trust | AHITX | Fixed Income | $13,110 | $13,626 | +$516 | +3.9% |
| American Funds New Econ. | ANEFX | US Equity | $7,940 | $8,253 | +$313 | +3.9% |
| iShares Core S&P 500 | IVV | US Equity | $29,495 | $30,657 | +$1,162 | +3.9% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,880 | $14,426 | +$547 | +3.9% |
| SPDR Gold Shares | GLD | Alternatives | $5,740 | $5,966 | +$226 | +3.9% |
| TOTAL PORTFOLIO |  |  | $253,290 | $263,267 | +$9,977 | +3.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $253,290.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,401.00 |
| Interest Income | $155.00 |
| Market Appreciation / (Depreciation) | $5,612.00 |
| Advisory & Management Fees | ($191.00) |
| Net Change for Period | $9,977.00 |
| Ending Account Value | $263,267.00 |

Advisor Commentary: Portfolio performance of +2.74% was in line with the blended benchmark (+2.75%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2016 | -1.23% | -0.24% |
| Q2 2016 | +1.62% | +2.33% |
| Q3 2016 | +2.74% | +2.75% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
