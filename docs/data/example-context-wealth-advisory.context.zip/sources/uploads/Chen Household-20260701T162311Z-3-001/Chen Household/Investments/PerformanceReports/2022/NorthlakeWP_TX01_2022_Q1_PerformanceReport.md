CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2022Quarter 1, 2022 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2022 Portfolio | Q1 2022 Blend Bench. | Excess Return | YTD 2022 Portfolio | YTD 2022 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -3.60% | -5.25% | +1.66% | -3.60% | -5.25% |
| Benchmark Return | -5.25% | -4.78% | -5.96% | — | — |

▪ Beginning Value: $452,972 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $439,625

▪ Dividends & Interest: $2,298 ▪ Market Gain / (Loss): $-18,418 ▪ Advisory Fees: ($227)

MARKET COMMENTARY

2022 began with a dramatic shift in the investment environment as the Fed signaled aggressive tightening to combat inflation running at 40-year highs (CPI hit 8.5%). The S&P 500 fell 4.6%, while bonds fell even more sharply — the Bloomberg Agg declined 5.9%, its worst quarter since 1980. Russia's invasion of Ukraine in late February added a geopolitical dimension, sending energy prices surging. The classic 60/40 portfolio suffered as both stocks and bonds declined simultaneously. Your portfolio navigated these challenges with the benefit of diversification.

| Benchmark | Q1 2022 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -4.78% | 60% | -2.87% |
| Bloomberg US Aggregate (Fixed Income) | -5.96% | 40% | -2.38% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 16% | ████████  16% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,035 | $12,685 | +$4,651 | +57.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $40,325 | $37,229 | $-3,096 | -7.7% |
| MFS Mid Cap Growth | MFEKX | US Equity | $36,531 | $34,133 | $-2,397 | -6.6% |
| American Funds AMCAP | AMCPX | US Equity | $55,732 | $49,891 | $-5,841 | -10.5% |
| American Funds Growth | AGTHX | US Equity | $47,290 | $43,948 | $-3,342 | -7.1% |
| American Funds New World | ANCFX | Intl Equity | $28,929 | $27,151 | $-1,778 | -6.1% |
| American Funds Income | AMRMX | US Equity | $15,426 | $15,786 | +$361 | +2.3% |
| American Funds Investment | AIVSX | US Equity | $49,194 | $46,532 | $-2,662 | -5.4% |
| American Funds New Persp. | ANWPX | Intl Equity | $22,812 | $21,208 | $-1,605 | -7.0% |
| American Funds Balanced | AMFFX | US Equity | $14,370 | $14,231 | $-140 | -1.0% |
| American Funds Bond | ABNDX | Fixed Income | $17,532 | $18,370 | +$838 | +4.8% |
| American High Income Trust | AHITX | Fixed Income | $13,733 | $15,269 | +$1,536 | +11.2% |
| American Funds New Econ. | ANEFX | US Equity | $13,526 | $13,197 | $-329 | -2.4% |
| iShares Core S&P 500 | IVV | US Equity | $65,867 | $62,041 | $-3,825 | -5.8% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,004 | $15,786 | +$783 | +5.2% |
| SPDR Gold Shares | GLD | Alternatives | $8,668 | $12,168 | +$3,501 | +40.4% |
| TOTAL PORTFOLIO |  |  | $452,972 | $439,625 | $-13,347 | -2.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $452,972.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,114.00 |
| Interest Income | $184.00 |
| Market Appreciation / (Depreciation) | $-18,418.00 |
| Advisory & Management Fees | ($227.00) |
| Net Change for Period | $-13,347.00 |
| Ending Account Value | $439,625.00 |

Advisor Commentary: Portfolio performance of -3.60% was ahead of the blended benchmark (-5.25%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2021 | +4.75% | +3.92% |
| Q3 2021 | +2.60% | +0.18% |
| Q4 2021 | +5.51% | +5.62% |
| Q1 2022 | -3.60% | -5.25% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
