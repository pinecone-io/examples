CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2023Quarter 3, 2023 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2023 Portfolio | Q3 2023 Blend Bench. | Excess Return | YTD 2023 Portfolio | YTD 2023 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +5.70% | -3.24% | +8.94% | +6.27% | +6.91% |
| Benchmark Return | -3.24% | -3.27% | -3.20% | — | — |

▪ Beginning Value: $560,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $595,000

▪ Dividends & Interest: $3,526 ▪ Market Gain / (Loss): $28,722 ▪ Advisory Fees: ($248)

MARKET COMMENTARY

Q3 2023 saw markets pull back as the 'higher for longer' rate narrative took hold. The S&P 500 fell 3.3% and bonds declined 3.2% as the 10-year yield surged toward 5% — a level not seen since 2007. The Fed raised rates one final time in July, bringing the fed funds target to 5.25-5.50%. Energy stocks outperformed on rising oil prices. Your money market holdings continued generating attractive yields. The short-term decline followed an exceptional H1 and your portfolio's value remained substantially above year-ago levels.

| Benchmark | Q3 2023 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -3.27% | 60% | -1.96% |
| Bloomberg US Aggregate (Fixed Income) | -3.20% | 40% | -1.28% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $16,061 | $17,065 | +$1,004 | +6.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $47,163 | $50,111 | +$2,948 | +6.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $43,279 | $45,984 | +$2,705 | +6.2% |
| American Funds AMCAP | AMCPX | US Equity | $66,609 | $70,772 | +$4,163 | +6.2% |
| American Funds Growth | AGTHX | US Equity | $58,828 | $62,505 | +$3,677 | +6.2% |
| American Funds New World | ANCFX | Intl Equity | $36,227 | $38,491 | +$2,264 | +6.2% |
| American Funds Income | AMRMX | US Equity | $20,193 | $21,455 | +$1,262 | +6.2% |
| American Funds Investment | AIVSX | US Equity | $62,235 | $66,125 | +$3,890 | +6.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $28,693 | $30,487 | +$1,793 | +6.2% |
| American Funds Balanced | AMFFX | US Equity | $18,005 | $19,131 | +$1,125 | +6.2% |
| American Funds Bond | ABNDX | Fixed Income | $18,491 | $19,647 | +$1,156 | +6.2% |
| American High Income Trust | AHITX | Fixed Income | $15,089 | $16,032 | +$943 | +6.2% |
| American Funds New Econ. | ANEFX | US Equity | $16,785 | $17,834 | +$1,049 | +6.2% |
| iShares Core S&P 500 | IVV | US Equity | $83,378 | $88,589 | +$5,211 | +6.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,332 | $16,290 | +$958 | +6.2% |
| SPDR Gold Shares | GLD | Alternatives | $13,631 | $14,483 | +$852 | +6.2% |
| TOTAL PORTFOLIO |  |  | $560,000 | $595,000 | +$35,000 | +6.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $560,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,914.00 |
| Interest Income | $612.00 |
| Market Appreciation / (Depreciation) | $28,722.00 |
| Advisory & Management Fees | ($248.00) |
| Net Change for Period | $35,000.00 |
| Ending Account Value | $595,000.00 |

Advisor Commentary: Portfolio performance of +5.70% was ahead of the blended benchmark (-3.24%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2022 | +2.94% | +5.13% |
| Q1 2023 | +5.15% | +5.40% |
| Q2 2023 | -4.39% | +4.83% |
| Q3 2023 | +5.70% | -3.24% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
