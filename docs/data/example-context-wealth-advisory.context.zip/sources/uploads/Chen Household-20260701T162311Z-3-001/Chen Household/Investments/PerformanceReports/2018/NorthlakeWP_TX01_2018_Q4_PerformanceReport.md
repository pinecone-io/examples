CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2018Quarter 4, 2018 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2018 Portfolio | Q4 2018 Blend Bench. | Excess Return | YTD 2018 Portfolio | YTD 2018 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -6.43% | -9.08% | +2.65% | -2.46% | -2.70% |
| Benchmark Return | -9.08% | -13.69% | +1.69% | — | — |

▪ Beginning Value: $346,986 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $327,579

▪ Dividends & Interest: $2,222 ▪ Market Gain / (Loss): $-24,418 ▪ Advisory Fees: ($211)

MARKET COMMENTARY

Q4 2018 delivered the worst quarter for U.S. equities since the 2008 financial crisis. The S&P 500 fell 13.5% amid fears of slowing global growth, Fed policy error concerns, and trade war uncertainty. December alone was the worst December since 1931. The Fed hiked rates in December despite market pressure. Investment-grade bonds served as a partial safe haven, gaining 1.6% for the quarter. Your portfolio's equity holdings bore the brunt of the selloff, while fixed income provided meaningful protection relative to an all-equity portfolio.

| Benchmark | Q4 2018 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -13.69% | 70% | -9.58% |
| Bloomberg US Aggregate (Fixed Income) | +1.69% | 30% | +0.51% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $12,826 | $12,108 | $-717 | -5.6% |
| American Funds EuroPacific | SEEGX | Intl Equity | $30,293 | $28,599 | $-1,694 | -5.6% |
| MFS Mid Cap Growth | MFEKX | US Equity | $23,890 | $22,554 | $-1,336 | -5.6% |
| American Funds AMCAP | AMCPX | US Equity | $36,108 | $34,088 | $-2,020 | -5.6% |
| American Funds Growth | AGTHX | US Equity | $32,330 | $30,522 | $-1,808 | -5.6% |
| American Funds New World | ANCFX | Intl Equity | $20,101 | $18,977 | $-1,124 | -5.6% |
| American Funds Income | AMRMX | US Equity | $11,952 | $11,284 | $-669 | -5.6% |
| American Funds Investment | AIVSX | US Equity | $34,944 | $32,989 | $-1,954 | -5.6% |
| American Funds New Persp. | ANWPX | Intl Equity | $16,027 | $15,130 | $-896 | -5.6% |
| American Funds Balanced | AMFFX | US Equity | $11,079 | $10,460 | $-620 | -5.6% |
| American Funds Bond | ABNDX | Fixed Income | $21,708 | $20,494 | $-1,214 | -5.6% |
| American High Income Trust | AHITX | Fixed Income | $17,633 | $16,647 | $-986 | -5.6% |
| American Funds New Econ. | ANEFX | US Equity | $10,497 | $9,910 | $-587 | -5.6% |
| iShares Core S&P 500 | IVV | US Equity | $41,643 | $39,314 | $-2,329 | -5.6% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $18,652 | $17,609 | $-1,043 | -5.6% |
| SPDR Gold Shares | GLD | Alternatives | $7,302 | $6,893 | $-408 | -5.6% |
| TOTAL PORTFOLIO |  |  | $346,986 | $327,579 | $-19,407 | -5.6% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $346,986.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,924.00 |
| Interest Income | $298.00 |
| Market Appreciation / (Depreciation) | $-24,418.00 |
| Advisory & Management Fees | ($211.00) |
| Net Change for Period | $-19,407.00 |
| Ending Account Value | $327,579.00 |

Advisor Commentary: Portfolio performance of -6.43% was ahead of the blended benchmark (-9.08%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2018 | -0.25% | -0.08% |
| Q2 2018 | +1.52% | +2.01% |
| Q3 2018 | +2.95% | +4.99% |
| Q4 2018 | -6.43% | -9.08% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
