CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2026Quarter 1, 2026 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2026 Portfolio | Q1 2026 Blend Bench. | Excess Return | YTD 2026 Portfolio | YTD 2026 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.58% | +2.42% | -0.84% | +1.58% | +2.42% |
| Benchmark Return | +2.42% | +3.12% | +1.12% | — | — |

▪ Beginning Value: $760,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $775,000

▪ Dividends & Interest: $4,668 ▪ Market Gain / (Loss): $7,617 ▪ Advisory Fees: ($285)

MARKET COMMENTARY

Q1 2026 opened constructively, with the S&P 500 gaining 3.1% and bonds gaining 1.1%. Economic growth remained positive with moderate inflation. The Fed maintained its current policy rate. Technology sector earnings remained strong, and AI infrastructure investment continued at a high pace. Geopolitical uncertainties remained a background risk. Your portfolio's equity and fixed income blend contributed to a positive start to the year, continuing the long track record of steady wealth accumulation.

| Benchmark | Q1 2026 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +3.12% | 65% | +2.03% |
| Bloomberg US Aggregate (Fixed Income) | +1.12% | 35% | +0.39% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $20,642 | $19,014 | $-1,627 | -7.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $64,243 | $65,494 | +$1,252 | +1.9% |
| MFS Mid Cap Growth | MFEKX | US Equity | $60,066 | $61,496 | +$1,430 | +2.4% |
| American Funds AMCAP | AMCPX | US Equity | $91,126 | $93,477 | +$2,351 | +2.6% |
| American Funds Growth | AGTHX | US Equity | $82,511 | $84,731 | +$2,220 | +2.7% |
| American Funds New World | ANCFX | Intl Equity | $51,185 | $52,495 | +$1,310 | +2.6% |
| American Funds Income | AMRMX | US Equity | $27,173 | $27,511 | +$338 | +1.2% |
| American Funds Investment | AIVSX | US Equity | $85,905 | $87,735 | +$1,830 | +2.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $39,965 | $41,005 | +$1,040 | +2.6% |
| American Funds Balanced | AMFFX | US Equity | $23,774 | $24,507 | +$733 | +3.1% |
| American Funds Bond | ABNDX | Fixed Income | $20,908 | $20,514 | $-394 | -1.9% |
| American High Income Trust | AHITX | Fixed Income | $16,987 | $16,765 | $-222 | -1.3% |
| American Funds New Econ. | ANEFX | US Equity | $22,991 | $23,507 | +$516 | +2.2% |
| iShares Core S&P 500 | IVV | US Equity | $115,148 | $118,971 | +$3,823 | +3.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,253 | $17,015 | $-238 | -1.4% |
| SPDR Gold Shares | GLD | Alternatives | $20,125 | $20,764 | +$639 | +3.2% |
| TOTAL PORTFOLIO |  |  | $760,000 | $775,000 | +$15,000 | +2.0% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $760,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $4,014.00 |
| Interest Income | $654.00 |
| Market Appreciation / (Depreciation) | $7,617.00 |
| Advisory & Management Fees | ($285.00) |
| Net Change for Period | $15,000.00 |
| Ending Account Value | $775,000.00 |

Advisor Commentary: Portfolio performance of +1.58% was behind the blended benchmark (+2.42%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2025 | +1.70% | +3.23% |
| Q3 2025 | +1.66% | +4.60% |
| Q4 2025 | +2.99% | +1.98% |
| Q1 2026 | +1.58% | +2.42% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
