CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2020Quarter 4, 2020 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2020 Portfolio | Q4 2020 Blend Bench. | Excess Return | YTD 2020 Portfolio | YTD 2020 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +6.31% | +7.08% | -0.77% | +8.87% | +12.92% |
| Benchmark Return | +7.08% | +12.14% | -0.51% | — | — |

▪ Beginning Value: $419,696 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $449,283

▪ Dividends & Interest: $2,194 ▪ Market Gain / (Loss): $24,618 ▪ Advisory Fees: ($225)

MARKET COMMENTARY

Q4 2020 capped an extraordinary year. After a volatile October, markets surged as Pfizer and Moderna announced highly effective COVID vaccines. The S&P 500 gained 12.2% in Q4 and ended the year up 18.4% — a remarkable result given the global pandemic. Small-cap value stocks and economically sensitive sectors led the rotation. The CARES Act was followed by an additional $900B stimulus. Bonds underperformed as yields rose. Your portfolio's equity holdings drove strong Q4 performance, closing 2020 well ahead of where it began the year.

| Benchmark | Q4 2020 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +12.14% | 60% | +7.28% |
| Bloomberg US Aggregate (Fixed Income) | -0.51% | 40% | -0.20% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $9,321 | $9,978 | +$657 | +7.0% |
| American Funds EuroPacific | SEEGX | Intl Equity | $37,236 | $39,861 | +$2,625 | +7.0% |
| MFS Mid Cap Growth | MFEKX | US Equity | $32,470 | $34,759 | +$2,289 | +7.0% |
| American Funds AMCAP | AMCPX | US Equity | $47,454 | $50,799 | +$3,345 | +7.0% |
| American Funds Growth | AGTHX | US Equity | $43,137 | $46,178 | +$3,041 | +7.0% |
| American Funds New World | ANCFX | Intl Equity | $25,889 | $27,714 | +$1,825 | +7.0% |
| American Funds Income | AMRMX | US Equity | $14,318 | $15,328 | +$1,009 | +7.0% |
| American Funds Investment | AIVSX | US Equity | $44,045 | $47,150 | +$3,105 | +7.0% |
| American Funds New Persp. | ANWPX | Intl Equity | $21,123 | $22,612 | +$1,489 | +7.0% |
| American Funds Balanced | AMFFX | US Equity | $13,406 | $14,351 | +$945 | +7.0% |
| American Funds Bond | ABNDX | Fixed Income | $20,219 | $21,645 | +$1,425 | +7.0% |
| American High Income Trust | AHITX | Fixed Income | $15,453 | $16,543 | +$1,089 | +7.0% |
| American Funds New Econ. | ANEFX | US Equity | $12,730 | $13,627 | +$897 | +7.0% |
| iShares Core S&P 500 | IVV | US Equity | $55,851 | $59,788 | +$3,937 | +7.0% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,037 | $18,238 | +$1,201 | +7.0% |
| SPDR Gold Shares | GLD | Alternatives | $10,006 | $10,712 | +$705 | +7.0% |
| TOTAL PORTFOLIO |  |  | $419,696 | $449,283 | +$29,587 | +7.0% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $419,696.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,118.00 |
| Interest Income | $76.00 |
| Market Appreciation / (Depreciation) | $24,618.00 |
| Advisory & Management Fees | ($225.00) |
| Net Change for Period | $29,587.00 |
| Ending Account Value | $449,283.00 |

Advisor Commentary: Portfolio performance of +6.31% was behind the blended benchmark (+7.08%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2020 | -14.82% | -10.56% |
| Q2 2020 | +13.42% | +12.29% |
| Q3 2020 | +6.01% | +5.00% |
| Q4 2020 | +6.31% | +7.08% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
