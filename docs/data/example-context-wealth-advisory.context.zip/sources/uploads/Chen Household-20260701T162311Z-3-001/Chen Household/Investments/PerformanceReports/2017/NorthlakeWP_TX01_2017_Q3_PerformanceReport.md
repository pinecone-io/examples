CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2017Quarter 3, 2017 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2017 Portfolio | Q3 2017 Blend Bench. | Excess Return | YTD 2017 Portfolio | YTD 2017 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.16% | +3.05% | +0.10% | +9.94% | +10.48% |
| Benchmark Return | +3.05% | +4.00% | +0.85% | — | — |

▪ Beginning Value: $298,251 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $310,720

▪ Dividends & Interest: $1,825 ▪ Market Gain / (Loss): $7,842 ▪ Advisory Fees: ($198)

MARKET COMMENTARY

Q3 2017 delivered strong returns across nearly all asset classes. U.S. equities gained 4.5%, international stocks rose sharply, and bonds held steady. The synchronized global expansion narrative gained momentum, and corporate earnings remained robust. Volatility, as measured by the VIX, touched multi-decade lows. Hurricanes Harvey and Irma created short-term disruptions but did not materially derail the economic outlook. The Fed announced the beginning of balance sheet normalization. Your equity-heavy positioning continued to reward returns.

| Benchmark | Q3 2017 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +4.00% | 70% | +2.80% |
| Bloomberg US Aggregate (Fixed Income) | +0.85% | 30% | +0.26% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 27% | █████████████  27% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,877 | $9,248 | +$371 | +4.2% |
| American Funds EuroPacific | SEEGX | Intl Equity | $25,905 | $26,988 | +$1,083 | +4.2% |
| MFS Mid Cap Growth | MFEKX | US Equity | $20,687 | $21,551 | +$865 | +4.2% |
| American Funds AMCAP | AMCPX | US Equity | $32,491 | $33,850 | +$1,358 | +4.2% |
| American Funds Growth | AGTHX | US Equity | $28,176 | $29,354 | +$1,178 | +4.2% |
| American Funds New World | ANCFX | Intl Equity | $17,734 | $18,476 | +$741 | +4.2% |
| American Funds Income | AMRMX | US Equity | $10,921 | $11,378 | +$457 | +4.2% |
| American Funds Investment | AIVSX | US Equity | $30,447 | $31,720 | +$1,273 | +4.2% |
| American Funds New Persp. | ANWPX | Intl Equity | $14,550 | $15,159 | +$608 | +4.2% |
| American Funds Balanced | AMFFX | US Equity | $9,786 | $10,195 | +$409 | +4.2% |
| American Funds Bond | ABNDX | Fixed Income | $17,507 | $18,239 | +$732 | +4.2% |
| American High Income Trust | AHITX | Fixed Income | $14,101 | $14,690 | +$590 | +4.2% |
| American Funds New Econ. | ANEFX | US Equity | $9,327 | $9,717 | +$390 | +4.2% |
| iShares Core S&P 500 | IVV | US Equity | $36,811 | $38,350 | +$1,539 | +4.2% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,777 | $15,395 | +$618 | +4.2% |
| SPDR Gold Shares | GLD | Alternatives | $6,152 | $6,409 | +$257 | +4.2% |
| TOTAL PORTFOLIO |  |  | $298,251 | $310,720 | +$12,469 | +4.2% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $298,251.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,621.00 |
| Interest Income | $204.00 |
| Market Appreciation / (Depreciation) | $7,842.00 |
| Advisory & Management Fees | ($198.00) |
| Net Change for Period | $12,469.00 |
| Ending Account Value | $310,720.00 |

Advisor Commentary: Portfolio performance of +3.16% was in line with the blended benchmark (+3.05%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2016 | +2.94% | +1.68% |
| Q1 2017 | +3.52% | +4.49% |
| Q2 2017 | +2.95% | +2.60% |
| Q3 2017 | +3.16% | +3.05% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
