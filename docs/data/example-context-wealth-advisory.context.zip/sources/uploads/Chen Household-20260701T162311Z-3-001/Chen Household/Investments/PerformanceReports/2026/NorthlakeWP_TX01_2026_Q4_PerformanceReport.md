CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2026Quarter 4, 2026 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2026 Portfolio | Q4 2026 Blend Bench. | Excess Return | YTD 2026 Portfolio | YTD 2026 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.29% | +4.51% | -1.22% | +10.17% | +15.30% |
| Benchmark Return | +4.51% | +6.14% | +1.48% | — | — |

▪ Beginning Value: $820,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $850,000

▪ Dividends & Interest: $4,930 ▪ Market Gain / (Loss): $22,366 ▪ Advisory Fees: ($296)

MARKET COMMENTARY

Q4 2026 brought another strong quarter, capping a decade of disciplined investing. The S&P 500 gained 6.1% and bonds gained 1.5%. The portfolio has grown substantially since inception in Q1 2016, reflecting the power of consistent contributions, reinvested income, disciplined rebalancing, and patient long-term equity exposure. The blended return over the full ten-year period reflects a portfolio that weathered COVID (2020), historic bond losses (2022), and multiple periods of significant market volatility — while delivering meaningful wealth accumulation for the Chen Household.

| Benchmark | Q4 2026 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +6.14% | 65% | +3.99% |
| Bloomberg US Aggregate (Fixed Income) | +1.48% | 35% | +0.52% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $20,118 | $20,854 | +$736 | +3.7% |
| American Funds EuroPacific | SEEGX | Intl Equity | $69,297 | $71,832 | +$2,535 | +3.7% |
| MFS Mid Cap Growth | MFEKX | US Equity | $65,067 | $67,447 | +$2,380 | +3.7% |
| American Funds AMCAP | AMCPX | US Equity | $98,905 | $102,523 | +$3,618 | +3.7% |
| American Funds Growth | AGTHX | US Equity | $89,651 | $92,931 | +$3,280 | +3.7% |
| American Funds New World | ANCFX | Intl Equity | $55,543 | $57,575 | +$2,032 | +3.7% |
| American Funds Income | AMRMX | US Equity | $29,108 | $30,173 | +$1,065 | +3.7% |
| American Funds Investment | AIVSX | US Equity | $92,829 | $96,225 | +$3,396 | +3.7% |
| American Funds New Persp. | ANWPX | Intl Equity | $43,386 | $44,973 | +$1,587 | +3.7% |
| American Funds Balanced | AMFFX | US Equity | $25,930 | $26,879 | +$949 | +3.7% |
| American Funds Bond | ABNDX | Fixed Income | $21,705 | $22,499 | +$794 | +3.7% |
| American High Income Trust | AHITX | Fixed Income | $17,739 | $18,388 | +$649 | +3.7% |
| American Funds New Econ. | ANEFX | US Equity | $24,872 | $25,782 | +$910 | +3.7% |
| iShares Core S&P 500 | IVV | US Equity | $125,879 | $130,484 | +$4,605 | +3.7% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $18,003 | $18,662 | +$659 | +3.7% |
| SPDR Gold Shares | GLD | Alternatives | $21,969 | $22,773 | +$804 | +3.7% |
| TOTAL PORTFOLIO |  |  | $820,000 | $850,000 | +$30,000 | +3.7% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $820,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $4,318.00 |
| Interest Income | $612.00 |
| Market Appreciation / (Depreciation) | $22,366.00 |
| Advisory & Management Fees | ($296.00) |
| Net Change for Period | $30,000.00 |
| Ending Account Value | $850,000.00 |

Advisor Commentary: Ten-year investment anniversary. The portfolio has grown from approximately $246,000 at inception to over $865,000, reflecting nearly 3.5x growth over the decade despite multiple significant market disruptions.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2026 | +1.58% | +2.42% |
| Q2 2026 | +2.19% | +3.52% |
| Q3 2026 | +2.76% | +4.06% |
| Q4 2026 | +3.29% | +4.51% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
