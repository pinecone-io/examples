CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2022Quarter 3, 2022 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2022 Portfolio | Q3 2022 Blend Bench. | Excess Return | YTD 2022 Portfolio | YTD 2022 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -5.17% | -5.00% | -0.17% | -19.49% | -20.54% |
| Benchmark Return | -5.00% | -5.12% | -4.82% | — | — |

▪ Beginning Value: $389,988 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $372,734

▪ Dividends & Interest: $2,398 ▪ Market Gain / (Loss): $-22,418 ▪ Advisory Fees: ($234)

MARKET COMMENTARY

Markets initially rallied in July on hopes of a Fed 'pivot,' but Chair Powell's hawkish Jackson Hole speech in late August reversed those gains. The S&P 500 fell 5.3% for the quarter. Bonds continued their historic decline, with the Bloomberg Agg falling another 4.7% as the 10-year yield reached 4.0%. The Fed hiked an additional 150 bps. Energy stocks were the lone bright spot in equities. Your money market holdings benefited from rising short-term rates, providing an increasingly attractive source of yield within the portfolio.

| Benchmark | Q3 2022 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -5.12% | 60% | -3.07% |
| Bloomberg US Aggregate (Fixed Income) | -4.82% | 40% | -1.93% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 16% | ████████  16% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $11,253 | $10,755 | $-498 | -4.4% |
| American Funds EuroPacific | SEEGX | Intl Equity | $33,025 | $31,564 | $-1,461 | -4.4% |
| MFS Mid Cap Growth | MFEKX | US Equity | $30,279 | $28,940 | $-1,340 | -4.4% |
| American Funds AMCAP | AMCPX | US Equity | $44,258 | $42,300 | $-1,958 | -4.4% |
| American Funds Growth | AGTHX | US Equity | $38,986 | $37,261 | $-1,725 | -4.4% |
| American Funds New World | ANCFX | Intl Equity | $24,085 | $23,020 | $-1,066 | -4.4% |
| American Funds Income | AMRMX | US Equity | $14,004 | $13,384 | $-620 | -4.4% |
| American Funds Investment | AIVSX | US Equity | $41,278 | $39,452 | $-1,826 | -4.4% |
| American Funds New Persp. | ANWPX | Intl Equity | $18,813 | $17,981 | $-832 | -4.4% |
| American Funds Balanced | AMFFX | US Equity | $12,624 | $12,065 | $-559 | -4.4% |
| American Funds Bond | ABNDX | Fixed Income | $16,296 | $15,575 | $-721 | -4.4% |
| American High Income Trust | AHITX | Fixed Income | $13,545 | $12,946 | $-599 | -4.4% |
| American Funds New Econ. | ANEFX | US Equity | $11,707 | $11,189 | $-518 | -4.4% |
| iShares Core S&P 500 | IVV | US Equity | $55,036 | $52,601 | $-2,435 | -4.4% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,004 | $13,384 | $-620 | -4.4% |
| SPDR Gold Shares | GLD | Alternatives | $10,795 | $10,317 | $-478 | -4.4% |
| TOTAL PORTFOLIO |  |  | $389,988 | $372,734 | $-17,254 | -4.4% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $389,988.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,014.00 |
| Interest Income | $384.00 |
| Market Appreciation / (Depreciation) | $-22,418.00 |
| Advisory & Management Fees | ($234.00) |
| Net Change for Period | $-17,254.00 |
| Ending Account Value | $372,734.00 |

Advisor Commentary: Portfolio performance of -5.17% was in line with the blended benchmark (-5.00%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2021 | +5.51% | +5.62% |
| Q1 2022 | -3.60% | -5.25% |
| Q2 2022 | -11.93% | -11.73% |
| Q3 2022 | -5.17% | -5.00% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
