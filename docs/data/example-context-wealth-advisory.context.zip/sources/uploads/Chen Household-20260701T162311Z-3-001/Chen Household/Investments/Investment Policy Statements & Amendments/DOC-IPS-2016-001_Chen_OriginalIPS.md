CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

INVESTMENT POLICY STATEMENT

Chen Household | Clearwater Wealth Partners | Original — Version 1.0

| Document ID DOC-IPS-2016-001 | Effective Date February 1, 2016 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

1. PURPOSE AND SCOPE

This Investment Policy Statement ("IPS") establishes the investment objectives, guidelines, constraints, and governance framework for the Chen Household (HH-CHEN-001) investment portfolio managed by Clearwater Wealth Partners under the Investment Advisory Agreement dated February 1, 2016 (DOC-AdvisoryAgreement-2016-001). This IPS governs the investment management of all Covered Accounts held at Fidelity Institutional (CUST-FI-001) and shall remain in effect until superseded by a signed amendment. It is intended to be a living document, reviewed at least annually and updated upon any material change in Client’s financial circumstances, goals, or risk tolerance.

2. PARTIES AND ACCOUNTS

| Clients: | Alex Chen (DOB 1983-05-14)  &  Sam Chen (DOB 1984-11-02) |
| --- | --- |

| Household ID: | HH-CHEN-001  |  Filing Status: Married Filing Jointly |
| --- | --- |

| Adviser: | Morgan Park, CFP®  (ADV-PARK-001)  |  Clearwater Wealth Partners |
| --- | --- |

| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| --- | --- |

| Covered Accounts: | ACCT-TX01 (Joint Taxable)  |  ACCT-IRA1 (Alex Trad. IRA)  |  ACCT-RIRA (Alex Roth IRA) |
| --- | --- |

| Opening AUM: | ~$410,000  (household aggregate, February 2016 inception) |
| --- | --- |

| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001  |  Fee: 1.00% flat annual |
| --- | --- |

3. RISK PROFILE AND INVESTMENT OBJECTIVES

Client’s risk tolerance was assessed via DOC-RiskQuestionnaire-2016-001 (completed February 10, 2016), yielding a composite score of 68 out of 100, categorized as “Moderate Growth.” Client acknowledges the potential for portfolio losses in adverse market environments and affirms a willingness to accept short-term volatility in pursuit of long-term capital appreciation consistent with retirement and education funding goals.

| Risk Dimension | Description | Chen Household Assessment |
| --- | --- | --- |
| Risk Tolerance | Willingness to accept loss in pursuit of return | Moderate Growth |
| Risk Capacity | Financial ability to absorb losses without hardship | Moderate-High (dual income, long horizon) |
| Time Horizon | Investment horizon before significant withdrawals needed | 20+ years (target retire ~age 60) |
| Liquidity Need | Cash required on short notice | Low-Moderate (GoalID-2016-03 buffer) |
| Max Drawdown Tol. | Max acceptable 12-month portfolio decline | ~20–25%  (per risk questionnaire) |
| Income Need | Reliance on portfolio for current income | None (fully employed, W-2 income) |

4. FINANCIAL PLANNING GOALS

| Goal ID | Goal Name | Description / Target | Priority |
| --- | --- | --- | --- |
| GoalID-2016-01 | Retirement Readiness | Retire ~age 60; $185,000/yr after-tax income (today’s dollars); funded ratio + confidence level tracked annually | Primary |
| GoalID-2016-02 | Education Funding (529s) | Fund meaningful share of college for Maya (DOB 2011) and Eli (DOB 2014); 529 accounts to be opened | Important |
| GoalID-2016-03 | Emergency Liquidity | 6–9 months household expenses (~$60,000–$90,000) in accessible, low-volatility instruments | Essential |

5. TARGET ASSET ALLOCATION POLICY

The following target allocations reflect the outcome of the risk assessment, goals review, and investment horizon analysis conducted at the time of engagement. Allocations are applied on an aggregate household basis across all Covered Accounts. Drift bands define the range within which each asset class may vary before rebalancing is required.

| Asset Class / Sub-Class | Target Weight | Drift Band (Min–Max) | Fund / Instrument |
| --- | --- | --- | --- |
| Equities (Total) | 70.0% | 65.0% – 75.0% | Domestic + International + EM |
| U.S. Large Cap Core | 42.0% | 37–47% | UECIX |
| U.S. Small Cap | 8.0% | 5–11% | USCIX |
| Intl Developed | 12.0% | 8–16% | IDEIX |
| Emerging Markets | 8.0% | 5–11% | EMEIX |
| Fixed Income (Total) | 28.0% | 23.0% – 33.0% | Investment Grade + TIPS + Munis |
| U.S. Core Bond | 14.0% | 10–18% | UCBIX |
| TIPS / Treasury | 8.0% | 5–11% | UTIPX |
| Municipal Bond | 6.0% | 3–9% | MUNIX |
| Cash & Equivalents | 2.0% | 0.0% – 4.0% | STBIX / Money Market |
| TOTAL | 100% | — | — |

Drift Band Rule: If any major asset class (Equity or Fixed Income) drifts beyond ±5% of target, Adviser will present a rebalancing proposal within 15 business days. Sub-class and Cash drift beyond ±2% triggers a review; rebalancing discretionary based on tax efficiency and transaction costs.

6. TAX-AWARE ACCOUNT PLACEMENT

Assets shall be placed across accounts to maximize after-tax returns, consistent with the overall allocation policy. Tax-inefficient assets (interest-generating bonds, TIPS, and short-term income) are held in tax-deferred/tax-free accounts; tax-efficient assets (equity index funds, munis) are held in the taxable account.

| Account | Account Type | Preferred Holdings |
| --- | --- | --- |
| ACCT-TX01 | Joint Taxable Brokerage | UECIX, USCIX, IDEIX, EMEIX (equity index — tax-efficient); MUNIX (muni — tax-exempt); STBIX (cash sleeve); NLTK single-stock concentration managed here |
| ACCT-IRA1 | Alex Traditional IRA | UCBIX (core bonds — interest taxed as ordinary income, deferred); UTIPX (TIPS — inflation adj. taxable, deferred); equity sleeve for rebalancing |
| ACCT-RIRA | Alex Roth IRA | USCIX (small cap), EMEIX (emerging markets) — highest growth potential in tax-free vehicle; long holding period maximizes Roth benefit |

7. INVESTMENT CONSTRAINTS AND RESTRICTIONS

| Constraint | Policy |
| --- | --- |
| Single-Stock Concentration | Maximum 10% of total household AUM in any single equity issuer  (NLTK exposure monitored quarterly) |
| Leverage / Margin | Prohibited in all Covered Accounts unless separately authorized in writing |
| Options / Derivatives | Prohibited without prior written consent of Client |
| Alternative Investments | Private equity, hedge funds, and illiquid alts prohibited without prior written amendment to this IPS |
| Prohibited Securities | No securities of any employer of Client (other than NLTK per equity comp plan) without Adviser approval |
| ESG / Values Screens | No restrictions at inception; Client may request screens via written amendment |
| Minimum Cash Balance | ACCT-TX01 to maintain minimum 1% cash/money market at all times for liquidity and rebalancing |

8. PERFORMANCE BENCHMARKS

| Portfolio Segment | Benchmark | Notes |
| --- | --- | --- |
| Total Portfolio | 70% MSCI ACWI / 28% Bloomberg US Agg / 2% 90-day T-Bill | Aggregate household benchmark |
| Equity Sleeve | MSCI ACWI (blended per sub-class weights) | US Large, Small, Intl, EM |
| Fixed Income Sleeve | Bloomberg US Aggregate Bond Index | Core bonds, TIPS |
| Municipal Bond | Bloomberg 1-15Y Muni Blend Index | MUNIX benchmark |
| Cash | SOFR / 90-Day T-Bill Rate | STBIX / sweep |

9. MONITORING, REPORTING, AND REBALANCING

| Portfolio Review: | Quarterly performance report  (DOC type: PerformanceReport)  |  Annual comprehensive strategy review |
| --- | --- |

| Drift Monitoring: | Quarterly; automatic rebalancing proposal if drift exceeds thresholds in Section 5 |
| --- | --- |

| Rebalancing Method: | Tax-aware: use new contributions first; harvest losses in ACCT-TX01 before selling appreciated positions |
| --- | --- |

| TLH Monitoring: | ACCT-TX01 monitored for tax-loss harvesting opportunities; documented under DecisionIDs |
| --- | --- |

| Reporting Frequency: | Quarterly account statements from custodian  +  quarterly performance reports from Adviser |
| --- | --- |

| Annual IPS Review: | At minimum one full IPS review per year, or earlier if event-driven trigger (Section 10) is activated |
| --- | --- |

| Documentation: | All trades documented in DecisionID / TradeProposal / Confirmation chain per MD Section 11 |
| --- | --- |

10. EVENT-DRIVEN REVIEW TRIGGERS

Consistent with Section 6 of DOC-AdvisoryAgreement-2016-001, the following events shall trigger an expedited IPS review prior to the next scheduled annual review:

| Trigger | Required Action |
| --- | --- |
| Equity Comp Event | EventID-2018-01 anticipated — RSU grant or vesting; concentration analysis and potential IPS allocation update |
| Major Life Event | Marriage, divorce, birth, disability, or death; may require immediate IPS amendment |
| Market Drawdown | Portfolio decline of 15%+ over 60 calendar days; risk tolerance re-survey required |
| AUM Milestone | Household AUM crosses $1,000,000 or falls below $300,000 — allocation strategy review |
| Income Change | Household W-2 income changes by more than 20% — goals and contribution rate review |
| Real Estate | Home purchase or sale — liquidity review and net worth update |
| Trust/Estate Change | Formation of trust or estate plan change — account titling and beneficiary coordination |

11. SIGNATURES AND ACKNOWLEDGEMENTS

By signing below, the parties confirm they have reviewed and agreed to this Investment Policy Statement. Client acknowledges that the IPS represents their current investment objectives and that they will notify Adviser promptly of any material changes in circumstances. Adviser acknowledges responsibility to manage the Covered Accounts consistent with this IPS until it is superseded.

| ____________________________________Primary ClientAlex ChenDate:  February 1, 2016 | ____________________________________Co-ClientSam ChenDate:  February 1, 2016 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  February 1, 2016 |
| --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-IPS-2016-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
