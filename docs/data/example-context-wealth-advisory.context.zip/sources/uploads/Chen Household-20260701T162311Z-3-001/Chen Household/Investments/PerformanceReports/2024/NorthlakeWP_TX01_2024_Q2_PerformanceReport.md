CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2024Quarter 2, 2024 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2024 Portfolio | Q2 2024 Blend Bench. | Excess Return | YTD 2024 Portfolio | YTD 2024 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.09% | +2.51% | -1.42% | +3.86% | +9.29% |
| Benchmark Return | +2.51% | +4.26% | -0.73% | — | — |

▪ Beginning Value: $640,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $650,000

▪ Dividends & Interest: $4,046 ▪ Market Gain / (Loss): $3,215 ▪ Advisory Fees: ($261)

MARKET COMMENTARY

Q2 2024 saw more moderate equity gains (+4.3%) as markets digested the higher-for-longer rate environment. Technology and communication services led; utilities and real estate lagged. Bonds declined modestly as yields remained elevated. The Fed held steady but continued to signal eventual rate cuts. Economic data remained resilient — GDP growth was positive and unemployment stayed low. Your portfolio's steady income generation and equity appreciation continued to compound your long-term wealth.

| Benchmark | Q2 2024 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +4.26% | 65% | +2.77% |
| Bloomberg US Aggregate (Fixed Income) | -0.73% | 35% | -0.26% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $18,893 | $19,188 | +$295 | +1.6% |
| American Funds EuroPacific | SEEGX | Intl Equity | $54,553 | $55,405 | +$852 | +1.6% |
| MFS Mid Cap Growth | MFEKX | US Equity | $50,358 | $51,145 | +$787 | +1.6% |
| American Funds AMCAP | AMCPX | US Equity | $76,687 | $77,886 | +$1,198 | +1.6% |
| American Funds Growth | AGTHX | US Equity | $68,997 | $70,075 | +$1,078 | +1.6% |
| American Funds New World | ANCFX | Intl Equity | $42,663 | $43,330 | +$667 | +1.6% |
| American Funds Income | AMRMX | US Equity | $22,859 | $23,216 | +$357 | +1.6% |
| American Funds Investment | AIVSX | US Equity | $72,026 | $73,152 | +$1,125 | +1.6% |
| American Funds New Persp. | ANWPX | Intl Equity | $33,346 | $33,867 | +$521 | +1.6% |
| American Funds Balanced | AMFFX | US Equity | $20,058 | $20,371 | +$313 | +1.6% |
| American Funds Bond | ABNDX | Fixed Income | $18,431 | $18,719 | +$288 | +1.6% |
| American High Income Trust | AHITX | Fixed Income | $14,936 | $15,169 | +$233 | +1.6% |
| American Funds New Econ. | ANEFX | US Equity | $19,126 | $19,425 | +$299 | +1.6% |
| iShares Core S&P 500 | IVV | US Equity | $96,034 | $97,535 | +$1,501 | +1.6% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,931 | $15,164 | +$233 | +1.6% |
| SPDR Gold Shares | GLD | Alternatives | $16,101 | $16,352 | +$252 | +1.6% |
| TOTAL PORTFOLIO |  |  | $640,000 | $650,000 | +$10,000 | +1.6% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $640,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,318.00 |
| Interest Income | $728.00 |
| Market Appreciation / (Depreciation) | $3,215.00 |
| Advisory & Management Fees | ($261.00) |
| Net Change for Period | $10,000.00 |
| Ending Account Value | $650,000.00 |

Advisor Commentary: Portfolio performance of +1.09% was behind the blended benchmark (+2.51%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2023 | +5.70% | -3.24% |
| Q4 2023 | +3.69% | +9.71% |
| Q1 2024 | +2.74% | +6.61% |
| Q2 2024 | +1.09% | +2.51% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
