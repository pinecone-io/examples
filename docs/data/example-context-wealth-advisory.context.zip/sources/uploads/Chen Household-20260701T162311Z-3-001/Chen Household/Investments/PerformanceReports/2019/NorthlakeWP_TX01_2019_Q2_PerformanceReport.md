CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2019Quarter 2, 2019 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2019 Portfolio | Q2 2019 Blend Bench. | Excess Return | YTD 2019 Portfolio | YTD 2019 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.45% | +3.71% | -0.26% | +10.60% | +14.31% |
| Benchmark Return | +3.71% | +4.01% | +3.02% | — | — |

▪ Beginning Value: $353,322 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $368,569

▪ Dividends & Interest: $2,245 ▪ Market Gain / (Loss): $10,218 ▪ Advisory Fees: ($216)

MARKET COMMENTARY

Q2 2019 saw continued gains, though not without turbulence. Trade tensions re-escalated in May when the U.S. hiked tariffs on $200B of Chinese goods, sending markets down ~6% before recovering. The S&P 500 gained 4.3% for the quarter. The Fed signaled rate cuts were on the table. Bonds rallied as yields fell. Fixed income was a meaningful positive contributor this quarter. Your balanced allocation continued to serve the portfolio well in a volatile but ultimately rewarding quarter.

| Benchmark | Q2 2019 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +4.01% | 70% | +2.81% |
| Bloomberg US Aggregate (Fixed Income) | +3.02% | 30% | +0.91% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $10,390 | $10,839 | +$448 | +4.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $31,568 | $32,930 | +$1,362 | +4.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $25,835 | $26,950 | +$1,115 | +4.3% |
| American Funds AMCAP | AMCPX | US Equity | $38,187 | $39,835 | +$1,648 | +4.3% |
| American Funds Growth | AGTHX | US Equity | $34,440 | $35,927 | +$1,486 | +4.3% |
| American Funds New World | ANCFX | Intl Equity | $21,418 | $22,342 | +$924 | +4.3% |
| American Funds Income | AMRMX | US Equity | $12,597 | $13,140 | +$544 | +4.3% |
| American Funds Investment | AIVSX | US Equity | $37,088 | $38,689 | +$1,600 | +4.3% |
| American Funds New Persp. | ANWPX | Intl Equity | $17,230 | $17,974 | +$744 | +4.3% |
| American Funds Balanced | AMFFX | US Equity | $11,489 | $11,985 | +$496 | +4.3% |
| American Funds Bond | ABNDX | Fixed Income | $18,554 | $19,355 | +$801 | +4.3% |
| American High Income Trust | AHITX | Fixed Income | $14,582 | $15,212 | +$629 | +4.3% |
| American Funds New Econ. | ANEFX | US Equity | $10,827 | $11,294 | +$467 | +4.3% |
| iShares Core S&P 500 | IVV | US Equity | $46,134 | $48,125 | +$1,991 | +4.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,686 | $16,362 | +$677 | +4.3% |
| SPDR Gold Shares | GLD | Alternatives | $7,297 | $7,612 | +$315 | +4.3% |
| TOTAL PORTFOLIO |  |  | $353,322 | $368,569 | +$15,247 | +4.3% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $353,322.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,944.00 |
| Interest Income | $301.00 |
| Market Appreciation / (Depreciation) | $10,218.00 |
| Advisory & Management Fees | ($216.00) |
| Net Change for Period | $15,247.00 |
| Ending Account Value | $368,569.00 |

Advisor Commentary: Portfolio performance of +3.45% was in line with the blended benchmark (+3.71%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2018 | +2.95% | +4.99% |
| Q4 2018 | -6.43% | -9.08% |
| Q1 2019 | +6.91% | +10.21% |
| Q2 2019 | +3.45% | +3.71% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
