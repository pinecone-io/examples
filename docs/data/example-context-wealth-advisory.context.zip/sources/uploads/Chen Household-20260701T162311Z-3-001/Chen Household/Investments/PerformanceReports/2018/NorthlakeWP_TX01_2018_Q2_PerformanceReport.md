CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2018Quarter 2, 2018 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2018 Portfolio | Q2 2018 Blend Bench. | Excess Return | YTD 2018 Portfolio | YTD 2018 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.52% | +2.01% | -0.48% | +1.26% | +1.93% |
| Benchmark Return | +2.01% | +2.93% | -0.15% | — | — |

▪ Beginning Value: $326,113 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $334,097

▪ Dividends & Interest: $2,076 ▪ Market Gain / (Loss): $3,114 ▪ Advisory Fees: ($206)

MARKET COMMENTARY

Markets stabilized in Q2 2018, with the S&P 500 recovering to post a 3.4% gain. Technology and consumer discretionary led the way. However, escalating U.S.-China trade rhetoric kept international equities under pressure, with emerging markets particularly hard hit. The Fed raised rates in June and signaled two more hikes in 2018. Bond returns were essentially flat as the yield curve continued to flatten. Your domestic equity holdings drove performance, while international exposure created a modest drag.

| Benchmark | Q2 2018 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +2.93% | 70% | +2.05% |
| Bloomberg US Aggregate (Fixed Income) | -0.15% | 30% | -0.04% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $12,054 | $12,349 | +$295 | +2.4% |
| American Funds EuroPacific | SEEGX | Intl Equity | $28,471 | $29,168 | +$697 | +2.4% |
| MFS Mid Cap Growth | MFEKX | US Equity | $22,453 | $23,003 | +$550 | +2.4% |
| American Funds AMCAP | AMCPX | US Equity | $33,936 | $34,767 | +$831 | +2.4% |
| American Funds Growth | AGTHX | US Equity | $30,385 | $31,129 | +$744 | +2.4% |
| American Funds New World | ANCFX | Intl Equity | $18,892 | $19,355 | +$463 | +2.4% |
| American Funds Income | AMRMX | US Equity | $11,233 | $11,509 | +$275 | +2.4% |
| American Funds Investment | AIVSX | US Equity | $32,842 | $33,646 | +$804 | +2.4% |
| American Funds New Persp. | ANWPX | Intl Equity | $15,063 | $15,432 | +$369 | +2.4% |
| American Funds Balanced | AMFFX | US Equity | $10,413 | $10,668 | +$255 | +2.4% |
| American Funds Bond | ABNDX | Fixed Income | $20,402 | $20,901 | +$499 | +2.4% |
| American High Income Trust | AHITX | Fixed Income | $16,573 | $16,978 | +$406 | +2.4% |
| American Funds New Econ. | ANEFX | US Equity | $9,866 | $10,107 | +$242 | +2.4% |
| iShares Core S&P 500 | IVV | US Equity | $39,138 | $40,096 | +$958 | +2.4% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,530 | $17,959 | +$429 | +2.4% |
| SPDR Gold Shares | GLD | Alternatives | $6,863 | $7,031 | +$168 | +2.4% |
| TOTAL PORTFOLIO |  |  | $326,113 | $334,097 | +$7,984 | +2.4% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $326,113.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,812.00 |
| Interest Income | $264.00 |
| Market Appreciation / (Depreciation) | $3,114.00 |
| Advisory & Management Fees | ($206.00) |
| Net Change for Period | $7,984.00 |
| Ending Account Value | $334,097.00 |

Advisor Commentary: Portfolio performance of +1.52% was in line with the blended benchmark (+2.01%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2017 | +3.16% | +3.05% |
| Q4 2017 | +3.27% | +4.17% |
| Q1 2018 | -0.25% | -0.08% |
| Q2 2018 | +1.52% | +2.01% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
