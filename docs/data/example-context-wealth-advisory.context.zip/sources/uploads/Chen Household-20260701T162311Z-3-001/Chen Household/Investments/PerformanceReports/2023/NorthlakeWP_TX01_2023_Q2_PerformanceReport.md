CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2023Quarter 2, 2023 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2023 Portfolio | Q2 2023 Blend Bench. | Excess Return | YTD 2023 Portfolio | YTD 2023 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -4.39% | +4.83% | -9.22% | +0.54% | +10.49% |
| Benchmark Return | +4.83% | +8.53% | -0.72% | — | — |

▪ Beginning Value: $409,755 ▪ Contributions / (Withdrawals): $172,000 ▪ Ending Value: $560,000

▪ Dividends & Interest: $2,746 ▪ Market Gain / (Loss): $-24,258 ▪ Advisory Fees: ($243)

MARKET COMMENTARY

Q2 2023 was highlighted by a major portfolio inflow: a $172,000 contribution was added, reflecting the vesting of a significant RSU equity grant. This represents an excellent opportunity to put new capital to work at current market levels. Markets continued their recovery, with the S&P 500 gaining 8.7% driven by AI/technology enthusiasm. The Fed hiked rates in May and July. Broad bonds declined modestly. The strategic deployment of new capital across your existing allocation maintains diversification while meaningfully increasing your long-term wealth-building potential.

| Benchmark | Q2 2023 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +8.53% | 60% | +5.12% |
| Bloomberg US Aggregate (Fixed Income) | -0.72% | 40% | -0.29% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 26% | █████████████  26% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $11,752 | $16,061 | +$4,309 | +36.7% |
| American Funds EuroPacific | SEEGX | Intl Equity | $34,509 | $47,163 | +$12,654 | +36.7% |
| MFS Mid Cap Growth | MFEKX | US Equity | $31,668 | $43,279 | +$11,612 | +36.7% |
| American Funds AMCAP | AMCPX | US Equity | $48,738 | $66,609 | +$17,871 | +36.7% |
| American Funds Growth | AGTHX | US Equity | $43,045 | $58,828 | +$15,783 | +36.7% |
| American Funds New World | ANCFX | Intl Equity | $26,507 | $36,227 | +$9,719 | +36.7% |
| American Funds Income | AMRMX | US Equity | $14,775 | $20,193 | +$5,418 | +36.7% |
| American Funds Investment | AIVSX | US Equity | $45,538 | $62,235 | +$16,697 | +36.7% |
| American Funds New Persp. | ANWPX | Intl Equity | $20,995 | $28,693 | +$7,698 | +36.7% |
| American Funds Balanced | AMFFX | US Equity | $13,175 | $18,005 | +$4,831 | +36.7% |
| American Funds Bond | ABNDX | Fixed Income | $13,530 | $18,491 | +$4,961 | +36.7% |
| American High Income Trust | AHITX | Fixed Income | $11,041 | $15,089 | +$4,048 | +36.7% |
| American Funds New Econ. | ANEFX | US Equity | $12,282 | $16,785 | +$4,503 | +36.7% |
| iShares Core S&P 500 | IVV | US Equity | $61,008 | $83,378 | +$22,370 | +36.7% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $11,219 | $15,332 | +$4,114 | +36.7% |
| SPDR Gold Shares | GLD | Alternatives | $9,974 | $13,631 | +$3,657 | +36.7% |
| TOTAL PORTFOLIO |  |  | $409,755 | $560,000 | +$150,245 | +36.7% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $409,755.00 |
| --- | --- |
| Contributions / (Withdrawals) | $172,000.00 |
| Dividend Income | $2,218.00 |
| Interest Income | $528.00 |
| Market Appreciation / (Depreciation) | $-24,258.00 |
| Advisory & Management Fees | ($243.00) |
| Net Change for Period | $150,245.00 |
| Ending Account Value | $560,000.00 |

Advisor Commentary: Large RSU equity grant vested — $172,000 contributed to the portfolio. Funds have been deployed across the portfolio's target allocation. This represents a significant milestone in long-term wealth accumulation.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2022 | -5.17% | -5.00% |
| Q4 2022 | +2.94% | +5.13% |
| Q1 2023 | +5.15% | +5.40% |
| Q2 2023 | -4.39% | +4.83% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
