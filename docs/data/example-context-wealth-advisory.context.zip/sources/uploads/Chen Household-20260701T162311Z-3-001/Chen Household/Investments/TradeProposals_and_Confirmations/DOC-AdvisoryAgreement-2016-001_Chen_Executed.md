CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

INVESTMENT ADVISORY AGREEMENT

(Discretionary — Event-Driven Review Provisions)

| Document ID DOC-AdvisoryAgreement-2016-001 | Effective Date February 1, 2016 | Agreement Version 1.0 — Original Executed |
| --- | --- | --- |

This Investment Advisory Agreement (the "Agreement") is entered into as of February 1, 2016, by and between Clearwater Wealth Partners, a registered investment adviser ("Adviser"), and the clients identified in Section 1 below (individually and collectively, "Client"). This Agreement sets forth the terms under which Adviser will provide discretionary investment management services to Client in connection with the accounts described herein.

1. PARTIES TO THIS AGREEMENT

1.1 Adviser

Clearwater Wealth Partners ("Adviser" or "Firm") 200 Prairie Lake Drive, Suite 300 Wayzata, MN 55391 Adviser Representative: Morgan Park, CFP® (ADV-PARK-001) CRD/ADV: [On file with FINRA/SEC]

1.2 Client(s)

| Field | Primary Client | Co-Client | Notes |
| --- | --- | --- | --- |
| Full Name | Alex Chen | Sam Chen | Household ID: HH-CHEN-001 |
| Date of Birth | March 22, 1981 | November 2, 1984 | Filing Status: MFJ |

Client Address: 3215 Lakeview Circle, Wayzata, MN 55391 Primary Email: alex.chen@exampledemo.com / sam.chen@exampledemo.com Primary Phone: (612) 555-0278

2. SCOPE OF ADVISORY SERVICES

Adviser agrees to provide discretionary investment management services to Client with respect to the Covered Accounts listed in Section 3. Services include, without limitation: (a) ongoing portfolio monitoring and asset allocation management; (b) securities selection and trade execution on a discretionary basis consistent with the Investment Policy Statement ("IPS") established pursuant to Section 4; (c) periodic performance reporting and account review; (d) financial planning coordination in respect of Client’s stated goals (GoalID-2016-01 through GoalID-2016-03); and (e) proactive review and rebalancing triggered by the Event-Driven Review provisions set forth in Section 6 of this Agreement.

Adviser is authorized to exercise full discretion over the Covered Accounts, including the authority to buy, sell, exchange, or otherwise trade securities without obtaining prior approval from Client for each transaction, subject to the investment guidelines and restrictions set forth in the IPS and any written amendments thereto.

3. COVERED ACCOUNTS

The following accounts ("Covered Accounts") are subject to this Agreement as of the Effective Date. Custody is maintained at Fidelity Institutional (CUST-FI-001), a qualified custodian. All account numbers listed are reference identifiers; actual custodial account numbers are on file with Adviser.

| Account ID | Account Nickname | Registration | Opened |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Brokerage | Joint (Chen) | February 1, 2016 |
| ACCT-IRA1 | Alex Traditional IRA | Individual (Alex) | February 1, 2016 |
| ACCT-RIRA | Alex Roth IRA | Individual (Alex) | February 1, 2016 |

Additional accounts may be added to the scope of this Agreement by written amendment executed by both parties. The addition of any account constitutes a triggering event subject to Section 6 (Event-Driven Review). Accounts opened after the Effective Date (e.g., ACCT-401R, rollover anticipated in 2017; ACCT-529A/529B, anticipated 2020; ACCT-CASH, anticipated 2019) will require a signed Account Addition Schedule prior to Adviser exercising discretion.

4. INVESTMENT OBJECTIVES AND POLICY

Client’s investment objectives are set forth in the Investment Policy Statement ("IPS") established concurrently herewith under document reference DOC-IPS-2016-001, effective February 1, 2016. The IPS is incorporated herein by reference and governs the allocation of assets within the Covered Accounts until amended pursuant to Section 6 or Section 10 of this Agreement.

| IPS Reference | Effective Date | Target Allocation | Risk Profile |
| --- | --- | --- | --- |
| DOC-IPS-2016-001 | February 1, 2016 | 70% Equity / 28% Fixed / 2% Cash | Moderate Growth (Score 68/100) |

The allocation targets and drift bands established under DOC-IPS-2016-001 are: Equity ±5%, Fixed Income ±5%, Cash ±2%. Single-issuer concentration shall not exceed 10% of total household assets under management. Risk tolerance is based on DOC-RiskQuestionnaire-2016-001 completed February 10, 2016, reflecting a maximum tolerable drawdown of approximately 20–25% over any rolling 12-month period.

Primary financial planning goals incorporated into the advisory mandate include: GoalID-2016-01 (retirement readiness, targeting retirement at approximately age 60 with $185,000/year after-tax income in today’s dollars); GoalID-2016-02 (education funding for dependents Maya Chen, DOB 2011-08-19, and Eli Chen, DOB 2014-03-07); and GoalID-2016-03 (emergency liquidity maintenance of 6–9 months’ household expenses in accessible, low-risk instruments).

5. ADVISORY FEES AND BILLING

In consideration of the services described herein, Client agrees to pay Adviser an annual advisory fee calculated as follows ("Fee Schedule"), billed quarterly in arrears based on the average daily balance of all Covered Accounts during each calendar quarter:

| AUM Tier | Annual Fee Rate | Billing Frequency |
| --- | --- | --- |
| All assets under management | 1.00% per annum (flat) | Quarterly in arrears |

The fee is calculated by Adviser and deducted directly from Client’s Covered Accounts at the custodian, unless Client elects to pay by separate invoice. Fees are prorated for partial quarters based on days in the billing period. Adviser will provide a fee disclosure with each quarterly billing reflecting the calculation methodology and aggregate fee charged.

This Fee Schedule (DOC-AdvisoryAgreement-2016-001) remains in effect until amended by written agreement of both parties. Any fee amendment shall take effect on the first day of the calendar quarter following execution of the written amendment. Estimated annual fee at inception (approximate AUM: $410,000) is approximately $4,100 billed at approximately $1,025 per quarter.

6. EVENT-DRIVEN REVIEW AND IPS AMENDMENT PROVISIONS

Adviser and Client acknowledge that material changes in Client’s financial circumstances, life events, or market conditions may necessitate a review and potential amendment of the IPS, fee arrangement, account scope, or investment strategy. The following events shall constitute mandatory triggers for an expedited advisory review (“Event-Driven Review”):

| Event Category | Specific Triggering Event | Required Action |
| --- | --- | --- |
| Equity Compensation Event | Commencement, modification, or vesting of equity compensation awards (RSUs, options, or otherwise) — EventID-2018-01 anticipated | IPS review; concentration analysis; tax-aware liquidation plan |
| Material Income Change | Promotion, job change, or material increase/decrease in household W-2 or other income exceeding 20% of prior year | Goals review; contribution rate update; risk reassessment |
| Major Life Event | Marriage, divorce, birth or adoption of dependent, death in household, disability diagnosis | Beneficiary audit; estate document check; IPS amendment if required |
| Real Estate Transaction | Purchase or sale of primary or investment real estate (home purchase anticipated EventID-2021-01) | Liquidity review; down payment staging plan; mortgage-debt integration |
| AUM Threshold Breach | Aggregate household AUM increases above $1,500,000 or drops below $300,000 for two consecutive quarters | Fee schedule review; diversification review |
| Market Stress Event | Drawdown of 15% or more in aggregate portfolio value over 60 days (COVID scenario anticipated EventID-2020-01) | Risk tolerance re-survey; IPS amendment if indicated; documented suitability review |

In addition to the above mandatory triggers, Adviser will conduct a minimum of two (2) scheduled portfolio reviews per year and one (1) comprehensive annual strategy review. Results of any Event-Driven Review shall be documented in meeting notes and, where an IPS amendment results, in a signed IPS amendment document bearing the applicable DocID (e.g., DOC-IPSAmendment-YYYY-001). Adviser shall notify Client in writing of any recommended IPS amendment within fifteen (15) business days of an identified triggering event.

7. CUSTODIAN ARRANGEMENT

Client’s assets shall be held in custody by Fidelity Institutional (CUST-FI-001), a qualified custodian independent of Adviser. Adviser shall have trading authority over the Covered Accounts consistent with the discretionary authorization granted herein but shall not have custody of Client funds within the meaning of applicable SEC rules. Client will receive account statements directly from the custodian no less than quarterly. Client should review custodial statements promptly and report any discrepancies to Adviser within 30 days of receipt.

8. CLIENT RESPONSIBILITIES

Client agrees to: (a) promptly notify Adviser of any Event-Driven trigger described in Section 6, including but not limited to material changes in employment, income, equity compensation awards, family composition, or significant financial obligations; (b) provide complete and accurate financial information upon initial engagement and update such information when material changes occur; (c) complete any risk tolerance questionnaire requested by Adviser within 30 days of such request; and (d) review all account statements, performance reports, and trade confirmations in a timely manner.

9. MATERIAL DISCLOSURES AND CONFLICTS OF INTEREST

Adviser’s Form ADV, Parts 1 and 2A–2B, are incorporated herein by reference and have been provided to Client prior to or concurrent with execution of this Agreement. Client acknowledges receipt of Adviser’s current Form ADV brochure. Adviser is a fee-only registered investment adviser; Adviser does not receive commissions, 12b-1 fees, or other third-party compensation in connection with investment recommendations. Clearwater Wealth Partners may refer Clients to affiliated or unaffiliated specialists (e.g., estate attorney Westfield & Baker LLP, tax specialist Lisa Torres EA) for services outside the scope of this Agreement; Adviser receives no referral compensation from such specialists.

10. AMENDMENT, TERMINATION, AND SURVIVAL

10.1 Amendment. This Agreement may be amended by written agreement signed by both Adviser and Client. Amendments to the Fee Schedule shall be documented under a separate DocID (e.g., DOC-FeeAmendment-YYYY-001) and shall not require re-execution of this entire Agreement.

10.2 Termination. Either party may terminate this Agreement upon thirty (30) days’ prior written notice to the other party. Upon termination, Adviser shall have no further obligation to manage Client’s accounts, and any outstanding fee earned through the effective date of termination shall be due and payable. Adviser’s obligation to maintain Client records following termination shall be governed by applicable regulations.

10.3 Survival. Sections 5 (Fees, for earned but unpaid amounts), 9 (Disclosures), and the confidentiality obligations of the parties shall survive any termination of this Agreement.

11. GOVERNING LAW; ARBITRATION

This Agreement shall be governed by the laws of the State of Minnesota, without regard to its conflict of law provisions. Any dispute arising from or related to this Agreement that cannot be resolved informally shall be submitted to binding arbitration before FINRA Dispute Resolution Services (or, if FINRA jurisdiction is unavailable, the American Arbitration Association) in Hennepin County, Minnesota. Nothing herein waives any right of Client under applicable federal or state securities laws.

EXECUTION PAGE

DOC-AdvisoryAgreement-2016-001 • Effective February 1, 2016 • Clearwater Wealth Partners / Chen Household (HH-CHEN-001)

IN WITNESS WHEREOF, the parties have executed this Investment Advisory Agreement as of the date first written above. By signing below, each party acknowledges having read and understood this Agreement and received Adviser’s Form ADV brochure at least 48 hours prior to execution.

| ________________________________________Signature — Primary ClientAlex ChenDate: February 1, 2016 | ________________________________________Signature — Co-ClientSam ChenDate: February 1, 2016 |
| --- | --- |
| ________________________________________Signature — Adviser RepresentativeMorgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date: February 1, 2016 |  |

CLIENT ACKNOWLEDGEMENT: By executing this Agreement, Client confirms: (1) receipt of Adviser’s Form ADV, Parts 1 and 2A–2B; (2) completion of DOC-RiskQuestionnaire-2016-001 (Risk Tolerance Survey, February 10, 2016); (3) review and approval of DOC-IPS-2016-001 (Investment Policy Statement); and (4) understanding of the Event-Driven Review triggers set forth in Section 6, including the anticipated equity compensation event (EventID-2018-01), to be addressed in a subsequent IPS review upon vesting or grant of RSUs.

SYNTHETIC DEMONSTRATION DOCUMENT — NWP-DEMO-HH-CHEN-001 v1.2 • NOT INVESTMENT, LEGAL, OR TAX ADVICE • Clearwater Wealth Partners • Wayzata, MN 55391
