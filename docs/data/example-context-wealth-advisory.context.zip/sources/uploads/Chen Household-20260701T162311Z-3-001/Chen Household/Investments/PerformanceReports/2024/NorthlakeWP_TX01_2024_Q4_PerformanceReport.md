CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODOctober 1 - December 31, 2024Quarter 4, 2024 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q4 2024 Portfolio | Q4 2024 Blend Bench. | Excess Return | YTD 2024 Portfolio | YTD 2024 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +5.59% | -2.60% | +8.20% | +10.84% | +12.27% |
| Benchmark Return | -2.60% | -2.38% | -3.02% | — | — |

▪ Beginning Value: $660,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $700,000

▪ Dividends & Interest: $4,274 ▪ Market Gain / (Loss): $32,995 ▪ Advisory Fees: ($269)

MARKET COMMENTARY

Q4 2024 presented a mixed environment. Following the U.S. election, equity markets initially surged on expectations of business-friendly policies, then gave back some gains as rate concerns returned. The S&P 500 declined 2.4% for the quarter — dragged by a difficult December. Bonds also declined as yields reversed higher. The full year 2024 was strong (+25.0% for equities), leaving your portfolio at a new high. The Fed cut rates twice more in Q4. Your diversified holdings softened the Q4 decline relative to a concentrated equity portfolio.

| Benchmark | Q4 2024 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -2.38% | 65% | -1.55% |
| Bloomberg US Aggregate (Fixed Income) | -3.02% | 35% | -1.06% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,483 | $20,664 | +$1,181 | +6.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $56,258 | $59,667 | +$3,410 | +6.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $51,932 | $55,079 | +$3,147 | +6.1% |
| American Funds AMCAP | AMCPX | US Equity | $79,084 | $83,877 | +$4,793 | +6.1% |
| American Funds Growth | AGTHX | US Equity | $71,153 | $75,465 | +$4,312 | +6.1% |
| American Funds New World | ANCFX | Intl Equity | $43,996 | $46,663 | +$2,666 | +6.1% |
| American Funds Income | AMRMX | US Equity | $23,573 | $25,002 | +$1,429 | +6.1% |
| American Funds Investment | AIVSX | US Equity | $74,277 | $78,779 | +$4,502 | +6.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $34,388 | $36,472 | +$2,084 | +6.1% |
| American Funds Balanced | AMFFX | US Equity | $20,685 | $21,938 | +$1,254 | +6.1% |
| American Funds Bond | ABNDX | Fixed Income | $19,007 | $20,159 | +$1,152 | +6.1% |
| American High Income Trust | AHITX | Fixed Income | $15,402 | $16,336 | +$933 | +6.1% |
| American Funds New Econ. | ANEFX | US Equity | $19,723 | $20,919 | +$1,195 | +6.1% |
| iShares Core S&P 500 | IVV | US Equity | $99,036 | $105,038 | +$6,002 | +6.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,398 | $16,331 | +$933 | +6.1% |
| SPDR Gold Shares | GLD | Alternatives | $16,604 | $17,610 | +$1,006 | +6.1% |
| TOTAL PORTFOLIO |  |  | $660,000 | $700,000 | +$40,000 | +6.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $660,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,518.00 |
| Interest Income | $756.00 |
| Market Appreciation / (Depreciation) | $32,995.00 |
| Advisory & Management Fees | ($269.00) |
| Net Change for Period | $40,000.00 |
| Ending Account Value | $700,000.00 |

Advisor Commentary: Portfolio performance of +5.59% was ahead of the blended benchmark (-2.60%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2024 | +2.74% | +6.61% |
| Q2 2024 | +1.09% | +2.51% |
| Q3 2024 | +1.07% | +5.48% |
| Q4 2024 | +5.59% | -2.60% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
