CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2016Quarter 1, 2016 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2016 Portfolio | Q1 2016 Blend Bench. | Excess Return | YTD 2016 Portfolio | YTD 2016 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | -1.23% | -0.24% | -0.99% | -1.23% | -0.24% |
| Benchmark Return | -0.24% | -1.63% | +2.99% | — | — |

▪ Beginning Value: $246,318 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $246,265

▪ Dividends & Interest: $1,352 ▪ Market Gain / (Loss): $-4,218 ▪ Advisory Fees: ($187)

MARKET COMMENTARY

Markets began 2016 under significant pressure, with global growth concerns and falling oil prices sparking a sharp selloff through mid-February. The S&P 500 fell 5.1% in January before recovering most losses by quarter-end. China's slowing economy and currency devaluation weighed on sentiment throughout the period. The Federal Reserve, which had raised rates in December 2015, adopted a more cautious posture given global headwinds. Your portfolio held up relatively well due to its diversified allocation, with bond holdings providing a meaningful offset to equity weakness.

| Benchmark | Q1 2016 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | -1.63% | 70% | -1.14% |
| Bloomberg US Aggregate (Fixed Income) | +2.99% | 30% | +0.90% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,863 | $7,715 | $-148 | -1.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $20,920 | $21,191 | +$271 | +1.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $16,340 | $16,703 | +$364 | +2.2% |
| American Funds AMCAP | AMCPX | US Equity | $25,648 | $25,897 | +$248 | +1.0% |
| American Funds Growth | AGTHX | US Equity | $22,070 | $22,260 | +$191 | +0.9% |
| American Funds New World | ANCFX | Intl Equity | $14,726 | $14,564 | $-162 | -1.1% |
| American Funds Income | AMRMX | US Equity | $9,440 | $9,324 | $-116 | -1.2% |
| American Funds Investment | AIVSX | US Equity | $24,614 | $24,831 | +$218 | +0.9% |
| American Funds New Persp. | ANWPX | Intl Equity | $11,278 | $11,356 | +$77 | +0.7% |
| American Funds Balanced | AMFFX | US Equity | $8,295 | $8,357 | +$62 | +0.7% |
| American Funds Bond | ABNDX | Fixed Income | $16,323 | $15,848 | $-476 | -2.9% |
| American High Income Trust | AHITX | Fixed Income | $13,122 | $12,746 | $-376 | -2.9% |
| American Funds New Econ. | ANEFX | US Equity | $7,831 | $7,720 | $-111 | -1.4% |
| iShares Core S&P 500 | IVV | US Equity | $28,291 | $28,677 | +$386 | +1.4% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,025 | $13,495 | $-530 | -3.8% |
| SPDR Gold Shares | GLD | Alternatives | $5,532 | $5,581 | +$48 | +0.9% |
| TOTAL PORTFOLIO |  |  | $246,318 | $246,265 | $-53 | -0.0% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $246,318.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,204.00 |
| Interest Income | $148.00 |
| Market Appreciation / (Depreciation) | $-4,218.00 |
| Advisory & Management Fees | ($187.00) |
| Net Change for Period | $-53.00 |
| Ending Account Value | $246,265.00 |

Advisor Commentary: Initial portfolio statement — account established Q1 2016. Regular monthly contributions of $1,000 are being made per the investment plan. Dollar-cost averaging into the market over time.

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
