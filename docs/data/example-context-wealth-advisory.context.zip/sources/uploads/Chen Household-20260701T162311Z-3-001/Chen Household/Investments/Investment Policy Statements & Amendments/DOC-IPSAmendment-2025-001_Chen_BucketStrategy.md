CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

INVESTMENT POLICY STATEMENT — AMENDMENT

Bucket Strategy Framework | Pre-Retirement Transition | IPS Version 3.0

| Document ID DOC-IPSAmendment-2025-001 | Effective Date March 1, 2025 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: Retirement horizon approach — Alex Chen turns 42 in 2025, approximately 18 years from target retirement age of ~60. Pre-retirement income distribution planning initiated in 2024-Q3 per DOC-AgreementAmendment-2024-001. DOC-RiskQuestionnaire-2025-001 completed February 10, 2025 (score 58/100, “Moderate — bucket preference”), reflecting partial recovery from 2020 risk aversion and a preference for a structured spending framework. Bucket strategy implementation via DecisionID-2025-112 (window: 2025-02-15 to 2025-03-31). This Amendment supersedes Sections 5, 7, 8, and 9 of DOC-IPS-2016-001 as amended by DOC-IPSAmendment-2020-001, effective March 1, 2025.

1. BASIS FOR AMENDMENT

| Amends: | DOC-IPS-2016-001 (as amended by DOC-IPSAmendment-2020-001) — Sections 5, 7, 8, 9 |
| --- | --- |

| Effective Date: | March 1, 2025 |
| --- | --- |

| Risk Survey: | DOC-RiskQuestionnaire-2025-001  (completed 2025-02-10)  |  Score: 58/100  (“Moderate — bucket preference”) |
| --- | --- |

| Prior IPS Score: | 54/100 (IPS-2020, COVID)  |  Change: +4 points  |  IPS-2016 baseline: 68/100 |
| --- | --- |

| AUM at Amendment: | ~$1,315,000  (2025-Q1;  Tier 1 of fee schedule: 0.85% per DOC-FeeAmendment-2021-001) |
| --- | --- |

| Key Trigger: | Retirement horizon planning; sequence-of-returns risk management; 2023 liquidity event materially improved retirement confidence |
| --- | --- |

| Implementation: | DecisionID-2025-112  |  Window: 2025-02-15 to 2025-03-31 |
| --- | --- |

| Related Documents: | DOC-AgreementAmendment-2024-001 (added pre-retirement income planning to advisory scope);  DOC-BeneficiaryAudit-2024-001 |
| --- | --- |

The bucket strategy framework was adopted to address three specific planning concerns: (1) sequence-of-returns risk — the household is now within 15–20 years of retirement distributions and needs protection against an adverse market early in distribution phase; (2) spending clarity — Client expressed a desire for a clear, intuitive framework that separates near-term, medium-term, and long-term assets; (3) GoalID-2016-01 confidence level was materially improved by the 2023 liquidity event (EventID-2023-01), making it feasible to slightly increase equity allocation (from 60% back toward 62%) while simultaneously building a dedicated near-term spending buffer (Bucket 1).

2. BUCKET STRATEGY FRAMEWORK

The household portfolio is organized into three time-horizon “buckets.” Each bucket has a distinct purpose, time horizon, risk profile, and designated account(s). The aggregate allocation across all buckets produces the overall 62% Equity / 33% Fixed / 5% Cash target.

| Bucket | Time Horizon | Purpose | Instruments | Accounts | Target Size |
| --- | --- | --- | --- | --- | --- |
| Bucket 1 | 0 – 24 months | Near-term spending, emergency reserve, capital preservation | Cash, STBIX (Short-Term Bond / Cash Equivalent) | ACCT-CASH (primary);  ACCT-TX01 cash sleeve | ~5% of HH AUM (~$65,000–$75,000 target) |
| Bucket 2 | 2 – 7 years | Medium-term stability, income generation, inflation protection | UCBIX (Core Bond), UTIPX (TIPS / Treasury);  some MUNIX | ACCT-IRA1 (primary);  ACCT-TX01 fixed income sleeve | ~33% of HH AUM (~$430,000–$440,000 target) |
| Bucket 3 | 7+ years | Long-term growth, inflation-beating returns; funds eventual retirement distributions | UECIX, USCIX, IDEIX, EMEIX, REITX (Real Estate Index) | ACCT-RIRA (primary — tax-free growth);  ACCT-TX01 equity sleeve;  ACCT-IRA1 equity sleeve | ~62% of HH AUM (~$815,000–$820,000 target) |

3. UPDATED TARGET ASSET ALLOCATION (REPLACES IPS-2020 SECTION 5)

| Asset Class | IPS-2020 Target | IPS-2025 Target | Change | Bucket |
| --- | --- | --- | --- | --- |
| Equity (Total) | 60.0% | 62.0% | +2.0 pp | Bucket 3 |
| U.S. Large Cap | 34.0% | 36.0% | +2.0 pp | Bucket 3 |
| U.S. Small Cap | 6.0% | 6.0% | 0.0 | Bucket 3 |
| Intl Developed | 12.0% | 12.0% | 0.0 | Bucket 3 |
| Emerging Markets | 8.0% | 8.0% | 0.0 | Bucket 3 |
| Real Estate (REITX) | 0.0% | 0.0% (Bucket 3 reserve) | NEW | Bucket 3 |
| Fixed Income (Total) | 35.0% | 33.0% | −2.0 pp | Bucket 2 |
| U.S. Core Bond | 17.0% | 16.0% | −1.0 pp | Bucket 2 |
| TIPS / Treasury | 12.0% | 11.0% | −1.0 pp | Bucket 2 |
| Municipal Bond | 6.0% | 6.0% | 0.0 | Bucket 2 |
| Cash & Equivalents | 5.0% | 5.0% | 0.0 | Bucket 1 |
| TOTAL | 100% | 100% | — |  |

4. AMENDED CONSTRAINTS (REPLACES IPS-2020 SECTION 3)

| Single-Stock Limit: | FURTHER REDUCED to <5% of total HH AUM  (NLTK now subject to tighter 5% cap; RSU vesting plan must account for this) |
| --- | --- |

| Bucket 1 Floor: | ACCT-CASH + TX01 cash sleeve must maintain minimum $60,000 combined at all times  (Bucket 1 hard floor) |
| --- | --- |

| Bucket 1 Refill Rule: | If Bucket 1 falls below $60,000, Adviser will present a Bucket 2 → Bucket 1 transfer proposal within 30 days |
| --- | --- |

| REITX Allocation: | May be introduced in Bucket 3 up to 5% of equity sleeve; requires separate trade proposal (DecisionID-2025-112 scope) |
| --- | --- |

| Equity Hard Floor: | 55%  (reduced from IPS-2020 hard floor of 50%; bucket strategy provides sufficient liquidity without over-de-risking) |
| --- | --- |

| Max Fixed Income: | 40%  (reduced from 45%; bucket framework eliminates need for excess bond allocation as “safety” proxy) |
| --- | --- |

5. UPDATED BENCHMARKS

| Segment | Benchmark | Notes |
| --- | --- | --- |
| Total Portfolio | 62% MSCI ACWI / 33% Bloomberg US Agg / 5% T-Bill | IPS-2025 blended |
| Bucket 1 | SOFR / ICE BofA 1–3 Year US Treasury Index | Cash + STBIX |
| Bucket 2 | Bloomberg US Agg + Bloomberg TIPS | UCBIX + UTIPX blend |
| Bucket 3 | MSCI ACWI (blended per equity sub-weights) | All equity sleeves |
| REITX (if added) | MSCI US REIT Index | When/if allocated |

6. FINANCIAL PLANNING GOALS — 2025 STATUS UPDATE

| Goal ID | Goal | 2025 Status |
| --- | --- | --- |
| GoalID-2016-01 | Retirement Readiness | Confidence level materially improved by 2023 liquidity event (EventID-2023-01). Bucket strategy directly supports sequence-of-returns risk management. On track for ~age 60 retirement; formal income distribution modeling in progress. |
| GoalID-2016-02 | Education Funding | ACCT-529A (Maya, ~age 14): balance on track; allocation shifting more conservative. ACCT-529B (Eli, ~age 11): balance on track; age-based moderate portfolio. Contribution targets reviewed 2023-Q3. |
| GoalID-2016-03 | Emergency / Liquidity | ACCT-CASH integrated into Bucket 1. Bucket 1 target: $60,000–$75,000. Liquidity now explicitly managed as part of bucket framework rather than separate goal. |
| GoalID-2023-01 | Values-Based Giving | Annual DAF contribution and grant cycle active. Q4 giving review incorporated into advisory calendar. Tax optimization relative to RSU vesting calendar. |

7. PROVISIONS UNCHANGED FROM PRIOR IPS VERSIONS

The following remain in effect from DOC-IPS-2016-001 (as previously amended): Section 2 (Parties and Accounts, with addition of ACCT-CASH, ACCT-529A/B per DOC-FeeAmendment-2021-001); Section 6 (Tax-Aware Placement — bucket assignments above refine but do not replace); Section 9 (Monitoring — quarterly + annual; bucket refill monitoring added); Section 10 (Event-Driven Triggers, with additions per DOC-AgreementAmendment-2024-001 Section 5).

8. SIGNATURES

| ____________________________________Primary ClientAlex ChenDate:  March 1, 2025 | ____________________________________Co-ClientSam ChenDate:  March 1, 2025 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  March 1, 2025 |
| --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-IPSAmendment-2025-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
