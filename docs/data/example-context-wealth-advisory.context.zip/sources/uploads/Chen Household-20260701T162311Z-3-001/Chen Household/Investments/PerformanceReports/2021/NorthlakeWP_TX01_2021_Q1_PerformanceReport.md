CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2021Quarter 1, 2021 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2021 Portfolio | Q1 2021 Blend Bench. | Excess Return | YTD 2021 Portfolio | YTD 2021 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.74% | +1.83% | +1.91% | +3.74% | +1.83% |
| Benchmark Return | +1.83% | +6.28% | -3.60% | — | — |

▪ Beginning Value: $449,283 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $469,159

▪ Dividends & Interest: $2,286 ▪ Market Gain / (Loss): $14,818 ▪ Advisory Fees: ($228)

MARKET COMMENTARY

Q1 2021 saw a continuation of the 'reopening trade' as vaccine rollouts accelerated. The S&P 500 gained 6.2%, led by economically sensitive value stocks while growth names struggled. The 10-year Treasury yield surged from 0.9% to 1.7%, causing significant pain in long-duration bonds; the Bloomberg Agg fell 3.4% — its worst quarter in decades. President Biden signed the $1.9 trillion American Rescue Plan. The Fed maintained emergency-era policy. Your portfolio benefited from equity exposure while the fixed income component faced headwinds from rising rates.

| Benchmark | Q1 2021 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +6.28% | 55% | +3.45% |
| Bloomberg US Aggregate (Fixed Income) | -3.60% | 45% | -1.62% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $9,978 | $8,322 | $-1,656 | -16.6% |
| American Funds EuroPacific | SEEGX | Intl Equity | $39,861 | $41,766 | +$1,905 | +4.8% |
| MFS Mid Cap Growth | MFEKX | US Equity | $34,759 | $37,836 | +$3,077 | +8.9% |
| American Funds AMCAP | AMCPX | US Equity | $50,799 | $57,724 | +$6,924 | +13.6% |
| American Funds Growth | AGTHX | US Equity | $46,178 | $48,980 | +$2,802 | +6.1% |
| American Funds New World | ANCFX | Intl Equity | $27,714 | $29,962 | +$2,249 | +8.1% |
| American Funds Income | AMRMX | US Equity | $15,328 | $15,977 | +$649 | +4.2% |
| American Funds Investment | AIVSX | US Equity | $47,150 | $50,952 | +$3,802 | +8.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $22,612 | $23,628 | +$1,016 | +4.5% |
| American Funds Balanced | AMFFX | US Equity | $14,351 | $14,884 | +$533 | +3.7% |
| American Funds Bond | ABNDX | Fixed Income | $21,645 | $18,158 | $-3,486 | -16.1% |
| American High Income Trust | AHITX | Fixed Income | $16,543 | $14,224 | $-2,319 | -14.0% |
| American Funds New Econ. | ANEFX | US Equity | $13,627 | $14,010 | +$382 | +2.8% |
| iShares Core S&P 500 | IVV | US Equity | $59,788 | $68,220 | +$8,432 | +14.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $18,238 | $15,540 | $-2,699 | -14.8% |
| SPDR Gold Shares | GLD | Alternatives | $10,712 | $8,978 | $-1,734 | -16.2% |
| TOTAL PORTFOLIO |  |  | $449,283 | $469,159 | +$19,876 | +4.4% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $449,283.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $2,204.00 |
| Interest Income | $82.00 |
| Market Appreciation / (Depreciation) | $14,818.00 |
| Advisory & Management Fees | ($228.00) |
| Net Change for Period | $19,876.00 |
| Ending Account Value | $469,159.00 |

Advisor Commentary: Portfolio performance of +3.74% was ahead of the blended benchmark (+1.83%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2020 | +13.42% | +12.29% |
| Q3 2020 | +6.01% | +5.00% |
| Q4 2020 | +6.31% | +7.08% |
| Q1 2021 | +3.74% | +1.83% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
