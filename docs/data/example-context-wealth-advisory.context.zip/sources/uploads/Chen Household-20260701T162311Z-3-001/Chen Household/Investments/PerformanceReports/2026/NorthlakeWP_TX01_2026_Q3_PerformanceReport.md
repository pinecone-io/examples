CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2026Quarter 3, 2026 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2026 Portfolio | Q3 2026 Blend Bench. | Excess Return | YTD 2026 Portfolio | YTD 2026 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.76% | +4.06% | -1.30% | +6.67% | +10.33% |
| Benchmark Return | +4.06% | +5.24% | +1.88% | — | — |

▪ Beginning Value: $795,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $820,000

▪ Dividends & Interest: $4,840 ▪ Market Gain / (Loss): $17,452 ▪ Advisory Fees: ($292)

MARKET COMMENTARY

Q3 2026 saw continued positive market momentum. The S&P 500 gained 5.2% and investment-grade bonds gained 1.9% as the economy sustained its expansion. The Fed made one additional rate cut, bringing short-term rates modestly lower. Strong consumer balance sheets and corporate cash generation supported valuations. Your portfolio continued to benefit from its balanced allocation, with equity gains driving total returns and fixed income providing stability and income. The portfolio approaches record levels as the ten-year investment horizon nears completion.

| Benchmark | Q3 2026 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +5.24% | 65% | +3.41% |
| Bloomberg US Aggregate (Fixed Income) | +1.88% | 35% | +0.66% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,505 | $20,118 | +$613 | +3.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $67,184 | $69,297 | +$2,113 | +3.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $63,083 | $65,067 | +$1,984 | +3.1% |
| American Funds AMCAP | AMCPX | US Equity | $95,889 | $98,905 | +$3,015 | +3.1% |
| American Funds Growth | AGTHX | US Equity | $86,917 | $89,651 | +$2,733 | +3.1% |
| American Funds New World | ANCFX | Intl Equity | $53,850 | $55,543 | +$1,693 | +3.1% |
| American Funds Income | AMRMX | US Equity | $28,221 | $29,108 | +$887 | +3.1% |
| American Funds Investment | AIVSX | US Equity | $89,999 | $92,829 | +$2,830 | +3.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $42,063 | $43,386 | +$1,323 | +3.1% |
| American Funds Balanced | AMFFX | US Equity | $25,139 | $25,930 | +$791 | +3.1% |
| American Funds Bond | ABNDX | Fixed Income | $21,043 | $21,705 | +$662 | +3.1% |
| American High Income Trust | AHITX | Fixed Income | $17,198 | $17,739 | +$541 | +3.1% |
| American Funds New Econ. | ANEFX | US Equity | $24,114 | $24,872 | +$758 | +3.1% |
| iShares Core S&P 500 | IVV | US Equity | $122,041 | $125,879 | +$3,838 | +3.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $17,454 | $18,003 | +$549 | +3.1% |
| SPDR Gold Shares | GLD | Alternatives | $21,299 | $21,969 | +$670 | +3.1% |
| TOTAL PORTFOLIO |  |  | $795,000 | $820,000 | +$25,000 | +3.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $795,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $4,214.00 |
| Interest Income | $626.00 |
| Market Appreciation / (Depreciation) | $17,452.00 |
| Advisory & Management Fees | ($292.00) |
| Net Change for Period | $25,000.00 |
| Ending Account Value | $820,000.00 |

Advisor Commentary: Portfolio performance of +2.76% was behind the blended benchmark (+4.06%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2025 | +2.99% | +1.98% |
| Q1 2026 | +1.58% | +2.42% |
| Q2 2026 | +2.19% | +3.52% |
| Q3 2026 | +2.76% | +4.06% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
