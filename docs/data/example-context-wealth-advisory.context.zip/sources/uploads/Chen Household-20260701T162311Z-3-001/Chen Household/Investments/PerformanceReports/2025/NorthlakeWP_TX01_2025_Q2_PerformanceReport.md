CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2025Quarter 2, 2025 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2025 Portfolio | Q2 2025 Blend Bench. | Excess Return | YTD 2025 Portfolio | YTD 2025 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.70% | +3.23% | -1.53% | +1.99% | +0.95% |
| Benchmark Return | +3.23% | +4.24% | +1.36% | — | — |

▪ Beginning Value: $705,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $720,000

▪ Dividends & Interest: $4,416 ▪ Market Gain / (Loss): $7,860 ▪ Advisory Fees: ($276)

MARKET COMMENTARY

Q2 2025 saw a recovery as some tariff-related fears moderated following trade negotiations and positive earnings surprises. The S&P 500 gained 4.3% and bonds gained 1.4%. Technology and healthcare led equity returns. The Fed held rates steady while monitoring inflation and growth. Global supply chain adjustments continued. Your portfolio recovered Q1 losses and advanced, with both equity and income contributions supporting strong results.

| Benchmark | Q2 2025 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +4.24% | 65% | +2.76% |
| Bloomberg US Aggregate (Fixed Income) | +1.36% | 35% | +0.48% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,148 | $19,555 | +$407 | +2.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $59,594 | $60,861 | +$1,268 | +2.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $55,719 | $56,904 | +$1,186 | +2.1% |
| American Funds AMCAP | AMCPX | US Equity | $84,531 | $86,330 | +$1,799 | +2.1% |
| American Funds Growth | AGTHX | US Equity | $76,540 | $78,169 | +$1,629 | +2.1% |
| American Funds New World | ANCFX | Intl Equity | $47,481 | $48,491 | +$1,010 | +2.1% |
| American Funds Income | AMRMX | US Equity | $25,207 | $25,743 | +$536 | +2.1% |
| American Funds Investment | AIVSX | US Equity | $79,688 | $81,384 | +$1,695 | +2.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $37,073 | $37,861 | +$789 | +2.1% |
| American Funds Balanced | AMFFX | US Equity | $22,054 | $22,523 | +$469 | +2.1% |
| American Funds Bond | ABNDX | Fixed Income | $19,395 | $19,807 | +$413 | +2.1% |
| American High Income Trust | AHITX | Fixed Income | $15,757 | $16,093 | +$335 | +2.1% |
| American Funds New Econ. | ANEFX | US Equity | $21,327 | $21,781 | +$454 | +2.1% |
| iShares Core S&P 500 | IVV | US Equity | $106,815 | $109,088 | +$2,273 | +2.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $16,004 | $16,345 | +$341 | +2.1% |
| SPDR Gold Shares | GLD | Alternatives | $18,668 | $19,065 | +$397 | +2.1% |
| TOTAL PORTFOLIO |  |  | $705,000 | $720,000 | +$15,000 | +2.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $705,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,718.00 |
| Interest Income | $698.00 |
| Market Appreciation / (Depreciation) | $7,860.00 |
| Advisory & Management Fees | ($276.00) |
| Net Change for Period | $15,000.00 |
| Ending Account Value | $720,000.00 |

Advisor Commentary: Portfolio performance of +1.70% was behind the blended benchmark (+3.23%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2024 | +1.07% | +5.48% |
| Q4 2024 | +5.59% | -2.60% |
| Q1 2025 | +0.29% | -2.21% |
| Q2 2025 | +1.70% | +3.23% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
