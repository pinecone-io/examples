CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100

FEE SCHEDULE AMENDMENT

Amendment to Investment Advisory Agreement — DOC-AdvisoryAgreement-2016-001

| Document ID DOC-FeeAmendment-2021-001 | Effective Date July 1, 2021 | Amends DOC-AdvisoryAgreement-2016-001 |
| --- | --- | --- |

This Fee Schedule Amendment ("Amendment") is entered into as of June 20, 2021, by and between Clearwater Wealth Partners ("Adviser") and Alex Chen and Sam Chen (collectively, "Client"), household reference HH-CHEN-001. This Amendment modifies Section 5 (Advisory Fees and Billing) of the Investment Advisory Agreement dated February 1, 2016 (DOC-AdvisoryAgreement-2016-001). All other provisions of the original Agreement remain in full force and effect.

1. TRIGGERING EVENTS FOR THIS AMENDMENT

The following events, individually and collectively, have prompted the parties to review and amend the advisory fee arrangement pursuant to the Event-Driven Review provisions of Section 6 of the original Agreement:

| Event Reference | Event Description | Date / Quarter |
| --- | --- | --- |
| EventID-2021-01 | Home purchase — down payment funded from ACCT-TX01 in Q3 2021; material liquidity event; account balance review required | 2021-Q3 (pending) |
| AUM Growth Review | Household AUM reached approximately $870,000 at 2021-Q2 end, approaching the $1,000,000 advisory fee tier threshold; fee schedule review triggered per Section 6 of original Agreement | 2021-Q2 ($870,000) |
| IPS-2020 Amendment | Post-COVID IPS shift (DOC-IPSAmendment-2020-001, eff. 2020-06-15) introduced enhanced Fixed Income and Cash management; expanded advisory services warranting tiered fee recalibration | 2020-Q2 (prior event) |
| 529 Account Addition | Opening of ACCT-529A (Maya) and ACCT-529B (Eli) in May 2020; education planning coordination added to advisory mandate; accounts formally incorporated into fee base | 2020-Q2 |

2. PRIOR FEE SCHEDULE (SUPERSEDED)

The following fee schedule established under DOC-AdvisoryAgreement-2016-001 is hereby superseded in its entirety effective July 1, 2021:

| AUM Tier | Fee Rate | Status |
| --- | --- | --- |
| All assets under management (flat) | 1.00% per annum | SUPERSEDED as of July 1, 2021 |

3. AMENDED FEE SCHEDULE (EFFECTIVE JULY 1, 2021)

Effective July 1, 2021, the following tiered fee schedule replaces the flat 1.00% rate in its entirety. Fees continue to be billed quarterly in arrears based on the average daily balance of all Covered Accounts during each calendar quarter. The tiered rate is applied to the total household AUM across all Covered Accounts on an aggregated basis.

| Tier | AUM Band | Annual Fee Rate | Quarterly Rate |
| --- | --- | --- | --- |
| 1 | First $1,500,000 | 0.85% per annum | 0.2125% per quarter |
| 2 | Next $1,500,000 | 0.70% per annum | 0.1750% per quarter |
| 3 | Assets above $3,000,000 | 0.55% per annum | 0.1375% per quarter |

Estimated annual advisory fee at amendment effective date (approximate AUM: $905,000 at 2021-Q3 end, post home purchase): approximately $7,693 per year ($905,000 × 0.85%), billed at approximately $1,923 per quarter. At AUM of $870,000 (2021-Q2 end): approximately $7,395/year. Prorated fee adjustment for Q3 2021 will be calculated from July 1, 2021 through September 30, 2021 under the new rate.

4. COVERED ACCOUNTS — UPDATED SCOPE

Effective concurrent with this Amendment, the following accounts are confirmed as Covered Accounts subject to advisory fees, supplementing the original three accounts listed in DOC-AdvisoryAgreement-2016-001:

| Account ID | Nickname | Registration | Fee Status |
| --- | --- | --- | --- |
| ACCT-TX01 | Taxable Brokerage | Joint (Chen) | Original — Covered |
| ACCT-IRA1 | Alex Trad. IRA | Individual (J.) | Original — Covered |
| ACCT-RIRA | Alex Roth IRA | Individual (J.) | Original — Covered |
| ACCT-529A | 529 Maya | Household | Added — Covered (eff. 2021-07-01) |
| ACCT-529B | 529 Eli | Household | Added — Covered (eff. 2021-07-01) |

Note: ACCT-CASH (Cash Management Account, opened January 1, 2019) has been maintained as an advisory account since inception but was not formally enumerated in the original Agreement. This Amendment confirms ACCT-CASH as a Covered Account subject to advisory fees on the average daily balance. ACCT-401R (Alex 401(k) Rollover, opened 2017-08-15) was consolidated into ACCT-IRA1 by March 31, 2018 and is no longer a separate account.

5. EVENT-DRIVEN REVIEW ACKNOWLEDGEMENT

The parties acknowledge that this Amendment was initiated pursuant to the Event-Driven Review provisions (Section 6) of the original Agreement. The following forward-looking event triggers are noted for planning purposes:

| Anticipated Event | Advisory Action Required |
| --- | --- |
| Alex’s equity comp (RSU) vesting schedule — EventID-2018-01 (active; multi-year vesting program) | Annual concentration review; tax-aware liquidation plan; IPS single-stock cap monitoring (<10%) |
| AUM crossing $1,500,000 Tier 1 threshold — projected mid-2023 absent market disruption | Automatic Tier 2 fee rate (0.70%) applies; no amendment required; Adviser to provide updated fee disclosure |
| Estate planning documents — revocable trust created 2019 (EventID-2019-01); periodic beneficiary review required | Confirm custodial beneficiary designations align with trust; coordinate with estate attorney Westfield & Baker LLP |

EXECUTION PAGE

DOC-FeeAmendment-2021-001 • Effective July 1, 2021 • Clearwater Wealth Partners / Chen Household (HH-CHEN-001)

IN WITNESS WHEREOF, the parties have executed this Amendment as of the effective date set forth above. This Amendment is incorporated into and forms part of the Investment Advisory Agreement (DOC-AdvisoryAgreement-2016-001) between Clearwater Wealth Partners and the Chen Household (HH-CHEN-001). All other terms and conditions of the original Agreement remain unchanged except as expressly modified herein.

| ______________________________________Signature — Primary ClientAlex ChenDate: July 1, 2021 | ______________________________________Signature — Co-ClientSam ChenDate: July 1, 2021 |
| --- | --- |
| ______________________________________Signature — Adviser RepresentativeMorgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date: July 1, 2021 |  |

SYNTHETIC DEMONSTRATION DOCUMENT — NWP-DEMO-HH-CHEN-001 v1.2 • NOT INVESTMENT, LEGAL, OR TAX ADVICE • Clearwater Wealth Partners • Wayzata, MN 55391
