CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJanuary 1 - March 31, 2017Quarter 1, 2017 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q1 2017 Portfolio | Q1 2017 Blend Bench. | Excess Return | YTD 2017 Portfolio | YTD 2017 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +3.52% | +4.49% | -0.97% | +3.52% | +4.49% |
| Benchmark Return | +4.49% | +6.06% | +0.82% | — | — |

▪ Beginning Value: $274,052 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $286,751

▪ Dividends & Interest: $1,680 ▪ Market Gain / (Loss): $8,214 ▪ Advisory Fees: ($195)

MARKET COMMENTARY

Global equities extended their post-election rally into 2017, with the S&P 500 gaining 6.1% in Q1 — one of its best first quarters in years. Economic data remained solid, and corporate earnings beat expectations broadly. International developed and emerging markets also outperformed, with the dollar weakening slightly from its late-2016 highs. The Fed raised rates in March, as expected. Bond markets absorbed the hike relatively well. Your portfolio benefited from strong equity positioning and solid income generation.

| Benchmark | Q1 2017 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +6.06% | 70% | +4.24% |
| Bloomberg US Aggregate (Fixed Income) | +0.82% | 30% | +0.25% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 27% | █████████████  27% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,586 | $8,535 | $-51 | -0.6% |
| American Funds EuroPacific | SEEGX | Intl Equity | $23,582 | $24,906 | +$1,325 | +5.6% |
| MFS Mid Cap Growth | MFEKX | US Equity | $18,588 | $19,889 | +$1,301 | +7.0% |
| American Funds AMCAP | AMCPX | US Equity | $28,819 | $31,238 | +$2,420 | +8.4% |
| American Funds Growth | AGTHX | US Equity | $24,772 | $27,090 | +$2,318 | +9.4% |
| American Funds New World | ANCFX | Intl Equity | $16,208 | $17,050 | +$843 | +5.2% |
| American Funds Income | AMRMX | US Equity | $10,376 | $10,500 | +$124 | +1.2% |
| American Funds Investment | AIVSX | US Equity | $27,633 | $29,273 | +$1,640 | +5.9% |
| American Funds New Persp. | ANWPX | Intl Equity | $12,637 | $13,989 | +$1,352 | +10.7% |
| American Funds Balanced | AMFFX | US Equity | $9,300 | $9,408 | +$108 | +1.2% |
| American Funds Bond | ABNDX | Fixed Income | $17,636 | $16,832 | $-804 | -4.6% |
| American High Income Trust | AHITX | Fixed Income | $14,184 | $13,557 | $-627 | -4.4% |
| American Funds New Econ. | ANEFX | US Equity | $8,591 | $8,967 | +$377 | +4.4% |
| iShares Core S&P 500 | IVV | US Equity | $31,913 | $35,391 | +$3,478 | +10.9% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,017 | $14,208 | $-810 | -5.4% |
| SPDR Gold Shares | GLD | Alternatives | $6,210 | $5,915 | $-295 | -4.8% |
| TOTAL PORTFOLIO |  |  | $274,052 | $286,751 | +$12,699 | +4.6% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $274,052.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,502.00 |
| Interest Income | $178.00 |
| Market Appreciation / (Depreciation) | $8,214.00 |
| Advisory & Management Fees | ($195.00) |
| Net Change for Period | $12,699.00 |
| Ending Account Value | $286,751.00 |

Advisor Commentary: Portfolio performance of +3.52% was behind the blended benchmark (+4.49%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q2 2016 | +1.62% | +2.33% |
| Q3 2016 | +2.74% | +2.75% |
| Q4 2016 | +2.94% | +1.68% |
| Q1 2017 | +3.52% | +4.49% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
