CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2017Quarter 2, 2017 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2017 Portfolio | Q2 2017 Blend Bench. | Excess Return | YTD 2017 Portfolio | YTD 2017 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +2.95% | +2.60% | +0.35% | +6.57% | +7.20% |
| Benchmark Return | +2.60% | +3.09% | +1.45% | — | — |

▪ Beginning Value: $286,751 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $298,251

▪ Dividends & Interest: $1,779 ▪ Market Gain / (Loss): $6,918 ▪ Advisory Fees: ($197)

MARKET COMMENTARY

Risk assets continued to perform well in Q2 2017, supported by synchronized global growth and subdued inflation. Technology stocks were standout performers, while energy lagged amid renewed oil price weakness. The Fed held steady in Q2 but signaled further hikes ahead. International equity exposure added value as European markets surged on Macron's election victory in France. Your diversified equity holdings — including domestic and international funds — contributed to solid portfolio appreciation.

| Benchmark | Q2 2017 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +3.09% | 70% | +2.16% |
| Bloomberg US Aggregate (Fixed Income) | +1.45% | 30% | +0.43% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 42% | █████████████████████  42% |
| International Equity | 18% | █████████  18% |
| Fixed Income | 27% | █████████████  27% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,535 | $8,877 | +$342 | +4.0% |
| American Funds EuroPacific | SEEGX | Intl Equity | $24,906 | $25,905 | +$999 | +4.0% |
| MFS Mid Cap Growth | MFEKX | US Equity | $19,889 | $20,687 | +$798 | +4.0% |
| American Funds AMCAP | AMCPX | US Equity | $31,238 | $32,491 | +$1,253 | +4.0% |
| American Funds Growth | AGTHX | US Equity | $27,090 | $28,176 | +$1,086 | +4.0% |
| American Funds New World | ANCFX | Intl Equity | $17,050 | $17,734 | +$684 | +4.0% |
| American Funds Income | AMRMX | US Equity | $10,500 | $10,921 | +$421 | +4.0% |
| American Funds Investment | AIVSX | US Equity | $29,273 | $30,447 | +$1,174 | +4.0% |
| American Funds New Persp. | ANWPX | Intl Equity | $13,989 | $14,550 | +$561 | +4.0% |
| American Funds Balanced | AMFFX | US Equity | $9,408 | $9,786 | +$377 | +4.0% |
| American Funds Bond | ABNDX | Fixed Income | $16,832 | $17,507 | +$675 | +4.0% |
| American High Income Trust | AHITX | Fixed Income | $13,557 | $14,101 | +$544 | +4.0% |
| American Funds New Econ. | ANEFX | US Equity | $8,967 | $9,327 | +$360 | +4.0% |
| iShares Core S&P 500 | IVV | US Equity | $35,391 | $36,811 | +$1,419 | +4.0% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $14,208 | $14,777 | +$570 | +4.0% |
| SPDR Gold Shares | GLD | Alternatives | $5,915 | $6,152 | +$237 | +4.0% |
| TOTAL PORTFOLIO |  |  | $286,751 | $298,251 | +$11,500 | +4.0% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $286,751.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,588.00 |
| Interest Income | $191.00 |
| Market Appreciation / (Depreciation) | $6,918.00 |
| Advisory & Management Fees | ($197.00) |
| Net Change for Period | $11,500.00 |
| Ending Account Value | $298,251.00 |

Advisor Commentary: Portfolio performance of +2.95% was in line with the blended benchmark (+2.60%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2016 | +2.74% | +2.75% |
| Q4 2016 | +2.94% | +1.68% |
| Q1 2017 | +3.52% | +4.49% |
| Q2 2017 | +2.95% | +2.60% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
