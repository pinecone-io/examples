CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2016Quarter 2, 2016 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2016 Portfolio | Q2 2016 Blend Bench. | Excess Return | YTD 2016 Portfolio | YTD 2016 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.62% | +2.33% | -0.70% | +0.37% | +2.08% |
| Benchmark Return | +2.33% | +2.34% | +2.29% | — | — |

▪ Beginning Value: $246,265 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $253,290

▪ Dividends & Interest: $1,460 ▪ Market Gain / (Loss): $2,754 ▪ Advisory Fees: ($189)

MARKET COMMENTARY

Markets stabilized and advanced in Q2 despite a dramatic late-quarter shock: the U.K.'s surprise vote to leave the European Union (Brexit) sent global equities sharply lower in the final days of June. U.S. markets recovered quickly, with the S&P 500 posting a modest gain for the quarter. Energy prices rebounded from multi-year lows, boosting commodity-linked assets. The Fed held rates steady amid Brexit uncertainty. Your portfolio's U.S. equity and bond blend contributed to positive performance, with income reinvestment adding to overall returns.

| Benchmark | Q2 2016 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +2.34% | 70% | +1.64% |
| Bloomberg US Aggregate (Fixed Income) | +2.29% | 30% | +0.69% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 41% | ████████████████████  41% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 28% | ██████████████  28% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,715 | $7,935 | +$220 | +2.9% |
| American Funds EuroPacific | SEEGX | Intl Equity | $21,191 | $21,795 | +$604 | +2.9% |
| MFS Mid Cap Growth | MFEKX | US Equity | $16,703 | $17,180 | +$476 | +2.9% |
| American Funds AMCAP | AMCPX | US Equity | $25,897 | $26,635 | +$739 | +2.9% |
| American Funds Growth | AGTHX | US Equity | $22,260 | $22,895 | +$635 | +2.9% |
| American Funds New World | ANCFX | Intl Equity | $14,564 | $14,980 | +$415 | +2.9% |
| American Funds Income | AMRMX | US Equity | $9,324 | $9,590 | +$266 | +2.9% |
| American Funds Investment | AIVSX | US Equity | $24,831 | $25,540 | +$708 | +2.9% |
| American Funds New Persp. | ANWPX | Intl Equity | $11,356 | $11,680 | +$324 | +2.9% |
| American Funds Balanced | AMFFX | US Equity | $8,357 | $8,595 | +$238 | +2.9% |
| American Funds Bond | ABNDX | Fixed Income | $15,848 | $16,300 | +$452 | +2.9% |
| American High Income Trust | AHITX | Fixed Income | $12,746 | $13,110 | +$364 | +2.9% |
| American Funds New Econ. | ANEFX | US Equity | $7,720 | $7,940 | +$220 | +2.9% |
| iShares Core S&P 500 | IVV | US Equity | $28,677 | $29,495 | +$818 | +2.9% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,495 | $13,880 | +$385 | +2.9% |
| SPDR Gold Shares | GLD | Alternatives | $5,581 | $5,740 | +$159 | +2.9% |
| TOTAL PORTFOLIO |  |  | $246,265 | $253,290 | +$7,025 | +2.9% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $246,265.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,318.00 |
| Interest Income | $142.00 |
| Market Appreciation / (Depreciation) | $2,754.00 |
| Advisory & Management Fees | ($189.00) |
| Net Change for Period | $7,025.00 |
| Ending Account Value | $253,290.00 |

Advisor Commentary: Portfolio performance of +1.62% was behind the blended benchmark (+2.33%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q1 2016 | -1.23% | -0.24% |
| Q2 2016 | +1.62% | +2.33% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
