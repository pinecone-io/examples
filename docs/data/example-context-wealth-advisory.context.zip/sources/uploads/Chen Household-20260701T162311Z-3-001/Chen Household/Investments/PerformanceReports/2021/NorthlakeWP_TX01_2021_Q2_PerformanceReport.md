CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2021Quarter 2, 2021 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2021 Portfolio | Q2 2021 Blend Bench. | Excess Return | YTD 2021 Portfolio | YTD 2021 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +4.75% | +3.92% | +0.83% | +8.67% | +5.83% |
| Benchmark Return | +3.92% | +8.40% | -1.55% | — | — |

▪ Beginning Value: $469,159 ▪ Contributions / (Withdrawals): $-77,000 ▪ Ending Value: $412,610

▪ Dividends & Interest: $2,062 ▪ Market Gain / (Loss): $18,614 ▪ Advisory Fees: ($225)

MARKET COMMENTARY

Q2 2021 was marked by an important portfolio event: a $80,000 withdrawal was made to facilitate a home purchase. Markets remained supportive, with the S&P 500 gaining 8.6% as the reopening accelerated, infrastructure spending passed, and corporate earnings exceeded expectations. Inflation began rising more than anticipated — CPI reached 5.0% — though the Fed maintained it was 'transitory.' Your portfolio's investment performance was strong despite the significant outflow, demonstrating the portfolio's resilience and the value of maintaining a long-term investment strategy even through major life events.

| Benchmark | Q2 2021 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +8.40% | 55% | +4.62% |
| Bloomberg US Aggregate (Fixed Income) | -1.55% | 45% | -0.70% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 43% | █████████████████████  43% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 24% | ████████████  24% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $8,322 | $7,319 | $-1,003 | -12.1% |
| American Funds EuroPacific | SEEGX | Intl Equity | $41,766 | $36,732 | $-5,034 | -12.1% |
| MFS Mid Cap Growth | MFEKX | US Equity | $37,836 | $33,276 | $-4,560 | -12.1% |
| American Funds AMCAP | AMCPX | US Equity | $57,724 | $50,766 | $-6,958 | -12.1% |
| American Funds Growth | AGTHX | US Equity | $48,980 | $43,076 | $-5,904 | -12.1% |
| American Funds New World | ANCFX | Intl Equity | $29,962 | $26,351 | $-3,611 | -12.1% |
| American Funds Income | AMRMX | US Equity | $15,977 | $14,051 | $-1,926 | -12.1% |
| American Funds Investment | AIVSX | US Equity | $50,952 | $44,810 | $-6,141 | -12.1% |
| American Funds New Persp. | ANWPX | Intl Equity | $23,628 | $20,780 | $-2,848 | -12.1% |
| American Funds Balanced | AMFFX | US Equity | $14,884 | $13,090 | $-1,794 | -12.1% |
| American Funds Bond | ABNDX | Fixed Income | $18,158 | $15,970 | $-2,189 | -12.1% |
| American High Income Trust | AHITX | Fixed Income | $14,224 | $12,509 | $-1,714 | -12.1% |
| American Funds New Econ. | ANEFX | US Equity | $14,010 | $12,321 | $-1,689 | -12.1% |
| iShares Core S&P 500 | IVV | US Equity | $68,220 | $59,998 | $-8,223 | -12.1% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,540 | $13,667 | $-1,873 | -12.1% |
| SPDR Gold Shares | GLD | Alternatives | $8,978 | $7,895 | $-1,082 | -12.1% |
| TOTAL PORTFOLIO |  |  | $469,159 | $412,610 | $-56,549 | -12.1% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $469,159.00 |
| --- | --- |
| Contributions / (Withdrawals) | $-77,000.00 |
| Dividend Income | $1,988.00 |
| Interest Income | $74.00 |
| Market Appreciation / (Depreciation) | $18,614.00 |
| Advisory & Management Fees | ($225.00) |
| Net Change for Period | $-56,549.00 |
| Ending Account Value | $412,610.00 |

Advisor Commentary: Home purchase facilitated via $80,000 portfolio withdrawal ($77,000 net after fees). This was a planned liquidity event. Regular $1,000 monthly contributions continue.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2020 | +6.01% | +5.00% |
| Q4 2020 | +6.31% | +7.08% |
| Q1 2021 | +3.74% | +1.83% |
| Q2 2021 | +4.75% | +3.92% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
