CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODJuly 1 - September 30, 2024Quarter 3, 2024 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q3 2024 Portfolio | Q3 2024 Blend Bench. | Excess Return | YTD 2024 Portfolio | YTD 2024 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +1.07% | +5.48% | -4.40% | +4.97% | +15.28% |
| Benchmark Return | +5.48% | +5.60% | +5.25% | — | — |

▪ Beginning Value: $650,000 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $660,000

▪ Dividends & Interest: $4,156 ▪ Market Gain / (Loss): $3,109 ▪ Advisory Fees: ($265)

MARKET COMMENTARY

Q3 2024 was a strong quarter: the Fed finally began cutting rates in September (50bp cut), and both stocks and bonds responded positively. The S&P 500 gained 5.9% and bonds gained 5.3%, meaning the 60/40 portfolio had one of its best quarters in recent memory. Rate-sensitive sectors including utilities and REITs outperformed. The labor market showed modest cooling but remained healthy. Your balanced allocation was well-positioned to benefit from the rate-cutting environment, with both equity and fixed income contributing to returns.

| Benchmark | Q3 2024 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +5.60% | 65% | +3.64% |
| Bloomberg US Aggregate (Fixed Income) | +5.25% | 35% | +1.84% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 44% | ██████████████████████  44% |
| International Equity | 19% | █████████  19% |
| Fixed Income | 23% | ███████████  23% |
| Alternatives | 5% | ██  5% |
| Cash & Money Market | 9% | ████  9% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $19,188 | $19,483 | +$295 | +1.5% |
| American Funds EuroPacific | SEEGX | Intl Equity | $55,405 | $56,258 | +$852 | +1.5% |
| MFS Mid Cap Growth | MFEKX | US Equity | $51,145 | $51,932 | +$787 | +1.5% |
| American Funds AMCAP | AMCPX | US Equity | $77,886 | $79,084 | +$1,198 | +1.5% |
| American Funds Growth | AGTHX | US Equity | $70,075 | $71,153 | +$1,078 | +1.5% |
| American Funds New World | ANCFX | Intl Equity | $43,330 | $43,996 | +$667 | +1.5% |
| American Funds Income | AMRMX | US Equity | $23,216 | $23,573 | +$357 | +1.5% |
| American Funds Investment | AIVSX | US Equity | $73,152 | $74,277 | +$1,125 | +1.5% |
| American Funds New Persp. | ANWPX | Intl Equity | $33,867 | $34,388 | +$521 | +1.5% |
| American Funds Balanced | AMFFX | US Equity | $20,371 | $20,685 | +$313 | +1.5% |
| American Funds Bond | ABNDX | Fixed Income | $18,719 | $19,007 | +$288 | +1.5% |
| American High Income Trust | AHITX | Fixed Income | $15,169 | $15,402 | +$233 | +1.5% |
| American Funds New Econ. | ANEFX | US Equity | $19,425 | $19,723 | +$299 | +1.5% |
| iShares Core S&P 500 | IVV | US Equity | $97,535 | $99,036 | +$1,501 | +1.5% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $15,164 | $15,398 | +$233 | +1.5% |
| SPDR Gold Shares | GLD | Alternatives | $16,352 | $16,604 | +$252 | +1.5% |
| TOTAL PORTFOLIO |  |  | $650,000 | $660,000 | +$10,000 | +1.5% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $650,000.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $3,414.00 |
| Interest Income | $742.00 |
| Market Appreciation / (Depreciation) | $3,109.00 |
| Advisory & Management Fees | ($265.00) |
| Net Change for Period | $10,000.00 |
| Ending Account Value | $660,000.00 |

Advisor Commentary: Federal Reserve began its rate-cutting cycle in September. This is expected to benefit fixed income holdings over the medium term and may support further equity market appreciation.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q4 2023 | +3.69% | +9.71% |
| Q1 2024 | +2.74% | +6.61% |
| Q2 2024 | +1.09% | +2.51% |
| Q3 2024 | +1.07% | +5.48% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
