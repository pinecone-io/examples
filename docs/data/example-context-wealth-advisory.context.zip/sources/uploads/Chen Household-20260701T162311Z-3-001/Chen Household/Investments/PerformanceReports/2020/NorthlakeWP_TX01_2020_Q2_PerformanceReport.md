CLEARWATER WEALTH PARTNERS

Investment Performance Report

| CLIENT:  Chen Household — Alex & Sam ChenACCOUNT:  TX01 — Taxable Joint InvestmentADVISOR:  Morgan Park, CFP® | Clearwater Wealth Partners | REPORTING PERIODApril 1 - June 30, 2020Quarter 2, 2020 |
| --- | --- |

PORTFOLIO PERFORMANCE SUMMARY

| Metric | Q2 2020 Portfolio | Q2 2020 Blend Bench. | Excess Return | YTD 2020 Portfolio | YTD 2020 Blend Bench. |
| --- | --- | --- | --- | --- | --- |
| Portfolio Return | +13.42% | +12.29% | +1.12% | -3.39% | +0.43% |
| Benchmark Return | +12.29% | +20.54% | -0.08% | — | — |

▪ Beginning Value: $343,690 ▪ Contributions / (Withdrawals): $3,000 ▪ Ending Value: $393,002

▪ Dividends & Interest: $1,912 ▪ Market Gain / (Loss): $44,618 ▪ Advisory Fees: ($218)

MARKET COMMENTARY

Markets staged an extraordinary recovery in Q2 2020 despite the deepest economic contraction since the Great Depression. The S&P 500 gained 20.5%, its best quarter since 1998, fueled by massive fiscal and monetary stimulus, vaccine optimism, and a faster-than-expected economic reopening. GDP collapsed ~32% annualized in Q2, yet equities surged. The Fed's balance sheet expanded dramatically. Low-quality credit and growth stocks led the rally. Your portfolio recovered substantially from Q1 lows, with equity holdings driving gains while fixed income held steady.

| Benchmark | Q2 2020 Return | Weight | Contribution |
| --- | --- | --- | --- |
| S&P 500 (Equity Proxy) | +20.54% | 60% | +12.32% |
| Bloomberg US Aggregate (Fixed Income) | -0.08% | 40% | -0.03% |

ASSET ALLOCATION

| Asset Class | Allocation | Bar |
| --- | --- | --- |
| U.S. Equity | 39% | ███████████████████  39% |
| International Equity | 17% | ████████  17% |
| Fixed Income | 30% | ███████████████  30% |
| Alternatives | 6% | ███  6% |
| Cash & Money Market | 8% | ████  8% |

HOLDINGS PERFORMANCE

| Fund Name | Symbol | Category | Beg. Value | End Value | Change $ | Chg % |
| --- | --- | --- | --- | --- | --- | --- |
| American Funds Money Mkt | AIMMA | Cash | $7,633 | $8,728 | +$1,095 | +14.3% |
| American Funds EuroPacific | SEEGX | Intl Equity | $30,493 | $34,868 | +$4,375 | +14.3% |
| MFS Mid Cap Growth | MFEKX | US Equity | $26,590 | $30,405 | +$3,815 | +14.3% |
| American Funds AMCAP | AMCPX | US Equity | $38,860 | $44,435 | +$5,576 | +14.3% |
| American Funds Growth | AGTHX | US Equity | $35,325 | $40,393 | +$5,068 | +14.3% |
| American Funds New World | ANCFX | Intl Equity | $21,200 | $24,242 | +$3,042 | +14.3% |
| American Funds Income | AMRMX | US Equity | $11,725 | $13,408 | +$1,682 | +14.3% |
| American Funds Investment | AIVSX | US Equity | $36,068 | $41,243 | +$5,175 | +14.3% |
| American Funds New Persp. | ANWPX | Intl Equity | $17,297 | $19,779 | +$2,482 | +14.3% |
| American Funds Balanced | AMFFX | US Equity | $10,978 | $12,553 | +$1,575 | +14.3% |
| American Funds Bond | ABNDX | Fixed Income | $16,558 | $18,933 | +$2,376 | +14.3% |
| American High Income Trust | AHITX | Fixed Income | $12,655 | $14,470 | +$1,816 | +14.3% |
| American Funds New Econ. | ANEFX | US Equity | $10,424 | $11,920 | +$1,496 | +14.3% |
| iShares Core S&P 500 | IVV | US Equity | $45,736 | $52,299 | +$6,562 | +14.3% |
| Vanguard Total Bond Mkt | BND | Fixed Income | $13,952 | $15,954 | +$2,002 | +14.3% |
| SPDR Gold Shares | GLD | Alternatives | $8,194 | $9,370 | +$1,176 | +14.3% |
| TOTAL PORTFOLIO |  |  | $343,690 | $393,002 | +$49,312 | +14.3% |

ACCOUNT ACTIVITY & ADVISOR NOTES

| Beginning Account Value | $343,690.00 |
| --- | --- |
| Contributions / (Withdrawals) | $3,000.00 |
| Dividend Income | $1,814.00 |
| Interest Income | $98.00 |
| Market Appreciation / (Depreciation) | $44,618.00 |
| Advisory & Management Fees | ($218.00) |
| Net Change for Period | $49,312.00 |
| Ending Account Value | $393,002.00 |

Advisor Commentary: Portfolio performance of +13.42% was ahead of the blended benchmark (+12.29%) for the quarter. The portfolio remains on track with the long-term investment plan. Regular monthly contributions continue as planned.

TRAILING QUARTERLY PERFORMANCE

| Period | Portfolio | Blend Benchmark |
| --- | --- | --- |
| Q3 2019 | +1.41% | +1.92% |
| Q4 2019 | +5.40% | +6.19% |
| Q1 2020 | -14.82% | -10.56% |
| Q2 2020 | +13.42% | +12.29% |

This report is provided for informational purposes only and does not constitute investment advice. Past performance is not indicative of future results. Returns are calculated using the Modified Dietz method and may differ from time-weighted returns. The blended benchmark consists of the S&P 500 Index (equity component) and the Bloomberg U.S. Aggregate Bond Index (fixed income component). Benchmark weights vary by period based on target allocation. All figures are approximate. Holdings data is representative of proportional allocations based on annual period-end values. Please refer to your official account statement for verified account data. Clearwater Wealth Partners is a registered investment adviser.
