CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | April–June 2021Household AUM: $870,000Policy: IPS-2020  |  Alloc: 58/37/5 |
| --- | --- |

Mid-Year Market Commentary — Q2 2021

Reopening Euphoria, Inflation Emergence & the Home Purchase Milestone

EXECUTIVE SUMMARY

H1 2021 delivered strong equity returns as vaccine rollouts accelerated, economies reopened, and fiscal stimulus flooded consumer balance sheets. The S&P 500 gained 15.3% in H1 — extending the remarkable 2020 recovery. However, the narrative was complicated by the sharpest rise in inflation since the 1990s: CPI reached 5.0% by May, well above the Fed's target. The Fed maintained its 'transitory' assessment. For the Chen Household, Q2 2021 was defined by a major life event: the purchase of a new home, financed in part through a planned liquidation of taxable account holdings. Household AUM reached $870,000 by Q2 end despite the portfolio outflow.

MARKET ENVIRONMENT

Q2 2021 saw a broadening of equity market leadership from technology to 'reopening' beneficiaries: airlines, hotels, restaurants, and energy stocks surged as economic activity normalized. The S&P 500 gained 8.6% in Q2. The 10-year Treasury yield rose from 0.9% at year-start to 1.7% by March before stabilizing near 1.5% at Q2 end — causing significant pain in long-duration bonds. The Bloomberg U.S. Aggregate fell 3.4% in Q1 (its worst quarter in decades) before recovering modestly. Value stocks significantly outperformed growth in Q1 before growth reclaimed leadership in Q2.

KEY THEMES

1. Home Purchase Milestone (EventID-2021-01 / DecisionID-2021-141): The Chens closed on a new home in the Minnetonka area, funded in part by a planned liquidation from ACCT-TX01. The cash staging strategy in ACCT-CASH was executed over Q1–Q2, with the final settlement in Q3.

2. Inflation Shock: CPI at 5.0% was the highest reading since 1992. The debate between 'transitory' and 'persistent' inflation would define the remainder of 2021 and ultimately prove consequential in 2022. The UTIPX (TIPS) sleeve provides meaningful inflation hedging.

3. Meme Stock Volatility (GME, AMC): The January/February meme stock episode highlighted the role of retail investors and social media in short-term market dynamics. A disciplined, long-term approach remains the appropriate response.

4. Fee Schedule Amendment (DOC-FeeAmendment-2021-001): The advisory fee agreement was updated to a tiered structure (0.85% / 0.70% / 0.55%) effective July 1, 2021 — a favorable change for the household as AUM grows.

5. Bond Market Recalibration: The sharp rise in yields in Q1 2021 caused bonds to decline simultaneously with the early equity wobbles — a reminder that bond protection works best in deflationary crises, not inflationary environments.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +10,000     |     Household AUM: $870,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. The home purchase liquidation (EventID-2021-01) reduced ACCT-TX01 by approximately $80,000 but was a planned outflow. The household's total AUM at $870,000 remains on the retirement trajectory for GoalID-2016-01.

2. Under IPS-2020 (60/35/5), the remaining portfolio allocation was rebalanced post-liquidation. The fixed income allocation (35%) includes UTIPX with inflation-linked returns — particularly relevant given CPI running at 5%.

3. The 529 accounts (ACCT-529A, ACCT-529B) continue to grow with the market recovery. Regular contributions should be established now that the home purchase cash flow impact is absorbed.

4. The new tiered advisory fee structure (effective July 1) reduces the fee burden as AUM scales — a meaningful change that compounds favorably over the remaining 15+ year investment horizon.

FORWARD LOOK & PLANNING PRIORITIES

H2 2021 will be shaped by the Fed's tapering timeline, the inflation trajectory, and the fiscal cliff as pandemic-era stimulus programs expire. The housing market boom is creating affordability challenges but the Chens' home purchase is now complete. Key priorities: re-establishing regular contributions after the home purchase outflow, reviewing mortgage payment impact on monthly cash flow, and ensuring the NLTK diversification plan remains on track.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2021-01: Home purchase completed; $80K outflow from ACCT-TX01 (DecisionID-2021-141)

◆ DOC-FeeAmendment-2021-001: Tiered fee structure effective 2021-07-01

References: DOC-IPSAmendment-2020-001 | DOC-FeeAmendment-2021-001 | DecisionID-2021-141

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
