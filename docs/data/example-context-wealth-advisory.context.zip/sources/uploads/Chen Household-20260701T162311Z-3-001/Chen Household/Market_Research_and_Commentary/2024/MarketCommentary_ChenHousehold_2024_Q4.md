CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | October–December 2024Household AUM: $1,285,000Policy: IPS-2020  |  Alloc: 62/33/5 |
| --- | --- |

Year-End Market Commentary — Q4 2024

The Fed Cuts, Markets Pause, and Beneficiaries Are Corrected

EXECUTIVE SUMMARY

2024 was another strong year for equity investors, with the S&P 500 gaining 25.0% for the full year. The Federal Reserve finally began cutting rates in September (a 50bp cut), followed by additional 25bp cuts in November and December — bringing the fed funds rate to 4.25–4.50%. However, Q4 itself was more subdued: the S&P 500 declined 2.4% as rates reversed higher on stronger-than-expected economic data, and bonds fell. The household's critical estate planning milestone was completed: the beneficiary mismatch on ACCT-IRA1 and ACCT-RIRA was corrected, aligning all accounts with the 2019 trust. AUM closed 2024 at $1,285,000.

MARKET ENVIRONMENT

The Q4 2024 narrative was one of initial euphoria (post-election equity surge on tax cut and deregulation expectations) followed by a December correction as the Fed's rate path proved less accommodative than markets expected. The 10-year yield rose from 3.6% at September's rate cut to 4.6% by year-end — reversing the bond gains of Q3. The Fed's December dot plot showed only two cuts expected for 2025 — a hawkish surprise that triggered a sharp bond selloff and equity correction in the final weeks of the year.

KEY THEMES

1. Fed Rate Cuts Began, But Fewer Than Expected: Three cuts delivered in 2024 (total -100bp) brought rates from 5.25–5.50% to 4.25–4.50%. The 'higher for longer' thesis moderated but did not fully resolve — rates remain meaningfully above zero.

2. Election Year: Policy Uncertainty Ahead: The election outcome introduces potential policy changes in trade, taxes, and regulation that may affect markets in 2025. Historical evidence suggests maintaining strategic allocation through policy uncertainty is superior to tactical repositioning.

3. Estate Milestone: Beneficiary Mismatch Corrected (EventID-2024-01 Resolved): DOC-BeneficiaryForm-2024-001 was executed, correcting the IRA1 and RIRA contingent beneficiary from Alex's parent to trust/children alignment. The healthcare directive was also updated.

4. AI Capex Continues at Extraordinary Scale: Despite questions about ROI, corporate AI investment accelerated further in H2 2024. The equity market assigned significant value to AI optionality — whether justified will be revealed over the coming decade.

5. 2024 Tax Year: Moderate Complexity: Net capital gains of approximately $14,500 — well below the 2023 liquidity event year. DAF distributions from GoalID-2023-01 continued to support the charitable deduction strategy.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +12,000     |     Household AUM: $1,285,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. Household AUM of $1,285,000 closes 2024 at a new high. The retirement goal (GoalID-2016-01) funded ratio continues to improve. At current trajectory, early retirement optionality is emerging ahead of the original plan.

2. Under IPS-2020 (60/35/5), the Q4 bond selloff was a headwind for the 35% fixed income sleeve. The 10-year at 4.6% entering 2025 actually represents an attractive starting yield — forward-looking bond returns are reasonable.

3. Estate planning is now complete for this cycle: trust (2019), beneficiary forms corrected (2024), healthcare directives updated. A 5-year trust review should be calendared for 2024 given the 2019 establishment date.

4. A pre-retirement planning conversation should begin in earnest in 2025 — including bucket strategy, Social Security claiming analysis (RecID-2025-02), and cash flow modeling.

FORWARD LOOK & PLANNING PRIORITIES

2025 arrives with important planning milestones: the IPS-2025 bucket strategy discussion, a college funding review for Maya (7 years to projected enrollment), and Social Security analysis. The macro environment features solid growth, moderating inflation, and a Fed in pause mode. The household's financial position — over $1.28M in AUM, a paid-down mortgage, and strong earning years ahead — reflects the power of consistent, disciplined wealth management across a decade of market cycles.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2024-01 resolved: Beneficiary forms corrected; healthcare directive updated; estate now fully aligned with trust

References: DOC-BeneficiaryForm-2024-001 | DOC-Trust-2019-001 | DOC-IPSAmendment-2020-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
