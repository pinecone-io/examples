CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | October–December 2021Household AUM: $952,000Policy: IPS-2020  |  Alloc: 60/35/5 |
| --- | --- |

Year-End Market Commentary — Q4 2021

A Strong Year Ends With Inflation's Shadow and Fed's Pivot on Tapering

EXECUTIVE SUMMARY

2021 delivered another exceptional year for equities, with the S&P 500 gaining 28.7% — its third consecutive year of double-digit returns, an outcome few would have predicted in the depths of the COVID crisis. The recovery was powered by strong earnings growth, ongoing fiscal stimulus, and accommodative monetary policy. However, the year ended on a cautionary note: inflation proved far more persistent than the Fed's 'transitory' characterization, and the Fed accelerated its tapering schedule in November, setting the stage for rate hikes in 2022. The Omicron variant caused late-year volatility but markets ultimately recovered. Household AUM reached $952,000 — within sight of $1 million.

MARKET ENVIRONMENT

Q4 2021 delivered 11.0% for the S&P 500 despite the Omicron scare and Fed hawkishness. The full year saw broad-based gains: large-cap growth +27%, value +24%, REITs +46%, and energy stocks +54% on surging commodity prices. Fixed income was the exception: the Bloomberg U.S. Aggregate returned -1.5% for the year — its first negative year since 2013 — as rising rate expectations pressured bond prices. The 10-year yield climbed from 0.9% to 1.5% over the year. The Fed announced in November that it would taper at double the original pace, completing asset purchase reduction by March 2022.

KEY THEMES

1. Inflation Persistence Confirmed: CPI reached 7.0% in December 2021 — the highest reading since 1982 — forcing the Fed to abandon the 'transitory' narrative and pivot aggressively toward tightening. This sets up 2022 as a challenging year for rate-sensitive assets.

2. Fed Tapering and Hike Signals: The Fed's November tapering acceleration and December dot plot (signaling 3 hikes in 2022) represented a major shift in the monetary policy regime — from maximum stimulus to normalization.

3. Equity Resilience Despite Rate Fears: The S&P 500's 28.7% return demonstrates the market's capacity to absorb early-stage rate normalization when earnings growth remains strong. Earnings grew approximately 45% in 2021.

4. Bond Market Headwinds Confirmed: The -1.5% total return for the Bloomberg Agg in 2021 previews the risks ahead in 2022. The IPS-2020's fixed income sleeve (35%) contains rate-sensitive assets that will face headwinds if the Fed tightens aggressively.

5. Household Milestone: AUM approaching $1M: Consistent contributions, disciplined investing through COVID, and strong market returns have brought the household from ~$410K at IPS-2016 inception to nearly $1M in just 5+ years.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +10,000     |     Household AUM: $952,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. Household AUM of $952,000 reflects strong investment performance and continued contributions despite the $80K home purchase outflow in Q3 2021. The retirement goal (GoalID-2016-01) confidence level has improved materially.

2. Under IPS-2020 (60/35/5), the fixed income sleeve's 35% weight is a headwind if rates rise significantly in 2022. The duration risk within UCBIX and UTIPX warrants a conversation about whether to shorten duration or increase the STBIX allocation.

3. Annual rebalancing should trim equities (which have outperformed and grown above the 60% target) and add to fixed income — mechanically buying the underperforming asset class, which is the right long-term discipline.

4. The 529 accounts (ACCT-529A, ACCT-529B) benefited from a full year of strong equity returns. Maya is now 10 (2029 projected enrollment) and Eli is 7 (2032 projected enrollment) — still ample time for growth.

FORWARD LOOK & PLANNING PRIORITIES

2022 will be defined by how aggressively the Fed tightens and whether inflation moderates. Consensus expects 3–4 rate hikes; the actual outcome could be more. A 'rates up, bonds down' scenario is well-understood, but the correlation between bonds and equities can temporarily turn positive in inflationary environments — meaning diversification may provide less protection than usual. Tax-loss harvesting opportunities may emerge if market volatility increases. Maintaining discipline and avoiding reactive portfolio changes remain paramount.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ Home purchase completed; 529s growing; advisory fee tiered structure in effect

References: DOC-IPSAmendment-2020-001 | DOC-FeeAmendment-2021-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
