CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | April–June 2024Household AUM: $1,205,000Policy: IPS-2020  |  Alloc: 61/34/5 |
| --- | --- |

Mid-Year Market Commentary — Q2 2024

AI Euphoria, Sticky Inflation, and Estate Planning Urgency

EXECUTIVE SUMMARY

H1 2024 delivered strong equity returns driven primarily by AI investment enthusiasm. The S&P 500 gained 15.3% in H1, led by NVIDIA (which briefly became the world's most valuable company by market cap) and the broader AI infrastructure theme. However, the Federal Reserve's path to rate cuts proved more tortured than markets expected: sticky inflation (running at 3.0–3.5% versus the 2% target) forced the Fed to postpone its first cut from early 2024 to September. For the Chen Household, H1 2024 was a strong investment period — AUM reached $1,205,000 — but a family health event (EventID-2024-01) elevated the urgency of completing the estate and beneficiary planning started in 2019.

MARKET ENVIRONMENT

The S&P 500 gained 10.6% in Q1 and 4.3% in Q2. Technology and communication services dominated, while rate-sensitive sectors (utilities, REITs, small caps) underperformed as the Fed delayed cuts. The 10-year Treasury yield remained stubbornly above 4.0%. Bonds were essentially flat in H1. International equities also performed well in Q1 before pulling back in Q2 on dollar strength. Corporate earnings were broadly better-than-expected, with AI-related capex growth a key driver.

KEY THEMES

1. AI Infrastructure Investment Cycle: Corporate AI capex (data centers, chips, networking) reached extraordinary levels, with the 'Magnificent 7' spending hundreds of billions. NVIDIA's revenue grew 265% YoY. The key question is whether AI monetization can justify these investment levels.

2. Fed Rate Cut Timeline Delayed: Markets entered 2024 pricing in 6-7 cuts; by mid-year, the expectation had compressed to 1-2 cuts. The persistence of services inflation (particularly shelter CPI) kept the Fed cautious despite an improving trend.

3. Family Health Event and Estate Urgency (EventID-2024-01): A health event affecting a close family member created urgency around estate planning. A beneficiary audit was initiated, revealing the outdated contingent beneficiary listing in DOC-BeneficiaryForm-2018-001 (Alex's parent still listed from 2018).

4. Election Year Dynamics: 2024 is a major election year. Historical evidence shows that markets tend to perform reasonably regardless of election outcomes, though sector leadership can shift. Policy uncertainty warrants maintaining the strategic allocation.

5. 529 Accounts Building Momentum: ACCT-529A (Maya, now 13) and ACCT-529B (Eli, now 10) have grown to approximately $14,000 each by Q2 end — on track but additional contributions are recommended.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +12,000     |     Household AUM: $1,205,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. Household AUM of $1,205,000 continues to compound strongly. The larger asset base amplifies both the positive impact of returns and the importance of fee efficiency — the tiered advisory structure provides increasing value at scale.

2. The estate review triggered by EventID-2024-01 requires immediate action: DOC-BeneficiaryForm-2024-001 should be completed to replace the outdated contingent beneficiary listing. The trust created in 2019 (DOC-Trust-2019-001) should be the template.

3. Under IPS-2020 (60/35/5), the fixed income allocation is positioned somewhat conservatively relative to the improving rate environment. As the Fed begins cutting, intermediate-duration bonds should outperform — the 35% allocation is well-positioned for this scenario.

4. The DAF (GoalID-2023-01) should distribute its first meaningful grant in 2024. Annual charitable giving from the Clearwater Giving Fund maintains the household's giving discipline and provides ongoing deduction strategy.

FORWARD LOOK & PLANNING PRIORITIES

H2 2024 will be shaped by the timing and pace of Fed rate cuts, the election outcome, and whether AI investment translates into measurable productivity gains. The September Fed meeting is the key catalyst to watch. The estate planning action items (beneficiary correction, healthcare directive, trust review) should be completed before year-end. The Q3 rate cut environment should benefit the fixed income allocation.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2024-01: Family health event triggers estate audit; DOC-BeneficiaryForm-2018-001 mismatch identified

References: DOC-IPSAmendment-2020-001 | DOC-Trust-2019-001 | DOC-BeneficiaryForm-2018-001 (mismatch) | GoalID-2023-01

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
