CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | July–September 2026Household AUM: $1,585,000Policy: IPS-2025  |  Alloc: 61/34/5 |
| --- | --- |

Mid-Year Market Commentary — Q3 2026

Disciplined Compounding, Stewardship, and the 10-Year Wealth Milestone

EXECUTIVE SUMMARY

Markets delivered solid returns in Q2–Q3 2026, with the S&P 500 gaining 4.9% in Q2 and 5.2% in Q3. Investment-grade bonds gained 1.0% and 1.9% respectively as the Fed made one additional modest rate cut in Q3. Household AUM reached $1,585,000 by Q3 end — a figure that underscores the cumulative power of a decade of disciplined, diversified wealth management. The governance focus established in Q1 (fee resolution, documentation integrity) has strengthened the advisory relationship. With the 10-year account anniversary in the rearview mirror, the focus shifts to the final approach toward the retirement goal.

MARKET ENVIRONMENT

Q3 2026 equity performance was supported by resilient consumer spending, continued AI infrastructure investment, and improving international economic momentum. The Fed's modest Q3 rate cut (25bp) reflected balanced economic conditions — growth positive, inflation near target, labor market healthy but not overheating. Corporate earnings growth continued at a low single-digit pace, supporting but not dramatically expanding equity valuations. International developed markets benefited from European economic improvement and a modestly weaker dollar.

KEY THEMES

1. The Power of Compounding Over a Decade: From $246,000 in ACCT-TX01 at inception (2016) to $820,000 in ACCT-TX01 alone by Q3 2026 (with household AUM at $1,585,000 across all accounts) — representing approximately 3.5-4x growth over ten years. Consistent contributions and reinvested dividends were essential contributors alongside market returns.

2. AI Transformation in Financial Services: Wealth management firms are leveraging AI for portfolio analysis, tax optimization, and client communication. The documentation governance practices established over the 2016–2026 period — meeting notes, cross-referenced decision logs, evidence chains — position the household for the AI-augmented advisory model.

3. Retirement Readiness Trajectory: With 16–17 years to the target retirement age (60), the household's funded ratio (simplified) has improved materially. The bucket strategy provides an organizing framework for the wealth accumulation phase and will extend naturally into the distribution phase.

4. Maya's College Countdown: 3 years to projected enrollment. ACCT-529A de-risking should continue; the current allocation in the age-based portfolio is shifting appropriately toward more conservative positioning. A 529 spending plan should be formalized in Q4.

5. Ongoing DAF Giving (GoalID-2023-01): The Clearwater Giving Fund continues to distribute annual grants. The household's giving cadence is established and can be increased as AUM grows. Consider whether to formally set a long-term annual giving target in the next financial plan update.

| Investment Policy Statement in Effect: IPS-2025Target Allocation: 62% Equity / 33% Fixed / 5% Cash (Bucket Framework)     |     Net Flows This Quarter: +12,000     |     Household AUM: $1,585,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2025)

1. Household AUM at $1,585,000 puts the household approximately 45% of the way to the estimated AUM needed for retirement income self-sufficiency (rough estimate: $3.5–4.0M at retirement based on GoalID-2016-01 targets). Still within the high-growth accumulation phase.

2. Under IPS-2025 (62/33/5 bucket overlay), the portfolio is well-positioned. Bucket 3 (equity at 62%) is the engine of long-term growth. Bucket 1 and 2 provide stability and intermediate income. Annual rebalancing should maintain these weights.

3. The 529 accounts — ACCT-529A at ~$40,000 and ACCT-529B at ~$40,000 — are growing steadily. ACCT-529A should be monitored against projected 2029 college costs (3 years). ACCT-529B has until 2032 and can maintain a growth tilt.

4. The advisory fee on $1,585,000 at the 0.85% tier is approximately $13,470 annually. As AUM approaches $1.5M, the blended rate will decrease. Transparency in fee reporting — reinforced by the Q1 2026 resolution — remains a priority.

FORWARD LOOK & PLANNING PRIORITIES

Q4 2026 will complete the 10-year dataset and set up the next decade of wealth management for the Chen Household. Key planning priorities: finalize the 529 spending plan for Maya (2029 enrollment), update the retirement income model with current asset levels and projected Social Security benefits, and begin exploring long-term care insurance options as Alex and Sam enter their mid-40s. The relationship between Clearwater Wealth Partners and the Chen Household — built on consistent planning, transparent communication, and disciplined investing across multiple market cycles — is the foundational asset underlying all financial plans.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ 10-year account anniversary; Maya college planning (2029); DAF giving cadence established

References: DOC-IPSAmendment-2025-001 | GoalID-2016-01 | GoalID-2016-02 | GoalID-2023-01 | MtgID-2026Q1-01

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
