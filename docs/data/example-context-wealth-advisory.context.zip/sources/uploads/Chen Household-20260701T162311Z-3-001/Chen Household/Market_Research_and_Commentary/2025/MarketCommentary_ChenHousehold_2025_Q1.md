CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | January–March 2025Household AUM: $1,315,000Policy: IPS-2020  |  Alloc: 61/34/5 |
| --- | --- |

Q1 2025 Market Commentary

Bucket Strategy Launch, Tariff Uncertainty, and the Pre-Retirement Horizon

EXECUTIVE SUMMARY

Q1 2025 opened with increased market volatility driven by trade policy uncertainty. The announcement of broad tariff measures in late Q1 triggered a sharp equity selloff, with the S&P 500 declining approximately 4.6% — its worst quarter since Q1 2022. Investment-grade bonds gained 2.5% as investors sought safety. For the Chen Household, Q1 2025 was a pivotal planning quarter: the IPS-2025 amendment was adopted, implementing a formal bucket strategy framework that aligns the portfolio with the household's approaching pre-retirement phase. Household AUM closed at $1,315,000.

MARKET ENVIRONMENT

The tariff announcement in late Q1 triggered the quarter's sharpest selling. Technology and consumer discretionary bore the brunt of the declines as earnings estimates were revised downward on supply chain and cost margin concerns. Defensive sectors (utilities, healthcare) and bonds outperformed. The Fed held rates steady, monitoring the inflationary impact of tariffs before committing to further cuts. The dollar weakened on trade uncertainty, providing a tailwind for international equities.

KEY THEMES

1. IPS-2025 Bucket Strategy Adopted (DOC-IPSAmendment-2025-001 / DecisionID-2025-112): The investment policy was updated to a three-bucket framework: Bucket 1 (0–24 months: STBIX + cash), Bucket 2 (2–7 years: UCBIX + UTIPX), Bucket 3 (7+ years: equities + REITX). Target allocation: 62/33/5.

2. Tariff-Driven Volatility: The administration's trade policy announcements created meaningful near-term uncertainty. While the ultimate economic impact depends on negotiated outcomes, tariff-related inflation and supply chain disruption are legitimate concerns that may keep the Fed on hold longer.

3. Sequence-of-Returns Risk Awareness: With Alex at age 42 and a targeted retirement near age 60 (~18 years), the household is entering the period where sequence risk begins to matter. The bucket strategy provides explicit protection: Bucket 1 provides 24 months of spending needs in non-equity assets.

4. College Funding Review: Maya is now 14 (projected enrollment 2029, approximately 4 years). ACCT-529A at $18,500 may be underfunded relative to projected costs. An additional 529 contribution plan is recommended.

5. Social Security Analysis Initiated (RecID-2025-02): A preliminary Social Security claiming analysis was prepared, modeling different claiming ages for Alex and Sam. This analysis will inform long-term retirement cash flow planning.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +12,000     |     Household AUM: $1,315,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. The IPS-2025 transition (from IPS-2020's 60/35/5 to 62/33/5 with bucket overlay) is implemented. The slight equity increase to 62% reflects the household's continued long investment horizon, while the bucket framework addresses sequence risk.

2. Bucket 1 is funded primarily from ACCT-CASH ($35,000) and the STBIX allocation — providing approximately 24 months of estimated withdrawal needs as a non-market-risk buffer.

3. The Q1 tariff-driven equity selloff was absorbed by the portfolio's fixed income and cash allocations. Household AUM declined modestly from $1,285,000 to $1,315,000 (including $12K contributions) — demonstrating the bucket strategy's stabilizing function.

4. 529 funding gap for Maya (ACCT-529A): at $18,500 with 4 years to enrollment and estimated 4-year costs of $80–120K (private) or $50–80K (in-state), an accelerated contribution plan is warranted.

FORWARD LOOK & PLANNING PRIORITIES

Q2 2025 and beyond will be shaped by tariff negotiation outcomes, the Fed's inflation-growth balancing act, and corporate earnings resilience. The bucket strategy positions the household to navigate volatility without being forced to sell equities into a down market. Key priorities: execute the Social Security analysis (RecID-2025-02), accelerate 529 contributions, and hold the Q1 annual review meeting with the full bucket framework as the organizational structure.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ DOC-IPSAmendment-2025-001 effective 2025-03-01; bucket strategy implemented (DecisionID-2025-112)

References: DOC-IPSAmendment-2025-001 | DOC-RiskQuestionnaire-2025-001 | RecID-2025-02 | GoalID-2016-02

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
