CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | April–June 2022Household AUM: $860,000Policy: IPS-2020  |  Alloc: 57/38/5 |
| --- | --- |

Mid-Year Market Commentary — Q2 2022

The Great Repricing: Worst H1 in 50 Years for the 60/40 Portfolio

EXECUTIVE SUMMARY

The first half of 2022 delivered the worst combined equity-and-bond performance in over 50 years. The S&P 500 fell 20.0% — entering a bear market — while the Bloomberg U.S. Aggregate Bond Index fell 10.4%, its worst H1 ever recorded. The traditional 60/40 portfolio lost approximately 16% in H1, with no safe harbor in conventional asset classes. The root cause was the Federal Reserve's aggressive pivot to fight inflation running at 40-year highs: 225 basis points of rate hikes in H1 (including a rare 75bp hike in June). Household AUM declined to approximately $860,000 by Q2 end, reflecting the broad market drawdown. The portfolio's diversification and continued contributions cushioned, but could not fully offset, the macro storm.

MARKET ENVIRONMENT

Q2 2022 alone saw the S&P 500 fall 16.5% — its worst quarter since Q2 2008. Growth stocks and technology (which led the 2020–2021 recovery) bore the brunt of the repricing, with the NASDAQ falling 30%+ from its peak. Energy was the lone bright spot (+40% YTD). Investment-grade bonds fell sharply as the 10-year yield surged from 1.5% to 3.5%. The 2-year yield rose even faster, causing the most severe yield curve inversion since 1981. Russia's invasion of Ukraine (February) kept energy prices elevated and added geopolitical uncertainty to an already challenging environment.

KEY THEMES

1. Inflation at 40-Year Highs: CPI peaked at 9.1% in June 2022 — the highest since 1981 — forcing the Fed's hand into the most aggressive tightening cycle in four decades. Inflation was broad-based: food, energy, shelter, and services all contributed.

2. Fed's 75bp 'Shock and Awe' Hike: The June 75bp rate hike — the largest single hike since 1994 — signaled the Fed's willingness to accept economic pain to restore price stability. Markets now pricing terminal rate above 3%.

3. Simultaneous Equity and Bond Losses: The historical diversification benefit of holding bonds during equity selloffs failed in 2022 because both were repriced by the same force: rising interest rates. This is the core challenge of an inflationary bear market.

4. Tax-Loss Harvesting Opportunity Emerging (EventID-2022-01): With equity and bond holdings both well below cost basis, a strategic tax-loss harvesting campaign is being evaluated for Q3 execution — maintaining market exposure while capturing tax losses.

5. Ukraine-Russia War and Energy Shock: The war added a commodity supply shock that amplified inflation and complicated the European growth outlook. Energy sector outperformance reflects these supply dynamics.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +9,000     |     Household AUM: $860,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. Household AUM declined to $860,000 under IPS-2020 (60/35/5) — a loss of approximately $90,000 from year-end 2021. This drawdown is painful but within the risk tolerance range for a Moderate allocation (DOC-RiskQuestionnaire-2020-001, max drawdown ~15–18%).

2. The bond allocation, while not providing its usual crisis protection, is not impaired fundamentally: the bonds still pay coupons and will return par at maturity. The unrealized losses represent duration risk, not credit risk.

3. The TLH campaign planned for Q3 (DecisionID-2022-301) will target UECIX positions for harvesting, with replacement into UECIY to maintain equity exposure while avoiding wash sale rules. The 2022 capital loss could offset several years of future gains.

4. 529 accounts (ACCT-529A, ACCT-529B) experienced market-value declines in H1 — ACCT-529A is now at approximately $4,000 and ACCT-529B at $4,000. Given Maya's 7-year horizon to college, no changes to the age-based moderate allocation are warranted.

FORWARD LOOK & PLANNING PRIORITIES

H2 2022 will hinge on the inflation trajectory and the Fed's response. A scenario where inflation peaks and begins declining meaningfully could allow the Fed to slow its tightening — potentially triggering a significant market rally. The TLH campaign should be executed in Q3 while losses remain available. Maintaining investment discipline through the bear market is essential: equity bear markets have historically ended before recessions do, meaning selling now risks missing the recovery.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2022-01: TLH campaign planning underway for Q3 execution (DecisionID-2022-301)

References: DOC-IPSAmendment-2020-001 | KF-Tax-Loss-Harvesting.md | KF-Bond-Duration-Risk.md

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
