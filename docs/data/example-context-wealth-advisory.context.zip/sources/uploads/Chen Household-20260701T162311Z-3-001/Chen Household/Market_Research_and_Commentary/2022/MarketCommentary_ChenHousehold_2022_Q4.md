CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | October–December 2022Household AUM: $890,000Policy: IPS-2020  |  Alloc: 58/37/5 |
| --- | --- |

Year-End Market Commentary — Q4 2022

The TLH Campaign, a Q4 Rally, and Positioning for 2023

EXECUTIVE SUMMARY

Q4 2022 provided meaningful relief after one of the most difficult years in multi-decade memory. The S&P 500 gained 7.6% in Q4, and investment-grade bonds gained 1.8% — both recovering partially from the year's historic losses. The full year ended: S&P 500 -18.1%, Bloomberg U.S. Agg -13.0% — the worst annual result for bonds ever recorded. For the Chen Household, Q4 was defined by the successful execution of the tax-loss harvesting campaign (DecisionID-2022-301), which captured meaningful capital losses to be applied against future gains. Household AUM closed 2022 at $890,000, recovering from Q3's low of $840,000.

MARKET ENVIRONMENT

The Q4 rally was driven by moderating inflation data (CPI fell from 9.1% peak to 7.1% by November), raising hopes that the Fed could slow its hiking pace. The Fed raised rates 50bp in December (down from prior 75bp increments) — a step-down that markets interpreted positively. However, Chair Powell's press conference remained hawkish, cautioning that the terminal rate would be higher than previously expected. The 10-year yield finished the year at 3.88%. Energy stocks remained the year's best performer (+65%).

KEY THEMES

1. TLH Campaign Successfully Executed (DecisionID-2022-301): UECIX was sold and replaced with UECIY (and IDEIX with IDEIY) between September 5–30, capturing approximately $15,500 in net capital losses while maintaining full equity market exposure. The 30-day wash sale holding period was observed.

2. 2022 Tax Outcome: The household's 2022 net capital gains position is approximately -$15,500 — a $3,000 deduction in 2022 with a carryforward to offset future gains. This represents meaningful long-term tax savings against the 2023 liquidity event gains.

3. Bonds: The Worst Year Ever for Good Reasons: The Bloomberg Agg's -13% result was historic, but the underlying bonds remain fundamentally sound. Higher coupon rates going forward mean better starting yields for 2023 — the bond math has improved significantly.

4. Recession Risk Debate: The inverted yield curve and aggressive Fed tightening have raised recession probabilities. However, the consumer and labor market remain resilient, and corporate balance sheets are generally healthy — suggesting a mild recession if one occurs.

5. Crypto Collapse (FTX): The FTX collapse in November highlighted the speculative risks in unregulated digital assets. The household has no direct crypto exposure; the event reinforces the value of regulated, transparent investment structures.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +10,000     |     Household AUM: $890,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. The TLH campaign's -$15,500 capital loss carryforward is a valuable asset, particularly given the anticipated 2023 RSU vesting event (EventID-2023-01 / DecisionID-2023-349) which will generate substantial taxable gains.

2. Under IPS-2020 (60/35/5), the portfolio is well-positioned to benefit from the improved bond yield environment. The 35% fixed income allocation now earns meaningfully higher coupons than in the near-zero rate era — improving the portfolio's income generation.

3. Household AUM at $890,000 is slightly above the pre-2022 level of $840,000 (Q3 2022 trough), reflecting the Q4 rally and continued contributions. The retirement trajectory (GoalID-2016-01) has been delayed but not derailed.

4. The 2022 TLH documentation chain (TaxPlanningMemo-TLH, trade confirmations, 1099 Bundle) is complete and supports the full evidence trail needed for tax filing and the 2023 planning conversation.

FORWARD LOOK & PLANNING PRIORITIES

2023 presents an improved opportunity set relative to the end of 2021. Bond starting yields are materially higher (3.5–4.5%+ across the curve), equity valuations are more reasonable after the 2022 repricing, and the inflation shock — while not fully resolved — appears to be past its worst phase. The critical priority for early 2023 is preparing for the anticipated NLTK RSU vesting event and designing a tax-aware diversification strategy in coordination with the 2022 capital loss carryforward.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ DecisionID-2022-301: TLH executed; $15,500 capital loss carryforward generated for 2023

References: DOC-IPSAmendment-2020-001 | TaxPlanningMemo-TLH-DecisionID-2022-301 | DOC-StrategyDeck-2022-003

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
