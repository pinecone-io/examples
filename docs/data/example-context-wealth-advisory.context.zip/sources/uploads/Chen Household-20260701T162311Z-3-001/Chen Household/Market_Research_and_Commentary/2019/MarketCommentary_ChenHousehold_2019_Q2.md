CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | April–June 2019Household AUM: $668,000Policy: IPS-2016  |  Alloc: 72/26/2 |
| --- | --- |

Mid-Year Market Commentary — Q2 2019

The Fed Pivot and the Art of Staying Invested Through Turbulence

EXECUTIVE SUMMARY

Markets staged a powerful recovery in H1 2019, with the S&P 500 delivering its best first half since 1997 (+18.5%). The Federal Reserve's dramatic policy pivot — abandoning its rate-hike posture entirely and signaling cuts ahead — was the single most important macro development of the period. Trade tensions re-escalated in May (when the U.S. hiked tariffs on $200B in Chinese goods), causing a sharp 6% correction, before markets recovered as G20 negotiations resumed. For the Chen Household, the strong H1 recovery more than erased the 2018 losses and established the foundation for the revocable trust planning that would be completed in Q3.

MARKET ENVIRONMENT

The S&P 500 gained 4.3% in Q2 and 18.5% in H1. Bonds also performed well as the Fed's pivot drove yields lower: the 10-year Treasury fell from 2.7% to 2.0% by quarter-end. The Bloomberg U.S. Aggregate Bond Index returned approximately 6.1% in H1 — an exceptional result for investment-grade fixed income. Both equity and fixed income performed well simultaneously, a rarity that reflects the abrupt shift in the policy backdrop. Growth stocks led domestic equity returns. Emerging markets underperformed as trade war uncertainty persisted.

KEY THEMES

1. Fed Pivot is the Defining Theme: Chair Powell's pivot from 'autopilot' rate hikes to patient signaling — and ultimately three cuts in H2 — was a defining macro event validating why staying invested through the Q4 2018 selloff was the right decision.

2. Trade War: Escalation and De-escalation Cycle: The May tariff escalation demonstrated how quickly sentiment can shift on trade headlines. Investors who reacted to the May correction missed the subsequent sharp recovery.

3. Yield Curve Inversion and Recession Fears: The 2-10 year Treasury curve inverted briefly in Q2, sparking recession concerns. Historical evidence suggests inversion precedes recessions by 12–24 months on average — not an immediate signal.

4. Trust and Estate Milestone (EventID-2019-01): The Chen Family Revocable Trust was established in Q3 2019, formalizing estate planning and establishing beneficiary structures aligned with long-term household goals.

5. Strong Earnings Growth Validating 2018 Concerns Were Overblown: Q1 2019 earnings beat estimates broadly, confirming that the Q4 2018 selloff overstated the fundamental deterioration in corporate profitability.

| Investment Policy Statement in Effect: IPS-2016Target Allocation: 70% Equity / 28% Fixed / 2% Cash     |     Net Flows This Quarter: +12,500     |     Household AUM: $668,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2016)

1. Household AUM reached $668,000 at Q2 end — a new high water mark, recovering and exceeding the 2018 losses. The long-term compounding story for GoalID-2016-01 (retirement readiness) remains on track.

2. Under IPS-2016 (70/28/2), both equity and fixed income allocations contributed positively to H1 returns. The multi-asset structure delivered exactly what it is designed to do: meaningful upside capture with dampened volatility.

3. The trust establishment (EventID-2019-01) should trigger a beneficiary designation review across all accounts (ACCT-TX01, ACCT-IRA1, ACCT-RIRA) to ensure alignment with the new trust structure.

4. International developed equity lagged U.S. equity in H1 but remains an important structural diversifier. Maintaining 15–20% international exposure within the equity sleeve is consistent with IPS-2016 policy.

FORWARD LOOK & PLANNING PRIORITIES

H2 2019 will be shaped by trade negotiation progress, the degree of Fed easing, and the consumer's resilience in the face of slowing business investment. Markets are pricing in approximately 2–3 additional Fed cuts by year-end. With yields now significantly lower, fixed income valuations are less attractive on a forward basis. A key priority for Q3 is completing the trust-aligned beneficiary designations and reviewing the NLTK diversification progress.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2019-01: Chen Family Revocable Trust established in Q3 2019

References: IPS-2016 (DOC-IPS-2016-001) | DOC-Trust-2019-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
