CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | July–September 2020Household AUM: $740,000Policy: IPS-2020  |  Alloc: 60/35/5 |
| --- | --- |

Mid-Year Market Commentary — Q3 2020

The V-Shaped Recovery and a New Policy Regime

EXECUTIVE SUMMARY

The six months following the COVID crash delivered one of the most extraordinary recoveries in market history — and one of the most counterintuitive, given the ongoing pandemic. The S&P 500 returned 20.5% in Q2 and another 8.9% in Q3, entirely recovering its losses and reaching new all-time highs by late August. The recovery was powered by massive fiscal and monetary stimulus, vaccine optimism, and the rapid adaptation of the economy to a digital, work-from-home model. For the Chen Household, the period was marked by a critical transition: the IPS was amended in June (IPS-2020) to reflect updated risk tolerance, and the 529 accounts were opened. Household AUM recovered to $740,000 by Q3 end.

MARKET ENVIRONMENT

The equity recovery was led by large-cap technology stocks (FANG+), which benefited from accelerated digital adoption. The NASDAQ surged over 40% from its lows by quarter-end. Value stocks and small caps significantly lagged. International equities recovered more slowly. The Federal Reserve adopted Average Inflation Targeting (AIT) in August, explicitly committing to keeping rates near zero until inflation sustainably exceeded 2%. This 'lower for longer' framework had profound implications for both asset classes and financial planning.

KEY THEMES

1. IPS-2020 Amendment Effective (DecisionID-2020-044): Following the risk questionnaire update (score moved from 68 to 54), the household's target allocation shifted from 70/28/2 to 60/35/5. This more defensive posture provides better downside protection while still participating in equity growth.

2. Fed's 'Lower for Longer' Commitment: The Fed's AIT framework fundamentally changes the cash and short-term bond calculus. With rates near zero for the foreseeable future, STBIX and money market allocations deliver minimal yield — the cost of maintaining liquidity is high.

3. 529 Accounts Opened (ACCT-529A, ACCT-529B — GoalID-2016-02): Opening the 529s in mid-2020 during a market dislocation was excellent timing. Age-based moderate portfolios were established for Maya (now 9) and Eli (now 6), with meaningful investment horizons.

4. Work-From-Home Economy: The structural shift toward remote work accelerated technology adoption by 5–10 years. Secular growth beneficiaries in software, e-commerce, and cloud computing significantly outperformed cyclical sectors.

5. Pandemic's Unequal Impact: The recovery was K-shaped — strong for knowledge workers and professional households, but damaging for service workers and small businesses. Policy responses will continue to shape the macro landscape.

| Investment Policy Statement in Effect: IPS-2020Target Allocation: 60% Equity / 35% Fixed / 5% Cash     |     Net Flows This Quarter: +11,000     |     Household AUM: $740,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2020)

1. Under the new IPS-2020 (60/35/5), the portfolio carries meaningfully more fixed income than under IPS-2016. This reflects the updated risk tolerance and provides better crisis resilience — the Q1 2020 experience validated the importance of that buffer.

2. Household AUM at $740,000 is on a strong recovery trajectory. Contributions continued throughout the crisis — the monthly contribution discipline through March–June was well-rewarded as markets recovered sharply.

3. The 529 accounts (opened in Q2 2020) are invested in age-based moderate portfolios that benefit from the recovery. Regular 529 contributions should be established as part of the household's savings discipline (GoalID-2016-02).

4. The 'lower for longer' rate environment compresses yield on the fixed income sleeve but still provides portfolio ballast and rebalancing opportunities. UTIPX (Treasury & TIPS) is particularly relevant given emerging inflation discussions.

FORWARD LOOK & PLANNING PRIORITIES

The key questions for Q4 2020 and into 2021 are vaccine rollout timing, fiscal cliff risk (additional stimulus), and the November election outcome. Markets have largely priced in a V-shaped recovery — meaning the risk is tilted toward disappointment if the recovery stalls. Under IPS-2020's 60/35/5 framework, the portfolio is well-positioned to navigate continued uncertainty while participating in the eventual economic normalization.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2020-01: IPS-2020 effective 2020-06-15 (60/35/5); 529s opened (ACCT-529A, ACCT-529B)

References: DOC-IPSAmendment-2020-001 | DOC-RiskQuestionnaire-2020-001 | DecisionID-2020-044

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
