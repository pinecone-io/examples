CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | October–December 2019Household AUM: $732,000Policy: IPS-2016  |  Alloc: 71/27/2 |
| --- | --- |

Year-End Market Commentary — Q4 2019

An Exceptional Year: Recovery, Resilience, and the Estate Foundation

EXECUTIVE SUMMARY

2019 will be remembered as one of the best years for diversified investors in the past decade. The S&P 500 surged 31.5% — its best year since 2013 — and bonds returned approximately 8.7% (Bloomberg U.S. Agg), meaning a balanced 70/30 portfolio delivered roughly 25%+ in total return. The year was bookended by a dramatic recovery from Q4 2018's selloff and ended with a Phase 1 trade deal framework that removed a key market overhang. The Federal Reserve cut rates three times and shifted to an extended pause. Household AUM reached $732,000, a new all-time high. The revocable trust was completed and the estate foundation was established.

MARKET ENVIRONMENT

The S&P 500 gained 9.1% in Q4 alone. Every major asset class delivered positive returns for the year: large-cap U.S. equities +31.5%, international developed +22.0%, emerging markets +18.4%, U.S. investment-grade bonds +8.7%, and REITs +28.9%. This rare 'everything up' environment was driven by the Fed's policy pivot and the resolution of several 2018 risk factors. The December Phase 1 trade deal announcement drove the final leg of the equity rally. Volatility (VIX) averaged near historically low levels in H2.

KEY THEMES

1. Policy Pivot Delivers: The Fed's three 2019 rate cuts, combined with global central bank easing, created a powerful tailwind for risk assets. This reinforces the lesson from 2018: the Fed's posture is one of the most important variables in the macro equation.

2. Phase 1 Trade Deal Framework: The December U.S.-China agreement reduced a major source of uncertainty that had suppressed business investment and global trade volumes throughout 2018 and 2019.

3. Defensive Assets Also Rally: In a year when equities surged, investment-grade bonds and Treasuries also delivered strong returns as the yield curve normalized. This unusual combination validates diversification.

4. Revocable Trust Milestone (EventID-2019-01): The Chen Family Revocable Trust was finalized, establishing the legal framework for estate planning across all household accounts. Beneficiary designations require ongoing coordination.

5. Concentration Risk Still Present: NLTK single-stock exposure grew with continued RSU vesting throughout 2019. A formal, tax-aware diversification roadmap should be a Q1 2020 priority.

| Investment Policy Statement in Effect: IPS-2016Target Allocation: 70% Equity / 28% Fixed / 2% Cash     |     Net Flows This Quarter: +13,500     |     Household AUM: $732,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2016)

1. With household AUM at $732,000 and strong full-year performance, the retirement confidence level (GoalID-2016-01) improved materially. The funded ratio trajectory is ahead of plan at this stage.

2. Under IPS-2016 (70/28/2), the equity-heavy allocation was well-rewarded in 2019. Annual rebalancing should be executed to trim equity back toward the 70% target after a year of significant equity outperformance.

3. The trust establishment (EventID-2019-01) should prompt a formal beneficiary designation review for ACCT-IRA1 and ACCT-RIRA — particularly given the note in DOC-BeneficiaryForm-2018-001 that may reflect an outdated contingent beneficiary listing.

4. Emergency fund in ACCT-CASH ($52,000 at year-end) represents approximately 6–7 months of expenses — within the GoalID-2016-03 target range. No action required on liquidity.

FORWARD LOOK & PLANNING PRIORITIES

Entering 2020, the key risks are stretched equity valuations (S&P 500 P/E near 19x forward), geopolitical uncertainty, and an election year that may introduce policy volatility. However, the consumer remains resilient, unemployment is near record lows, and corporate earnings growth — while moderating — remains positive. The 2020 planning agenda should focus on formalizing the NLTK diversification plan, completing beneficiary coordination with the trust, and beginning to think about education funding vehicles for Maya and Eli.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2019-01: Trust completed; beneficiary audit should be completed in 2020

References: IPS-2016 (DOC-IPS-2016-001) | DOC-Trust-2019-001 | DOC-BeneficiaryForm-2018-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
