CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | April–June 2018Household AUM: ~$304K (est. mid-year)Policy: IPS-2016  |  Alloc: 70/28/2 |
| --- | --- |

Mid-Year Market Commentary — Q2 2018

Trade Tensions, Rising Rates & the First Test of Equity Compensation

EXECUTIVE SUMMARY

The first half of 2018 presented investors with a meaningful shift in market character. After the exceptionally calm, high-return environment of 2017, volatility returned with force in early February before settling. By mid-year, escalating U.S.-China trade tensions had become the defining macro narrative — raising uncertainty about corporate earnings, global supply chains, and Federal Reserve policy. Domestically, the economy remained robust, with GDP on track for its strongest year since 2014 and unemployment near multi-decade lows. For the Chen Household, Q2 2018 marked the beginning of Alex's equity compensation program (RSUs in NLTK), introducing a new dimension of concentration risk into the household's financial picture.

MARKET ENVIRONMENT

The S&P 500 posted a modest gain of approximately 3.4% in Q2 after recovering from February's 10% correction. Technology and consumer discretionary sectors led, while materials and industrials lagged on trade war exposure. Internationally, the picture was bleaker: emerging markets fell nearly 8% as the U.S. dollar strengthened and tariff fears hit export-dependent economies. The Federal Reserve raised rates in June (its second hike of the year), bringing the fed funds rate to 1.75–2.00%. The 10-year Treasury yield climbed toward 3.0%. Corporate credit spreads were contained, reflecting confidence in U.S. fundamentals even amid global uncertainty.

KEY THEMES

1. Trade War Escalation: The U.S. imposed $34B in tariffs on Chinese goods in July, with China retaliating in kind. Markets repriced global growth assumptions, particularly for industrial and agricultural sectors.

2. Federal Reserve on Track: The Fed remained committed to gradual normalization, raising rates twice in H1 2018 and signaling two more hikes in H2. Rising short-term rates began to make cash and money markets meaningfully more attractive.

3. Dollar Strength Creates EM Headwinds: A strengthening U.S. dollar pressured emerging market currencies and assets, with the Turkish lira and Argentine peso experiencing particular stress.

4. Equity Compensation Concentration Emerges (EventID-2018-01): Alex's RSU grant in NLTK created a new single-stock concentration risk that requires ongoing monitoring and a long-term diversification plan.

5. Volatility Regime Shift: The VIX averaged above 15 in H1 2018 versus below 11 for most of 2017 — a meaningful change in the risk environment that validates maintaining a diversified, multi-asset allocation.

| Investment Policy Statement in Effect: IPS-2016Target Allocation: 70% Equity / 28% Fixed / 2% Cash     |     Net Flows This Quarter: +13,500     |     Household AUM: ~$304K (est. mid-year) |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2016)

1. Under IPS-2016 (70/28/2 target), the portfolio's equity exposure remained appropriate for the long-term growth objective. The February volatility was within the expected range for a moderate-growth allocation.

2. NLTK concentration from RSU vesting requires a formal diversification plan. Single-stock exposure above the IPS-2016 threshold of 10% warrants active monitoring and a tax-aware liquidation schedule.

3. Rising short-term rates are beginning to benefit the money market sleeve (STBIX / MUNIX) within ACCT-TX01, improving after-fee yield on the liquidity allocation.

4. International equity underperformance in Q2 reflects near-term dollar and tariff headwinds, not a structural breakdown in the diversification thesis. Maintaining international exposure is consistent with long-term IPS-2016 policy.

FORWARD LOOK & PLANNING PRIORITIES

The second half of 2018 will be shaped by the resolution — or escalation — of U.S.-China trade negotiations, the Fed's rate trajectory, and the sustainability of U.S. corporate earnings growth. With equity valuations at above-average levels and the yield curve flattening, maintaining disciplined rebalancing and beginning to formalize a NLTK diversification plan are top priorities. An equity compensation analysis should be completed before Q3 vesting.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2018-01: Alex's RSU equity compensation program begins — NLTK concentration management now required

References: IPS-2016 (DOC-IPS-2016-001) | DOC-RiskQuestionnaire-2016-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
