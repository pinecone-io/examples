CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | July–September 2025Household AUM: $1,395,000Policy: IPS-2025  |  Alloc: 62/33/5 |
| --- | --- |

Mid-Year Market Commentary — Q3 2025

Market Recovery, Retirement Framing, and the 10-Year Wealth Journey

EXECUTIVE SUMMARY

Markets recovered meaningfully in Q2–Q3 2025, with the S&P 500 gaining 4.3% in Q2 and 5.9% in Q3 as tariff concerns moderated following trade negotiations and corporate earnings remained resilient. Fixed income gained in tandem as the Fed made one additional rate cut in Q3. Household AUM reached $1,395,000 by Q3 end — comfortably above $1.3M and approaching the 10-year wealth accumulation milestone with strong momentum. The bucket strategy framework, now 6 months in effect, has provided the intended stabilization through Q1's volatility and Q2-Q3's recovery.

MARKET ENVIRONMENT

Q3 2025 performance was broadly positive: S&P 500 +5.9%, Bloomberg U.S. Agg +2.2%, international equities +4.5%. The Fed cut rates 25bp in September, citing continued inflation progress and a desire to support growth amid trade policy uncertainty. The 10-year Treasury yield declined modestly. Consumer spending remained resilient, corporate margins were better than feared despite tariff headwinds, and the labor market showed continued — if moderating — strength. The dollar weakened, benefiting international equity holdings.

KEY THEMES

1. Trade Policy Resolution Progress: H2 2025 saw negotiated trade frameworks reduce the most acute tariff uncertainty. While structural changes to global supply chains are underway, the immediate economic disruption was less severe than feared in Q1.

2. Retirement Framing Takes Center Stage: With Alex approaching age 42 and Sam 41, the household is approximately 18 years from the targeted retirement age. This mid-career vantage point is the highest-leverage period for retirement wealth accumulation.

3. Bucket Strategy Operating as Designed: Bucket 1 (24-month cash/short-term) provided psychological stability through Q1's selloff. Bucket 3 (long-duration equity) captured the Q2-Q3 recovery without forced liquidation pressure. The framework is working.

4. DAF Giving Cadence Established (GoalID-2023-01): Annual charitable distributions from the Clearwater Giving Fund continue, with 2025 grants reflecting the household's philanthropic priorities. The DAF provides giving flexibility across high and low income years.

5. 529 Funding Accelerated: Additional contributions to ACCT-529A (Maya) and ACCT-529B (Eli) have been made following the Q1 analysis. ACCT-529A now at approximately $21,500 — progress toward the enrollment goal.

| Investment Policy Statement in Effect: IPS-2025Target Allocation: 62% Equity / 33% Fixed / 5% Cash (Bucket Framework)     |     Net Flows This Quarter: +12,000     |     Household AUM: $1,395,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2025)

1. Household AUM at $1,395,000 is approximately 10% ahead of the base-case trajectory modeled in the 2025 retirement projection. The improved funded ratio supports GoalID-2016-01 with increasing confidence.

2. Under IPS-2025 (62/33/5 with bucket overlay), the recovery in Bucket 3 (equities) replenished the allocation above the strategic target. A modest rebalancing — selling equity back to 62% and adding to Bucket 2 fixed income — should be executed.

3. Bucket 1 remains fully funded at approximately $35,000+ equivalent. Annual review should confirm that Bucket 1 is funded to the 24-month spending need threshold.

4. The fee structure (0.85% on the first $1.5M) is appropriately transparent and competitive. The Q4 2025 annual meeting should review the advisory agreement, confirm fee schedule alignment, and ensure all documentation is current — particularly given the fee question raised in Q4.

FORWARD LOOK & PLANNING PRIORITIES

Q4 2025 sets up the 10-year anniversary of the Clearwater Wealth Partners engagement (ACCT-TX01 opened February 2016). This milestone warrants a comprehensive review: goal progress across all GoalIDs, life event documentation, and forward planning. The fee question raised in Q4 (foreshadowing EventID-2026-01) should be addressed transparently before year-end. 2026 will be a year of documentation governance and planning for Maya's approaching college enrollment.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ IPS-2025 bucket framework 6 months in effect; 529 contributions accelerated; fee question emerging

References: DOC-IPSAmendment-2025-001 | GoalID-2016-01 | GoalID-2016-02 | GoalID-2023-01

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
