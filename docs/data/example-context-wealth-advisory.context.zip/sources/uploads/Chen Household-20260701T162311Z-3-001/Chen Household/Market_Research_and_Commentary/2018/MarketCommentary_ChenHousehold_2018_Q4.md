CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | October–December 2018Household AUM: $608,000Policy: IPS-2016  |  Alloc: 70/28/2 |
| --- | --- |

Year-End Market Commentary — Q4 2018

The December Shock: When Policy Uncertainty Meets Peak Earnings

EXECUTIVE SUMMARY

Q4 2018 delivered the worst quarter for U.S. equities since the 2008 financial crisis. The S&P 500 fell 13.5% in the final three months of the year, with December alone posting its worst monthly decline since 1931. For the full year, the S&P 500 finished down approximately 6% — the index's first negative calendar year since 2008. The selloff was driven by a toxic combination of peak earnings anxiety, Federal Reserve policy perceived as out-of-step with slowing conditions, escalating trade tensions, and political uncertainty in Washington. The household's full-year portfolio return of approximately -6% reflected broad market conditions, with bond holdings providing only modest cushion as credit spreads widened.

MARKET ENVIRONMENT

After an exceptional Q3 (+7.7%), the market reversed sharply. Technology stocks, which had led the bull market, corrected 20%+ from their peaks. The Fed raised rates in December for the fourth time in 2018, and Chair Powell's comments suggesting rates remained 'far from neutral' appeared tone-deaf to deteriorating financial conditions — sparking a market panic. The 10-year Treasury yield peaked at 3.24% before rallying as investors sought safety. Investment-grade bonds returned +1.6% in Q4 as a partial safe haven. High-yield bonds fell sharply as recession fears mounted. Oil prices collapsed 40% from October highs on supply glut concerns.

KEY THEMES

1. Fed Policy Miscalibration: Markets interpreted the Fed's December hike and balance sheet reduction as excessively tight given slowing global growth and inverted segments of the yield curve. The 'Fed pivot' narrative would define early 2019.

2. Corporate Earnings Peak Anxiety: Q4 2018 earnings reports (delivered in early 2019) would ultimately show strong results, but markets in Q4 were pricing in a significant slowdown — a classic 'shooting at shadows' episode.

3. Trade War Uncertainty Lingers: Despite a temporary ceasefire agreed at the G20 in December, markets remained skeptical that a comprehensive U.S.-China trade deal was imminent.

4. Volatility and Investor Psychology: The VIX spiked above 36 in late December, testing investor resolve. Staying disciplined through sharp selloffs is essential to capturing long-term equity risk premiums.

5. NLTK Concentration Flagged: The year-end portfolio review highlighted the growing weight of NLTK shares in the taxable account, underscoring the need for a formal concentration risk plan in 2019.

| Investment Policy Statement in Effect: IPS-2016Target Allocation: 70% Equity / 28% Fixed / 2% Cash     |     Net Flows This Quarter: +55,000     |     Household AUM: $608,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2016)

1. Under IPS-2016 (70/28/2), the equity drawdown in Q4 was consistent with the risk tolerance established at inception (max drawdown tolerance ~20–25%). The portfolio behaved as expected for a moderate-growth allocation.

2. The investment-grade bond allocation (UCBIX, UTIPX, MUNIX) provided meaningful relative cushion in Q4 as the equity sleeve declined sharply — validating the multi-asset diversification strategy.

3. NLTK's decline in Q4 created a potential tax-loss harvesting opportunity that should be evaluated alongside the broader concentration reduction plan for 2019.

4. Household AUM ended 2018 at approximately $608,000. Despite the difficult Q4, the long-term trajectory remains intact: the primary retirement goal (GoalID-2016-01) projects continued progress assuming disciplined contributions and equity recovery.

FORWARD LOOK & PLANNING PRIORITIES

The outlook for 2019 depends critically on whether the Federal Reserve recalibrates its policy stance and whether the U.S.-China trade dispute moves toward resolution. History shows that years following significant equity corrections often deliver strong returns for investors who remain invested. The priority actions heading into 2019 are: formalizing the NLTK diversification plan, reviewing the trust and estate documents (now appropriate given equity comp), and ensuring the emergency fund remains adequate given the Q4 volatility experience.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2018-01: Equity comp diversification plan to be formalized in 2019

References: IPS-2016 (DOC-IPS-2016-001) | DOC-RiskQuestionnaire-2016-001

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
