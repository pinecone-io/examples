CLEARWATER WEALTH PARTNERS

Market Commentary & Macro Brief | Chen Household

| CLIENT: Chen Household (HH-CHEN-001)ACCOUNT: ACCT-TX01 + Household AccountsADVISOR: Morgan Park, CFP®  |  Clearwater Wealth Partners | January–March 2020Household AUM: $665,000Policy: IPS-2016  |  Alloc: 74/24/2 |
| --- | --- |

Emergency Market Commentary — Q1 2020

COVID-19: The Fastest Bear Market in History and the Policy Response

EXECUTIVE SUMMARY

Q1 2020 will stand as one of the most dramatic quarters in financial market history. COVID-19 transformed from a distant concern into a global pandemic that triggered widespread economic lockdowns, a 34% peak-to-trough decline in the S&P 500 (the fastest bear market entry on record — 16 trading days), emergency Federal Reserve action (two cuts totaling 150 basis points bringing rates to zero), and the largest fiscal stimulus package since World War II ($2.2 trillion CARES Act). The S&P 500 ended Q1 down 19.6%. For the Chen Household, the experience triggered an important and healthy risk tolerance reassessment — ultimately leading to a defensive IPS amendment in Q2.

MARKET ENVIRONMENT

Markets entered 2020 at all-time highs before the COVID shock. The selloff was unprecedented in its speed: the S&P 500 fell 34% peak-to-trough in just 33 days. Every sector declined; energy stocks fell 50%+ as oil prices collapsed (Brent crude briefly turned negative in April). Investment-grade bonds provided crucial portfolio protection, gaining 3.2% in Q1 as investors fled to safety and the Fed's emergency bond purchases stabilized the credit market. The yield on the 10-year Treasury fell to 0.54% — a record low. Household AUM declined to approximately $665,000, down from $732,000 at year-end 2019.

KEY THEMES

1. COVID-19 and the Economic Shutdown: Lockdowns in 20+ countries brought economic activity to a near halt, with GDP projected to contract by 30%+ annualized in Q2 2020. The speed and severity of the shock was unlike anything in the post-WWII era.

2. Federal Reserve Emergency Response: The Fed cut rates to zero at emergency March meetings, launched unlimited quantitative easing, and introduced new credit market facilities — the most aggressive monetary policy response since 2008.

3. CARES Act ($2.2T): Congress passed the largest emergency fiscal package in U.S. history, providing direct payments, enhanced unemployment benefits, and business loans — critical support for household and corporate balance sheets.

4. Risk Tolerance Reality Check (EventID-2020-01): The pandemic-driven decline revealed a gap between stated and revealed risk tolerance for many clients. The experience prompted a constructive risk questionnaire recount and IPS discussion.

5. Bonds Served Their Purpose: The investment-grade bond allocation delivered exactly the crisis protection it was designed to provide — decoupling from equities and gaining ground as equities collapsed.

| Investment Policy Statement in Effect: IPS-2016Target Allocation: 70% Equity / 28% Fixed / 2% Cash     |     Net Flows This Quarter: +12,000     |     Household AUM: $665,000 |
| --- |

PORTFOLIO IMPLICATIONS (IPS-2016)

1. Under IPS-2016 (70/28/2), the portfolio declined in line with expectations for a moderate-growth allocation during an acute crisis event. The peak-to-trough drawdown was within the risk tolerance band established at inception (max drawdown ~20–25%).

2. The emotional experience of the Q1 decline prompted a meaningful conversation about risk capacity versus risk tolerance (EventID-2020-01). A formal risk questionnaire update is underway; results will guide a potential IPS amendment.

3. The emergency fund in ACCT-CASH ($43,000 at Q1 end) remains within target range. No forced selling was required — validating the importance of maintaining a dedicated liquidity allocation.

4. The 529 accounts for Maya and Eli were not yet open — now is an opportune moment to establish them (ACCT-529A, ACCT-529B) given depressed market levels and the long investment horizon for both children.

FORWARD LOOK & PLANNING PRIORITIES

The Q2 2020 outlook is highly uncertain. The depth and duration of the economic recession will depend on the pace of pandemic containment, vaccine development timelines, and the effectiveness of fiscal and monetary support. However, history consistently shows that investors who remain disciplined through crisis periods capture the subsequent recovery. Selling into a panic is historically the costliest mistake. The immediate priorities are completing the risk questionnaire reassessment and 529 account establishment.

LIFE EVENTS & DOCUMENT CROSS-REFERENCES

◆ EventID-2020-01: COVID anxiety triggers risk reassessment; IPS amendment discussion underway

References: IPS-2016 (DOC-IPS-2016-001) | DOC-RiskQuestionnaire-2020-001 (in progress)

This market commentary is produced by Clearwater Wealth Partners for informational purposes only and does not constitute investment advice. All data is synthetic and for demonstration purposes. Past performance is not indicative of future results. Household data is drawn from the NWP-DEMO-HH-CHEN-001 dataset. AUM figures are household-level estimates. Morgan Park, CFP® | Clearwater Wealth Partners | ADV-PARK-001
