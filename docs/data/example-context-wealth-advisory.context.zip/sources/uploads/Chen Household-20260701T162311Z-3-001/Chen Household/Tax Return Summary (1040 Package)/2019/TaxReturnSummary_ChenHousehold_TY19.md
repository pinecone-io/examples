CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2019

Trust Formation Year — Chen Family Revocable Trust Created (EventID-2019-01)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2019 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 14, 2020 |
| Document ID: | DOC-TaxReturnSummary-2019-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader |
| Occupation (Spouse): | Marketing Director |
| Trust: | Chen Family Revocable Trust (created 2019-09-10 — disregarded entity for tax purposes) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — Clearwater Tech (NLTK Corp.): | $190,500 |
| Includes NLTK RSU vest tranche (FMV at vest included in Box 1) |  |
| Sam Chen — Lakeside Marketing Group: | $45,500 |
| TOTAL W-2 Wages: | $236,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Consulting / Freelance Income (Alex): | $10,000 |
| Form 1099-NEC received; Schedule C filed (no net profit — offset by business expenses) |  |
| Net Self-Employment Income after Expenses: | $10,000 |
| Self-Employment Tax (SE Tax on $10,000): | $1,413 |
| SE Tax Deduction (50% of SE Tax, Schedule 1): | ($707) |
| TOTAL Other Income (net of SE deduction): | $9,293 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $420 |
| ACCT-CASH High-Yield Savings (rising rate environment): | $580 |
| TOTAL Taxable Interest: | $1,000 |
| Tax-Exempt Interest (MUNIX — informational): | $195 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $320 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $240 |
| REITX — Real Estate Index Fund (ACCT-TX01): | $145 |
| Other Fund Distributions: | $195 |
| Total Ordinary Dividends: | $900 |
| Qualified Dividends: | $720 |
| Tax-Exempt Interest (MUNIX — informational only): | $195 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $0 |
| Long-Term Capital Gains (ACCT-TX01 rebalancing): | $7,500 |
| Annual rebalancing trades; IPS-2016 drift band management |  |
| Capital Loss Carryforward from 2018: | $0 |
| NET Capital Gains: | $7,500 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total Gross Income: | $255,400 |
| --- | --- |
| Less: SE Tax Deduction (50% of $1,413): | ($707) |
| Less: Other Schedule 1 Deductions: | $0 |
| ADJUSTED GROSS INCOME (AGI): | $254,693 |

Note: The Chen Family Revocable Trust (DOC-Trust-2019-001) is a disregarded entity for federal income tax purposes. All trust income flows directly to Alex and Sam Chen’s Form 1040. No separate trust return (Form 1041) required. Trust established September 10, 2019. Reference: EventID-2019-01 | KF-Revocable-Trust-Basics.md.

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Standard Deduction (MFJ 2019) |
| --- | --- |
| Standard Deduction: | ($24,400) |
| Itemized Deduction Analysis (for reference): |  |
| SALT (state/local taxes paid — capped at TCJA limit): | $10,000 |
| Charitable contributions: | $4,000 |
| Mortgage interest: | $0  (renting in 2019) |
| Total Itemized (estimated): | $14,000 |
| Standard deduction elected — $24,400 > $14,000: | (Standard deduction more beneficial) |
| TAXABLE INCOME: | $230,293 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2019 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $19,400 | $19,400 | $1,940 |
| 12% | $19,401 – $78,950 | $59,550 | $7,146 |
| 22% | $78,951 – $168,400 | $89,450 | $19,679 |
| 24% | $168,401 – $222,793 | $54,393 | $13,054 |
| Ordinary Income Tax Subtotal: |  |  | $41,819 |
| LT Cap Gains Tax (15% on $7,500): |  |  | $1,125 |
| Total Income Tax Before NIIT/Credits: |  |  | $42,944 |

Additional Taxes, Credits & SE Tax

| Net Investment Income Tax (3.8% on NII above $250K): | $181 |
| --- | --- |
| (AGI $254,693 > $250K; NII = $9,400; excess AGI = $4,693) |  |
| NIIT base = min($9,400, $4,693) = $4,693 × 3.8% |  |
| Self-Employment Tax (Schedule SE on $10,000): | $1,413 |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children × $2,000): | ($4,000) |
| TOTAL FEDERAL INCOME TAX: | $40,538 |
| Effective Federal Tax Rate: | 15.9% |
| Marginal Rate: | 24% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s): | $42,500 |
| --- | --- |
| Estimated Tax Payments: | $1,500 |
| TOTAL PAYMENTS: | $44,000 |
| Federal Tax Liability: | $40,538 |
| Refund: | $3,462 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | $230,293 |
| --- | --- |
| MN Tax (approx. effective rate 7.6%): | $17,502 |
| MN Tax Withheld + Estimated Payments: | $18,400 |
| MN Refund: | $898 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| ACCT-TX01 Money Market (Fidelity Institutional): | $420 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $580 |
| TOTAL TAXABLE INTEREST: | $1,000 |
| Tax-Exempt Interest (MUNIX — informational): | $195 |

Part II — Ordinary Dividends

| UECIX — US Equity Core Index Fund: | $320 |
| --- | --- |
| IDEIX — Intl Developed Equity Index: | $240 |
| REITX — Real Estate Index Fund: | $145 |
| Other / Miscellaneous Fund Distributions: | $195 |
| TOTAL ORDINARY DIVIDENDS: | $900 |
| Qualified Dividends (Form 1040, Line 3a): | $720 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| No short-term transactions in TY2019 | — | — | $0 |

Long-Term Transactions

| UECIX rebalancing — ACCT-TX01 | 2017-02-15 | 2019-11-20 | $3,200 |
| --- | --- | --- | --- |
| IDEIX rebalancing — ACCT-TX01 | 2016-08-10 | 2019-11-20 | $2,800 |
| REITX trim — ACCT-TX01 (drift correction) | 2017-05-02 | 2019-11-20 | $1,500 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $7,500 |

| Capital Loss Carryforward to 2020: | $0 |
| --- | --- |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2019)

2019 was a strong recovery year (S&P 500 +29%) and an estate planning milestone year. The Chen Family Revocable Trust (DOC-Trust-2019-001) was established on September 10, 2019, managed by Westfield & Baker LLP (EventID-2019-01). For tax purposes the trust is a disregarded entity — no Form 1041 required. Beneficiary designations were partially updated, with a noted mismatch in DOC-BeneficiaryForm-2018-001 (Alex’s parent listed as IRA contingent) flagged for correction. The Fed cut rates three times, compressing bond yields and moderating interest income compared to 2018. Year-end AUM reached $732,000. Meeting transcripts began this year.

Tax Planning Notes

| IPS Version in Effect: | DOC-IPS-2016-001 (70/28/2) |
| --- | --- |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 (1.00% flat fee) |
| Life Event: | EventID-2019-01 — Revocable Trust created Sept 2019 |
| Trust Tax Impact: | None — grantor/disregarded entity; all income on Form 1040 |
| Beneficiary Note: | DOC-BeneficiaryForm-2018-001 has outdated contingent (Alex’s parent); correction TaskID assigned; not resolved until 2024 |
| SE Income: | $10,000 consulting income; Schedule C / SE tax applies |
| NIIT: | AGI $254,693 slightly above $250K threshold; modest NIIT impact ($181) |
| Charity: | $4,000 cash; standard deduction still optimal |
| Cap Loss Carryforward to 2020: | $0 |
| Recommendation: | Open 529 accounts for Maya and Eli (GoalID-2016-02); monitor NLTK concentration; trust review Q1 2020 |

Document Cross-References

| Meeting Notes / Transcripts: | MtgID-2019Q1-01 through MtgID-2019Q4-01 |
| --- | --- |
| Revocable Trust: | DOC-Trust-2019-001 | EventID-2019-01 |
| Beneficiary Form (outdated): | DOC-BeneficiaryForm-2018-001 |
| Risk Questionnaire: | DOC-RiskQuestionnaire-2016-001 |
| IPS: | DOC-IPS-2016-001 |
| Prior Year: | DOC-TaxReturnSummary-2018-001 |
| Next Year: | DOC-TaxReturnSummary-2020-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
