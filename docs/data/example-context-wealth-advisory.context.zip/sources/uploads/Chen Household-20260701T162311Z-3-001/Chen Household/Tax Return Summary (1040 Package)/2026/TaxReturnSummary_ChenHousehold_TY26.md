CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2026

Stable Income Year — Fee Governance Resolution | Story Arc 3 Concludes | EventID-2026-01

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2026 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 15, 2027 |
| Document ID: | DOC-TaxReturnSummary-2026-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981  (Age 43 at year-end) |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984  (Age 42 at year-end) |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader  |  NLTK Corp. |
| Occupation (Spouse): | Marketing Director |
| Home Ownership: | Homeowners since 2021 (EventID-2021-01) |
| IPS: | IPS-2025 bucket strategy (DOC-IPSAmendment-2025-001) continues |
| Trust: | Chen Family Revocable Trust — disregarded entity (DOC-Trust-2019-001) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001  |  Age 15 at year-end |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002  |  Age 12 at year-end |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — NLTK Corp. (incl. routine RSU vest FMV): | $225,000 |
| Sam Chen — Lakeside Marketing Group: | $57,000 |
| TOTAL W-2 Wages: | $282,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Equity Compensation — Supplemental RSU Income (NLTK Corp.): | $20,000 |
| Supplemental vest; FMV at vest date per NLTK plan statement; Box 12 Code V |  |
| TOTAL Other Income: | $20,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| ACCT-TX01 Money Market (Fidelity Institutional): | $880 |
| ACCT-CASH High-Yield Savings / Bucket 1: | $570 |
| TOTAL Taxable Interest: | $1,450 |
| Tax-Exempt Interest (MUNIX in ACCT-TX01 — informational): | $460 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $430 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $275 |
| NLTK — Common Stock (<5% per IPS-2025; ACCT-TX01): | $115 |
| REITX — Real Estate Index Fund (ACCT-RIRA — Bucket 3): | $90 |
| Total Ordinary Dividends: | $910 |
| Qualified Dividends: | $750 |
| Tax-Exempt Interest (MUNIX): | $460 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01 routine rebalancing): | $2,000 |
| Long-Term Capital Gains (rebalancing + NLTK maintenance trim): | $16,000 |
| NLTK maintained at <5% per IPS-2025 single-stock limit |  |
| Capital Loss Carryforward from Prior Years: | $0 |
| NET Capital Gains: | $18,000 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| W-2 Wages: | $282,000 |
| --- | --- |
| Other Income (RSU supplement): | $20,000 |
| Taxable Interest: | $1,450 |
| Ordinary Dividends: | $910 |
| Net Capital Gains: | $18,000 |
| Gross Income: | $322,360 |
| Less: Schedule 1 Deductions: | $0 |
| ADJUSTED GROSS INCOME (AGI): | ~$322,360 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Itemized (sixth consecutive year) |
| --- | --- |
| Standard Deduction (MFJ 2026 — not elected): | ~$30,800  (est.) |
| Itemized Deductions: |  |
| Mortgage Interest (Lakeside Mortgage Co.): | $15,000 |
| State & Local Taxes Paid (SALT — TCJA cap): | $10,000 |
| Charitable Contributions (cash + DAF grants): | $8,000 |
| Total Itemized Deductions: | $33,000 |
| Exceeds standard deduction ($33,000 > ~$30,800): | (Itemized) |
| TAXABLE INCOME: | ~$289,360 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2026 MFJ Tax Brackets — Estimated)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $24,400 | $24,400 | $2,440 |
| 12% | $24,401 – $99,200 | $74,800 | $8,976 |
| 22% | $99,201 – $211,700 | $112,500 | $24,750 |
| 24% | $211,701 – $289,360 | $77,660 | $18,638 |
| Ordinary Income Tax Subtotal: |  |  | $54,804 |
| LT Cap Gains Tax (15% on ~$15,500; 20% on ~$2,500): |  |  | $2,825 |
| Total Income Tax Before NIIT/Credits: |  |  | $57,629 |

Additional Taxes, Credits & NIIT

| Net Investment Income Tax (3.8% on NII above $250K): |  |
| --- | --- |
| AGI $322,360 > $250K; excess = $72,360 |  |
| NII = ~$20,360 (int/div/cap gains); NIIT = $20,360 × 3.8% | $774 |
| Muni income (MUNIX $460) excluded from NII — ongoing tax benefit |  |
| Self-Employment Tax: | $0 |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children; below phase-out threshold): | ($4,000) |
| TOTAL FEDERAL INCOME TAX (Est.): | ~$54,403 |
| Effective Federal Tax Rate: | ~16.9% |
| Marginal Rate: | 24% |

Payments & Refund

| Federal Tax Withheld (W-2s): | $56,000 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $56,000 |
| Federal Tax Liability: | ~$54,403 |
| Refund: | ~$1,597 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | ~$289,360 |
| --- | --- |
| MN Tax (approx. effective rate 8.1%): | ~$23,438 |
| MN Tax Withheld + Estimated Payments: | $24,000 |
| MN Refund: | $562 |

SECTION 6 — FEE ADVISORY NOTE (EVENTID-2026-01)

A fee billing discrepancy was identified in Q4 2025 and resolved in Q1 2026. For completeness, this tax return reflects the correct advisory fee schedule — tiered per DOC-FeeAmendment-2021-001 (effective July 1, 2021). Advisory fees paid in TY2026 are NOT deductible as investment expenses under current tax law (TCJA eliminated the Schedule A miscellaneous itemized deduction). The $1,250 fee credit issued in Q1 2026 (EventID-2026-01) has no direct income tax impact. Reference: MtgID-2026Q1-01 | TaskID-2026Q1-801.

| Advisory Fee Schedule (correct): | 0.85% first $1.5M; 0.70% next $1.5M; 0.55% above $3M |
| --- | --- |
| Source Document: | DOC-FeeAmendment-2021-001 (effective 2021-07-01) |
| Superseded Draft: | DOC-StrategyDeck-2022-002 (stale 1.00% reference — do not rely on) |
| Fee Credit (2026-Q1): | $1,250 goodwill credit — no taxable income |
| Federal Deductibility: | Advisory fees not deductible under TCJA (2018–present) |

SECTION 7 — RETIREMENT & EDUCATION ACCOUNT CONTRIBUTIONS

| Account / Item | Detail |
| --- | --- |
| Alex — 401(k) Contributions (NLTK Corp.): | $24,000  (2026 est. IRS limit) |
| Sam — 401(k) Contributions (Lakeside Marketing): | $12,000 |
| Roth IRA (ACCT-RIRA) — Direct: | Not eligible (MAGI >> phase-out) |
| 529 Contributions (ACCT-529A + ACCT-529B): | $8,000 each  ($16,000 total) |
| MN 529 Deduction (up to $1,500/beneficiary MFJ): | ($3,000) |
| Note: Maya (age 15) entering key 529 accumulation window (2029 enrollment) |  |

SECTION 8 — TAX PLANNING NOTES & CROSS-REFERENCES

Key Events — TY2026

| EventID-2026-01: | Fee billing mismatch — identified Q4 2025; resolved Q1 2026; no tax impact |
| --- | --- |
| TaskID-2026Q1-801: | Client summary letter re fee resolution — delivered March 1, 2026 |
| Story Arc 3: | Concludes: fee schedule amendment → version drift → AI-assisted resolution |
| NLTK: | Maintained below 5% IPS-2025 limit; routine trimming as needed |
| GoalID-2023-01: | DAF $8,000 in charitable grants; ongoing annual giving strategy |
| 10-Year View: | Household AUM grew from $410K (2016) to $1,650K (2026) across all three story arcs |

Document Cross-References

| 1099 Bundle TY2026: | 1099Bundle_ChenHousehold_TY26.pdf |
| --- | --- |
| Fee Amendment (correct schedule): | DOC-FeeAmendment-2021-001 |
| Fee Resolution Meeting Transcript: | MeetingTranscript_ChenHousehold_MtgID-2026Q1-01.pdf |
| Annual Consolidated Report 2026: | DOC-AnnualConsolidatedReport-2026-001 |
| IPS-2025 Amendment: | DOC-IPSAmendment-2025-001 |
| Meeting Notes Q1 2026: | MeetingNotes_ChenHousehold_MtgID-2026Q1-01.pdf |
| This Document: | DOC-TaxReturnSummary-2026-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Document ID: DOC-TaxReturnSummary-2026-001 | Dataset: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
