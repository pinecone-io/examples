CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2021

Home Purchase Year — First Itemized Return & Down Payment Gains (EventID-2021-01 / DecisionID-2021-141)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2021 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 12, 2022 |
| Document ID: | DOC-TaxReturnSummary-2021-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| (Home purchased July 2021 — same address; prior to purchase this was a rental) |  |
| State of Residence: | Minnesota (MN) |
| Trust (disregarded entity): | Chen Family Revocable Trust — DOC-Trust-2019-001 |
| Mortgage Lender: | Lakeside Mortgage Co. (EventID-2021-01) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — Clearwater Tech (NLTK Corp.): | $200,000 |
| Includes NLTK RSU vest tranche and annual merit increase |  |
| Sam Chen — Lakeside Marketing Group: | $50,000 |
| TOTAL W-2 Wages: | $250,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Equity Compensation Supplement (Alex — NLTK RSU supplemental): | $12,000 |
| Supplemental vest; Form W-2c supplemental; NLTK concentration now ~5% of portfolio |  |
| TOTAL Other Income: | $12,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $250 |
| ACCT-CASH High-Yield Savings (Fed rates still near zero): | $350 |
| Lakeside Mortgage Co. — escrow interest: | $200 |
| TOTAL Taxable Interest: | $800 |
| (Note: Fed maintained near-zero policy through 2021; inflation concerns emerging) |  |
| Tax-Exempt Interest (MUNIX): | $130 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $280 |
| UCBIX — US Core Bond Index Fund: | $220 |
| IDEIX — Intl Developed Equity Index: | $200 |
| MUNIX — Municipal Bond Fund (tax-exempt): | $130 * |
| Other / Reinvested Fund Distributions: | $170 |
| Total Ordinary Dividends: | $1,000 |
| (Note: reduced vs. 2020 as equity trimmed for down payment staging) |  |
| Qualified Dividends: | $800 |
| * Tax-Exempt Interest (informational): | $130 |

Capital Gains (Schedule D) — DecisionID-2021-141

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $2,500 |
| NLTK shares sold for tax withholding at vest (held <12 months) |  |
| Long-Term Capital Gains — Down Payment Staging: | $16,000 |
| UECIX / IDEIX / REITX liquidation to fund home purchase |  |
| DecisionID-2021-141 — Window July 10, 2021 |  |
| Capital Loss Carryforward from 2020: | $0 |
| NET Capital Gains: | $18,500 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total Gross Income: | $282,300 |
| --- | --- |
| Above-the-Line Adjustments (Schedule 1): | $0 |
| ADJUSTED GROSS INCOME (AGI): | $282,300 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME (FIRST ITEMIZED YEAR)

Itemized Deductions (Schedule A) — TaxTopicID-2021-01

| Mortgage Interest (Lakeside Mortgage Co. — ~6 months, July–Dec 2021): | $11,800 |
| --- | --- |
| Loan amount approx. $530,000; annualized rate ~4.5% |  |
| State & Local Taxes (SALT — TCJA cap applies): | $10,000 |
| MN income tax withheld + property tax (prorated post-purchase) |  |
| Charitable Contributions (cash — verified receipts): | $4,500 |
| Other Itemized Deductions: | $0 |
| TOTAL ITEMIZED DEDUCTIONS: | $26,300 |
| Standard Deduction (MFJ 2021) for comparison: | $25,100 |
| DEDUCTION ELECTED — Itemized (more beneficial by $1,200): | ($26,300) |
| TAXABLE INCOME: | $256,000 |

This is the first year itemized deductions exceed the standard deduction, primarily due to mortgage interest from the July 2021 home purchase (EventID-2021-01). In future years with a full 12 months of mortgage interest (~$23,600/year), itemization will provide greater benefit. Reference: TaxTopicID-2021-01 | KF-Home-Purchase-Liquidity.md.

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2021 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $19,900 | $19,900 | $1,990 |
| 12% | $19,901 – $81,050 | $61,150 | $7,338 |
| 22% | $81,051 – $172,750 | $91,700 | $20,174 |
| 24% | $172,751 – $237,500 | $64,750 | $15,540 |
| Ordinary Income Tax Subtotal: |  |  | $45,042 |
| ST Cap Gains (22% on $2,500): |  |  | $550 |
| LT Cap Gains (15% on $16,000): |  |  | $2,400 |
| Total Before NIIT/Credits: |  |  | $47,992 |

Additional Taxes & Credits

| Net Investment Income Tax (3.8% on NII above $250K): | $1,233 |
| --- | --- |
| AGI $282,300 > $250K; NII = $20,300 (cap gains + divs + int) |  |
| Excess AGI over threshold = $32,300; NIIT on min($20,300, $32,300) = $20,300 |  |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 × $2,000 — base rate at this income level): | ($4,000) |
| (ARPA enhanced credit phased out above $150K MFJ) |  |
| TOTAL FEDERAL INCOME TAX: | $45,225 |
| Effective Federal Tax Rate: | 16.0% |
| Marginal Rate: | 24% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s combined): | $46,500 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $46,500 |
| Federal Tax Liability: | $45,225 |
| Refund: | $1,275 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | $256,000 |
| --- | --- |
| MN uses its own deduction schedule; partial MN mortgage deduction applies |  |
| MN Tax (approx. effective rate 8.0%): | $20,480 |
| MN Tax Withheld: | $21,200 |
| MN Refund: | $720 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| ACCT-TX01 Money Market (Fidelity): | $250 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $350 |
| Lakeside Mortgage Escrow Interest: | $200 |
| TOTAL TAXABLE INTEREST: | $800 |
| Tax-Exempt Interest (MUNIX): | $130 |

Part II — Ordinary Dividends

| UECIX: | $280 |
| --- | --- |
| UCBIX: | $220 |
| IDEIX: | $200 |
| Other / Misc Fund Distributions: | $170 |
| Miscellaneous (ACCT-TX01 sweep): | $130 |
| TOTAL ORDINARY DIVIDENDS: | $1,000 |
| Qualified Dividends: | $800 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| NLTK — shares sold at supplemental vest (ACCT-TX01) | 2021-04-15 | 2021-07-05 | $2,500 |
| NET SHORT-TERM CAPITAL GAIN: |  |  | $2,500 |

Long-Term Transactions — Down Payment Staging (DecisionID-2021-141)

| UECIX liquidation — ACCT-TX01 | 2018-05-10 | 2021-07-10 | $7,200 |
| --- | --- | --- | --- |
| IDEIX liquidation — ACCT-TX01 | 2017-08-15 | 2021-07-10 | $4,900 |
| REITX liquidation — ACCT-TX01 | 2018-11-05 | 2021-07-10 | $2,400 |
| UECIX trim (additional) — ACCT-TX01 | 2019-02-20 | 2021-07-12 | $1,500 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $16,000 |

| Capital Loss Carryforward to 2022: | $0 |
| --- | --- |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2021)

2021 was a landmark year for the Chen household: the home purchase closed in July 2021 (EventID-2021-01), funded by liquidating investments in ACCT-TX01 and drawdown from ACCT-CASH. Mortgage originated with Lakeside Mortgage Co. This generated $18,500 in capital gains (DecisionID-2021-141) and triggered the first year of itemized deductions — making mortgage interest deductible. S&P 500 finished +27%. Year-end AUM: $952,000. In Q3, Clearwater executed a fee schedule amendment (DOC-FeeAmendment-2021-001), moving from a flat 1.00% to a tiered structure (0.85% / 0.70% / 0.55%) effective July 1, 2021 — the beginning of Story Arc 3. Inflation concerns emerged, particularly in housing and goods.

Tax Planning Notes — TaxTopicID-2021-01

| IPS Version in Effect: | DOC-IPSAmendment-2020-001 (60/35/5) |
| --- | --- |
| Advisory Fee Schedule (changed mid-year): | DOC-FeeAmendment-2021-001 — tiered effective 2021-07-01 |
| Life Event: | EventID-2021-01 — Home purchase; down payment from ACCT-TX01 |
| Key Decision: | DecisionID-2021-141 — Down payment staging; LT gains $16,000 |
| Tax Topic: | TaxTopicID-2021-01 — Home purchase itemization and cash planning |
| Itemization: | FIRST YEAR of itemized deductions; $26,300 elected over $25,100 standard |
| Mortgage Interest: | $11,800 (partial year) deducted on Schedule A |
| SALT Cap: | $10,000 cap fully utilized (MN income tax + property tax) |
| Net Cap Gains: | $18,500 (highest since relationship began); NIIT $1,233 |
| Carryforward to 2022: | $0 |
| 529 Accounts: | ACCT-529A (Maya) and ACCT-529B (Eli) growing; first full year of contributions |
| Advisory Note: | With full year of mortgage interest in 2022 (~$23,600), itemized deductions will increase significantly over the standard deduction |

Fee Schedule Change Note (Story Arc 3)

Fee Amendment executed June 20, 2021 (DOC-FeeAmendment-2021-001), effective July 1, 2021. New tiered schedule: 0.85% on first $1.5M; 0.70% on next $1.5M; 0.55% above $3M. Advisory fees are not deductible on the federal return (investment expense deduction eliminated by TCJA). For reference only: advisory fees paid in TY2021 approximately $8,600 (blended rate under transition — half-year at 1.00%, half-year at ~0.85%). Note: a stale ‘1.00%’ fee reference will appear in DOC-StrategyDeck-2022-002 (v2) — this is an intentional document inconsistency flagged for AI demo. DOC-StrategyDeck-2022-003 (FINAL) is correct.

Document Cross-References

| Meeting Notes / Transcripts: | MtgID-2021Q1-01 through MtgID-2021Q4-01 |
| --- | --- |
| Home Purchase / Mortgage Docs: | EventID-2021-01 | Lakeside Mortgage Co. |
| Trade Decision (Down Payment): | DecisionID-2021-141 |
| Fee Amendment: | DOC-FeeAmendment-2021-001 |
| Tax Topic: | TaxTopicID-2021-01 | KF-Home-Purchase-Liquidity.md |
| 1099 Bundle: | 1099Bundle_ChenHousehold_TY21.pdf |
| Prior Year: | DOC-TaxReturnSummary-2020-001 |
| Next Year: | DOC-TaxReturnSummary-2022-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
