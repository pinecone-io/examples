CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2023

Liquidity Event + DAF Bunching — AGI ~$426K | 2022 Carryforward Applied | TaxTopicID-2023-01

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2023 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 15, 2024 |
| Document ID: | DOC-TaxReturnSummary-2023-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981  (Age 40 at year-end) |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984  (Age 39 at year-end) |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader  |  NLTK Corp. |
| Occupation (Spouse): | Marketing Director |
| Home Ownership: | Homeowners since 2021 (EventID-2021-01) |
| Trust: | Chen Family Revocable Trust — disregarded entity (DOC-Trust-2019-001) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001  |  Age 12 at year-end |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002  |  Age 9 at year-end |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — NLTK Corp. (base salary + standard RSU vest in Box 1): | $210,000 |
| Base salary $190K + routine annual RSU vest FMV $20K (incl. in Box 1) |  |
| Sam Chen — Lakeside Marketing Group: | $52,000 |
| TOTAL W-2 Wages: | $262,000 |

Other Income — Equity Compensation Liquidity Event (Schedule 1 / Form 1040)

EventID-2023-01: Large NLTK RSU vest occurred Q2 2023. Shares vested at elevated FMV; proceeds reported on Form 1099-B and W-2 supplement. Three-phase diversification DecisionID-2023-349 executed April–June 2023.

| Source | Amount |
| --- | --- |
| NLTK RSU Vest — Supplemental W-2 / 1099 Proceeds (above routine vest): | $120,000 |
| FMV at vest date: $48.50/share; shares vested: approx. 2,474 shares |  |
| Income reported on Alex’s Form W-2 Box 12 (Code V) / supplemental statement |  |
| Consulting / Freelance Income (Alex): | $0  (discontinued in 2022; none in 2023) |
| TOTAL Other Income: | $120,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| ACCT-TX01 Money Market (elevated Fed Funds rate — peak 5.25–50%): | $720 |
| ACCT-CASH High-Yield Savings: | $480 |
| TOTAL Taxable Interest: | $1,200 |
| Tax-Exempt Interest (MUNIX — informational only): | $380 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (post-swap restoration; ACCT-TX01): | $380 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $240 |
| NLTK — Common Stock (reduced position; ACCT-TX01): | $110 |
| REITX — Real Estate Index Fund (ACCT-TX01): | $70 |
| Total Ordinary Dividends: | $800 |
| Qualified Dividends: | $660 |
| Tax-Exempt Interest (MUNIX — informational only): | $380 |

Capital Gains (Schedule D — High-Income Year)

2022 capital loss carryforward of $12,500 applied against 2023 gains. NLTK diversification generated significant short- and long-term gains. DAF contribution of $25,000 in appreciated NLTK shares avoids recognition of embedded gain in contributed shares. Reference: DecisionID-2023-349 | TaxTopicID-2023-01.

| Category | Amount |
| --- | --- |
| Short-Term Gains — NLTK shares held <1yr at vest (ACCT-TX01): | $8,200 |
| Long-Term Gains — NLTK shares held >1yr (ACCT-TX01): | $36,300 |
| Capital Gains from routine UECIX rebalancing (LT): | $5,500 |
| Capital Loss Carryforward from TY2022 Applied: | ($12,500) |
| Shares contributed to DAF — gain NOT recognized (IRC §170(e)(1)(A)): | $0  (no gain recognized on $25K FMV donation) |
| NET Capital Gains: | $37,500 |
| After carryforward: $50,000 gross − $12,500 = $37,500 net |  |
| Note: Approx. $4,500 net LTCG taxed at 20% rate (income above LTCG 15% threshold) |  |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| W-2 Wages: | $262,000 |
| --- | --- |
| Other Income (NLTK RSU Liquidity Event): | $120,000 |
| Taxable Interest: | $1,200 |
| Ordinary Dividends: | $800 |
| Net Capital Gains: | $37,500 |
| Gross Income: | $421,500 |
| Less: Schedule 1 Deductions (student loan, etc.): | $0 |
| ADJUSTED GROSS INCOME (AGI): | ~$421,500 |

Note: AGI of ~$421,500 is the highest in household history, driven by the NLTK RSU liquidity event. Quarterly estimated tax payments were required in 2023 Q3 and Q4 to avoid underpayment penalties — coordinated with Lisa Torres, EA. TaxTopicID-2023-01: High-income year estimated taxes + DAF bunching.

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Itemized (third consecutive year) |
| --- | --- |
| Standard Deduction (MFJ 2023 — not elected): | $27,700 |
| Itemized Deductions: |  |
| Mortgage Interest (Lakeside Mortgage Co.): | $16,500 |
| State & Local Taxes Paid (SALT — TCJA cap): | $10,000 |
| Charitable Contributions — Cash Gifts: | $1,000 |
| Charitable Contributions — DAF (Clearwater Giving Fund): | $25,000 |
| Note: DAF = $25K fair market value of appreciated NLTK shares donated |  |
| Note: Full FMV deductible; no gain recognized on donated shares (IRC §170) |  |
| Total Itemized Deductions: | $52,500 |
| Significantly exceeds standard deduction ($52,500 >> $27,700): | (Itemized) |
| TAXABLE INCOME: | ~$369,000 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2023 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $22,000 | $22,000 | $2,200 |
| 12% | $22,001 – $89,075 | $67,075 | $8,049 |
| 22% | $89,076 – $190,750 | $101,675 | $22,369 |
| 24% | $190,751 – $364,200 | $173,450 | $41,628 |
| 32% | $364,201 – $369,000 | $4,800 | $1,536 |
| Ordinary Income Tax Subtotal: |  |  | $75,782 |
| LT Cap Gains Tax (15% on ~$29,000; 20% on ~$4,500): |  |  | $5,250  (est.) |
| Total Income Tax Before NIIT/Credits: |  |  | $81,032 |

Additional Taxes, Credits & NIIT

| Net Investment Income Tax (3.8% on NII above $250K threshold): | $6,497 |
| --- | --- |
| AGI $421,500 > $250K; excess = $171,500 |  |
| NII = $40,500 (int/div/cap gains); NIIT base = min($40,500, $171,500) |  |
| NIIT = $40,500 × 3.8% = $1,539  (approx. after DAF offset on NII base) | $1,539 |
| Note: Muni interest (MUNIX) excluded from NII base — ongoing tax benefit |  |
| Self-Employment Tax: | $0  (no SE income in 2023) |
| Alternative Minimum Tax (AMT): | $0  (deductions reduce AMTI below exemption) |
| Child Tax Credit (2 children; phase-out begins $400K — partial phase-out): | ($1,500) |
| TOTAL FEDERAL INCOME TAX (Est.): | ~$81,071 |
| Effective Federal Tax Rate: | ~19.2% |
| Marginal Rate: | 32% |

Estimated Tax Payments & Balance Due

| Federal Tax Withheld (W-2s): | $48,000 |
| --- | --- |
| Estimated Tax Payments (Q3 + Q4 2023): | $28,000 |
| TOTAL PAYMENTS: | $76,000 |
| Federal Tax Liability: | ~$81,071 |
| Balance Due (filed April 15, 2024): | ~$5,071 |

Estimated payments of $28,000 were made in Q3 and Q4 2023 to reduce underpayment exposure following the Q2 RSU vest. Coordinated by Lisa Torres, EA. Balance due ~$5,071 paid at filing.

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | ~$369,000 |
| --- | --- |
| MN Tax (approx. effective rate 8.5%): | ~$31,365 |
| MN Tax Withheld + Estimated Payments: | $29,000 |
| Balance Due: | ~$2,365 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

| ACCT-TX01 Money Market (Fidelity Institutional): | $720 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $480 |
| TOTAL TAXABLE INTEREST: | $1,200 |
| Tax-Exempt Interest (MUNIX — informational): | $380 |

| UECIX (ACCT-TX01): | $380 |
| --- | --- |
| IDEIX (ACCT-TX01): | $240 |
| NLTK Common Stock: | $110 |
| REITX (ACCT-TX01): | $70 |
| Total Ordinary Dividends: | $800 |
| Qualified Dividends: | $660 |

SECTION 7 — CHARITABLE CONTRIBUTIONS & DAF (SCHEDULE A)

Clearwater Giving Fund — DAF Contribution | GoalID-2023-01

| DAF Sponsor: | Clearwater Giving Fund (Clearwater Wealth Partners affiliate) |
| --- | --- |
| Contribution Date: | Q2 2023 (April–June per DecisionID-2023-349) |
| Assets Contributed: | Appreciated NLTK common stock shares |
| Fair Market Value at Contribution: | $25,000 |
| Cost Basis of Contributed Shares: | ~$8,200  (long-term holding) |
| Embedded Gain NOT Recognized: | ~$16,800  (IRC §170(e)(1)(A) — appreciated property rule) |
| Estimated Tax Savings on Avoided Gain (at 23.8%): | ~$3,998 |
| Federal Deduction (FMV — held >1 year): | $25,000 |
| AGI Limitation Check (60% for cash; 30% for appreciated stock): | 30% of ~$421,500 = $126,450  — deduction not limited |
| Schedule A Line 12 (Charitable contributions): | $25,000 (DAF) + $1,000 (cash) = $26,000 total |

SECTION 8 — RETIREMENT ACCOUNT CONTRIBUTIONS

| Account / Item | Detail |
| --- | --- |
| Alex — 401(k) Contributions (NLTK Corp.): | $22,500  (2023 IRS limit) |
| Sam — 401(k) Contributions (Lakeside Marketing): | $10,000 |
| Roth IRA (ACCT-RIRA) — Direct Contribution: | Not eligible (MAGI >> Roth limit) |
| 2023 Roth phase-out MFJ: $218K–$228K MAGI; household MAGI ~$421K |  |
| Backdoor Roth conversion not executed in 2023 (under evaluation) |  |
| 529 Contributions (ACCT-529A Maya + ACCT-529B Eli): | $5,000 each  ($10,000 total) |
| MN 529 Deduction (up to $1,500/beneficiary MFJ): | ($3,000) |

SECTION 9 — TAX PLANNING NOTES & CROSS-REFERENCES

Key Events — TY2023

| EventID-2023-01: | NLTK RSU liquidity event — large vest; AGI spikes to ~$421K |
| --- | --- |
| TaxTopicID-2023-01: | High-income year: estimated taxes + DAF bunching strategy |
| DecisionID-2023-349: | NLTK diversification (Apr–Jun 2023); DAF funded Phase 1 |
| GoalID-2023-01: | Values-based giving plan — Clearwater Giving Fund established |
| 2022 Carryforward: | $12,500 applied; reduces net taxable gains to $37,500 |
| Carryforward Remaining: | $0  (fully utilized in 2023) |
| Story Arc 2: | Begins: Liquidity event → DAF → estate urgency in 2024 |

Forward-Looking Items

1. No capital loss carryforward remaining after TY2023 application. Future TLH opportunities should be evaluated annually.

2. High AGI ($421K) triggers maximum NIIT. Ongoing muni bond placement in ACCT-TX01 (MUNIX) remains tax-efficient as MUNIX income is excluded from NII.

3. 2024 estate planning review triggered by EventID-2024-01 — beneficiary designation audit and healthcare directive update required.

Document Cross-References

| 1099 Bundle TY2023: | 1099Bundle_ChenHousehold_TY23.pdf |
| --- | --- |
| DAF Establishment Packet: | DAFEstablishmentPacket_ClearwaterGivingFund_2023.pdf |
| Tax Planning Memo (High-Income Year): | TaxPlanningMemo_HighIncomeYear_TaxTopicID-2023-01.pdf |
| Trade Proposal (NLTK Diversification): | TradeProposal_ChenHousehold_DecisionID-2023-349.pdf |
| Annual Consolidated Report 2023: | DOC-AnnualConsolidatedReport-2023-001 |
| Meeting Notes Q2 2023: | MeetingNotes_ChenHousehold_MtgID-2023Q2-01.pdf |
| This Document: | DOC-TaxReturnSummary-2023-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Document ID: DOC-TaxReturnSummary-2023-001 | Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
