CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2022

Tax-Loss Harvesting Year — Net Capital Loss (−$15,500) + Carryforward | TaxTopicID-2022-01

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2022 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 15, 2023 |
| Document ID: | DOC-TaxReturnSummary-2022-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981  (Age 39 at year-end) |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984  (Age 38 at year-end) |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader  |  NLTK Corp. |
| Occupation (Spouse): | Marketing Director |
| Home Ownership: | Homeowners since 2021 (EventID-2021-01) — first full itemized year 2021 |
| Trust: | Chen Family Revocable Trust — disregarded entity (DOC-Trust-2019-001) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001  |  Age 11 at year-end |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002  |  Age 8 at year-end |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — NLTK Corp. (incl. RSU vest FMV in Box 1): | $207,000 |
| NLTK RSUs vested in 2022; FMV at vest included in Box 1 W-2 income |  |
| Sam Chen — Lakeside Marketing Group: | $51,000 |
| TOTAL W-2 Wages: | $258,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Consulting / Freelance Income (Alex — Form 1099-NEC): | $10,000 |
| Self-Employment Tax (SE Tax on $10,000): | $1,413 |
| SE Tax Deduction (50% of SE Tax, Schedule 1): | ($707) |
| TOTAL Other Income (net of SE deduction): | $9,293 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| ACCT-TX01 Money Market (elevated rates — Fed raised 7x in 2022): | $520 |
| ACCT-CASH High-Yield Savings: | $380 |
| TOTAL Taxable Interest: | $900 |
| Tax-Exempt Interest (MUNIX — informational only): | $320 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX / UECIY — US Equity Core Index (ACCT-TX01; TLH swap positions): | $265 |
| IDEIX / IDEIY — Intl Developed Equity (ACCT-TX01; TLH swap positions): | $180 |
| NLTK — Common Stock (ACCT-TX01): | $65 |
| Other Fund Distributions (IRA1, RIRA — not taxable currently): | $0 |
| Total Ordinary Dividends: | $510 |
| Qualified Dividends: | $420 |
| Tax-Exempt Interest (MUNIX — informational only): | $320 |

Capital Gains & Losses (Schedule D — TLH Year)

TLH Campaign executed September 5–30, 2022 under DecisionID-2022-301. UECIX swapped to UECIY; IDEIX swapped to IDEIY. Wash sale rules observed; 31-day hold confirmed before any reversal. Reference: TaxPlanningMemo-TLH-DecisionID-2022-301.pdf | TaxTopicID-2022-01.

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (routine rebalancing in ACCT-TX01): | $2,100 |
| Short-Term Capital Losses (TLH swaps — UECIX, IDEIX): | ($11,800) |
| NET Short-Term Capital Gains / (Losses): | ($9,700) |
| Long-Term Capital Gains (routine rebalancing): | $2,200 |
| Long-Term Capital Losses (TLH swaps): | ($8,000) |
| NET Long-Term Capital Gains / (Losses): | ($5,800) |
| NET Capital Gain / (Loss) before limitation: | ($15,500) |
| Capital Loss Deduction against Ordinary Income (IRC §1211): | ($3,000) |
| Capital Loss Carryforward to 2023: | ($12,500) |

Net capital loss of ($15,500) yields: $3,000 deducted against ordinary income in 2022 (estimated tax savings ~$990 at 33% marginal rate), and $12,500 carried forward to TY2023 to offset future capital gains — strategically timed to offset anticipated RSU-related gains. See 1099-B: 1099Bundle_ChenHousehold_TY22.pdf.

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| W-2 Wages: | $258,000 |
| --- | --- |
| Other Income (Consulting / SE): | $10,000 |
| Taxable Interest: | $900 |
| Ordinary Dividends: | $510 |
| Net Capital Loss (limited to $3,000 deduction): | ($3,000) |
| Total Gross Income: | $266,410 |
| Less: SE Tax Deduction: | ($707) |
| Less: Other Schedule 1 Deductions: | $0 |
| ADJUSTED GROSS INCOME (AGI): | ~$265,703 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Itemized (second year; home purchased 2021) |
| --- | --- |
| Standard Deduction (MFJ 2022 — not elected): | $25,900 |
| Itemized Deductions: |  |
| Mortgage Interest (Lakeside Mortgage Co. — ACCT-TX01 source): | $17,000 |
| State & Local Taxes Paid (SALT — TCJA cap): | $10,000 |
| Charitable Contributions (cash gifts): | $5,000 |
| Total Itemized Deductions: | $32,000 |
| Elected over standard ($32,000 > $25,900): | (Itemized) |
| Qualified Business Income Deduction (QBI): | $0 |
| TAXABLE INCOME: | ~$233,703 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2022 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $20,550 | $20,550 | $2,055 |
| 12% | $20,551 – $83,550 | $63,000 | $7,560 |
| 22% | $83,551 – $178,150 | $94,600 | $20,812 |
| 24% | $178,151 – $233,703 | $55,553 | $13,333 |
| Ordinary Income Tax Subtotal: |  |  | $43,760 |
| Long-Term Cap Gains Tax: |  |  | $0  (no net LTCG) |
| Total Income Tax Before Credits: |  |  | $43,760 |

Additional Taxes, Credits & SE Tax

| Net Investment Income Tax (3.8% on NII above $250K threshold): | $594 |
| --- | --- |
| AGI $265,703 > $250K; NII = $15,660; excess = $15,703 |  |
| NIIT base = min($15,660, $15,703) = $15,660 × 3.8% |  |
| Self-Employment Tax (Schedule SE on $10,000): | $1,413 |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children × $2,000; phase-out begins $400K — not affected): | ($4,000) |
| Other Credits: | $0 |
| TOTAL FEDERAL INCOME TAX: | $41,767 |
| Effective Federal Tax Rate: | ~15.7% |
| Marginal Rate: | 24% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s): | $43,200 |
| --- | --- |
| Estimated Tax Payments (Quarterly): | $0 |
| TOTAL PAYMENTS: | $43,200 |
| Federal Tax Liability: | $41,767 |
| Refund: | $1,433 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx. same as federal base): | ~$233,703 |
| --- | --- |
| MN Tax (approx. effective rate 7.8%): | ~$18,229 |
| MN Tax Withheld + Estimated Payments: | $18,900 |
| MN Refund: | $671 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| ACCT-TX01 Money Market (Fidelity Institutional): | $520 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $380 |
| TOTAL TAXABLE INTEREST: | $900 |
| Tax-Exempt Interest (MUNIX in ACCT-TX01 — informational): | $320 |

Part II — Ordinary Dividends

| UECIX / UECIY (TLH swap fund; ACCT-TX01): | $265 |
| --- | --- |
| IDEIX / IDEIY (TLH swap fund; ACCT-TX01): | $180 |
| NLTK Common Stock (ACCT-TX01): | $65 |
| Total Ordinary Dividends: | $510 |
| Qualified Dividends: | $420 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

TLH Campaign Summary — DecisionID-2022-301 | TaxTopicID-2022-01

Execution window: September 5–30, 2022. Securities sold and replaced:

| UECIX (US Equity Core Index) → UECIY (Alt fund; near-identical exposure): | Sold at loss; UECIY purchased |
| --- | --- |
| IDEIX (Intl Developed Equity) → IDEIY (Alt fund; near-identical exposure): | Sold at loss; IDEIY purchased |
| Wash Sale Compliance: | 31-day hold confirmed; no disallowed losses |
| Form 8949 Reference: | 1099Bundle_ChenHousehold_TY22.pdf (Box E short-term; Box F long-term) |

| Security / Description | Date(s) Sold | Proceeds | Gain / (Loss) |
| --- | --- | --- | --- |
| UECIX (ST) | Various 2022 | $47,200 | ($8,700) |
| IDEIX (ST) | Various 2022 | $31,100 | ($3,100) |
| Routine rebalance trades (ST) | Q1–Q2 2022 | $12,400 | $2,100 |
| NET Short-Term: |  |  | ($9,700) |
| UECIX lot (LT, held >1yr) | Various 2021 | $38,600 | ($4,200) |
| IDEIX lot (LT, held >1yr) | Various 2021 | $22,900 | ($3,800) |
| Routine rebalance (LT) | Q1 2022 | $8,700 | $2,200 |
| NET Long-Term: |  |  | ($5,800) |
| NET CAPITAL GAIN / (LOSS): |  |  | ($15,500) |

Capital Loss Application: ($3,000) against ordinary income per IRC §1211(b). Remaining ($12,500) carried to TY2023 — Form 1040 Schedule D, Line 6.

SECTION 8 — RETIREMENT ACCOUNT CONTRIBUTIONS

| Account / Item | Detail |
| --- | --- |
| Alex — 401(k) Contributions (via NLTK Corp. payroll): | $20,500  (2022 IRS limit) |
| Sam — 401(k) Contributions (via Lakeside Marketing): | $10,000 |
| Alex — Roth IRA Contribution (ACCT-RIRA): | $6,000  (2022 limit; MFJ MAGI phase-out begins $204K) |
| MAGI check: ~$265K exceeds Roth limit — no direct contribution eligible |  |
| Note: Backdoor Roth conversion to be evaluated; not executed in 2022 |  |
| IRA Deductibility: | Non-deductible (covered by employer plan; AGI above phase-out) |
| 529 Contributions (ACCT-529A Maya + ACCT-529B Eli): | $5,000 each  ($10,000 total) |
| MN 529 Deduction (up to $1,500/beneficiary MFJ): | ($3,000) |

SECTION 9 — TAX PLANNING NOTES & CROSS-REFERENCES

Key Events — TY2022

| TaxTopicID-2022-01: | TLH, wash sale avoidance, $12,500 carryforward to TY2023 |
| --- | --- |
| EventID-2022-01: | Rate hike environment; TLH opportunity identified and executed |
| DecisionID-2022-301: | TLH campaign (Sep 5–30, 2022) — UECIX→UECIY; IDEIX→IDEIY |
| DOC-IPS-Ref: | IPS-2020 (DOC-IPSAmendment-2020-001) in effect; 60/35/5 allocation |
| Story Arc 1: | Concludes: COVID reallocation → IPS amendment → TLH harvest |
| Story Arc 3 Note: | DOC-StrategyDeck-2022-002 (v2) has stale 1.00% fee reference; FINAL is DOC-StrategyDeck-2022-003 with correct tiered schedule |

Forward-Looking Items

1. Capital Loss Carryforward ($12,500) will offset TY2023 capital gains — strategically valuable given anticipated RSU vest in 2023 (EventID-2023-01 preview).

2. Itemized deductions ($32,000) continue to exceed standard deduction and are expected to remain effective for the foreseeable future given mortgage interest on the 2021 home purchase.

3. NIIT exposure present ($594) — monitor AGI in future years, particularly if RSU vesting accelerates. Muni bond income (MUNIX) is excluded from NIIT base.

Document Cross-References

| 1099 Bundle TY2022: | 1099Bundle_ChenHousehold_TY22.pdf |
| --- | --- |
| TLH Tax Planning Memo: | TaxPlanningMemo-TLH-DecisionID-2022-301.pdf |
| Trade Confirmations: | TradeConfirmations_TLH_DecisionID-2022-301.pdf |
| IPS Amendment (2020): | DOC-IPSAmendment-2020-001 |
| Meeting Notes Q3 2022: | MeetingNotes_ChenHousehold_MtgID-2022Q3-01.pdf |
| Annual Consolidated Report: | DOC-AnnualConsolidatedReport-2022-001 |
| This Document: | DOC-TaxReturnSummary-2022-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Document ID: DOC-TaxReturnSummary-2022-001 | Dataset ID: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
