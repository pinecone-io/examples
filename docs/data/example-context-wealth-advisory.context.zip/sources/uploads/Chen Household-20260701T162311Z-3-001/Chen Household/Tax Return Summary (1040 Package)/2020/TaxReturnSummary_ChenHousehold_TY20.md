CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2020

COVID Reallocation Year — IPS Amendment & Realized Gains (EventID-2020-01 / DecisionID-2020-044)

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2020 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 13, 2021 |
| Document ID: | DOC-TaxReturnSummary-2020-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Trust (disregarded entity): | Chen Family Revocable Trust — DOC-Trust-2019-001 |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — Clearwater Tech (NLTK Corp.): | $194,000 |
| Includes NLTK RSU tranche; COVID-related bonus included in W-2 |  |
| Sam Chen — Lakeside Marketing Group: | $48,000 |
| TOTAL W-2 Wages: | $242,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Employer Bonus / Supplemental Compensation (Alex): | $8,000 |
| Paid outside W-2 cycle; Form 1099-MISC received |  |
| TOTAL Other Income: | $8,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $280 |
| ACCT-CASH High-Yield Savings (rate compression from Fed cuts): | $320 |
| TOTAL Taxable Interest: | $600 |
| (Note: Fed slashed rates to 0% in March 2020; interest income lower vs. 2019) |  |
| Tax-Exempt Interest (MUNIX): | $140 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $370 |
| UCBIX — US Core Bond Index Fund (expanded in IPS-2020): | $280 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $210 |
| MUNIX — Municipal Bond Fund (tax-exempt): | $140 * |
| Total Ordinary Dividends: | $1,000 |
| Qualified Dividends: | $800 |
| * Tax-Exempt Interest (informational): | $140 |

Capital Gains (Schedule D) — DecisionID-2020-044

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $0 |
| Long-Term Capital Gains — Defensive Reallocation Trades: | $12,000 |
| UECIX → UCBIX / UTIPX repositioning (June 2020) |  |
| Tax outcome of DecisionID-2020-044 (COVID risk shift) |  |
| Capital Loss Carryforward from 2019: | $0 |
| NET Capital Gains: | $12,000 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total Gross Income: | $263,600 |
| --- | --- |
| Above-the-Line Adjustments (Schedule 1): | $0 |
| ADJUSTED GROSS INCOME (AGI): | $263,600 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Standard Deduction (MFJ 2020) |
| --- | --- |
| Standard Deduction: | ($24,800) |
| Itemized Deduction Analysis (for reference): |  |
| SALT (capped): | $10,000 |
| Charitable contributions: | $4,500 |
| Total Itemized (estimated): | $14,500 |
| Standard deduction elected — $24,800 > $14,500: | (Standard deduction more beneficial) |
| TAXABLE INCOME: | $238,800 |

Note: CARES Act (2020) provisions: no RMD required this year (not applicable to Chens at current age); 100% AGI charitable deduction limit (Chens elected standard deduction, so enhanced limit not utilized). Reference: KF-CARES-Act-Summary.md.

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2020 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $19,750 | $19,750 | $1,975 |
| 12% | $19,751 – $80,250 | $60,500 | $7,260 |
| 22% | $80,251 – $171,050 | $90,800 | $19,976 |
| 24% | $171,051 – $226,800 | $55,750 | $13,380 |
| Ordinary Income Tax Subtotal: |  |  | $42,591 |
| LT Cap Gains Tax (15% on $12,000): |  |  | $1,800 |
| Total Before NIIT/Credits: |  |  | $44,391 |

Additional Taxes & Credits

| Net Investment Income Tax (3.8% on NII above $250K): | $518 |
| --- | --- |
| AGI $263,600 > $250K; excess = $13,600; NII = $13,600 × 3.8% |  |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 × $2,000): | ($4,000) |
| TOTAL FEDERAL INCOME TAX: | $40,909 |
| Effective Federal Tax Rate: | 15.5% |
| Marginal Rate: | 24% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s combined): | $43,500 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $43,500 |
| Federal Tax Liability: | $40,909 |
| Refund: | $2,591 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | $238,800 |
| --- | --- |
| MN Tax (approx. effective rate 7.7%): | $18,388 |
| MN Tax Withheld: | $19,200 |
| MN Refund: | $812 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| ACCT-TX01 Money Market: | $280 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $320 |
| TOTAL TAXABLE INTEREST: | $600 |
| Tax-Exempt Interest (MUNIX): | $140 |

Part II — Ordinary Dividends

| UECIX — US Equity Core Index: | $370 |
| --- | --- |
| UCBIX — US Core Bond Index (increased position per IPS-2020): | $280 |
| IDEIX — Intl Developed Equity: | $210 |
| Miscellaneous / Reinvested: | $140 |
| TOTAL ORDINARY DIVIDENDS: | $1,000 |
| Qualified Dividends: | $800 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| No short-term transactions in TY2020 | — | — | $0 |

Long-Term Transactions — DecisionID-2020-044 (COVID Defensive Repositioning)

| UECIX → UCBIX swap (ACCT-TX01) | 2017-04-10 | 2020-06-22 | $5,800 |
| --- | --- | --- | --- |
| UECIX → UTIPX swap (ACCT-TX01) | 2018-01-15 | 2020-06-25 | $3,200 |
| IDEIX → UCBIX swap (ACCT-TX01) | 2016-09-20 | 2020-06-30 | $2,200 |
| REITX trim (ACCT-TX01 risk reduction) | 2018-03-10 | 2020-06-30 | $800 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $12,000 |

| Capital Loss Carryforward to 2021: | $0 |
| --- | --- |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2020)

2020 was defined by the COVID-19 pandemic shock (S&P 500 fell 34% in March, recovered to +16% for the full year) and the beginning of Story Arc 1. Alex expressed significant concern in the Q1 emergency meeting (MtgID-2020Q1-02), which triggered a formal risk tolerance review (DOC-RiskQuestionnaire-2020-001, score dropped from 68 to 54/100). The IPS was formally amended in June 2020 (DOC-IPSAmendment-2020-001): allocation shifted from 70/28/2 to 60/35/5 with a ‘sleep-at-night’ defensive posture. The repositioning trades (DecisionID-2020-044) generated ~$12,000 in long-term capital gains — the primary tax story this year. 529 accounts for Maya (ACCT-529A) and Eli (ACCT-529B) were opened in May 2020 (RecID-2020-02). Year-end AUM: $792,000.

Tax Planning Notes — TaxTopicID-2020-01

| IPS Version in Effect: | DOC-IPSAmendment-2020-001 (60/35/5) — effective June 15, 2020 |
| --- | --- |
| Prior IPS: | DOC-IPS-2016-001 (70/28/2) — active Jan–Jun 2020 |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 (1.00% flat fee) |
| Life Event: | EventID-2020-01 — COVID volatility triggers IPS amendment |
| Key Decision: | DecisionID-2020-044 — defensive repositioning; LT gains $12,000 |
| Tax Topic: | TaxTopicID-2020-01 — Reallocation gains and tax budgeting |
| 529 Accounts Opened: | ACCT-529A (Maya), ACCT-529B (Eli) — May 2020; RecID-2020-02 |
| CARES Act: | Enhanced charitable deduction not used (std deduction); no RMD applies |
| NIIT: | AGI $263,600 generates NIIT of $518; NII = cap gains + dividends |
| Charity: | $4,500 — standard deduction remains optimal |
| Cap Loss Carryforward to 2021: | $0 |

Story Arc 1 Note

This tax return documents the tax consequence of Story Arc 1 (Phase 1): the COVID anxiety event (EventID-2020-01) led to a risk questionnaire score drop, IPS amendment, and defensive repositioning (DecisionID-2020-044). The resulting LT gains of $12,000 appear here on Schedule D. Cross-reference: DOC-RiskQuestionnaire-2020-001, DOC-IPSAmendment-2020-001, 1099Bundle_ChenHousehold_TY20.pdf (ACCT-TX01 1099-B details).

Document Cross-References

| Emergency Meeting Notes + Transcript: | MtgID-2020Q1-02 | EventID-2020-01 |
| --- | --- |
| IPS Amendment (COVID Defensive): | DOC-IPSAmendment-2020-001 |
| Risk Questionnaire Update: | DOC-RiskQuestionnaire-2020-001 |
| Trade Decision: | DecisionID-2020-044 |
| 1099 Bundle: | 1099Bundle_ChenHousehold_TY20.pdf |
| Tax Topic: | TaxTopicID-2020-01 |
| Prior Year: | DOC-TaxReturnSummary-2019-001 |
| Next Year: | DOC-TaxReturnSummary-2021-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
