CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2018

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2018 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 9, 2019 |
| Document ID: | DOC-TaxReturnSummary-2018-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader |
| Occupation (Spouse): | Marketing Director |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries (TCJA — First Year)

| Source | Amount |
| --- | --- |
| Alex Chen — Clearwater Tech (NLTK Corp.): | $183,000 |
| (Includes $25,000 initial RSU vest — EventID-2018-01) |  |
| Sam Chen — Lakeside Marketing Group: | $45,000 |
| TOTAL W-2 Wages: | $228,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Equity Compensation — Supplemental RSU Vest (NLTK): | $25,000 |
| (Reported on Form W-2c; included in Alex’s W-2 total above) |  |
| Reference: EventID-2018-01 | KF-RSU-Taxation.md | KF-Concentration-Risk.md |  |
| Business / Consulting Income: | $0 |
| TOTAL Other Income: | $0 (captured in W-2) |

RSU Note: Alex received the first tranche of Clearwater Tech (NLTK) Restricted Stock Units. The FMV at vesting ($25,000) is included in W-2 Box 1 wages. Shares held in ACCT-TX01. This initiates the NLTK single-stock concentration position that will be actively managed in subsequent years. Reference: EventID-2018-01.

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $355 |
| ACCT-CASH High-Yield Savings: | $445 |
| Checking/Savings — Operating Account: | $200 |
| TOTAL Taxable Interest: | $800 |
| (Note: rising Fed funds rate driving higher cash yields) |  |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $290 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $225 |
| NLTK — Clearwater Tech (ACCT-TX01) — no dividend declared: | $0 |
| MUNIX — Municipal Bond Fund (tax-exempt): | $185 * |
| Total Ordinary Dividends: | $700 |
| Qualified Dividends: | $560 |
| * Tax-Exempt Interest (informational): | $185 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $1,000 |
| Long-Term Capital Gains (ACCT-TX01): | $5,000 |
| Capital Loss Carryforward from 2017: | $0 |
| NET Capital Gains: | $6,000 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total W-2 + Investment Income: | $260,500 |
| --- | --- |
| Above-the-Line Adjustments (Schedule 1): | $0 |
| (SALT deduction moved below-line under TCJA) |  |
| ADJUSTED GROSS INCOME (AGI): | $260,500 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Standard Deduction (MFJ 2018 — TCJA) |
| --- | --- |
| Standard Deduction: | ($24,000) |
| (TCJA nearly doubled the standard deduction — exemptions eliminated) |  |
| TAXABLE INCOME: | $236,500 |

Itemized deduction analysis (for planning): Total itemized deductions estimated at ~$18,200 (state/local taxes capped at $10,000 SALT, mortgage interest not applicable — renting in 2018, charitable $3,500). Standard deduction of $24,000 is more beneficial. Itemization revisited after home purchase in 2021.

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2018 MFJ Tax Brackets — TCJA Year 1)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $19,050 | $19,050 | $1,905 |
| 12% | $19,051 – $77,400 | $58,350 | $7,002 |
| 22% | $77,401 – $165,000 | $87,600 | $19,272 |
| 24% | $165,001 – $230,500 | $65,500 | $15,720 |
| Ordinary Income Tax Subtotal: |  |  | $43,899 |
| ST Cap Gains (22% rate on $1,000): |  |  | $220 |
| LT Cap Gains (15% on $5,000): |  |  | $750 |
| Total Income Tax Before NIIT/Credits: |  |  | $44,869 |

Additional Taxes & Credits

| Net Investment Income Tax (3.8% on NII above $250K): | $394 |
| --- | --- |
| (AGI $260,500 exceeds $250K by $10,500; NII = $7,500 × 3.8%) |  |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 × $2,000 — TCJA increased credit): | ($4,000) |
| TOTAL FEDERAL INCOME TAX: | $41,263 |
| Effective Federal Tax Rate: | 15.8% |
| Marginal Rate: | 24% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s combined): | $44,500 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $44,500 |
| Federal Tax Liability: | $41,263 |
| Refund: | $3,237 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx. — MN does not conform to TCJA × exemptions): | $222,500 |
| --- | --- |
| MN Tax (approx. effective rate 7.8%): | $17,355 |
| MN Tax Withheld: | $17,800 |
| MN Refund: | $445 |
| Note: | MN did not adopt TCJA standard deduction increase; MN uses separate deduction schedule |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| ACCT-TX01 Money Market (Fidelity): | $355 |
| --- | --- |
| ACCT-CASH High-Yield Savings: | $445 |
| Operating/Checking Account: | $200 |
| TOTAL TAXABLE INTEREST: | $800 |
| Tax-Exempt Interest (MUNIX): | $185 |

Part II — Ordinary Dividends

| UECIX — US Equity Core Index Fund: | $290 |
| --- | --- |
| IDEIX — Intl Developed Equity Index: | $225 |
| Miscellaneous / Fund Distributions: | $185 |
| TOTAL ORDINARY DIVIDENDS: | $700 |
| Qualified Dividends: | $560 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| NLTK — Partial shares sold at vesting (ACCT-TX01) | 2018-06-01 | 2018-06-15 | $1,000 |
| NET SHORT-TERM CAPITAL GAIN: |  |  | $1,000 |

Long-Term Transactions

| UECIX rebalancing — ACCT-TX01 | 2016-03-10 | 2018-10-22 | $2,800 |
| --- | --- | --- | --- |
| IDEIX rebalancing — ACCT-TX01 | 2015-06-22 | 2018-10-22 | $2,200 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $5,000 |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2018)

2018 was the first year under TCJA and the year Alex’s equity compensation (NLTK RSUs) began — EventID-2018-01. The S&P 500 fell 6% with a sharp Q4 selloff (-14% in December), testing the Chens’ risk tolerance. Portfolio ended the year at $608,000 AUM. The NLTK concentration position is now actively monitored. NIIT became applicable for the first time as AGI exceeded the $250,000 MFJ threshold.

Tax Planning Notes

| IPS Version in Effect: | DOC-IPS-2016-001 (70/28/2) |
| --- | --- |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 (1.00% flat fee) |
| Life Event: | EventID-2018-01 — Equity comp (RSUs) begins; NLTK concentration introduced |
| TCJA Impact: | Std deduction $24,000 elected; Child Tax Credit doubled to $2,000/child |
| NIIT First Year: | AGI $260,500 triggers NIIT on $7,500 NII; $394 tax impact |
| Concentration Risk: | NLTK now ~4% of taxable portfolio; KF-Concentration-Risk.md consulted |
| Charitable: | $3,500 cash — standard deduction remains superior to itemizing |
| MN Non-Conformity: | MN does not follow TCJA; uses separate MN deduction schedule |
| Capital Loss Carryforward to 2019: | $0 |
| AMT: | None |
| Recommendation for 2019: | Begin NLTK diversification planning; monitor RSU vest schedule; review trust planning (EventID-2019-01 expected) |

RSU / Equity Compensation Summary

| Employer: | Clearwater Tech (NLTK) |
| --- | --- |
| Grant Date: | 2018-06-01 |
| Shares Vested (TY2018): | 500 shares |
| FMV at Vest: | $50.00 per share |
| W-2 Ordinary Income (included above): | $25,000 |
| Shares Sold at Vest for Tax Withholding: | 20 shares ($1,000 short-term gain) |
| Shares Retained in ACCT-TX01: | 480 shares |
| Reference: | EventID-2018-01 | KF-RSU-Taxation.md |

Document Cross-References

| Meeting Notes (Q4 2018): | MtgID-2018Q4-01 |
| --- | --- |
| Equity Comp Analysis: | EventID-2018-01 | KF-RSU-Taxation.md |
| Trade Proposal (Q4 Rebalancing): | DOC-TradeProposal-2018Q4-001 |
| IPS: | DOC-IPS-2016-001 |
| Prior Year Tax Return: | DOC-TaxReturnSummary-2017-001 |
| Next Year Tax Return: | DOC-TaxReturnSummary-2019-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
