CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2016

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2016 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 12, 2017 |
| Document ID: | DOC-TaxReturnSummary-2016-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader |
| Occupation (Spouse): | Marketing Director |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Relationship: Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Relationship: Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — Employer: Clearwater Tech (NLTK Corp.): | $163,500 |
| Sam Chen — Employer: Lakeside Marketing Group: | $41,500 |
| TOTAL W-2 Wages: | $205,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $285 |
| ACCT-CASH High-Yield Savings Account: | $315 |
| TOTAL Taxable Interest: | $600 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $240 |
| UCBIX — US Core Bond Index Fund (ACCT-IRA1 — non-taxable): | — |
| MUNIX — Municipal Bond Fund (tax-exempt interest): | $175 * |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $185 |
| Total Ordinary Dividends: | $600 |
| Qualified Dividends (subset): | $480 |
| * Tax-Exempt Interest (reported, not taxed): | $175 |

Capital Gains & Losses (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $0 |
| Long-Term Capital Gains (ACCT-TX01 rebalancing): | $3,500 |
| Capital Loss Carryforward from Prior Year: | $0 |
| NET Capital Gains (reported on Form 1040): | $3,500 |

Other Income

| Other Income (Schedule 1): | $0 |
| --- | --- |
| Alimony / Business Income: | $0 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total Income (Line 7b): | $209,700 |
| --- | --- |
| Above-the-Line Adjustments: | $0 |
| (IRA deduction: phased out at this income level for MFJ) |  |
| ADJUSTED GROSS INCOME (AGI): | $209,700 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Standard Deduction (MFJ 2016) |
| --- | --- |
| Standard Deduction: | ($12,600) |
| Personal Exemptions (4 × $4,050): | ($16,200) |
| TAXABLE INCOME: | $180,900 |

Note: Charitable contributions of $2,500 paid in 2016 did not yield an itemized deduction benefit; standard deduction exceeded itemized total. Contributions documented for record-keeping. Advisory recommendation to revisit itemization in future years.

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2016 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $18,550 | $18,550 | $1,855 |
| 15% | $18,551 – $75,300 | $56,750 | $8,513 |
| 25% | $75,301 – $151,900 | $76,600 | $19,150 |
| 28% | $151,901 – $177,400 | $25,500 | $7,140 |
| Ordinary Income Tax Subtotal: |  |  | $36,658 |
| LTCG Tax (15% on $3,500): |  |  | $525 |
| Total Income Tax Before Credits: |  |  | $37,183 |

Additional Taxes & Credits

| Net Investment Income Tax (3.8% on NII above $250K threshold): | $0 |
| --- | --- |
| (AGI $209,700 below MFJ threshold of $250,000) |  |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children × $1,000): | ($2,000) |
| Child & Dependent Care Credit: | $0 |
| Other Credits: | $0 |
| TOTAL FEDERAL INCOME TAX: | $35,183 |
| Effective Federal Tax Rate: | 16.8% |
| Marginal Rate: | 28% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s combined): | $37,200 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $37,200 |
| Federal Tax Liability: | $35,183 |
| Refund: | $2,017 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | $180,900 |
| --- | --- |
| MN Tax (approx. effective rate 7.2%): | $13,025 |
| MN Tax Withheld: | $13,800 |
| MN Refund: | $775 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| Fidelity Institutional — Money Market (ACCT-TX01): | $285 |
| --- | --- |
| High-Yield Savings (ACCT-CASH): | $315 |
| TOTAL TAXABLE INTEREST (Line 4): | $600 |
| Tax-Exempt Interest (MUNIX — for information only): | $175 |

Part II — Ordinary Dividends

| UECIX — US Equity Core Index Fund: | $240 |
| --- | --- |
| IDEIX — Intl Developed Equity Index Fund: | $185 |
| Miscellaneous / Reinvested (ACCT-TX01): | $175 |
| TOTAL ORDINARY DIVIDENDS (Line 6): | $600 |
| Qualified Dividends (Form 1040, Line 3a): | $480 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions (Assets Held 12 Months or Less)

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| No short-term transactions | — | — | $0 |

Long-Term Transactions (Assets Held More Than 12 Months)

| UECIX rebalancing — ACCT-TX01 | 2015-03-10 | 2016-11-14 | $2,100 |
| --- | --- | --- | --- |
| IDEIX rebalancing — ACCT-TX01 | 2015-06-22 | 2016-11-14 | $1,400 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $3,500 |

| Capital Loss Carryforward to 2017: | $0 |
| --- | --- |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2016)

2016 was the Chen household’s foundational year with Clearwater Wealth Partners. The account relationship was established in February 2016 with initial AUM of $410,000. The portfolio was positioned at 70% Equity / 28% Fixed / 2% Cash per IPS-2016 (DOC-IPS-2016-001). Year-end AUM reached $486,000 following contributions and strong market performance (S&P 500 +10%, post-election rally).

Tax Planning Notes

| IPS Version in Effect: | DOC-IPS-2016-001 (70/28/2) |
| --- | --- |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 (1.00% flat fee) |
| Risk Questionnaire: | DOC-RiskQuestionnaire-2016-001 (Score: 68/100 — Moderate Growth) |
| Related Goals: | GoalID-2016-01 (Retirement), GoalID-2016-02 (Education), GoalID-2016-03 (Liquidity) |
| Capital Gains Strategy: | Routine rebalancing only; no significant tax-planning trades executed |
| Itemization Status: | Standard deduction elected; charitable giving ($2,500) documented for records |
| 529 Accounts: | Not yet opened; recommendation made in Q4 2016 meeting (MtgID-2016Q4-01) |
| AMT Exposure: | None — income below AMT threshold for MFJ |
| NIIT Exposure: | None — AGI below $250,000 threshold |
| Recommendation for 2017: | Monitor TCJA tax reform proposals; evaluate itemization strategy |

Document Cross-References

| Meeting Notes (Q4 2016): | MtgID-2016Q4-01 |
| --- | --- |
| Investment Policy Statement: | DOC-IPS-2016-001 |
| Risk Questionnaire: | DOC-RiskQuestionnaire-2016-001 |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 |
| Account Statements: | ACCT-TX01, ACCT-IRA1, ACCT-RIRA |
| Next Document in Tax Series: | DOC-TaxReturnSummary-2017-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
