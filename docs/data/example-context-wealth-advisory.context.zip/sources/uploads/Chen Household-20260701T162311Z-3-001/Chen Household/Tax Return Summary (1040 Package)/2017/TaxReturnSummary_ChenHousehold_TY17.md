CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2017

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2017 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 10, 2018 |
| Document ID: | DOC-TaxReturnSummary-2017-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981 |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader |
| Occupation (Spouse): | Marketing Director |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001 |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002 |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — Clearwater Tech (NLTK Corp.): | $170,500 |
| Sam Chen — Lakeside Marketing Group: | $43,500 |
| TOTAL W-2 Wages: | $214,000 |

Non-Taxable 401(k) Rollover Note

In August 2017, Alex Chen completed a direct rollover of a prior-employer 401(k) balance to ACCT-401R (Rollover IRA), subsequently consolidated into ACCT-IRA1 (Traditional IRA) by March 31, 2018. This was a non-taxable, trustee-to-trustee transfer. No amount is included in gross income. IRS Form 5498 filed for the receiving account. Reference: ACCT-401R.

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| Fidelity Institutional — ACCT-TX01 Money Market: | $320 |
| ACCT-CASH High-Yield Savings: | $380 |
| TOTAL Taxable Interest: | $700 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $275 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $210 |
| MUNIX — Municipal Bond Fund (tax-exempt): | $165 * |
| Total Ordinary Dividends: | $650 |
| Qualified Dividends: | $520 |
| * Tax-Exempt Interest (informational, not included in income): | $165 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01): | $200 |
| Long-Term Capital Gains (ACCT-TX01): | $4,000 |
| Capital Loss Carryforward from 2016: | $0 |
| NET Capital Gains: | $4,200 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| Total Income: | $219,550 |
| --- | --- |
| Above-the-Line Adjustments: | $0 |
| ADJUSTED GROSS INCOME (AGI): | $219,550 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Standard Deduction (MFJ 2017) |
| --- | --- |
| Standard Deduction: | ($12,700) |
| Personal Exemptions (4 × $4,050): | ($16,200) |
| TAXABLE INCOME: | $190,650 |

Note: Tax Cuts and Jobs Act (TCJA) was signed into law December 22, 2017. The new law's provisions (higher standard deduction, eliminated exemptions, new marginal brackets) take effect for Tax Year 2018. A planning memo was prepared to model 2018 impact. Reference: KF-TCJA-Summary.md.

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2017 MFJ Tax Brackets — Pre-TCJA)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $18,650 | $18,650 | $1,865 |
| 15% | $18,651 – $75,900 | $57,250 | $8,588 |
| 25% | $75,901 – $153,100 | $77,200 | $19,300 |
| 28% | $153,101 – $190,650 | $37,550 | $10,514 |
| Ordinary Income Tax Subtotal: |  |  | $40,267 |
| ST Cap Gains Tax (ordinary rate 25% on $200): |  |  | $50 |
| LT Cap Gains Tax (15% on $4,000): |  |  | $600 |
| Total Income Tax Before Credits: |  |  | $40,917 |

Additional Taxes & Credits

| Net Investment Income Tax (NIIT): | $0 |
| --- | --- |
| (AGI $219,550 below $250,000 MFJ threshold) |  |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children × $1,000): | ($2,000) |
| TOTAL FEDERAL INCOME TAX: | $38,917 |
| Effective Federal Tax Rate: | 17.7% |
| Marginal Rate: | 28% |

Payments & Refund / Balance Due

| Federal Tax Withheld (W-2s combined): | $40,500 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $40,500 |
| Federal Tax Liability: | $38,917 |
| Refund: | $1,583 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | $190,650 |
| --- | --- |
| MN Tax (approx. effective rate 7.5%): | $14,299 |
| MN Tax Withheld: | $15,100 |
| MN Refund: | $801 |

SECTION 6 — SCHEDULE B: INTEREST & ORDINARY DIVIDENDS

Part I — Interest Income

| Fidelity Institutional — ACCT-TX01 Money Market: | $320 |
| --- | --- |
| High-Yield Savings (ACCT-CASH): | $380 |
| TOTAL TAXABLE INTEREST: | $700 |
| Tax-Exempt Interest (MUNIX): | $165 |

Part II — Ordinary Dividends

| UECIX — US Equity Core Index Fund: | $275 |
| --- | --- |
| IDEIX — Intl Developed Equity Index: | $210 |
| Miscellaneous / Sweep (ACCT-TX01): | $165 |
| TOTAL ORDINARY DIVIDENDS: | $650 |
| Qualified Dividends: | $520 |

SECTION 7 — SCHEDULE D: CAPITAL GAINS & LOSSES

Short-Term Transactions

| Description | Date Acquired | Date Sold | Gain / (Loss) |
| --- | --- | --- | --- |
| STBIX — Short-Term Bond Fund (ACCT-TX01) | 2017-04-10 | 2017-10-05 | $200 |
| NET SHORT-TERM CAPITAL GAIN: |  |  | $200 |

Long-Term Transactions

| UECIX rebalancing — ACCT-TX01 | 2016-01-15 | 2017-11-08 | $2,400 |
| --- | --- | --- | --- |
| IDEIX rebalancing — ACCT-TX01 | 2015-09-10 | 2017-11-08 | $1,600 |
| NET LONG-TERM CAPITAL GAIN: |  |  | $4,000 |

SECTION 8 — YEAR-IN-REVIEW & PLANNING NOTES

Key Events & Context (Tax Year 2017)

Strong year for markets (S&P 500 +19%) drove portfolio growth from $486,000 to $595,000. The 401(k) rollover was completed in Q3, consolidating Alex’s prior-employer plan into ACCT-IRA1 — a non-taxable event. TCJA was signed in December, prompting Clearwater to begin modeling the 2018 tax environment for the Chens. Advisory fee: 1.00% flat under DOC-AdvisoryAgreement-2016-001.

Tax Planning Notes

| IPS Version in Effect: | DOC-IPS-2016-001 (70/28/2) |
| --- | --- |
| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001 (1.00% flat fee) |
| Key Event: | ACCT-401R rollover completed Aug 2017 — non-taxable |
| TCJA Planning: | Planning memo prepared Q4 2017 (see TaskID-2017Q4-001) |
| Charitable Contributions: | $3,000 cash — standard deduction still elected |
| Cap Gains Strategy: | Routine rebalancing; no accelerated gain/loss harvesting |
| Capital Loss Carryforward to 2018: | $0 |
| AMT Exposure: | None |
| NIIT Exposure: | None — AGI below $250,000 threshold |
| Recommendation for 2018: | TCJA doubles standard deduction to $24,000 — re-evaluate itemization |

Document Cross-References

| Meeting Notes (Q4 2017): | MtgID-2017Q4-01 |
| --- | --- |
| Tax Planning Memo (TCJA): | TaskID-2017Q4-001 | KF-TCJA-Summary.md |
| Annual Strategy Deck: | DOC-StrategyDeck-2017-001 |
| IPS: | DOC-IPS-2016-001 |
| Prior Year Tax Return: | DOC-TaxReturnSummary-2016-001 |
| Next Year Tax Return: | DOC-TaxReturnSummary-2018-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Dataset ID: NWP-DEMO-HH-CHEN-001 | Household: HH-CHEN-001.
