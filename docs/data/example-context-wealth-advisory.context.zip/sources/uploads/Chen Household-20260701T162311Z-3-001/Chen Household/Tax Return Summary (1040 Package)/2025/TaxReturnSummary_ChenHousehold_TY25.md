CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2025

Bucket Strategy Implemented — Tax-Efficient Asset Location | TaxTopicID-2025-01

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2025 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 15, 2026 |
| Document ID: | DOC-TaxReturnSummary-2025-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981  (Age 42 at year-end) |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984  (Age 41 at year-end) |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader  |  NLTK Corp. |
| Occupation (Spouse): | Marketing Director |
| Home Ownership: | Homeowners since 2021 (EventID-2021-01) |
| IPS Amendment: | IPS-2025 bucket strategy effective March 1, 2025 (DOC-IPSAmendment-2025-001) |
| Trust: | Chen Family Revocable Trust — disregarded entity (DOC-Trust-2019-001) |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001  |  Age 14 at year-end |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002  |  Age 11 at year-end |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — NLTK Corp. (incl. routine RSU vest FMV): | $220,000 |
| Sam Chen — Lakeside Marketing Group: | $56,000 |
| TOTAL W-2 Wages: | $276,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Equity Compensation — Supplemental RSU Income (NLTK Corp.): | $20,000 |
| Supplemental vest; FMV at vest date per NLTK equity plan statement |  |
| TOTAL Other Income: | $20,000 |

Interest Income (Schedule B — Part I)

Note: Under IPS-2025, ACCT-CASH (Bucket 1) and STBIX are held for near-term spending. Interest income reflects the continuing normalization of rates in 2025.

| Payer | Amount |
| --- | --- |
| ACCT-TX01 Money Market (Fidelity Institutional): | $800 |
| ACCT-CASH High-Yield Savings / Bucket 1 Reserve: | $550 |
| TOTAL Taxable Interest: | $1,350 |
| Tax-Exempt Interest (MUNIX in ACCT-TX01 — informational): | $430 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $415 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $265 |
| NLTK — Common Stock (<5% per IPS-2025 concentration limit): | $110 |
| REITX — Real Estate Index Fund (ACCT-RIRA — Bucket 3): | $85 |
| Other (UCBIX distributions — from ACCT-IRA1; tax-deferred): | $0  (deferred; not currently taxable) |
| Total Ordinary Dividends: | $875 |
| Qualified Dividends: | $720 |
| Tax-Exempt Interest (MUNIX): | $430 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01 rebalancing): | $1,900 |
| Long-Term Capital Gains (routine rebalancing + NLTK trim): | $14,100 |
| NLTK maintained below 5% per IPS-2025; incremental trimming |  |
| Capital Loss Carryforward from Prior Years: | $0 |
| NET Capital Gains: | $16,000 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| W-2 Wages: | $276,000 |
| --- | --- |
| Other Income (RSU supplement): | $20,000 |
| Taxable Interest: | $1,350 |
| Ordinary Dividends: | $875 |
| Net Capital Gains: | $16,000 |
| Gross Income: | $314,225 |
| Less: Schedule 1 Deductions: | $0 |
| ADJUSTED GROSS INCOME (AGI): | ~$314,225 |

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Itemized (fifth consecutive year) |
| --- | --- |
| Standard Deduction (MFJ 2025 — not elected): | ~$30,000 |
| Itemized Deductions: |  |
| Mortgage Interest (Lakeside Mortgage Co.): | $15,500 |
| State & Local Taxes Paid (SALT — TCJA cap): | $10,000 |
| Charitable Contributions (cash + DAF grant): | $7,500 |
| Total Itemized Deductions: | $33,000 |
| Exceeds standard deduction ($33,000 > ~$30,000): | (Itemized) |
| TAXABLE INCOME: | ~$281,225 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2025 MFJ Tax Brackets — Estimated)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $23,850 | $23,850 | $2,385 |
| 12% | $23,851 – $96,950 | $73,100 | $8,772 |
| 22% | $96,951 – $206,700 | $109,750 | $24,145 |
| 24% | $206,701 – $281,225 | $74,525 | $17,886 |
| Ordinary Income Tax Subtotal: |  |  | $53,188 |
| LT Cap Gains Tax (15% on ~$14,000; 20% on ~$2,000): |  |  | $2,500 |
| Total Income Tax Before NIIT/Credits: |  |  | $55,688 |

Additional Taxes, Credits & NIIT

| Net Investment Income Tax (3.8% on NII above $250K): |  |
| --- | --- |
| AGI $314,225 > $250K; excess = $64,225 |  |
| NII = ~$18,225 (int/div/cap gains); NIIT = $18,225 × 3.8% | $692 |
| Muni income (MUNIX $430) excluded from NII base — tax-efficient |  |
| Self-Employment Tax: | $0 |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children; below phase-out): | ($4,000) |
| TOTAL FEDERAL INCOME TAX (Est.): | ~$52,380 |
| Effective Federal Tax Rate: | ~16.7% |
| Marginal Rate: | 24% |

Payments & Refund

| Federal Tax Withheld (W-2s): | $54,000 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $54,000 |
| Federal Tax Liability: | ~$52,380 |
| Refund: | ~$1,620 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | ~$281,225 |
| --- | --- |
| MN Tax (approx. effective rate 8.0%): | ~$22,498 |
| MN Tax Withheld + Estimated Payments: | $23,000 |
| MN Refund: | $502 |

SECTION 6 — ASSET LOCATION & BUCKET TAX EFFICIENCY (TAXTOPICID-2025-01)

IPS-2025 (effective March 1, 2025) introduced a bucket framework with explicit tax placement rules reviewed with Lisa Torres, EA. Key principles implemented in TY2025:

| Bucket 1 (ACCT-CASH + STBIX): | Near-term spending reserve; high-yield savings for interest income |
| --- | --- |
| Bucket 2 (ACCT-IRA1 — UCBIX + UTIPX): | Taxable bonds in tax-deferred account; no annual 1099 impact |
| Bucket 3 (ACCT-TX01 — equities + MUNIX): | Growth assets; munis for tax-exempt income |
| Bucket 3 (ACCT-RIRA — REITX + small cap): | High-growth + REIT in Roth for tax-free appreciation |
| Tax Drag Reduction (Est.): | ~$1,200–$1,800/yr vs. less-optimized placement |
| Reference: | TaxTopicID-2025-01 | DOC-IPSAmendment-2025-001 |

SECTION 7 — RETIREMENT & EDUCATION ACCOUNT CONTRIBUTIONS

| Account / Item | Detail |
| --- | --- |
| Alex — 401(k) Contributions (NLTK Corp.): | $23,500  (2025 IRS limit est.) |
| Sam — 401(k) Contributions (Lakeside Marketing): | $11,500 |
| Roth IRA (ACCT-RIRA) — Direct: | Not eligible (MAGI >> Roth phase-out limit) |
| 529 Contributions (ACCT-529A + ACCT-529B): | $7,000 each  ($14,000 total) |
| MN 529 Deduction (up to $1,500/beneficiary MFJ): | ($3,000) |

SECTION 8 — TAX PLANNING NOTES & CROSS-REFERENCES

Key Events — TY2025

| TaxTopicID-2025-01: | Bucket strategy tax placement; muni bond efficiency analysis |
| --- | --- |
| DecisionID-2025-112: | Bucket strategy implementation; IPS-2025 amendment |
| RecID-2025-01: | Bucket strategy (Implemented Q1 2025) |
| RecID-2025-02: | Social Security claiming analysis delivered Q3 2025 |
| GoalID-2023-01: | DAF $7,500 in charitable grants distributed from Clearwater Giving Fund |
| Story Arc 2: | Concludes: estate corrected → bucket strategy → SS analysis |
| Arc 3 Preview: | Fee question raised Q4 2025 (EventID-2026-01 setup) — no tax impact |

Document Cross-References

| 1099 Bundle TY2025: | 1099Bundle_ChenHousehold_TY25.pdf |
| --- | --- |
| IPS Amendment (2025 Bucket Strategy): | DOC-IPSAmendment-2025-001 |
| Annual Consolidated Report 2025: | DOC-AnnualConsolidatedReport-2025-001 |
| SS Claiming Analysis: | SocialSecurityAnalysis_ChenHousehold_RecID-2025-02.pdf |
| Meeting Notes Q4 2025: | MeetingNotes_ChenHousehold_MtgID-2025Q4-01.pdf |
| This Document: | DOC-TaxReturnSummary-2025-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Document ID: DOC-TaxReturnSummary-2025-001 | Dataset: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
