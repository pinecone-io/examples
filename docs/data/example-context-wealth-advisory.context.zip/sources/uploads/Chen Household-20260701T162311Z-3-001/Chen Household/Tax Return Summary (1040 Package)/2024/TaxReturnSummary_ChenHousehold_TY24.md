CLEARWATER WEALTH PARTNERS

3215 Lakeview Circle | Wayzata, MN 55391 | clearwaterwealth.example.com

ANNUAL TAX RETURN SUMMARY

Form 1040 Package — Tax Year 2024

Normalized Income Year — Estate Audit & Beneficiary Correction | EventID-2024-01

| Prepared For: | Alex & Sam Chen |
| --- | --- |
| Household ID: | HH-CHEN-001 |
| Filing Status: | Married Filing Jointly (MFJ) |
| Tax Year: | 2024 |
| Prepared By: | Lisa Torres, EA  |  Clearwater Wealth Partners |
| Advisor of Record: | Morgan Park, CFP®  (ADV-PARK-001) |
| Date Prepared: | April 15, 2025 |
| Document ID: | DOC-TaxReturnSummary-2024-001 |

SYNTHETIC DEMO DATA ONLY — Not investment, tax, or legal advice. All names, SSNs, account numbers, and figures are fictitious.

SECTION 1 — FILING INFORMATION

| Taxpayer (Primary): | Alex Chen |
| --- | --- |
| SSN (Primary): | XXX-XX-4444 |
| Date of Birth (Primary): | March 22, 1981  (Age 41 at year-end) |
| Taxpayer (Spouse): | Sam Chen |
| SSN (Spouse): | XXX-XX-8888 |
| Date of Birth (Spouse): | November 2, 1984  (Age 40 at year-end) |
| Filing Status: | Married Filing Jointly (MFJ) |
| Mailing Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| State of Residence: | Minnesota (MN) |
| Occupation (Primary): | Software Product Leader  |  NLTK Corp. |
| Occupation (Spouse): | Marketing Director |
| Home Ownership: | Homeowners since 2021 (EventID-2021-01) |
| Trust: | Chen Family Revocable Trust — disregarded entity (DOC-Trust-2019-001) |
| Estate Update: | Beneficiary forms corrected 2024-Q3 — DOC-BeneficiaryForm-2024-001 |

Dependents

| Maya Chen | DOB: Aug 19, 2011  |  Child  |  SSN: XXX-XX-2001  |  Age 13 at year-end |
| --- | --- |
| Eli Chen | DOB: Mar 7, 2014  |  Child  |  SSN: XXX-XX-2002  |  Age 10 at year-end |

SECTION 2 — INCOME SUMMARY (FORM 1040)

W-2 Wages & Salaries

| Source | Amount |
| --- | --- |
| Alex Chen — NLTK Corp. (incl. routine RSU vest FMV in Box 1): | $215,000 |
| Sam Chen — Lakeside Marketing Group: | $55,000 |
| TOTAL W-2 Wages: | $270,000 |

Other Income (Schedule 1)

| Source | Amount |
| --- | --- |
| Equity Compensation — Supplemental RSU / ESPP Income: | $15,000 |
| NLTK supplemental vest beyond routine Box 1 amount; 1099-B supplement |  |
| TOTAL Other Income: | $15,000 |

Interest Income (Schedule B — Part I)

| Payer | Amount |
| --- | --- |
| ACCT-TX01 Money Market (rates declining from 2023 peak): | $750 |
| ACCT-CASH High-Yield Savings: | $500 |
| TOTAL Taxable Interest: | $1,250 |
| Tax-Exempt Interest (MUNIX — informational only): | $410 |

Dividend Income (Schedule B — Part II)

| Fund / Payer | Amount |
| --- | --- |
| UECIX — US Equity Core Index Fund (ACCT-TX01): | $400 |
| IDEIX — Intl Developed Equity Index (ACCT-TX01): | $260 |
| NLTK — Common Stock (reduced position; ACCT-TX01): | $120 |
| REITX — Real Estate Index Fund (ACCT-TX01): | $80 |
| MUNIX — Municipal Bond Fund (ACCT-TX01 — exempt): | $0  (tax-exempt; reported informational) |
| Total Ordinary Dividends: | $860 |
| Qualified Dividends: | $710 |
| Tax-Exempt Interest (MUNIX): | $410 |

Capital Gains (Schedule D)

| Category | Amount |
| --- | --- |
| Short-Term Capital Gains (ACCT-TX01 routine rebalancing): | $1,800 |
| Long-Term Capital Gains (ACCT-TX01 rebalancing + NLTK trim): | $12,700 |
| NLTK position gradually reduced per ongoing diversification plan |  |
| Capital Loss Carryforward from Prior Years: | $0  (fully utilized in TY2023) |
| NET Capital Gains: | $14,500 |

SECTION 3 — ADJUSTED GROSS INCOME (AGI)

| W-2 Wages: | $270,000 |
| --- | --- |
| Other Income (RSU supplement): | $15,000 |
| Taxable Interest: | $1,250 |
| Ordinary Dividends: | $860 |
| Net Capital Gains: | $14,500 |
| Gross Income: | $301,610 |
| Less: Schedule 1 Deductions: | $0 |
| ADJUSTED GROSS INCOME (AGI): | ~$301,610 |

AGI of ~$301,610 returns to a normalized range following the 2023 spike ($421K). No large liquidity event in 2024; income driven by steady employment plus routine RSU vest. No estimated tax payment surprises.

SECTION 4 — DEDUCTIONS & TAXABLE INCOME

| Deduction Method: | Itemized (fourth consecutive year) |
| --- | --- |
| Standard Deduction (MFJ 2024 — not elected): | $29,200 |
| Itemized Deductions: |  |
| Mortgage Interest (Lakeside Mortgage Co.): | $16,000 |
| State & Local Taxes Paid (SALT — TCJA cap): | $10,000 |
| Charitable Contributions (cash + DAF grants): | $6,000 |
| Total Itemized Deductions: | $32,000 |
| Exceeds standard deduction ($32,000 > $29,200): | (Itemized) |
| TAXABLE INCOME: | ~$269,610 |

SECTION 5 — FEDERAL TAX COMPUTATION

Regular Income Tax (2024 MFJ Tax Brackets)

| Rate | Bracket | Taxable Amount | Tax |
| --- | --- | --- | --- |
| 10% | $0 – $23,200 | $23,200 | $2,320 |
| 12% | $23,201 – $94,300 | $71,100 | $8,532 |
| 22% | $94,301 – $201,050 | $106,750 | $23,485 |
| 24% | $201,051 – $269,610 | $68,560 | $16,454 |
| Ordinary Income Tax Subtotal: |  |  | $50,791 |
| LT Cap Gains Tax (15% on ~$13,000; 20% on ~$1,500): |  |  | $2,250 |
| Total Income Tax Before NIIT/Credits: |  |  | $53,041 |

Additional Taxes, Credits & NIIT

| Net Investment Income Tax (3.8% on NII above $250K): | $1,976 |
| --- | --- |
| AGI $301,610 > $250K; excess = $51,610 |  |
| NII = ~$17,110 (int/div/cap gains); NIIT base = min($17,110, $51,610) |  |
| NIIT = $17,110 × 3.8% (approx.) | $650 |
| Self-Employment Tax: | $0 |
| Alternative Minimum Tax (AMT): | $0 |
| Child Tax Credit (2 children; income below phase-out ceiling): | ($4,000) |
| TOTAL FEDERAL INCOME TAX (Est.): | ~$50,041 |
| Effective Federal Tax Rate: | ~16.6% |
| Marginal Rate: | 24% |

Payments & Refund

| Federal Tax Withheld (W-2s): | $52,000 |
| --- | --- |
| Estimated Tax Payments: | $0 |
| TOTAL PAYMENTS: | $52,000 |
| Federal Tax Liability: | ~$50,041 |
| Refund: | ~$1,959 |

Minnesota State Tax (MN Form M1)

| MN Taxable Income (approx.): | ~$269,610 |
| --- | --- |
| MN Tax (approx. effective rate 7.9%): | ~$21,299 |
| MN Tax Withheld + Estimated Payments: | $21,800 |
| MN Refund: | $501 |

SECTION 6 — RETIREMENT & EDUCATION ACCOUNT CONTRIBUTIONS

| Account / Item | Detail |
| --- | --- |
| Alex — 401(k) Contributions (NLTK Corp.): | $23,000  (2024 IRS limit) |
| Sam — 401(k) Contributions (Lakeside Marketing): | $11,000 |
| Roth IRA (ACCT-RIRA) — Direct: | Not eligible (MAGI >> Roth phase-out limit) |
| 529 Contributions (ACCT-529A + ACCT-529B): | $6,000 each  ($12,000 total) |
| MN 529 Deduction (up to $1,500/beneficiary MFJ): | ($3,000) |

SECTION 7 — TAX PLANNING NOTES & CROSS-REFERENCES

Key Events — TY2024

| EventID-2024-01: | Family health event — triggered estate audit and beneficiary correction |
| --- | --- |
| RecID-2024-01: | Estate refresh + POA/health directive review (complete Q3 2024) |
| DOC-BeneficiaryForm-2024-001: | Corrects 2018 form; IRA1 and RIRA now aligned with trust |
| Story Arc 2: | Continues: Liquidity event → DAF → estate urgency → beneficiary audit resolved |
| NIIT Note: | AGI above $250K threshold; muni placement (MUNIX) continues to reduce NII base |
| Capital Gains: | Normalized $14,500 net — no carryforward available; ongoing NLTK trimming |

Document Cross-References

| 1099 Bundle TY2024: | 1099Bundle_ChenHousehold_TY24.pdf |
| --- | --- |
| Corrected Beneficiary Form: | DOC-BeneficiaryForm-2024-001 |
| Estate Planning Review: | EstatePlanningReview_ChenHousehold_EventID-2024-01.pdf |
| Annual Consolidated Report 2024: | DOC-AnnualConsolidatedReport-2024-001 |
| Meeting Notes Q3 2024: | MeetingNotes_ChenHousehold_MtgID-2024Q3-01.pdf |
| This Document: | DOC-TaxReturnSummary-2024-001 |

This document is a synthetic demonstration record prepared by Clearwater Wealth Partners for illustration purposes only. It does not constitute tax, legal, or investment advice. All data is fictitious. Document ID: DOC-TaxReturnSummary-2024-001 | Dataset: NWP-DEMO-HH-CHEN-001 | HH-CHEN-001.
