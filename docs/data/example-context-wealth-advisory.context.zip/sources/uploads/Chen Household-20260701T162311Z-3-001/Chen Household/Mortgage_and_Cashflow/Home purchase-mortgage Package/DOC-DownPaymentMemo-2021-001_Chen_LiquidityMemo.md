| CLEARWATER WEALTH PARTNERSChen Household — Home Purchase Package 2021  |  HH-CHEN-001 | DOC-DownPaymentMemo-2021-001June 18, 2021DELIVERED |
| --- | --- |

DOWN PAYMENT SOURCING & LIQUIDITY MEMO

Home Purchase Preparation — EventID-2021-01 | DecisionID-2021-141

| EVENT TRIGGER: EventID-2021-01 — Chens under contract on 8912 Birchwood Drive, Evanston, IL. This memo documents the recommended down payment sourcing strategy, tax impact of ACCT-TX01 liquidation, and revised cash flow plan. Decision executed per DecisionID-2021-141 (2021-07-10). Cross-refs: DOC-TransferAuth-2021-001, DOC-MortgagePreApproval-2021-001, TaxTopicID-2021-01. |
| --- |

| MEMORANDUM HEADER |
| --- |

| To: | Alex Chen & Sam Chen |
| --- | --- |

| From: | Morgan Park, CFP®  |  Clearwater Wealth Partners  (ADV-PARK-001) |
| --- | --- |

| Date: | June 18, 2021 |
| --- | --- |

| Re: | Down Payment Sourcing Strategy — 8912 Birchwood Drive, Evanston, IL 60201 |
| --- | --- |

| Purchase Price: | $650,000  (under contract — accepted June 16, 2021) |
| --- | --- |

| Required Down Payment: | $130,000  (20.0%  — avoids PMI per Lakeside Mortgage guidelines) |
| --- | --- |

| Estimated Closing Costs: | $8,200  (includes origination, title, prepaid escrow) |
| --- | --- |

| Total Cash Needed at Closing: | $138,200  (down payment + closing costs) |
| --- | --- |

| SECTION 1 — RECOMMENDED DOWN PAYMENT SOURCING |
| --- |

Based on a review of your current account balances as of June 15, 2021, I recommend the following down payment sourcing strategy to minimize tax impact while maintaining adequate liquidity and portfolio integrity:

| Source Account | Account ID | Amount | Method | Notes |
| --- | --- | --- | --- | --- |
| Joint Taxable Brokerage | ACCT-TX01 | $55,000 | Partial liquidation (MUNIX/UECIX/STBIX) | Tax impact — see Section 2. Auth: DOC-TransferAuth-2021-001 |
| Cash Management (HYSA) | ACCT-CASH | $60,000 | Direct wire at closing | Emergency fund rebuilt post-close; no tax impact |
| Joint Checking Account | N/A (external) | $15,000 | Cashier's check at closing | Routine savings — verified on bank statement |
| Closing Cost Credit | Lender Credit | $8,000 | Rate adjust (3.375% option) | Optional — reduces cash needed; increases rate by 0.25% |
| TOTAL | — | $130,000 + $8,200 | — | ✅  Sufficient to close at $650,000 purchase price |

| SECTION 2 — TAX IMPACT ANALYSIS (ACCT-TX01 LIQUIDATION) |
| --- |

The $55,000 liquidation from ACCT-TX01 will trigger capital gains recognition. Below is the estimated tax impact based on current holdings and cost basis as of June 2021:

| Holding | Shares Sold | Cost Basis | Proceeds | Gain/Loss | Holding Period | Tax Rate (Est.) |
| --- | --- | --- | --- | --- | --- | --- |
| MUNIX (Muni Bond Fund) | Est. 340 sh | $18,200 | $21,500 | +$3,300 | Long-term (>1 yr) | 0% / 15% (LT) |
| UECIX (US Equity Core) | Est. 180 sh | $19,400 | $24,200 | +$4,800 | Long-term (>1 yr) | 15% (LT) |
| STBIX (Short-Term Bond) | Est. 480 sh | $9,300 | $9,500 | +$200 | Long-term (>1 yr) | 0% (LT, small) |
| TOTAL | — | $46,900 | $55,200 | +$8,300 LT gain | — | — |

| ⚠  TAX IMPACT NOTE:  Combined with investment income and other portfolio activity, estimated 2021 total capital gains are projected at ~$18,500 (TaxTopicID-2021-01). This is within the 0% LTCG bracket threshold for joint filers with income below $496,600 (2021). Recommend confirming with CPA Logan Hart, JD prior to closing. See DOC-LoanEstimate-2021-001 for full closing timeline. |
| --- |

| SECTION 3 — POST-CLOSE LIQUIDITY ANALYSIS |
| --- |

After the home purchase closes, your portfolio will be restructured as follows. This analysis ensures compliance with IPS-2020 (60/35/5 target allocation) and maintains emergency fund adequacy despite the temporary cash outflow:

| Metric | Pre-Close (June 2021) | Post-Close (Est. Aug 2021) | IPS Target / Guideline |
| --- | --- | --- | --- |
| Total Investment AUM | ~$870,000 | ~$815,000 | —  (post-liquidation; recovers via ongoing contributions) |
| ACCT-TX01 Balance | ~$540,000 | ~$485,000 | Primary liquidity + growth sleeve |
| ACCT-CASH Balance | ~$80,000 | ~$20,000 | GoalID-2016-03: rebuild to $35,000 within 6 months |
| Equity Allocation | ~60% | ~58%  (slightly below target) | IPS-2020: 60% target ± 5% drift band |
| Fixed Income Allocation | ~35% | ~37%  (slightly above target) | IPS-2020: 35% target ± 5% drift band |
| Cash / Equivalents | ~5% | ~5%  (ACCT-CASH partially depleted; STBIX maintained) | IPS-2020: 5% target |
| Emergency Fund Coverage | ~4.8 months | ~1.2 months (temporary) | GoalID-2016-03: 6-month target |

| ⚠  LIQUIDITY ALERT:  Post-close ACCT-CASH balance of ~$20,000 is below the 6-month emergency fund target. Recommend re-directing $1,500/month from joint checking to ACCT-CASH for the next 12 months to restore GoalID-2016-03 reserve target. Alex's next RSU vest (est. Q4 2021) may also supplement. Addressed in DOC-PostPurchaseReview-2021-001. |
| --- |

| SECTION 4 — REBALANCING RECOMMENDATION (DecisionID-2021-141) |
| --- |

Following the liquidity event, I recommend the following portfolio adjustments to restore IPS-2020 target allocation. These trades will be submitted via separate trade proposal and confirmed per standard execution protocol:

| Action | Account | Security | Rationale |
| --- | --- | --- | --- |
| Trim slightly | ACCT-TX01 | UECIX (US Equity Core) | Equity overweight post-liquidation mix; harvest any remaining short-term losses |
| Add to | ACCT-IRA1 | UCBIX (US Core Bond) | Restore FI allocation; IRA avoids tax drag |
| Maintain | ACCT-RIRA | USCIX / EMEIX | Roth tilt to high-growth; no change needed |
| Increase contribution | ACCT-CASH | $1,500/month | Emergency fund restoration — GoalID-2016-03 |
| No change | ACCT-529A/B | 529-AGE-MOD | On track; Maya/Eli college funding progressing |

| SIGNATURES AND ACKNOWLEDGEMENT |
| --- |

| ________________________________________ | ________________________________________ |
| --- | --- |
| Morgan Park, CFP®  (ADV-PARK-001) | Alex Chen  &  Sam Chen |
| Wealth Adviser, Clearwater Wealth Partners | Client Acknowledgement |

Date: June 18, 2021

| DOC-DownPaymentMemo-2021-001  |  HH-CHEN-001  |  EventID-2021-01 | CONFIDENTIAL — FOR BORROWER AND ADVISER USE ONLY |
| --- | --- |
