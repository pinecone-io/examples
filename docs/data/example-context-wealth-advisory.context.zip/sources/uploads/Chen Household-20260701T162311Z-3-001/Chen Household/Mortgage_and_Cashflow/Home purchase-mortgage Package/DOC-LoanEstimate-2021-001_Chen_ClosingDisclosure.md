| LAKESIDE MORTGAGE CO.230 N. Michigan Ave, Suite 800  |  Chicago, IL 60601  |  NMLS #: 1048203Tel: (312) 555-0192  |  loans@lakesidemortgage.com | DOC-LoanEstimate-2021-001July 15, 2021ISSUED |
| --- | --- |

LOAN ESTIMATE & CLOSING DISCLOSURE SUMMARY

| EVENT TRIGGER: EventID-2021-01 — 8912 Birchwood Drive, Evanston, IL 60201 under contract. This document combines the initial Loan Estimate (Reg Z / TRID) and final Closing Disclosure for the Chen household mortgage. Closing date: August 5, 2021. Cross-refs: DOC-MortgagePreApproval-2021-001, DOC-DownPaymentMemo-2021-001, DOC-MortgageCommitment-2021-001, DecisionID-2021-141. |
| --- |

| LOAN TERMS |
| --- |

| Loan Parameter | Amount / Rate | Notes |
| --- | --- | --- |
| Loan Amount | $520,000 | Purchase price $650,000 less 20% down payment $130,000 |
| Interest Rate | 3.125%  (Fixed) | Rate locked 2021-07-01 for 60 days; expires 2021-08-30 |
| Monthly Principal & Interest | $2,225.12 | Amortizes over 360 months (30 years) |
| Prepayment Penalty | None | Conventional conforming — no prepayment restriction |
| Balloon Payment | None | Fully amortizing 30-year fixed |
| Loan Type | Conventional (Conforming) | Fannie Mae / Freddie Mac guidelines; FNMA Form 3005 IL |
| Loan Purpose | Purchase | Primary Residence — Owner Occupied |
| Loan Program | 30-Year Fixed | NMLS Loan ID: LMC-2021-00847 |

| PROJECTED MONTHLY PAYMENTS (YEAR 1) |
| --- |

| Payment Component | Monthly Amount | Annual Amount | Notes |
| --- | --- | --- | --- |
| Principal & Interest | $2,225.12 | $26,701.44 | Fixed for loan term |
| Property Taxes (Escrow) | $601.00 | $7,212.00 | Cook County 2020 assessed value est.; adjusts annually |
| Homeowners Insurance (Escrow) | $180.00 | $2,160.00 | State Farm binder — Chen HH policy #SF-2021-4821 |
| PMI (Private Mortgage Ins.) | $0.00 | $0.00 | Not required — LTV at 80.0%; eliminated at 78% LTV (~yr 5) |
| HOA / Association Fees | $0.00 | $0.00 | Single-family detached; no HOA |
| TOTAL PITI | $3,006.12 | $36,073.44 | Represents 14.4% of gross monthly income ($20,833) |

| CLOSING COST SUMMARY (SECTION A–H) |
| --- |

| Section | Description | Amount | Paid By |
| --- | --- | --- | --- |
| A. Origination | Origination fee (0.50% × $520K) | $2,600 | Borrower |
| A. Origination | Application fee | $500 | Borrower |
| B. Services — Borrower | Appraisal (MAI — Midwest Property Group) | $650 | Borrower |
| B. Services — Borrower | Credit report (tri-merge) | $65 | Borrower |
| B. Services — Borrower | Flood certification | $12 | Borrower |
| C. Services — Borrower's Choice | Title search & exam (Chicago Title) | $425 | Borrower |
| C. Services — Borrower's Choice | Title insurance — Lender's policy | $960 | Borrower |
| C. Services — Borrower's Choice | Title insurance — Owner's policy | $1,100 | Seller |
| E. Taxes & Gov Fees | Transfer tax — Cook County | $715 | Seller |
| E. Taxes & Gov Fees | Recording fee — Cook County Recorder | $98 | Borrower |
| F. Prepaids | Homeowners insurance premium (12 months) | $2,160 | Borrower |
| F. Prepaids | Per diem interest (Aug 5–31 = 27 days × $44.79/day) | $1,209 | Borrower |
| G. Initial Escrow Payment | Property tax escrow (2 months × $601) | $1,202 | Borrower |
| G. Initial Escrow Payment | Homeowners insurance escrow (2 months × $180) | $360 | Borrower |
| H. Other | Attorney fee — Chicago closing attorney | $750 | Borrower |
| TOTAL CLOSING COSTS (Borrower) | — | $10,131 | — |
| Lender Credit (rate adjust 3.125%→3.375%) | Optional — reduces cash to close | ($0 — declined) | — |
| NET CASH TO CLOSE | Down payment + closing costs | $140,131 | ✅  Confirmed at closing |

| AMORTIZATION MILESTONES |
| --- |

| Year | Cumulative Principal Paid | Remaining Balance | LTV | Milestone |
| --- | --- | --- | --- | --- |
| 2021 (Close) | $0 | $520,000 | 80.0% | PMI waived at close |
| 2026 (Yr 5) | $22,100 | $497,900 | 76.6% | Equity at $152,100; refi opportunity if rates fall |
| 2031 (Yr 10) | $48,700 | $471,300 | 72.5% | 10-year review milestone; college funding begins |
| 2036 (Yr 15) | $81,000 | $439,000 | 67.5% | Midpoint; children's education funding peak |
| 2041 (Yr 20) | $122,900 | $397,100 | 61.1% | Approaching retirement — GoalID-2016-02 window |
| 2051 (Maturity) | $520,000 | $0 | 0.0% | Home fully paid off; retirement income optimization |

| ✅  CLOSING CONFIRMED: Property closed on August 5, 2021. Deed recorded with Cook County Recorder of Deeds (Instrument No. 2021214-05841). Title re-vested in Chen Family Revocable Living Trust (MFRL-2019-001) per EventID-2021-01 and DOC-Trust-2019-001. |
| --- |

| SIGNATURES AND ACKNOWLEDGEMENT |
| --- |

| ________________________________________ | ________________________________________ |
| --- | --- |
| Alex Chen | Sam Chen |
| Borrower | Co-Borrower |

Date: August 5, 2021 (Closing Date)

| DOC-LoanEstimate-2021-001  |  HH-CHEN-001  |  EventID-2021-01 | LAKESIDE MORTGAGE CO.  |  RESPA / TRID COMPLIANT |
| --- | --- |
