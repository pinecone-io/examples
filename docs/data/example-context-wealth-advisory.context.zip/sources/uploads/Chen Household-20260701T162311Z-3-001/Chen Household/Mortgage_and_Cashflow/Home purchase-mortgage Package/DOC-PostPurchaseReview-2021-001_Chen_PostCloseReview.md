| CLEARWATER WEALTH PARTNERSChen Household — Home Purchase Package 2021  |  HH-CHEN-001 | DOC-PostPurchaseReview-2021-001September 15, 2021DELIVERED |
| --- | --- |

POST-PURCHASE PORTFOLIO & CASH FLOW REVIEW

Home Purchase Follow-Up — EventID-2021-01 | Q3 2021 Review

| EVENT TRIGGER: EventID-2021-01 — Home closed August 5, 2021 (8912 Birchwood Drive). This memo documents the post-close portfolio review: allocation drift correction, emergency fund restoration plan, tax projection update, and GoalID status refresh. Covers period: August–September 2021. Cross-refs: DecisionID-2021-141, DOC-DownPaymentMemo-2021-001, DOC-FeeAmendment-2021-001, TaxTopicID-2021-01. |
| --- |

| EXECUTIVE SUMMARY |
| --- |

The Chen household's home purchase closed successfully on August 5, 2021. The $130,000 down payment was funded as planned (ACCT-TX01: $55,000; ACCT-CASH: $60,000; checking: $15,000). This review documents the portfolio's post-close status, the rebalancing executed per DecisionID-2021-141, and the updated financial plan going forward.

| SECTION 1 — PORTFOLIO SNAPSHOT: PRE vs. POST CLOSE |
| --- |

| Account | Balance (Jun 2021) | Outflow | Balance (Sep 2021 Est.) | Change |
| --- | --- | --- | --- | --- |
| ACCT-TX01 (Joint Taxable) | $540,000 | ($55,000) | $497,000 | Rebalanced; equity trimmed |
| ACCT-IRA1 (Traditional IRA) | $165,000 | $0 | $171,000 | +$6K growth; UCBIX added |
| ACCT-RIRA (Roth IRA) | $95,000 | $0 | $99,000 | +$4K growth; maintained |
| ACCT-401R (Rollover IRA) | $118,000 | $0 | $123,000 | +$5K growth; unchanged |
| ACCT-529A (Maya) | $18,000 | $0 | $19,500 | On track — GoalID-2016-04 |
| ACCT-529B (Eli) | $14,000 | $0 | $15,200 | On track — GoalID-2016-04 |
| ACCT-CASH (Cash Mgmt) | $80,000 | ($60,000) | $23,500 | ⚠ Below target; restoration plan active |
| TOTAL AUM (Investments) | $870,000 | ($55,000 TX01) | ~$848,200 | Excludes home equity |
| Home Equity (New) | $0 (renter) | +$130,000 down | $137,000 est. | Purchase $650K − Mortgage $520K + appreciation |
| TOTAL NET WORTH (Est.) | ~$1,340,000 | — | ~$1,485,000 | Investment AUM + home equity + non-investment assets |

| SECTION 2 — REBALANCING EXECUTED (DecisionID-2021-141) |
| --- |

The following trades were executed in August–September 2021 to restore IPS-2020 target allocation (60/35/5) following the down payment outflow:

| Trade | Account | Security | Direction | Amount | Result |
| --- | --- | --- | --- | --- | --- |
| Sell | ACCT-TX01 | UECIX (US Equity Core) | Reduce equity overweight | $12,000 | Proceeds added to UCBIX in IRA1 |
| Buy | ACCT-IRA1 | UCBIX (US Core Bond) | Restore FI allocation | $12,000 | Rebalance within IRA — no tax |
| Sell | ACCT-TX01 | MUNIX (Muni Bond) | Trim slightly to raise liquidity | $5,000 | Added to ACCT-CASH for emergency fund |
| Hold | ACCT-RIRA | USCIX / EMEIX | No change — on target | — | Roth maintained as planned |
| Hold | ACCT-529A/B | 529-AGE-MOD | No change — on track | — | Annual contribution continues |

| ✅  POST-REBALANCE ALLOCATION: Equity 60.2% / Fixed Income 34.9% / Cash 4.9%. Within IPS-2020 drift bands (±5%). Next formal rebalance review: Q1 2022. |
| --- |

| SECTION 3 — EMERGENCY FUND RESTORATION PLAN (GoalID-2016-03) |
| --- |

ACCT-CASH balance fell to ~$20,000 at close, below the 6-month target of ~$36,000 (based on current monthly expenses ~$6,000). The following plan restores the reserve:

| Month | Action | ACCT-CASH Balance (Est.) | Notes |
| --- | --- | --- | --- |
| August 2021 | $5,000 sweep from ACCT-TX01 (MUNIX proceeds) | $25,000 | Immediate post-close boost |
| Sep–Dec 2021 | $1,500/month from joint checking (4 months) | $31,000 | Automated transfer initiated |
| Q4 2021 | Alex RSU vest (est. $8,000 net) | $39,000 | ✅  Target restored |
| Jan 2022+ | Maintain $1,500/month savings cadence | $40,000+ | Exceeds 6-month target; surplus to ACCT-TX01 |

| SECTION 4 — TAX PROJECTION UPDATE (TaxTopicID-2021-01) |
| --- |

The 2021 tax year will reflect increased complexity due to the home purchase. Below is an updated projection for Alex and Sam Chen's 2021 tax situation:

| Tax Item | Projected Amount | Notes |
| --- | --- | --- |
| Combined W-2 / SE income | $250,000 | Alex salary + equity + Sam freelance |
| Long-term capital gains (ACCT-TX01) | +$8,300 | From June 2021 liquidation (see DOC-DownPaymentMemo-2021-001) |
| Other investment income (dividends) | +$2,800 | MUNIX / UECIX estimated annual dividends |
| Alex RSU income (W-2 component) | +$8,000 est. | Q4 vest; reported on W-2 by employer |
| Estimated AGI | ~$269,100 | — |
| Mortgage interest deduction | ($13,541) | ~$520K × 3.125% × 5/12 months (Aug–Dec 2021) |
| Property tax deduction (SALT cap) | ($3,606) | Cook County 2021 taxes ~$7,212 — limited by $10K SALT cap |
| SALT cap limitation | — | Total state/local taxes capped at $10,000; mortgage interest deductible above cap |
| Standard deduction vs. itemized | Itemized recommended | Mortgage interest + SALT ≈ $17,147 > $25,100 standard deduction for MFJ |
| Estimated federal tax (MFJ) | ~$52,000 | Effective rate ~19.3%; LTCG portion at 15% |
| 2021 Estimated Tax Payments | Q4 estimate due Jan 18, 2022 | Recommend $8,000 Q4 payment (coordinate with CPA Logan Hart) |

| ⚠  TAX ACTION ITEM:  2021 total capital gains (~$18,500) plus RSU income increase taxable income meaningfully above 2020. Recommend scheduling a year-end tax planning call with CPA Logan Hart, JD (TaxTopicID-2021-01) by November 2021 to review Q4 estimated tax, confirm itemized deductions, and plan 2022 contribution strategy. First full year of mortgage interest deduction begins 2022. |
| --- |

| SECTION 5 — GOAL STATUS UPDATE (POST-PURCHASE) |
| --- |

| GoalID | Goal | Status | Notes |
| --- | --- | --- | --- |
| GoalID-2016-01 | Portfolio growth to $1.5M by 2030 | On track — $848K AUM | Home equity adds $137K to net worth; contributes to goal |
| GoalID-2016-02 | Alex retirement 2028–2030 | On track | Home owned; reduces retirement expense uncertainty |
| GoalID-2016-03 | Emergency fund 6 months | ⚠  Temporarily below target — recovery plan active | Target: $36K; Current: ~$25K; restored by Q4 2021 per Section 3 |
| GoalID-2016-04 | Maya/Eli college funding 529s | On track | 529A: $19.5K; 529B: $15.2K; annual contributions continuing |
| Home Ownership | Primary residence owned | ✅  ACHIEVED — 2021-08-05 | 8912 Birchwood Drive, Evanston, IL — closed per EventID-2021-01 |

| SECTION 6 — FORWARD-LOOKING ADVISORY NOTES |
| --- |

Fee Amendment (Q3 2021)

The tiered fee amendment (DOC-FeeAmendment-2021-001, effective 2021-07-01) was executed concurrently with the home purchase. At current AUM of ~$848K, the blended advisory fee is 0.85% (Tier 1: first $1M). This amendment was triggered in part by the growth in AUM and new accounts (ACCT-529A/B, ACCT-CASH) added to the advisory relationship.

2022 Mortgage Interest

The full year of mortgage interest (~$16,250) will be deductible in 2022 (assuming balance stays above $750K per TCJA limit — our balance at $520K is well within limits). This will comfortably support itemizing deductions in 2022 and beyond.

RSU Planning

Alex's Q4 2021 RSU vest will introduce an NLTK concentration position in ACCT-TX01. Recommend developing a disciplined sell/diversification schedule for 2022 (DecisionID-2022 to follow). Single-stock concentration guidelines: IPS-2020 §4.4 limits to <10% of portfolio.

IPS Review

No IPS amendment is required at this time. Allocation is within drift bands post-rebalance. Next full IPS review scheduled for Q1 2022 annual planning meeting (MtgID-2022Q1-01). The COVID defensive 60/35/5 IPS-2020 remains in effect.

| SIGNATURES AND ACKNOWLEDGEMENT |
| --- |

| ________________________________________ | ________________________________________ |
| --- | --- |
| Morgan Park, CFP®  (ADV-PARK-001) | Alex Chen  &  Sam Chen |
| Wealth Adviser, Clearwater Wealth Partners | Client Acknowledgement |

Date: September 15, 2021

| DOC-PostPurchaseReview-2021-001  |  HH-CHEN-001  |  EventID-2021-01 | CONFIDENTIAL — FOR BORROWER AND ADVISER USE ONLY |
| --- | --- |
