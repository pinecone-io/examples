| LAKESIDE MORTGAGE CO.230 N. Michigan Ave, Suite 800  |  Chicago, IL 60601  |  NMLS #: 1048203Tel: (312) 555-0192  |  loans@lakesidemortgage.com | DOC-MortgagePreApproval-2021-001May 12, 2021ISSUED |
| --- | --- |

MORTGAGE PRE-APPROVAL LETTER

| EVENT TRIGGER: EventID-2021-01 — Home purchase and down payment staging. Pre-approval issued to Alex & Sam Chen in advance of property search. Coordinated with NWP adviser Morgan Park, CFP® (ADV-PARK-001) on down payment sourcing from ACCT-TX01 and ACCT-CASH. Cross-refs: DOC-DownPaymentMemo-2021-001, DOC-LoanEstimate-2021-001, DecisionID-2021-141. |
| --- |

| PRE-APPROVAL SUMMARY |
| --- |

| Borrower(s): | Alex Chen  &  Sam Chen  (Joint) |
| --- | --- |

| Property Address: | To Be Determined — Evanston / North Shore, IL market |
| --- | --- |

| Pre-Approval Amount: | $520,000  (based on qualification analysis dated 2021-05-12) |
| --- | --- |

| Loan Program: | 30-Year Fixed-Rate Conventional  |  Conforming Loan |
| --- | --- |

| Interest Rate (Est.): | 3.125%  (rate lock available at application; subject to market) |
| --- | --- |

| Monthly P&I (Est.): | $2,225  (on $520,000 loan at 3.125% / 360 months) |
| --- | --- |

| Max Purchase Price: | $650,000  (assuming 20% down payment of $130,000) |
| --- | --- |

| Expiration Date: | August 12, 2021  (90 days from issue; renewable upon request) |
| --- | --- |

| Loan Officer: | Derek Ashworth, NMLS #: 3384712  |  d.ashworth@lakesidemortgage.com |
| --- | --- |

| QUALIFICATION ANALYSIS |
| --- |

The following qualification analysis was performed based on documentation provided by the applicants as of May 10, 2021. All figures are subject to final underwriting verification.

| Qualification Factor | Applicant Data | Guideline | Status |
| --- | --- | --- | --- |
| Combined Gross Income | $250,000 / yr (Alex: $200K salary + equity; Sam: $50K) | — | ✅  Verified |
| Debt-to-Income (Front-End) | 12.8%  ($2,225 P&I + $601 taxes + $180 insurance ÷ $20,833 monthly income) | ≤ 28% | ✅  Pass |
| Debt-to-Income (Back-End) | 16.4%  (adds $750 est. other recurring debts) | ≤ 43% | ✅  Pass |
| Credit Score — Alex | 782  (Equifax, pulled 2021-05-10) | ≥ 740 for best rate tier | ✅  Excellent |
| Credit Score — Sam | 768  (Equifax, pulled 2021-05-10) | ≥ 740 for best rate tier | ✅  Excellent |
| Down Payment (20%) | $130,000  (sourced from investment + cash accounts; see DOC-DownPaymentMemo-2021-001) | ≥ 20% (no PMI) | ✅  Verified |
| Liquid Reserves (Post-Close) | ~$750,000 investment + $25,000 cash  (exceeds 6-month PITI reserve requirement) | ≥ 6 months PITI | ✅  Strong |
| Employment Stability | Alex: 10+ yrs at current employer; Sam: 6 yrs freelance (2-yr avg used) | 2-yr history | ✅  Verified |

| LOAN PROGRAM DETAILS |
| --- |

| Parameter | Value |
| --- | --- |
| Loan Type | Conventional — Fannie Mae / Freddie Mac conforming |
| Loan Amount | $520,000 |
| Purchase Price (Max) | $650,000 |
| Down Payment | $130,000  (20.0%)  — No PMI required |
| Loan-to-Value (LTV) | 80.0% |
| Interest Rate (Estimated) | 3.125%  (30-Year Fixed) |
| APR (Estimated) | 3.214%  (includes estimated closing costs) |
| Monthly P&I | $2,225.12 |
| Est. Monthly Taxes | $601.00  (Cook County; 2020 effective rate ~1.11% on $650K) |
| Est. Monthly Insurance | $180.00  (homeowners; quote pending property selection) |
| Est. Total Monthly PITI | $3,006.12 |
| Origination Fee | 0.50%  ($2,600)  |  Lender credit available at 3.375% rate |
| Rate Lock Period | 60 days from application (extendable 30 days) |

| CONDITIONS FOR FINAL APPROVAL |
| --- |

| ☑  Income Documentation | Most recent 2 years federal tax returns (2019, 2020); W-2s; 2 most recent pay stubs (Alex). CPA letter for Sam's self-employment income. |
| --- | --- |

| ☑  Asset Documentation | Last 3 months statements for ACCT-TX01 (Fidelity), ACCT-CASH (Fidelity), and joint checking. Investment account confirmation from Clearwater Wealth Partners. |
| --- | --- |

| ☑  Down Payment Verification | Large deposits (>$1,000) must be documented. Liquidation from investment accounts (DOC-TransferAuth-2021-001) will require brokerage confirmation of settled funds. |
| --- | --- |

| ☑  Property Appraisal | Licensed MAI appraisal required on subject property. Ordered by Lakeside upon acceptance of purchase agreement. |
| --- | --- |

| ☑  Title Insurance | Owner's and lender's title policies required. Chicago Title or First American acceptable. |
| --- | --- |

| ☑  Homeowners Insurance | Binder with Lakeside Mortgage Co. listed as mortgagee required 10 days prior to closing. |
| --- | --- |

This pre-approval is not a commitment to lend. Final loan approval is subject to satisfactory property appraisal, title search, underwriting review of all documentation, and no material change in borrower financial circumstances prior to closing. Rate and terms subject to change.

| SIGNATURES AND ACKNOWLEDGEMENT |
| --- |

| ________________________________________ | ________________________________________ |
| --- | --- |
| Derek Ashworth, NMLS #3384712 | Sandra Marin, NMLS #2201458 |
| Loan Officer, Lakeside Mortgage Co. | Branch Manager, Lakeside Mortgage Co. |

Date: May 12, 2021

| DOC-MortgagePreApproval-2021-001  |  HH-CHEN-001  |  EventID-2021-01 | LAKESIDE MORTGAGE CO.  |  NMLS #1048203 |
| --- | --- |
