| LAKESIDE MORTGAGE CO.230 N. Michigan Ave, Suite 800  |  Chicago, IL 60601  |  NMLS #: 1048203Tel: (312) 555-0192  |  loans@lakesidemortgage.com | DOC-MortgageCommitment-2021-001July 28, 2021ISSUED |
| --- | --- |

MORTGAGE LOAN COMMITMENT LETTER

| EVENT TRIGGER: EventID-2021-01 — Formal loan commitment issued following underwriting approval. Commitment valid through August 30, 2021 (closing scheduled August 5, 2021). Cross-refs: DOC-MortgagePreApproval-2021-001, DOC-LoanEstimate-2021-001, DOC-MortgageCommitment-2021-001, DecisionID-2021-141. |
| --- |

| COMMITMENT SUMMARY |
| --- |

Lakeside Mortgage Co. ("Lender") is pleased to issue this Mortgage Loan Commitment to Alex Chen and Sam Chen ("Borrowers") for the acquisition of the property described below, subject to the conditions and terms set forth herein.

| Borrower(s): | Alex Chen  &  Sam Chen  (Joint Obligors) |
| --- | --- |

| Property Address: | 8912 Birchwood Drive, Naperville, Illinois 60563  (Cook County) |
| --- | --- |

| Property Description: | Single-family detached residence; 4 BR / 2.5 BA; 2,640 sq ft; Lot 4, Block 7, Elmwood Estates Subdivision |
| --- | --- |

| Purchase Price: | $650,000 |
| --- | --- |

| Appraised Value: | $657,000  (MAI appraisal, Midwest Property Group, 2021-07-18) |
| --- | --- |

| Loan Amount: | $520,000  (80.0% LTV — no PMI) |
| --- | --- |

| Loan Type: | Conventional Conforming — 30-Year Fixed  |  NMLS Loan ID: LMC-2021-00847 |
| --- | --- |

| Interest Rate: | 3.125%  (rate locked 2021-07-01; expires 2021-08-30) |
| --- | --- |

| Commitment Issued: | July 28, 2021  |  Valid Through: August 30, 2021 |
| --- | --- |

| Scheduled Closing: | August 5, 2021  |  Chicago Closing Attorney: Rowan & Pierce LLP |
| --- | --- |

| UNDERWRITING CONDITIONS SATISFIED |
| --- |

| ✅  FULL APPROVAL: All underwriting conditions have been satisfied as of July 28, 2021. No outstanding conditions remain. Loan cleared to close. |
| --- |

| Condition | Required | Submitted | Status |
| --- | --- | --- | --- |
| Income verification (Alex) | 2 yrs tax returns + pay stubs | 2019, 2020 returns; 2 pay stubs 2021 | ✅  Cleared |
| Income verification (Sam) | 2-yr average self-employment | CPA letter + Sch. C (2019, 2020) | ✅  Cleared |
| Asset documentation | 3-mo statements: ACCT-TX01, ACCT-CASH, checking | Fidelity statements Jun–Apr 2021 | ✅  Cleared |
| Down payment sourcing | Large deposit explanation (>$1K) | DOC-TransferAuth-2021-001; wire confirmation | ✅  Cleared |
| Property appraisal | MAI appraisal ≥ $650,000 | $657,000 appraisal (2021-07-18) | ✅  Cleared |
| Title search & insurance | No material encumbrances | Chicago Title — clear title confirmed | ✅  Cleared |
| Homeowners insurance | Binder with Lakeside as mortgagee | State Farm binder #SF-2021-4821 | ✅  Cleared |
| Flood certification | Zone X (no flood required) | FEMA Zone X — no flood insurance required | ✅  Cleared |

| PROMISSORY NOTE SUMMARY (KEY TERMS) |
| --- |

The Borrowers will execute an Illinois Promissory Note at closing. Key terms are summarized below. The full Note is prepared by Rowan & Pierce LLP and will be executed at closing.

| Note Term | Detail |
| --- | --- |
| Principal Amount | $520,000.00 |
| Note Date | August 5, 2021  (Closing Date) |
| Maturity Date | September 1, 2051  (360 payments) |
| Interest Rate | 3.125% per annum (fixed) |
| Payment Amount | $2,225.12 per month  (P&I only; escrow collected separately) |
| First Payment Due | September 1, 2021 |
| Late Charge | 5.0% of overdue payment amount; 15-day grace period |
| Prepayment | No penalty — Borrowers may prepay in whole or in part at any time without premium |
| Acceleration Clause | Full balance due upon transfer of property; sale; or material breach |
| Governing Law | State of Illinois  |  Cook County venue |
| MERS Beneficiary | Mortgage Electronic Registration Systems, Inc. (MERS) — nominee for Lakeside Mortgage Co. |
| Deed of Trust / Mortgage | Illinois Mortgage (statutory short form) recorded Cook County Recorder of Deeds |

| TRUST TITLE COORDINATION |
| --- |

Per instructions from the Borrowers and their estate attorney (Westfield & Baker LLP), the property will be titled in the name of the Chen Family Revocable Living Trust (MFRL-2019-001) at closing, consistent with the Borrowers' estate plan.

| LENDER ACKNOWLEDGEMENT:  Lakeside Mortgage Co. acknowledges the trust titling. Borrowers have provided a Certification of Trust (755 ILCS 5/8.5) confirming the trust is revocable, the Borrowers are trustees and beneficiaries, and the trust has not been revoked. The mortgage will be signed by Alex Chen and Sam Chen in their capacity as Co-Trustees. Personal liability remains with the Borrowers as individuals under the Promissory Note. |
| --- |

| Party / Role | Name / Entity | Execution Capacity |
| --- | --- | --- |
| Borrower / Trustee | Alex Chen | Individual + Co-Trustee, Chen Family Revocable Living Trust |
| Co-Borrower / Trustee | Sam Chen | Individual + Co-Trustee, Chen Family Revocable Living Trust |
| Lender | Lakeside Mortgage Co. | Lender — NMLS #1048203 |
| Closing Attorney | Rowan & Pierce LLP | Neutral closing attorney — Chicago, IL |
| Title Company | Chicago Title Insurance Company | Title insurer and escrow agent |
| Wealth Adviser (notified) | Morgan Park, CFP® — Clearwater Wealth Partners | ADV-PARK-001 — coordinate account re-titling |

| SIGNATURES AND ACKNOWLEDGEMENT |
| --- |

| ________________________________________ | ________________________________________ |
| --- | --- |
| Derek Ashworth, NMLS #3384712 | Christine Lau, NMLS #2089311 |
| Loan Officer — Lakeside Mortgage Co. | VP Underwriting — Lakeside Mortgage Co. |

Date: July 28, 2021

| DOC-MortgageCommitment-2021-001  |  HH-CHEN-001  |  EventID-2021-01 | LAKESIDE MORTGAGE CO.  |  NMLS #1048203 |
| --- | --- |
