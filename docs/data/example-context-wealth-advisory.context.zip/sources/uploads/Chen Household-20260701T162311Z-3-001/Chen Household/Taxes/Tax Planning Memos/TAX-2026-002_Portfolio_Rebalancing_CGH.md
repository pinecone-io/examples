| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

Portfolio Rebalancing & Capital Gains Harvesting Memo

ACCT-TX01 Rebalancing Strategy — Tax-Efficient Gains Harvesting & Bucket Alignment

| Document ID: | TAX-2026-002 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | September 15, 2026 |
| --- | --- |

| Event Trigger: | 2026 Annual Portfolio Review — Bucket Strategy 18-Month Post-Implementation |
| --- | --- |

| Related Documents: | DOC-IPSAmendment-2025-001; TAX-2026-001; TAX-2025-001; DecisionID-2026 series |
| --- | --- |

1. PORTFOLIO STATUS: 18 MONTHS POST-BUCKET IMPLEMENTATION

The bucket strategy IPS (DOC-IPSAmendment-2025-001, effective March 1, 2025) has been in place for approximately 18 months. ACCT-TX01 (projected value ~$795,000–$820,000 at Q3 2026) has experienced material appreciation since the 2022 bear market low and the post-2023 RSU contribution growth. The portfolio’s strong performance now requires disciplined rebalancing to maintain bucket allocations and manage embedded capital gains in the taxable account.

2. CURRENT ALLOCATION vs. TARGET (ACCT-TX01)

| Asset Class / Bucket | Target (IPS-2025) | Current (Q3 2026 est.) | Drift | Action |
| --- | --- | --- | --- | --- |
| Bucket 3 — Equity growth (65%) | ~$520K | ~$556K | +$36K (+7%) | Trim equity; harvest gains |
| Bucket 2 — Fixed income (30%) | ~$240K | ~$215K | -$25K (-10%) | Add fixed income |
| Bucket 1 — Cash / T-bill (5%) | ~$40K | ~$42K | +$2K | Hold |
| Total ACCT-TX01 | ~$800K | ~$813K | — | — |

3. CAPITAL GAINS HARVESTING STRATEGY

Unlike tax-loss harvesting (TLH), capital gains harvesting strategically recognizes long-term capital gains in years when the marginal LTCG rate is favorable. Key 2026 LTCG rate analysis:

| LTCG Rate (2026 MFJ) | Taxable Income Range (approx.) | Chen 2026 Projection |
| --- | --- | --- |
| 0% | Up to ~$96,700 | Below household income |
| 15% | ~$96,700 – $600,050 | Chens in this range; LTCG rate = 15% |
| 20% | Above ~$600,050 | Not applicable |
| NIIT (3.8%) applies above $250K MAGI | Adds to effective LTCG rate | Chens MAGI > $250K; NII rate = 18.8% |

Gains harvesting is particularly attractive for positions with modest embedded gains where the effective 15% LTCG rate is acceptable and rebalancing is required. However, given the NIIT exposure ($250K+ MAGI), the effective rate on LTCG is approximately 18.8% (15% + 3.8%). This is still substantially lower than ordinary income rates and favorable for long-term rebalancing.

4. RECOMMENDED REBALANCING TRADES (Q4 2026)

| Position | Action | Est. LTCG | Est. Tax (18.8%) | Purpose |
| --- | --- | --- | --- | --- |
| AMCPX — trim $15K of appreciation | Sell $15,000 | ~$9,000 | ~$1,692 | Reduce equity drift; harvest gain at 15%+NIIT |
| AGTHX — trim $10K appreciation | Sell $10,000 | ~$6,500 | ~$1,222 | Bucket 3 right-size |
| SEEGX — rebalance $8K | Sell $8,000 | ~$4,200 | ~$790 | Maintain target weight |
| Fixed income (add UCBIX) | Buy $25,000 | N/A | N/A | Replenish Bucket 2 |
| Net rebalancing proceeds | ~$33,000 to fixed income | ~$19,700 total | ~$3,704 tax |  |

5. LTCG OFFSET WITH TLH OPPORTUNITIES

Before executing gains harvesting trades, scan ACCT-TX01 for any positions with unrealized losses that can offset harvested gains. While 2026 is not a significant bear market year (equity markets remain positive), selective positions with unrealized losses may exist in fixed income or international sleeves. Net the losses against gains to reduce tax impact before execution.

6. DAF TOP-UP COORDINATION

Per the 2026 DAF plan (DOC-DAFYearEndSummary-2026-001), an $8,000 contribution is planned to the Chen Family Charitable Fund in 2026. Contributing appreciated ACCT-TX01 positions (in lieu of cash) continues to deliver the dual benefit of avoiding embedded gains and generating a Schedule A deduction. Coordinate DAF contribution with Q4 2026 rebalancing trades.

| RECOMMENDED ACTIONS✓  Execute Q4 2026 rebalancing trades (see Table 4): trim equity, add fixed income to restore bucket targets✓  Harvest $19,700 LTCG across trimmed positions at estimated 18.8% effective rate ($3,704 tax)✓  Scan for TLH opportunities in fixed income / international sleeves before executing gains trades✓  Contribute $8,000 in appreciated ACCT-TX01 positions to DAF (DOC-DAFYearEndSummary-2026-001)✓  Document all 2026 trades under DecisionID-2026 series; provide Form 8949 lots to CPA✓  Project Q4 2026 estimated tax; fund December 15, 2026 estimated payment to include gains tax✓  Schedule Q1 2027 review: update bucket allocations, Roth conversion ladder, and 2027 tax planning |
| --- |

TAX-2026-002 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
