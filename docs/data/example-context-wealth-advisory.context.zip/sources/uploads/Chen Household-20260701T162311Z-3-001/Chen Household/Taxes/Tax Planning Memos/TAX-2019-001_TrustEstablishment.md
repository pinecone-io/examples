| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

Trust Establishment Tax Planning Memo

Revocable Living Trust Creation — Estate & Income Tax Implications

| Document ID: | TAX-2019-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | September 15, 2019 |
| --- | --- |

| Event Trigger: | EventID-2019-01 — Revocable Trust Creation & Estate Foundation |
| --- | --- |

| Related Documents: | DOC-Trust-2019-001; DOC-Will-2019-001/002; DOC-DPOA-2019-001 |
| --- | --- |

1. PURPOSE & BACKGROUND

On September 10, 2019, Alex and Sam Chen executed the Chen Family Revocable Living Trust (DOC-Trust-2019-001) as part of a comprehensive estate foundation review (EventID-2019-01). Companion documents executed simultaneously include pour-over wills for both spouses (DOC-Will-2019-001 and -002) and a Durable Power of Attorney (DOC-DPOA-2019-001). This memorandum summarizes the federal and state income tax implications of the trust structure and identifies near-term planning actions.

2. INCOME TAX STATUS OF THE REVOCABLE TRUST

Because the Chen Family Revocable Living Trust is a grantor trust for federal income tax purposes under IRC §671–§677, all income, deductions, and credits flow directly to the grantors (Alex and Sam Chen) on their joint Form 1040. The trust is NOT a separate taxable entity — no Form 1041 is required while both grantors are living and the trust remains revocable. The household’s effective tax rate and tax filing obligations are unchanged by the trust establishment.

| Tax Item | Treatment | Filing Impact |
| --- | --- | --- |
| Trust income (dividends, interest, gains) | Reported on Alex & Sam's joint Form 1040 | No change |
| Grantor trust status | IRC §671–§677: trust is disregarded entity | No Form 1041 required |
| Cost basis of assets transferred | Carryover basis — no gain/loss recognized | No 1099-B event |
| Real property re-titling (when purchased) | No income tax event; county transfer tax may apply | Deed recording fee only |
| Step-up in basis at death | Trust assets receive step-up under IRC §1014 | Preserves heirs' basis |

3. ESTATE & GIFT TAX CONSIDERATIONS

The revocable trust does NOT remove assets from the grantors’ gross estate for federal estate tax purposes (IRC §2038). All trust assets remain includable in Alex’s and Sam’s respective gross estates at date of death. However, the trust structure provides significant planning benefits:

Probate avoidance: Trust assets transfer outside probate, reducing delays, costs, and public disclosure.

Coordinated distribution: Pour-over wills (DOC-Will-2019-001/002) direct any outside assets into the trust at death, ensuring unified distribution.

Basis planning: Appreciated assets held in the revocable trust receive a full step-up in basis at each grantor’s death (IRC §1014), eliminating embedded capital gains.

Future planning bridge: The trust structure accommodates potential conversion to an irrevocable trust (e.g., SLAT, IDGT) if the estate grows to exceed the federal exemption ($12.92M per person in 2023; scheduled to revert to ~$6.8M in 2026 per TCJA sunset).

4. IRA / RETIREMENT ACCOUNT COORDINATION

Retirement accounts (ACCT-IRA1 — Alex Traditional IRA; ACCT-RIRA — Alex Roth IRA) cannot be titled in the name of a revocable trust. However, the trust can be named as a primary or contingent beneficiary. The Chens should coordinate beneficiary designations with the trust to ensure proper distribution of retirement assets to Maya and Eli (via conduit or accumulation sub-trusts) while maintaining stretch IRA benefits to the extent permitted under SECURE Act 10-year distribution rules. Action required: DOC-BeneficiaryUpdate-2019-001 (TaskID-2019Q2-001).

5. ILLINOIS STATE TAX IMPLICATIONS

Illinois does not impose a separate gift tax. Illinois estate tax exemption is $4.0 million per individual (not portable), which is significantly lower than the federal exemption. At current household net worth, state-level estate exposure is low but may become relevant as portfolio grows. Recommend revisiting Illinois estate tax planning when household net worth approaches $3.0 million (estimated 2027–2028 based on current trajectory).

6. ANNUAL REVIEW TRIGGERS

| Trigger Event | Recommended Action | Priority |
| --- | --- | --- |
| Home purchase (EventID-2021-01) | Re-title property to Trust; review IL property tax exemption | High — at purchase |
| Birth or adoption of child | Update sub-trust distribution ages; revise beneficiary schedule | High — at event |
| Household net worth > $3M | Illinois estate tax analysis; consider irrevocable planning | Medium |
| TCJA sunset (2026) | Federal exemption analysis; potential gifting strategy before sunset | Medium — by 2025 |
| Annual beneficiary review | Confirm IRA/Roth/life insurance designations align with trust | Annual |

| RECOMMENDED ACTIONS✓  File beneficiary designation updates (DOC-BeneficiaryUpdate-2019-001) — TaskID-2019Q2-001✓  Obtain trust EIN (SS-4) for financial institution titling records (no separate tax filing required)✓  Re-title eligible non-retirement accounts into Trust name: ACCT-TX01 (Joint Taxable), ACCT-CASH✓  Schedule Illinois estate tax review when household AUM approaches $3.0M✓  Calendar TCJA sunset review for 2025 (annual federal exemption may decrease ~50% in 2026) |
| --- |

TAX-2019-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
