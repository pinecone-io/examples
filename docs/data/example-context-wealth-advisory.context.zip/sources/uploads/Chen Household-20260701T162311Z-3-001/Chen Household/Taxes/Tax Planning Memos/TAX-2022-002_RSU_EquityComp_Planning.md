| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

RSU Equity Compensation: Annual Tax Planning Memo

Alex Chen NLTK RSU Vesting Schedule — W-2 Inclusion, FICA & NIIT Planning

| Document ID: | TAX-2022-002 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | January 20, 2022 |
| --- | --- |

| Event Trigger: | EventID-2018-01 — RSU Grant (recurring annual vest cycle, 2018–2026) |
| --- | --- |

| Related Documents: | DOC-AdvisoryAgreement-2016-001; DOC-DPOA-2019-001; TAX-2023-001 |
| --- | --- |

1. RSU BACKGROUND & VESTING STRUCTURE

Alex Chen received an RSU grant from NLTK (employer) in 2018 (EventID-2018-01), vesting ratably over a multi-year schedule. Annual vesting tranches add to Alex’s W-2 income in the year of vesting at the fair market value on the vesting date. This memo provides an annual planning framework applicable to each vesting year (2019–2026) and should be reviewed in Q4 of each year to project the following year’s tax impact.

2. INCOME TAX TREATMENT OF RSU VESTING

| Tax Item | Treatment |
| --- | --- |
| Income recognition | FMV of shares on vesting date included in W-2 as ordinary income (IRC §61) |
| FICA (Social Security) | Subject to SS tax (6.2%) up to $147,000 wage base (2022); Medicare (1.45%) on all W-2 |
| Additional Medicare Tax | 0.9% on W-2 income exceeding $200,000 for MFJ ($250,000 combined threshold) |
| Net Investment Income Tax | RSU W-2 income NOT subject to 3.8% NIIT; post-vest gains ARE subject to NIIT |
| Holding period (capital gains) | Clock starts at vesting date; <1 year = STCG; >1 year = LTCG |
| NLTK concentration risk | Immediate diversification recommended; concentration >10% of investable assets = risk |
| Withholding | Employer withholds at 22% flat rate on supplemental wages; may be insufficient at higher income |

3. ORDINARY VESTING YEAR (2022) PROJECTIONS

For routine vesting years (prior to the 2023 large vest), the estimated RSU income impact is modest and well-managed within the 22–24% bracket:

| Item | 2022 Estimate |
| --- | --- |
| Estimated RSU shares vesting (standard tranche) | ~200–400 shares |
| Estimated FMV on vest date | ~$30,000–$50,000 (NLTK market value dependent) |
| W-2 income addition | Captured in Alex’s W-2 Box 1; Box 14 notes RSU |
| Federal tax impact | ~$6,600–$12,000 at 22% marginal; additional 1.45% Medicare |
| Employer withholding | 22% flat (supplemental); shortfall covered by Q4 estimated payment |
| IL state tax (4.95%) | ~$1,485–$2,475 additional IL income tax |

4. CONCENTRATION MANAGEMENT STRATEGY

Upon vesting, NLTK shares become a concentrated single-stock position. The following framework should be applied immediately upon each vest:

Sell-to-cover tax withholding: Employer typically sells shares to cover withholding; remaining shares held in taxable account.

Diversification target: Sell remaining NLTK shares within 60 days of vest to achieve <10% single-stock exposure.

Loss offset coordination: In 2022, TLH carryforwards from 2020 and 2022 bear market can offset gains from NLTK sales.

Cost basis tracking: Each vesting tranche has a distinct cost basis (FMV at vest) and holding period. Maintain lot-level records.

2023 large vest planning: Anticipate a substantially larger vesting tranche in 2023 (EventID-2023-01) that will require elevated planning (see TAX-2023-001).

5. ESTIMATED TAX PAYMENT SCHEDULE

| Quarter | Due Date | Recommended Action |
| --- | --- | --- |
| Q1 2022 | April 15, 2022 | Estimate Q1 RSU income; adjust withholding via W-4 if needed |
| Q2 2022 | June 15, 2022 | Review YTD income vs. safe harbor (110% of 2021 tax) |
| Q3 2022 | Sept 15, 2022 | Project year-end AGI; fund estimated payment for supplemental W-2 shortfall |
| Q4 2022 | Jan 17, 2023 | Final true-up; capture TLH losses before 12/31; Roth conversion decision |

| RECOMMENDED ACTIONS✓  Confirm 2022 vesting date and NLTK FMV on vest date — obtain via employer equity portal✓  Coordinate sell-to-cover; sell remaining NLTK within 60 days of vest to reduce concentration✓  Apply 2022 TLH carryforward losses against NLTK sale gains (coordinated with TAX-2022-001)✓  Adjust Q4 estimated tax payment to cover W-4 withholding shortfall on RSU income✓  Brief CPA on RSU income by January 15, 2023 for Form W-2 Box 14 reconciliation✓  Initiate 2023 large vest planning discussion Q4 2022 (anticipated EventID-2023-01 — see TAX-2023-001) |
| --- |

TAX-2022-002 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
