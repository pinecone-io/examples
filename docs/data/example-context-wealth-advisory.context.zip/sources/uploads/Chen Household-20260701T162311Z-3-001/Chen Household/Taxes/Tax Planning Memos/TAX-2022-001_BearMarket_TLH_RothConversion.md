| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

2022 Bear Market: TLH & Roth Conversion Opportunity Memo

Equity & Bond Drawdown — Coordinated Tax-Loss Harvesting and Roth Strategy

| Document ID: | TAX-2022-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | October 12, 2022 |
| --- | --- |

| Event Trigger: | 2022 Bear Market — S&P 500 -19.4%, Bond Index -13% YTD (Oct 2022) |
| --- | --- |

| Related Documents: | DOC-IPSAmendment-2020-001; TAX-2020-001; ACCT-IRA1; ACCT-RIRA |
| --- | --- |

1. MARKET CONTEXT & PLANNING OPPORTUNITY

Calendar year 2022 produced the worst combined equity and fixed income performance since the 1970s. The S&P 500 declined approximately 19.4% year-to-date through October 2022, while the Bloomberg US Aggregate Bond Index fell approximately 13% — an historically rare scenario in which both major asset classes experienced simultaneous significant drawdowns. The Chen household portfolio (ACCT-TX01, end-Q3 value $372,734) reflects these market conditions. This dual-drawdown environment creates two distinct tax planning opportunities: (1) expanded tax-loss harvesting in ACCT-TX01, and (2) a potentially favorable Roth IRA conversion window in ACCT-IRA1.

2. TAX-LOSS HARVESTING — ACCT-TX01 (Taxable)

| Position | Approx. Unrealized Loss | Strategy | Priority |
| --- | --- | --- | --- |
| AMCPX (Growth equity) | ~($22,000) | Harvest; replace with AGTHX or diversified large-cap ETF | High |
| SEEGX (S&P 500 index eq.) | ~($14,000) | Harvest; replace with MFEKX or small/mid-cap blend | High |
| ANCFX (Mid-cap growth) | ~($9,500) | Harvest; replace with AMRMX or value tilt | Medium |
| Fixed income component | ~($6,000) | Harvest if in taxable; replace with diff. duration ETF | Medium |
| Total estimated losses | ~($51,500) | Net after estimated gains |  |

The 2022 bear market created substantially larger TLH opportunities than the 2020 COVID drawdown due to the multi-year appreciation of positions. Estimated net losses ~($51,500) can offset: (a) 2022 ordinary income up to $3,000; (b) future capital gains from RSU vesting events (EventID-2018-01 anticipated); and (c) any taxable gain from home purchase or refinance activities.

3. ROTH IRA CONVERSION OPPORTUNITY — ACCT-IRA1

The 2022 market decline has reduced the value of ACCT-IRA1 (Alex Traditional IRA) from its prior peak, creating an opportunity to convert a portion to ACCT-RIRA (Roth IRA) at temporarily depressed values. Key considerations:

| Factor | 2022 Analysis |
| --- | --- |
| ACCT-IRA1 estimated value (Q3 2022) | ~$145,000 (approximate, post-drawdown) |
| Estimated 2022 household W-2 income | ~$215,000 (Alex + Sam base) |
| 2022 Marginal bracket (MFJ) | 22% bracket up to $178,150; 24% above |
| Roth conversion headroom (22% bracket) | ~$0–$5,000 before hitting 24% threshold |
| Recommended conversion amount | $10,000–$20,000 at 24% (modest; strategic) |
| Tax on conversion at 24% | ~$2,400–$4,800 — low relative to long-term Roth benefit |
| Key benefit | Converts at depressed values; tax-free recovery in ACCT-RIRA |

4. 2022 ESTIMATED TAX IMPACT SUMMARY

| Tax Item | 2022 Estimate | Notes |
| --- | --- | --- |
| W-2 ordinary income | ~$215,000 | Alex + Sam combined |
| Investment income (div/int, TX01) | ~$2,300 | Taxable account only |
| Capital losses from TLH | ~($51,500) | Net harvested losses |
| Capital loss used vs. gains | ~($3,000) vs. ordinary income | IRC §1211 annual cap |
| Capital loss carryforward | ~($48,500) | Applied to future RSU/gain events |
| Roth conversion income | ~$15,000 (recommended) | Taxed as ordinary income @ 24% |
| Estimated AGI | ~$232,000 | Before above-the-line deductions |
| Estimated federal tax liability | ~$36,500–$42,000 | Rough estimate; CPA to finalize |

| RECOMMENDED ACTIONS✓  Execute TLH trades in ACCT-TX01 before December 31, 2022 to capture 2022 losses✓  Monitor wash sale compliance — do not repurchase sold funds within 31 days✓  Execute Roth conversion of $15,000 from ACCT-IRA1 to ACCT-RIRA (24% bracket)✓  Update capital loss carryforward schedule for use against 2023 RSU income (EventID-2023-01)✓  Document all trades under DecisionID-2022 series; coordinate with CPA for Form 8949 / Schedule D✓  Review Q4 estimated tax payments to avoid underpayment penalty given conversion income |
| --- |

TAX-2022-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
