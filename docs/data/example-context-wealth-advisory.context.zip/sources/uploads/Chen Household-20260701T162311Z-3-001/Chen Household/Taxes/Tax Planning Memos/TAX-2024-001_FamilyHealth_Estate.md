| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

Family Health Event: Estate & Tax Planning Implications

EventID-2024-01 — Health Event, Estate Audit & Tax Exposure Review

| Document ID: | TAX-2024-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | March 28, 2024 |
| --- | --- |

| Event Trigger: | EventID-2024-01 — Close Family Health Event; Estate Urgency Review (Q1 2024) |
| --- | --- |

| Related Documents: | DOC-TrustAmendment-2024-001; DOC-BeneficiaryAudit-2024-001; DOC-DPOA-2019-001 |
| --- | --- |

1. BACKGROUND

In Q1 2024, a close family health event (EventID-2024-01) prompted the Chen household to initiate an expedited review of estate documents, beneficiary designations, and potential medical expense deductibility. The estate audit was conducted by Westfield & Baker LLP and Morgan Park, CFP®, resulting in the execution of DOC-TrustAmendment-2024-001. This memo addresses the income tax, estate tax, and financial planning considerations arising from the health event.

2. MEDICAL EXPENSE DEDUCTIBILITY

Unreimbursed medical expenses exceeding 7.5% of AGI are deductible on Schedule A (IRC §213). With estimated 2024 AGI of ~$230,000–$245,000 (normalized year without large RSU tranche), the threshold is approximately $17,250–$18,375. Medical expenses below this threshold provide no incremental federal tax benefit unless itemizing for other reasons.

| Medical Expense Category | Deductibility | Notes |
| --- | --- | --- |
| Unreimbursed medical/dental | Above 7.5% AGI threshold only | Schedule A if itemizing |
| Long-term care insurance premiums | Age-based limits (IRC §213(d)(10)) | Alex (40): $480/yr limit; Sam (37): $480/yr |
| HSA distributions for qualified expenses | Tax-free — no AGI threshold | Best vehicle for medical costs |
| COBRA / insurance premiums (if event-related) | Deductible above AGI floor | Employer plan premiums not deductible |
| Qualified LTC services (not insurance) | Deductible above 7.5% AGI | If providing care for qualifying relative |

3. ESTATE TAX IMPACT & EXEMPTION PLANNING

The health event underscores the urgency of estate planning before the anticipated TCJA sunset in 2026, when the federal estate tax exemption is scheduled to revert from ~$13.6 million (2024) to approximately $6.8 million per individual. Current household situation:

| Estate Planning Item | 2024 Status | Action |
| --- | --- | --- |
| Household gross estate (approx.) | ~$1.8M (AUM + home equity) | Well below exemption; monitor growth |
| Federal exemption (2024) | $13.61M per person | No current exposure |
| Illinois exemption | $4.0M per person (not portable) | Approaching monitoring threshold |
| TCJA sunset risk (2026) | Exemption ~halves to ~$6.8M | Calendar 2025 gifting strategy review |
| Revocable trust status | DOC-TrustAmendment-2024-001 executed | DPOA & healthcare directive updated |
| Beneficiary designations | Audited per DOC-BeneficiaryAudit-2024-001 | All corrected and confirmed |

4. LONG-TERM CARE INSURANCE (LTCI) CONSIDERATIONS

EventID-2024-01 highlighted the potential financial impact of long-term care needs. Alex (age 41) and Sam (age 38 in 2024) are approaching the optimal age window for LTCI purchase (ages 45–55). Key tax considerations:

LTCI premiums may be partially deductible as medical expenses (age-based IRS limit for 2024: ~$480/year for ages 40–44).

Hybrid life/LTCI policies offer alternative structure with death benefit and potential tax-free LTC benefits.

Group LTCI through employer (NLTK) may offer more favorable underwriting and premium rates.

Strategy: Obtain LTCI quotes in 2024–2025; consider purchase before age 45 for best rates and full coverage.

5. DURABLE POWER OF ATTORNEY & TAX AUTHORITY

The updated DPOA (DOC-DPOA-2019-001, reviewed 2024) grants authority to manage tax filing, IRS communications, and financial transactions in the event of incapacity. The tax agent designation in the DPOA should be confirmed to include: filing Form 1040, executing IRS extensions, responding to IRS notices, and managing estimated tax payments. Recommend filing a Form 2848 (Power of Attorney) with the IRS designating Morgan Park and/or the CPA as authorized representative.

| RECOMMENDED ACTIONS✓  Confirm DPOA (DOC-DPOA-2019-001) includes IRS tax authority; file Form 2848 with IRS✓  Maximize HSA contributions ($8,300 family limit 2024) — best vehicle for medical cost management✓  Obtain LTCI quotes in 2024; target coverage securing before age 45✓  Confirm all beneficiary corrections from DOC-BeneficiaryAudit-2024-001 have been processed by Fidelity✓  Schedule 2025 TCJA sunset planning meeting — consider accelerated gifting before 2026 exemption reduction✓  Review disability insurance coverage for both Alex and Sam given health event context |
| --- |

TAX-2024-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
