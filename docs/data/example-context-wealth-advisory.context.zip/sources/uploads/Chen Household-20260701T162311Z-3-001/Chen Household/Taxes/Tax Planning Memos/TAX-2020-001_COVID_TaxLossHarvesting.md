| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

COVID-19 Market Decline: Tax-Loss Harvesting Strategy

Q1 2020 Drawdown — ACCT-TX01 TLH Execution & Wash Sale Compliance

| Document ID: | TAX-2020-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | April 10, 2020 |
| --- | --- |

| Event Trigger: | EventID-2020-01 — COVID-19 Market Volatility & IPS Defensive Shift |
| --- | --- |

| Related Documents: | DOC-IPSAmendment-2020-001; DecisionID-2020-044 |
| --- | --- |

1. SITUATION SUMMARY

The S&P 500 declined approximately 34% from its February 19, 2020 peak through the March 23, 2020 trough — the fastest bear market on record. The Chen household portfolio (ACCT-TX01, beginning value $400,232 at 2020 Q1 start) experienced significant unrealized losses across equity positions. This memo documents the tax-loss harvesting (TLH) strategy executed in response to EventID-2020-01, consistent with the tax-aware rebalancing mandate in DOC-IPS-2016-001 (Section 8).

2. TAX-LOSS HARVESTING POSITIONS IDENTIFIED

| Position / Fund | Estimated Loss | Replacement Fund | Lock-Out Period |
| --- | --- | --- | --- |
| AMCPX (Am Caps Growth) | ~$8,400 | AGTHX (Am Funds Growth) | 31-day wash sale window |
| SEEGX (SEI S&P 500 Eq) | ~$6,200 | MFEKX (MFS Core Equity) | 31-day wash sale window |
| ANCFX (Am New Concept) | ~$3,800 | AMRMX (Am Funds Multi) | 31-day wash sale window |
| Fixed income sleeve (ACCT-IRA1) | N/A — tax-deferred; no TLH benefit | Hold — no action | N/A |

Note: TLH was applied exclusively to ACCT-TX01 (taxable). Tax-deferred accounts (ACCT-IRA1, ACCT-RIRA) are not eligible for TLH, but were rebalanced into the new IPS-2020 target allocation (60/35/5) without tax consequence.

3. WASH SALE RULE COMPLIANCE (IRC §1091)

To preserve harvested losses while maintaining market exposure, replacement securities must NOT be ‘substantially identical’ to the sold position. The replacement funds selected track different indices and have distinct investment mandates. Key compliance requirements:

Do NOT repurchase any sold fund within 30 days before or after the sale date.

Do NOT hold the same fund in any account (including ACCT-IRA1, ACCT-RIRA) during the 61-day window.

Replacement period: April 2020. Earliest repurchase of original funds: ~May 5, 2020.

Document all TLH trades under DecisionID-2020-044 for Form 1099-B reconciliation.

4. PROJECTED 2020 TAX IMPACT

| Tax Item | Estimated Amount | Rate / Treatment |
| --- | --- | --- |
| Short-term losses harvested | ~($18,400) | Offset ordinary income @ 22–24% |
| Long-term losses harvested | ~($12,000) | Offset long-term gains first |
| Net capital loss applied in 2020 | ~($3,000) | Max deduction against ordinary income |
| Loss carryforward to 2021 | ~($8,400) | Carried forward indefinitely |
| Estimated 2020 federal tax savings | ~$4,900 – $6,200 | Varies by final income |
| Rebalancing gains (IPS-2020 shift) | ~$12,000 net LTCG | LTCG rate 15%; partially offset |

5. CAPITAL LOSS CARRYFORWARD TRACKING

Any capital losses not absorbed in 2020 carry forward indefinitely to future tax years (IRC §1212). The carryforward should be applied strategically in years with significant capital gain realization — particularly relevant given the anticipated home purchase (EventID-2021-01) and future RSU vesting cycles. Morgan Park will track the carryforward balance and coordinate with the Chens’ tax preparer annually.

| RECOMMENDED ACTIONS✓  Execute TLH trades by April 15, 2020 to maximize 2020 loss capture✓  Monitor 31-day wash sale windows — do not repurchase sold funds before May 5, 2020✓  Document all trades under DecisionID-2020-044; provide summary to tax preparer✓  Update cost basis records in Fidelity Institutional (CUST-FI-001) for replacement positions✓  Track capital loss carryforward; apply against 2021 home-sale gains or future RSU vesting income✓  Coordinate with IPS amendment (DOC-IPSAmendment-2020-001) — rebalancing window 2020-06-15 to 06-30 |
| --- |

TAX-2020-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
