| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

529 College Savings Plans: Tax Strategy Memo

ACCT-529A (Maya) & ACCT-529B (Eli) — IL State Deduction & Contribution Strategy

| Document ID: | TAX-2020-002 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | May 20, 2020 |
| --- | --- |

| Event Trigger: | EventID-2020-01 — 529 Accounts Opened (ACCT-529A, ACCT-529B) May 2020 |
| --- | --- |

| Related Documents: | DOC-IPSAmendment-2020-001; DOC-TrustAmendment-2024-001 |
| --- | --- |

1. PURPOSE & ACCOUNT SUMMARY

In May 2020, concurrent with the IPS defensive amendment (EventID-2020-01), the Chen household opened two 529 college savings accounts: ACCT-529A for Maya Chen (age 9, DOB: 2011-08-19) and ACCT-529B for Eli Chen (age 5, DOB: 2014-03-07). Alex Chen is account owner for ACCT-529A; Sam Chen is account owner for ACCT-529B. Both accounts are enrolled in the Illinois Bright Start Direct-Sold College Savings Program. This memo addresses Illinois state income tax benefits, federal gifting treatment, and recommended contribution strategy.

2. ILLINOIS STATE INCOME TAX DEDUCTION

| Item | Detail |
| --- | --- |
| Illinois deduction | Up to $10,000 per taxpayer, per year (Alex: $10K; Sam: $10K = $20K household) |
| Deduction type | Above-the-line for IL state income tax (4.95% flat rate) |
| Annual IL tax savings | $10,000 × 4.95% = $495 per account = $990 household maximum |
| Federal deductibility | None — 529 contributions are NOT federally deductible |
| Rollover contributions | Count toward deduction in year of rollover; pro-rated multi-year funding not allowed |
| Recapture risk | Non-qualified withdrawals may trigger IL recapture of prior deductions + 10% penalty on earnings |

3. FEDERAL GIFT TAX TREATMENT

529 contributions are treated as completed gifts for federal gift tax purposes. The annual exclusion in 2020 is $15,000 per donor per beneficiary. The Chens may contribute up to $15,000 each (Alex + Sam = $30,000 per child per year) without gift tax consequences. Additionally, IRC §529(c)(2) permits a five-year election (‘superfunding’) allowing a single contribution of up to $75,000 per donor per beneficiary ($150,000 per child from both parents combined) with the contribution treated as if made ratably over five years.

| Scenario | Maya (ACCT-529A) | Eli (ACCT-529B) | Annual Gift? |
| --- | --- | --- | --- |
| Standard annual | $15,000 Alex + $15,000 Sam | $15,000 Alex + $15,000 Sam | Yes, $30K/child |
| Superfunding (5-yr) | $75,000 Alex + $75,000 Sam | $75,000 Alex + $75,000 Sam | No (spread over 5 yrs) |
| 2020 initial target | $5,000 per account (starter) | $5,000 per account (starter) | Well below exclusion |
| Ongoing annual | $5,000–$10,000 per account | $5,000–$10,000 per account | Within exclusion |

4. PROJECTED ACCOUNT VALUES & EDUCATION COST COVERAGE

| Beneficiary | Years to College | Annual Contribution | Assumed Growth | Projected Value |
| --- | --- | --- | --- | --- |
| Maya (DOB 2011-08-19) | ~9 years | $8,000/yr | 6.0% net | ~$101,000 |
| Eli (DOB 2014-03-07) | ~13 years | $8,000/yr | 6.0% net | ~$158,000 |
| Combined household | — | $16,000/yr | 6.0% net | ~$259,000 |

Note: 4-year private university costs projected at approximately $320,000–$380,000 in 2029–2030 and $370,000–$440,000 in 2032–2033 assuming 5% annual cost inflation. 529 assets are expected to cover 40–60% of projected costs; remaining needs to be funded from household cash flow or additional savings.

5. INVESTMENT STRATEGY WITHIN 529 ACCOUNTS

Given Maya’s approximately 9-year runway and Eli’s ~13-year runway, both accounts should be invested in age-based glide-path options that gradually reduce equity exposure as the college start date approaches. Recommended age-based profile at opening: ~80% equity / 20% fixed income for Maya; ~90% equity / 10% fixed income for Eli. Accounts are not included in the Clearwater advisory fee schedule per DOC-FeeAmendment-2021-001 (added to covered accounts effective 2021-07-01 for monitoring purposes only).

| RECOMMENDED ACTIONS✓  Contribute $5,000 opening balance to each account (ACCT-529A, ACCT-529B) in May 2020✓  Alex claims $10,000 IL deduction for ACCT-529A; Sam claims $10,000 for ACCT-529B on 2020 IL return✓  Set up $500–$700/month automatic contributions to maximize annual IL deduction✓  Select age-based investment track at account opening (Bright Start growth portfolio)✓  Revisit superfunding strategy in 2021 if household liquidity allows after home purchase✓  Add 529 accounts to annual beneficiary/account review checklist (DOC-BeneficiaryAudit-2024-001) |
| --- |

TAX-2020-002 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
