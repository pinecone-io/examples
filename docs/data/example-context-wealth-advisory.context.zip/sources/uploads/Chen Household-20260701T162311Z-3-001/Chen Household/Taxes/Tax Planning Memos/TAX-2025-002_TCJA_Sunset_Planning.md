| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

TCJA Sunset: Year-End 2025 Tax Planning Memo

Tax Law Changes Effective 2026 — Accelerated Deductions & Rate Planning

| Document ID: | TAX-2025-002 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | November 1, 2025 |
| --- | --- |

| Event Trigger: | TCJA Provisions Scheduled to Expire December 31, 2025 |
| --- | --- |

| Related Documents: | TAX-2025-001; TAX-2024-001; TAX-2019-001; DOC-IPSAmendment-2025-001 |
| --- | --- |

1. TCJA SUNSET OVERVIEW

The Tax Cuts and Jobs Act of 2017 (TCJA) enacted numerous individual income tax provisions with a built-in sunset after December 31, 2025. Unless Congress acts, 2026 tax rates and rules will revert to pre-TCJA law. This creates a unique planning window in Q4 2025: the last opportunity to act under TCJA-favorable rules before potentially higher rates take effect January 1, 2026.

2. KEY TCJA CHANGES EXPIRING AFTER 2025

| TCJA Provision | 2025 (TCJA) | 2026 (Post-Sunset) | Impact on Chens |
| --- | --- | --- | --- |
| Top ordinary rate | 37% | 39.6% | Low direct impact (household in 24% bracket) |
| 22% bracket ceiling (MFJ) | ~$230K taxable income | ~$165K (reverts) | Effective bracket rises; Roth conversions costlier |
| Standard deduction (MFJ) | $30,000 | ~$15,000 (reverts) | Chens likely itemize both years |
| SALT deduction cap | $10,000 | Unlimited (reverts) | Potential Illinois property + income deduction benefit |
| Child tax credit | $2,000/child | $1,000/child (reverts) | Maya and Eli; ~$2,000 loss |
| Estate/gift tax exemption | $13.99M/person (2025) | ~$7.0M/person (reverts) | Household below threshold but approaches IL limit |
| Misc. itemized deductions (2% floor) | Suspended | Restored | Investment advisory fees may become deductible |
| Pease limitation (itemized) | Suspended | Restored | May reduce itemized deductions at high AGI |

3. 2025 YEAR-END PLANNING ACTIONS: ACCELERATE INTO TCJA WINDOW

The primary strategy is to accelerate income recognition, deductions, and planning actions that are more advantageous under 2025 TCJA rules before they expire:

| Action | Rationale | Amount / Timing |
| --- | --- | --- |
| Roth IRA conversion (see TAX-2025-001) | Convert at 24% in 2025 vs. potentially higher post-2026 brackets | $30,000 by Dec 31, 2025 |
| Accelerate deferred income | Recognize income at 2025 rates if next year rates will be higher | Evaluate case-by-case |
| Accelerate charitable giving | Maximize deductions in 2025 while PEASE limitation is suspended | DAF top-up $7,500 (per plan) |
| Lump estate gifts to children | Use 2025 annual exclusion ($19,000/person) before exemption shrinks | Up to $76K (4 exclusions) |
| Fund 529 accounts aggressively | Illinois deduction still available; college runway shortening for Maya | $10K/account (IL max) |
| SALT deduction review | Post-2025 SALT uncapped; estimate 2026 IL property + income tax value | Model 2026 itemization |

4. ESTATE PLANNING: EXEMPTION REDUCTION IMPACT

The federal estate and gift tax exemption is projected to revert from approximately $13.99 million per person (2025) to approximately $7.0 million per person (2026), adjusted for inflation. At current household net worth of approximately $1.8–$2.0M, the Chens are below both the current and projected future exemptions. However, the anticipated trajectory of the portfolio toward $3.0–$5.0M by retirement makes now an appropriate time to consider whether any gifting strategy (e.g., annual exclusion gifts to Maya and Eli, or front-loading 529 superfunding) should be executed before December 31, 2025.

5. 2026 PLANNING PREVIEW: OPPORTUNITIES IN NEW LAW

| 2026 Post-Sunset Opportunity | Action |
| --- | --- |
| SALT deduction restored (unlimited) | Compare IL income tax + property tax vs. standard deduction; itemize if beneficial |
| Misc. deduction floor (2%) restored | Investment advisory fees may again be partially deductible (confirm IRS guidance) |
| Lower bracket thresholds | Smaller Roth conversions may fill lower brackets more efficiently; recalibrate ladder |
| CTC reduced to $1,000 | Optimize withholding and estimated payments; reduced credit increases effective tax |

| RECOMMENDED ACTIONS✓  Execute 2025 Roth conversion by December 31, 2025 (target $30,000 at 24%) — see TAX-2025-001✓  Make $7,500 DAF top-up contribution by December 31, 2025 (PEASE limitation suspended in 2025)✓  Fund 529 accounts to $10,000 each (ACCT-529A and ACCT-529B) for maximum IL state deduction✓  Evaluate 2025 annual exclusion gifts ($19,000/person) to Maya and Eli for estate pre-planning✓  Model 2026 itemized deductions with SALT restored; determine if switching from standard to itemized✓  Obtain 2026 projected tax brackets from CPA; recalibrate Roth conversion ladder for post-TCJA environment |
| --- |

TAX-2025-002 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
