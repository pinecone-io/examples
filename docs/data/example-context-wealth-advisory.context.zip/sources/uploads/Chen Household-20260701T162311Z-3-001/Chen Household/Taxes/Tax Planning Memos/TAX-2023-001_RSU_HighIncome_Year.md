| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

2023 High-Income Year Tax Planning: RSU Vesting Event

EventID-2023-01 — $172K RSU Contribution, ~$426K AGI, NIIT & AMT Analysis

| Document ID: | TAX-2023-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | May 25, 2023 |
| --- | --- |

| Event Trigger: | EventID-2023-01 — RSU Liquidity Event & NLTK Concentration Reduction |
| --- | --- |

| Related Documents: | TAX-2022-002; DOC-DAFTaxStrategy-2023-001; ACCT-TX01; ACCT-IRA1 |
| --- | --- |

1. EXECUTIVE SUMMARY

May 2023 produced a significant RSU vesting event (EventID-2023-01) for Alex Chen, with approximately $120,000 in equity compensation W-2 income from the vesting of a large NLTK tranche. The net $172,000 was contributed to ACCT-TX01 after employment taxes and withholding. Combined with base household W-2 income of approximately $262,000, investment income of ~$2,100, and estimated net capital gains of ~$42,000 (after TLH carryforward offset), the household’s estimated 2023 AGI is approximately $426,000 — one of the highest-income years in the household’s planning history. This memo addresses NIIT exposure, AMT risk, estimated taxes, and DAF coordination.

2. 2023 INCOME SUMMARY & BRACKET ANALYSIS

| Income Component | Estimated Amount | Character |
| --- | --- | --- |
| Alex W-2 (base salary) | ~$185,000 | Ordinary — W-2 |
| Sam W-2 (base salary) | ~$77,000 | Ordinary — W-2 |
| Alex RSU vest income (NLTK) | ~$120,000 | Ordinary — W-2 supplemental |
| Investment income (ACCT-TX01) | ~$2,100 | Qualified div + interest |
| Net capital gains (NLTK sale, net TLH) | ~$42,000 | Mostly LTCG; some STCG |
| Estimated Gross Income | ~$426,100 | MFJ |
| Less: above-the-line deductions | ~($5,000) | Retirement + HSA contributions |
| Estimated AGI | ~$421,000 |  |
| Federal tax bracket (MFJ 2023) | 32% marginal (MFJ: $364,200–$462,500) | Top bracket hit |

3. NET INVESTMENT INCOME TAX (NIIT) ANALYSIS

The 3.8% NIIT (IRC §1411) applies to the lesser of (a) net investment income or (b) MAGI in excess of the MFJ threshold ($250,000 in 2023). With estimated MAGI of ~$421,000, the household has $171,000 above the NIIT threshold. Net investment income (~$44,100 = dividends + interest + capital gains) is the lesser figure:

| NIIT Calculation | Amount |
| --- | --- |
| Net investment income (NII) | ~$44,100 |
| MAGI above $250K threshold | ~$171,000 |
| Lesser of above | ~$44,100 (NII is binding) |
| NIIT at 3.8% | ~$1,676 |
| Note: RSU W-2 income is NOT NII | Not included in NIIT base |

4. ALTERNATIVE MINIMUM TAX (AMT) ANALYSIS

While ISOs are the primary AMT driver for equity compensation, RSU income is included in regular taxable income and generally does not trigger AMT adjustments. However, at AGI ~$421,000, the household should confirm the following AMT exemption phaseout does not create additional liability:

| AMT Factor (2023 MFJ) | Amount |
| --- | --- |
| AMT exemption (MFJ 2023) | $126,500 |
| Phaseout threshold (MFJ) | $1,156,300 (far above current AMTI) |
| Estimated AMTI (approx.) | ~$395,000 (post-exemption: ~$268,500) |
| Tentative minimum tax (26%/28%) | ~$69,810 vs. regular tax ~$91,000+ |
| AMT liability | $0 — regular tax exceeds TMT |

5. ABOVE-THE-LINE DEDUCTIONS & ITEMIZED ANALYSIS

| Deduction Item | 2023 Estimate | Notes |
| --- | --- | --- |
| Alex 401(k) contribution | ~($22,500) | Employer match not deductible |
| Sam 401(k) | ~($22,500) | Separate plan |
| HSA contribution (family) | ~($7,750) | Family limit 2023 |
| Mortgage interest (ACCT-HOME, 2021+) | ~($18,000) | Schedule A |
| State & local taxes (SALT) | ($10,000) | SALT cap under TCJA |
| Charitable contributions (non-DAF) | ~($3,500) | Schedule A |
| DAF contribution (DOC-DAFEstab-2023-001) | ~($25,000) | Full deduction yr of gift; no AGI %limit |
| Total above-the-line (retirement/HSA) | ~($52,750) | Reduces AGI |
| Total itemized vs. standard ($27,700 MFJ) | ~$56,500 — itemize | Itemized beats standard |

| RECOMMENDED ACTIONS✓  Maximize Alex & Sam 401(k) contributions ($22,500 each) to reduce AGI and RSU income impact✓  Fund HSA to family maximum ($7,750) for triple tax benefit✓  Contribute $25,000 NLTK appreciated stock to DAF (DOC-DAFEstablishment-2023-001) — avoid capital gains + deduction✓  Ensure Q2 2023 estimated tax paid by June 15; RSU supplemental withholding may be insufficient✓  Apply 2022 TLH carryforward (~$48,500) against 2023 NLTK sale capital gains to reduce LTCG exposure✓  Consult CPA re: Additional Medicare Tax (0.9%) on W-2 wages >$200K; ensure proper Form 8959 filing✓  Schedule Q3 2023 tax projection meeting to confirm estimated payments are on track |
| --- |

TAX-2023-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
