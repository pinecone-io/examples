| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

Pre-Retirement Roth Conversion Ladder Strategy

18-Year Runway to Retirement — Systematic Bracket-Filling Conversion Plan

| Document ID: | TAX-2025-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | March 15, 2025 |
| --- | --- |

| Event Trigger: | IPS Bucket Strategy Amendment (DOC-IPSAmendment-2025-001, eff. 2025-03-01) |
| --- | --- |

| Related Documents: | DOC-IPSAmendment-2025-001; ACCT-IRA1; ACCT-RIRA; TAX-2024-001 |
| --- | --- |

1. STRATEGIC CONTEXT

With the adoption of the bucket strategy IPS amendment (DOC-IPSAmendment-2025-001, effective March 1, 2025) and Alex Chen’s milestone of turning 42 in 2025, the household is entering its pre-retirement tax optimization phase. Alex and Sam have an approximately 18-year runway to target retirement at age ~60 (circa 2043). This extended horizon makes a systematic Roth IRA conversion ladder one of the most powerful tax strategies available — particularly before anticipated tax law changes in 2026 and during years when AGI may moderate from the 2023 high of ~$426,000.

2. CURRENT RETIREMENT ACCOUNT BALANCES (2025 Q1)

| Account | Account ID | Approx. Balance (2025 Q1) | Tax Character |
| --- | --- | --- | --- |
| Alex Traditional IRA | ACCT-IRA1 | ~$195,000 | Pre-tax; taxable at distribution |
| Alex Roth IRA | ACCT-RIRA | ~$88,000 | Post-tax; tax-free growth + distribution |
| Alex 401(k) at NLTK | ACCT-401R | ~$310,000 | Pre-tax; taxable at distribution |
| Sam 401(k) | (employer plan) | ~$135,000 | Pre-tax; taxable at distribution |
| ACCT-TX01 (Joint Taxable) | ACCT-TX01 | ~$720,000 (2025 Q2 est.) | Post-tax; LTCG on gains |

3. ROTH CONVERSION STRATEGY: 2025 FRAMEWORK

The objective is to systematically convert pre-tax IRA assets to Roth IRA at the lowest available marginal rates, building tax-free retirement income and reducing future Required Minimum Distributions (RMDs) from ACCT-IRA1. Recommended approach:

| Year | Conversion Target | Target Bracket | Rationale |
| --- | --- | --- | --- |
| 2025 | $25,000–$40,000 | 22% or 24% | Pre-TCJA-sunset; bracket still favorable vs. post-2025 |
| 2026 | $20,000–$35,000 | Post-sunset rates TBD | Adjust for new brackets; monitor legislation |
| 2027–2030 | $20,000–$30,000/yr | Target <24% bracket | Systematic ladder; smooth tax over 15+ years |
| 2031–2035 | $15,000–$25,000/yr | Depends on income | Reduce as 401(k) grows; reassess |
| 2036–2042 | Smaller conversions | Fill bracket gaps | RMD pre-planning; near-retirement refinement |

4. 2025 BRACKET ANALYSIS: OPTIMAL CONVERSION WINDOW

| Item | 2025 Estimate (MFJ) |
| --- | --- |
| Alex base W-2 | ~$195,000 |
| Sam W-2 | ~$82,000 |
| Investment income (ACCT-TX01) | ~$3,800 (divs + interest) |
| RSU income (routine tranche) | ~$25,000 (estimated) |
| Gross income (pre-conversion) | ~$305,800 |
| Less: standard 401(k) contributions (both) | ~($46,000) |
| Estimated AGI (pre-conversion) | ~$259,800 |
| 22% bracket ceiling (MFJ 2025) | ~$230,000 (taxable income threshold) |
| Estimated taxable income | ~$230,000 (near 22/24% boundary) |
| Conversion headroom at 22% | ~$0 — convert up to $35,000 at 24% |
| Recommended conversion | $30,000 at 24% blended rate |
| Estimated tax on conversion | ~$7,200 (24%) |

5. LONG-TERM ROTH CONVERSION BENEFITS

Systematic Roth conversions over 18 years at 22–24% deliver significant long-term benefits compared to distributing all pre-tax IRA assets in retirement potentially at higher rates:

Tax-free compound growth: Converted assets grow tax-free in ACCT-RIRA for 18+ years.

RMD reduction: Each dollar converted from ACCT-IRA1 reduces future taxable RMDs after age 73 (SECURE 2.0).

Social Security optimization: Lower pre-tax IRA balances reduce provisional income, potentially reducing SS taxation in retirement.

Estate planning: Roth IRAs have no RMD requirement during owner’s lifetime; ideal asset to leave heirs tax-free under 10-year rule.

Rate hedge: Converting now locks in 22–24% rates; avoids potential higher rates if post-2025 brackets increase.

| RECOMMENDED ACTIONS✓  Execute $30,000 Roth conversion from ACCT-IRA1 to ACCT-RIRA in Q2 2025 (DecisionID-2025-112 scope)✓  Adjust Q2–Q3 estimated tax payments to cover conversion income (~$7,200 additional tax)✓  Fund conversion tax from taxable account — do NOT withhold from IRA conversion (reduces principal)✓  Build multi-year conversion schedule through 2042; review annually at Q1 planning meeting✓  Model RMD projections at age 73 with and without conversion ladder — quantify lifetime tax savings✓  Coordinate with TCJA sunset planning (TAX-2025-002) to assess 2026 rate environment |
| --- |

TAX-2025-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
