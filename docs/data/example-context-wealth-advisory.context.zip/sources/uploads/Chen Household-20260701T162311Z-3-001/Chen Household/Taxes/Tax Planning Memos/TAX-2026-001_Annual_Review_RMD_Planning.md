| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

2026 Annual Tax Review & RMD Pre-Planning Memo

Post-TCJA Environment — Rate Recalibration & Long-Term Retirement Tax Strategy

| Document ID: | TAX-2026-001 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | February 20, 2026 |
| --- | --- |

| Event Trigger: | EventID-2026-01 — Fee Discrepancy Resolution; Annual Planning Cycle Q1 2026 |
| --- | --- |

| Related Documents: | TAX-2025-001; TAX-2025-002; DOC-AgreementAmendment-2024-001; ACCT-IRA1; ACCT-401R |
| --- | --- |

1. 2026 PLANNING CONTEXT

2026 marks the first year of the post-TCJA tax environment following the December 31, 2025 sunset of major individual income tax provisions. Concurrently, the resolution of the fee billing discrepancy (EventID-2026-01) in Q1 2026 was addressed in the January 2026 planning meeting (MtgID-2026Q1-01), reinforcing the household’s confidence in transparent, values-aligned advising. This memo provides the 2026 annual tax review and initiates Required Minimum Distribution (RMD) pre-planning for ACCT-IRA1 and ACCT-401R, which will become mandatory at age 73 (approximately 2056 for Alex).

2. 2026 INCOME PROJECTIONS (POST-TCJA ENVIRONMENT)

| Income Item | 2026 Estimate | Post-TCJA Change |
| --- | --- | --- |
| Alex W-2 (base) | ~$203,000 | No change in character |
| Sam W-2 (base) | ~$85,000 | No change in character |
| RSU income (NLTK) | ~$20,000–$30,000 | Routine tranche; W-2 supplemental |
| Investment income (ACCT-TX01) | ~$4,800 (div/int/LTCG) | LTCG rates unchanged (0/15/20%) |
| Roth conversion (continued) | ~$25,000 | Now at post-TCJA bracket rates |
| Estimated AGI | ~$315,000–$335,000 |  |
| Standard deduction (MFJ 2026) | ~$15,700 (reverts; est.) | Reduced vs. 2025 $30,000 |
| IL property + income tax (SALT) | ~$22,000 (estimated) | SALT uncapped post-TCJA; may itemize |
| Recommendation: itemize if SALT >$15,700 | Likely yes in 2026 | SALT restoration benefits Chens |

3. ROTH CONVERSION CONTINUATION: 2026 CALIBRATION

Post-TCJA, the 22% bracket ceiling drops from ~$230,000 (2025) to approximately $165,000 MFJ taxable income (2026), making smaller conversions required to stay within the 22% bracket. However, the Chens’ projected 2026 taxable income of ~$295,000–$315,000 (before conversion) likely places them in the 25% or 28% bracket post-sunset. Revised conversion target:

| Item | 2026 Post-TCJA Estimate |
| --- | --- |
| Estimated 2026 taxable income (no conversion) | ~$295,000 |
| Post-TCJA bracket at $295K (MFJ) | 28% marginal (approx.) |
| Roth conversion recommendation | $15,000–$20,000 at 28% |
| Tax on conversion (28%) | ~$4,200–$5,600 |
| Decision: convert at 28% vs. defer to retirement? | Yes — retirement RMDs likely 28%+ also |

4. RMD PRE-PLANNING: 30-YEAR HORIZON

Under SECURE 2.0 (effective 2023), the RMD beginning age is 73 for individuals born between 1951 and 1959, and 75 for those born 1960 or later. Alex (born 1983) will reach RMD age under current law at 75 — approximately 2058. Sam (born 1986) similarly reaches RMD age around 2061. The 30+ year pre-RMD window creates an exceptional opportunity to convert pre-tax assets systematically.

| Account | Projected Balance at Retirement (~2043) | Projected RMD at Age 75 (2058) |
| --- | --- | --- |
| ACCT-IRA1 (Alex Trad. IRA) | ~$1.1M (at 6% growth, no more conversions) | ~$40,000/yr |
| ACCT-IRA1 (with annual conversions) | ~$420K (converting $25K/yr 2025–2043) | ~$15,000/yr |
| ACCT-401R (Alex 401k) | ~$2.1M (at 7% growth) | ~$77,000/yr |
| Combined pre-tax RMD (no conversion) | ~$117,000/yr | Potentially 28%+ bracket in retirement |
| Roth IRA (ACCT-RIRA) | ~$420K+ (tax-free) | No RMD required |

The modeling above illustrates that a systematic Roth conversion ladder over the next 17 years can substantially reduce future RMD burden and retirement tax rates. Even at post-TCJA 28% conversion rates, the long-term benefit of tax-free Roth growth over 30+ years exceeds the current conversion tax cost.

| RECOMMENDED ACTIONS✓  Execute 2026 Roth conversion: $15,000–$20,000 from ACCT-IRA1 to ACCT-RIRA (28% post-TCJA)✓  Model SALT itemization benefit in 2026: compare IL income ($16,600) + property tax vs. standard deduction✓  Update Roth conversion ladder model for post-TCJA rates; recalibrate 2027–2030 conversion targets✓  Request 30-year RMD projection from Fidelity (CUST-FI-001) to quantify future mandatory distributions✓  Initiate 401(k) in-plan Roth conversion discussion with Alex’s NLTK plan administrator✓  Confirm Q1 2026 fee discrepancy credit applied correctly to household accounts (EventID-2026-01) |
| --- |

TAX-2026-001 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
