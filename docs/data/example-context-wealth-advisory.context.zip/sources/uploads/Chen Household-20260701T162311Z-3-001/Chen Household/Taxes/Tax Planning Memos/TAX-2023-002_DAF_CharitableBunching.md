| CLEARWATER WEALTH PARTNERSTAX PLANNING MEMORANDUM |
| --- |

DAF Charitable Bunching & Appreciated Stock Strategy

Clearwater Giving Fund — 2023 Establishment & Tax-Efficient Giving Plan

| Document ID: | TAX-2023-002 |
| --- | --- |

| Client: | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Advisor: | Morgan Park, CFP®  |  Clearwater Wealth Partners |
| --- | --- |

| Date: | May 30, 2023 |
| --- | --- |

| Event Trigger: | EventID-2023-01 — DAF Established; NLTK Concentration Reduction |
| --- | --- |

| Related Documents: | DOC-DAFEstablishment-2023-001; DOC-DAFTaxStrategy-2023-001; TAX-2023-001 |
| --- | --- |

1. STRATEGIC RATIONALE

The 2023 RSU vesting event (EventID-2023-01) created a rare opportunity: an exceptionally high-income year (AGI ~$426,000) combined with a concentrated NLTK position. This combination makes 2023 the optimal year to ‘bunch’ multiple years of charitable giving into a single large deduction by contributing appreciated NLTK stock to a Donor Advised Fund (DAF). The Chen Family Charitable Fund (Clearwater Giving Fund) was established in May 2023 with an opening contribution of $25,000 in NLTK appreciated stock.

2. TAX BENEFIT ANALYSIS: APPRECIATED STOCK vs. CASH

| Scenario | Cash Contribution | NLTK Stock Contribution |
| --- | --- | --- |
| Contribution amount | $25,000 | $25,000 (FMV at contribution) |
| Capital gains recognition | N/A | None — gain bypassed on transfer to DAF |
| Estimated embedded LTCG in stock | N/A | ~$18,000 gain avoided |
| LTCG tax avoided (20% + 3.8% NIIT) | N/A | ~$4,266 saved |
| Schedule A deduction | $25,000 | $25,000 (FMV of stock) |
| Federal income tax savings (32%) | ~$8,000 | ~$8,000 |
| Illinois income tax savings (4.95%) | ~$1,238 | ~$1,238 |
| Total estimated tax benefit | ~$9,238 | ~$13,504 (with LTCG avoidance) |

3. CHARITABLE BUNCHING STRATEGY

Rather than making modest annual cash donations ($5,000–$8,000/year), the Chens front-load several years of charitable intent into the 2023 high-income year via the DAF. Future annual grants from the DAF fund ongoing charitable giving without requiring additional above-the-line deductions in lower-income years:

| Year | Charitable Activity | Tax Strategy |
| --- | --- | --- |
| 2023 | $25,000 NLTK stock to DAF | Large deduction in 32% bracket year; stock gain bypassed |
| 2024 | $0 additional contribution to DAF | Take standard deduction ($29,200 MFJ); DAF grants from balance |
| 2025 | $7,500 additional contribution to DAF | DAF top-up; grants continue; pre-retirement giving alignment |
| 2026+ | $8,000+/year contributions planned | Ongoing charitable intent; estate legacy coordination |
| Annual DAF grants | $5,000–$8,000/year to qualified charities | Not deductible again; already deducted at contribution |

4. NLTK CONCENTRATION REDUCTION

Contributing NLTK shares to the DAF achieves three simultaneous objectives:

Reduces NLTK single-stock concentration in ACCT-TX01 from >20% to <10% of investable assets

Avoids capital gains tax that would have been triggered by a direct market sale

Generates a Schedule A deduction equal to the full FMV at the time of contribution

The DAF assets are then invested in a diversified portfolio within the sponsoring organization, eliminating the concentrated position without a taxable event.

5. AGI LIMITATION & DEDUCTIBILITY RULES

| Deductibility Rule | Detail |
| --- | --- |
| Cash to DAF (public charity) | 60% of AGI limit; excess carried forward 5 years |
| Appreciated stock to DAF | 30% of AGI limit; excess carried forward 5 years |
| 2023 limit (30% × ~$421K AGI) | ~$126,300 — $25,000 well within limit |
| Carryforward needed? | No — $25,000 < 30% AGI limit |
| Documentation required | Form 8283 if property contribution >$500; DAF acknowledgment letter |

| RECOMMENDED ACTIONS✓  Transfer $25,000 NLTK shares (appreciated) to Chen Family Charitable Fund by May 31, 2023✓  Obtain qualified appraisal acknowledgment from DAF sponsor for stock contribution✓  File Form 8283 with 2023 return for non-cash charitable contribution exceeding $500✓  Direct DAF to diversify holding into balanced portfolio after receipt of NLTK shares✓  Initiate first grant recommendations (DOC-DAFGrantLetter-2023-001) by Q4 2023✓  Calendar 2024 standard deduction year — no additional DAF contribution needed; grants funded from 2023 balance |
| --- |

TAX-2023-002 • Clearwater Wealth Partners • Wayzata, MN 55391 • SYNTHETIC DEMONSTRATION DOCUMENT — NOT TAX ADVICE • NWP-DEMO-HH-CHEN-001 v1.2
