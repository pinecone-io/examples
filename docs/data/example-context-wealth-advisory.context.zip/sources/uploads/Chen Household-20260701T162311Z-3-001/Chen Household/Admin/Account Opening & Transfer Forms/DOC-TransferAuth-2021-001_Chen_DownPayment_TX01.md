CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional Custodian (CUST-FI-001)

PARTIAL LIQUIDATION & DISTRIBUTION AUTHORIZATION

ACCT-TX01 (Joint Taxable Brokerage) | Purpose: Home Purchase Down Payment

| Document ID DOC-TransferAuth-2021-001 | Date July 15, 2021 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: EventID-2021-01 — Chen Household entered into purchase agreement for primary residence (3215 Lakeview Circle, Wayzata, MN 55391). Down payment and closing costs require approximately $55,000 liquidation from ACCT-TX01. This is the outflow reflected in 2021-Q3 AUM ledger (net flows: −$55,000). GoalID-2016-03 (emergency liquidity) and GoalID-2016-01 (retirement readiness) to be reviewed post-close; IPS drift bands to be monitored post-distribution.

SECTION A — ACCOUNT HOLDER & ACCOUNT INFORMATION

| Account Holders: | Alex Chen  &  Sam Chen  (Joint JTWROS) |
| --- | --- |

| Account ID: | ACCT-TX01  (Taxable Joint Brokerage — Fidelity Institutional) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Phone: | (612) 555-0278 |
| --- | --- |

| Email: | alex.chen@exampledemo.com  /  sam.chen@exampledemo.com |
| --- | --- |

SECTION B — DISTRIBUTION REQUEST DETAILS

| Request Type: | ☒ Partial Liquidation & Cash Distribution   ☐ Full Liquidation   ☐ In-Kind Transfer |
| --- | --- |

| Distribution Amount: | $55,000.00  (fifty-five thousand dollars) |
| --- | --- |

| Purpose: | Primary residence down payment and associated closing costs |
| --- | --- |

| Property Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Mortgage Lender: | Lakeside Mortgage Co.  (synthetic) |
| --- | --- |

| Closing Date (Est.): | August 2021  (exact date TBD per lender timeline) |
| --- | --- |

| Distribution Method: | ☒ Wire Transfer to Household Checking Account   ☐ Check   ☐ ACH |
| --- | --- |

| Destination Account: | Chen Household Checking (account on file with custodian) |
| --- | --- |

| Tax Withholding: | ☒ No withholding requested (taxable account; gains subject to capital gains tax)   ☐ Withhold Federal: ____% |
| --- | --- |

SECTION C — LIQUIDATION INSTRUCTIONS

Adviser authorizes and directs Fidelity Institutional to liquidate the following positions from ACCT-TX01 to raise $55,000 in cash, consistent with tax-aware liquidation principles under DOC-IPS-2016-001 (IPS-2020 in effect: 60/35/5):

| Fund / Security | Ticker | Estimated Shares / Amount | Tax Lot Preference |
| --- | --- | --- | --- |
| Municipal Bond Fund (MUNIX) | MUNIX | ~$20,000 (tax-exempt; lowest cap gain impact) | Long-term lots; FIFO |
| US Equity Core Index (UECIX) | UECIX | ~$20,000 | Long-term lots; highest cost basis |
| Short-Term Bond / Cash (STBIX) | STBIX | ~$15,000 (minimal gain expected) | Pro-rata |
| Total Distribution Target | — | $55,000 (net of estimated transaction costs) | — |

SECTION D — POST-DISTRIBUTION PORTFOLIO REVIEW

Following completion of the distribution, Adviser will conduct a post-close portfolio review to address: (1) IPS drift — distribution may cause temporary allocation deviation from IPS-2020 targets (60/35/5); rebalancing trade proposal to follow if drift exceeds ±4% equity / ±4% fixed bands; (2) GoalID-2016-03 emergency liquidity — ACCT-CASH balance to be reviewed to ensure 6–9 months of expenses remain accessible; (3) Mortgage interest deductibility — coordinate with Lisa Torres, EA for 2021 tax itemized deduction analysis; (4) Updated net worth and household balance sheet to reflect home equity addition. All post-close actions will be documented in Q3 2021 meeting notes.

SECTION E — TAX CONSIDERATIONS

| Capital Gains Exposure: | Long-term capital gains tax applies on UECIX / MUNIX lots with gain; estimated taxable gain: $4,200 — $7,500 (to be confirmed post-execution) |
| --- | --- |

| AMT / NIIT: | NIIT (3.8%) applies to net investment income above MFJ threshold; coordinate with Lisa Torres, EA for 2021 estimate |
| --- | --- |

| 1099-B: | Custodian (Fidelity Institutional) will issue 2021 Form 1099-B reflecting all realized gains/losses |
| --- | --- |

| Tax Planning Reference: | TaxTopicID-2021 — home purchase deductions; mortgage interest; state property tax |
| --- | --- |

SECTION F — SIGNATURES (BOTH ACCOUNT HOLDERS REQUIRED)

Both joint account holders must sign to authorize this partial liquidation and distribution. By signing, we confirm that the distribution is for the purpose stated above and authorize Clearwater Wealth Partners and Fidelity Institutional to execute the liquidation and transfer as described. We acknowledge the potential tax consequences and confirm we have consulted with our tax adviser.

| ____________________________________Joint Account HolderAlex ChenDate:  July 15, 2021 | ____________________________________Joint Account HolderSam ChenDate:  July 15, 2021 | ____________________________________Adviser AuthorizationMorgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  July 15, 2021 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) Established ACCT-TX01 | Date Approved 2021-07-15 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-TransferAuth-2021-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
