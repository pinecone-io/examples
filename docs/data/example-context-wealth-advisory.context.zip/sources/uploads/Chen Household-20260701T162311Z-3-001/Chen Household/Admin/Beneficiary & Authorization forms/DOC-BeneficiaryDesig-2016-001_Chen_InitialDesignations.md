CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional (CUST-FI-001)

BENEFICIARY DESIGNATION FORM — INITIAL

ACCT-TX01 | ACCT-IRA1 | ACCT-RIRA — Chen Household Accounts

| Document ID DOC-BeneficiaryDesig-2016-001 | Date February 1, 2016 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: New advisory relationship established — DOC-AdvisoryAgreement-2016-001 (eff. 2016-02-01). Beneficiary designations required on all three accounts opened concurrently. These are initial (first-time) designations; no prior designations exist. Adviser recommends review upon any major life event, including marriage, birth of children, and trust formation.

SECTION A — ACCOUNT HOLDER INFORMATION

| Primary Account Holder: | Alex Chen  (DOB: March 22, 1981  |  SSN: XXX-XX-4444) |
| --- | --- |

| Joint Account Holder: | Sam Chen  (DOB: November 2, 1984  |  SSN: XXX-XX-8888) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Filing Status: | Married Filing Jointly |
| --- | --- |

| Dependents: | Maya Chen (DOB: Aug 19, 2011)  |  Eli Chen (DOB: Mar 7, 2014) |
| --- | --- |

SECTION B — BENEFICIARY DESIGNATIONS

Beneficiary designations below apply to each account as of the account opening date. For JTWROS (ACCT-TX01), beneficiary only takes effect upon the death of both joint account holders. For IRAs (ACCT-IRA1, ACCT-RIRA), beneficiary designation governs distribution upon account holder’s death. Shares must total 100% per account per beneficiary tier.

| Account | Acct ID | Type | Beneficiary Name | Relationship | DOB | Share % | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Taxable Brokerage | ACCT-TX01 | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | JTWROS — survivor takes all |
| Taxable Brokerage | ACCT-TX01 | Contingent | Maya Chen | Child | 2011-08-19 | 50% | Per stirpes |
| Taxable Brokerage | ACCT-TX01 | Contingent | Eli Chen | Child | 2014-03-07 | 50% | Per stirpes |
| Alex Trad. IRA | ACCT-IRA1 | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | Eligible designated beneficiary (spouse) |
| Alex Trad. IRA | ACCT-IRA1 | Contingent | Maya Chen | Child | 2011-08-19 | 50% | Per stirpes |
| Alex Trad. IRA | ACCT-IRA1 | Contingent | Eli Chen | Child | 2014-03-07 | 50% | Per stirpes |
| Alex Roth IRA | ACCT-RIRA | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | Eligible designated beneficiary (spouse) |
| Alex Roth IRA | ACCT-RIRA | Contingent | Maya Chen | Child | 2011-08-19 | 50% | Per stirpes |
| Alex Roth IRA | ACCT-RIRA | Contingent | Eli Chen | Child | 2014-03-07 | 50% | Per stirpes |

SECTION C — DISTRIBUTION INSTRUCTIONS & ELECTIONS

☒ Per stirpes (issue of deceased beneficiary takes that share) ☐ Per capita (surviving beneficiaries divide equally) ☐ Specific instructions attached

| Roth Stretch / SECURE Act: | Contingent beneficiaries are minor children; 10-year rule applies after age of majority per SECURE Act |
| --- | --- |

| Trust Designation: | ☐ Designate trust as beneficiary   ☒ Direct individual designations (no trust in place as of 2016-02-01) |
| --- | --- |

⚠ ADVISER NOTE — REVIEW TRIGGER: A revocable trust is anticipated in the future (EventID-2019-01). Upon trust formation, all beneficiary designations must be reviewed and potentially updated to align with trust provisions and estate plan. Adviser will initiate this review as a required action under Section 6 of DOC-AdvisoryAgreement-2016-001.

SECTION D — ADVISER ACKNOWLEDGEMENT

Adviser (Morgan Park, CFP®) has reviewed these designations with Client and confirmed: (1) spouse Sam Chen is named primary beneficiary on all accounts consistent with household estate planning intent; (2) children Maya and Eli are named contingent beneficiaries on a per-stirpes basis; (3) no trust is in place as of this date; (4) the household has been advised to notify Adviser promptly upon any life event that may affect beneficiary designations, including trust formation (anticipated 2019), birth or adoption of additional dependents, or change in marital status.

SECTION E — SIGNATURES

| ____________________________________Primary Account HolderAlex ChenDate:  February 1, 2016 | ____________________________________Co-Account HolderSam ChenDate:  February 1, 2016 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  February 1, 2016 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) ACCT-TX01, ACCT-IRA1, ACCT-RIRA | Date Approved 2016-02-01 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-BeneficiaryDesig-2016-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
