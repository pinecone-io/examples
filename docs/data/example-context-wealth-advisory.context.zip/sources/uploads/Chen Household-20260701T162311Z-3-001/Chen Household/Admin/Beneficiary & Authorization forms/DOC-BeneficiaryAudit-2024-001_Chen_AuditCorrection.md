CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional (CUST-FI-001)

BENEFICIARY AUDIT & CORRECTION FORM

All Covered Accounts — EventID-2024-01: Family Health Event | Estate Alignment Review

| Document ID DOC-BeneficiaryAudit-2024-001 | Date September 20, 2024 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: EventID-2024-01 — A family health event affecting a member of the Chen household prompted a comprehensive estate and beneficiary audit in 2024-Q3. Adviser initiated a full review of all Covered Account beneficiary designations against the Chen Family Revocable Trust (est. March 2019) and current estate planning intent. Audit revealed one material mismatch (see Section C). All accounts updated to reflect current trust structure and household estate plan.

SECTION A — AUDIT SCOPE & METHODOLOGY

| Audit Date: | September 2024  (conducted in connection with 2024-Q3 advisory meeting) |
| --- | --- |

| Audit Scope: | All Covered Accounts: ACCT-TX01, ACCT-IRA1, ACCT-RIRA, ACCT-CASH, ACCT-529A, ACCT-529B |
| --- | --- |

| Adviser: | Morgan Park, CFP®  (ADV-PARK-001)  |  Estate coordination: Logan Hart, JD |
| --- | --- |

| Trust Reference: | Chen Family Revocable Trust (est. March 2019)  |  Westfield & Baker LLP |
| --- | --- |

| Prior Audit: | DOC-BeneficiaryDesig-2016-001 (initial) + DOC-BeneficiaryUpdate-2019-001 (partial update) |
| --- | --- |

| Methodology: | Custodian records compared to trust provisions; confirmed against DOC-AgreementAmendment-2024-001 (estate coordination added to advisory scope) |
| --- | --- |

SECTION B — AUDIT FINDINGS SUMMARY

| Account | Last Updated | Status | Finding |
| --- | --- | --- | --- |
| ACCT-TX01 | Mar 2019 | ✅ OK | Primary: Sam Chen (100%). Contingent: Chen Family Revocable Trust (100%). Aligned with trust. |
| ACCT-IRA1 | Mar 2019 | ✅ OK | Primary: Sam Chen (100%, EDB). Contingent: Chen Family Revocable Trust. Aligned with trust. |
| ACCT-RIRA | Feb 2016 | ⚠ MISMATCH | Primary: Sam Chen (100%). Contingent: Maya Chen 50% / Eli Chen 50% (direct). NOT updated in 2019. Trust NOT named. Inconsistent with ACCT-IRA1 and estate plan. |
| ACCT-CASH | Jan 2019 | ⚠ PARTIAL | Primary: Sam Chen (100%). Contingent: Maya & Eli Chen (direct, per stirpes). Trust not yet incorporated. Update required. |
| ACCT-529A | May 2020 | ✅ OK | Owner: Alex & Sam Chen. Beneficiary: Maya Chen. Successor owner: Sam Chen. No trust issue. |
| ACCT-529B | May 2020 | ✅ OK | Owner: Alex & Sam Chen. Beneficiary: Eli Chen. Successor owner: Sam Chen. No trust issue. |

SECTION C — MISMATCH DETAIL: ACCT-RIRA

MATERIAL MISMATCH IDENTIFIED — ACCT-RIRA (Alex Roth IRA): Custodian records show beneficiary designation dated February 1, 2016 (DOC-BeneficiaryDesig-2016-001). The 2019 trust formation update (DOC-BeneficiaryUpdate-2019-001) covered ACCT-TX01 and ACCT-IRA1 only. ACCT-RIRA was deferred (ActionID-2019Q1-003) and the deferred update was never completed. As a result, ACCT-RIRA contingent beneficiaries are Maya and Eli Chen directly, not the Chen Family Revocable Trust. This is inconsistent with household estate planning intent and the trust structure.

❌ ROOT CAUSE: ActionID-2019Q1-003 (ACCT-RIRA trust update, target 2019-Q2) was not completed. Trust certification delay and adviser tracking gap resulted in the deferred action item not being executed. This mismatch has persisted from 2019 through 2024 (5 years). Correction required immediately.

SECTION D — CORRECTED BENEFICIARY DESIGNATIONS (ALL ACCOUNTS)

The following designations are effective as of September 20, 2024 for all accounts requiring updates. Unchanged accounts (ACCT-TX01, ACCT-IRA1, ACCT-529A, ACCT-529B) are confirmed and reaffirmed for completeness. ACCT-RIRA and ACCT-CASH are corrected.

| Account | Acct ID | Type | Beneficiary Name | Relationship | DOB | Share % | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Taxable Brokerage | ACCT-TX01 | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | Confirmed — no change |
| Taxable Brokerage | ACCT-TX01 | Contingent | Chen Family Revocable Trust | Trust | Est. 2019 | 100% | Confirmed — no change |
| Alex Trad. IRA | ACCT-IRA1 | Primary | Sam Chen | Spouse (EDB) | 1984-11-02 | 100% | Confirmed — no change |
| Alex Trad. IRA | ACCT-IRA1 | Contingent | Chen Family Revocable Trust | Trust | Est. 2019 | 100% | Confirmed — no change |
| Alex Roth IRA | ACCT-RIRA | Primary | Sam Chen | Spouse (EDB) | 1984-11-02 | 100% | ✔ CORRECTED — was 2016 direct |
| Alex Roth IRA | ACCT-RIRA | Contingent | Chen Family Revocable Trust | Trust | Est. 2019 | 100% | ✔ CORRECTED — replaces Maya/Eli direct |
| Cash Mgmt | ACCT-CASH | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | Confirmed — no change |
| Cash Mgmt | ACCT-CASH | Contingent | Chen Family Revocable Trust | Trust | Est. 2019 | 100% | ✔ UPDATED — was Maya/Eli direct |
| 529 Maya | ACCT-529A | Beneficiary | Maya Chen | Child (Account Beneficiary) | 2011-08-19 | N/A | Confirmed — no change |
| 529 Eli | ACCT-529B | Beneficiary | Eli Chen | Child (Account Beneficiary) | 2014-03-07 | N/A | Confirmed — no change |

✔ RESOLUTION: All Covered Account beneficiary designations are now aligned with the Chen Family Revocable Trust and current estate planning intent as of September 20, 2024. ActionID-2019Q1-003 closed. Future annual beneficiary review incorporated into Q4 advisory meeting agenda per DOC-AgreementAmendment-2024-001.

SECTION E — FORWARD-LOOKING ITEMS

The following items are noted for future action: (1) Confirm successor trustee designations in the Chen Family Revocable Trust remain current with Westfield & Baker LLP; (2) Review trust provisions for SECURE Act compliance regarding trust as IRA beneficiary (conduit vs. accumulation trust analysis — coordinate with Logan Hart, JD); (3) As Maya (anticipated college 2029) and Eli (anticipated college 2032) approach college age, review 529 owner succession provisions; (4) Annual beneficiary review to be added as standing agenda item in Q4 strategy meeting beginning 2024-Q4 per DOC-AgreementAmendment-2024-001 Section 5.

SECTION F — ACKNOWLEDGEMENTS & SIGNATURES

By signing below, both account holders confirm they have reviewed and authorized all beneficiary designation updates described herein. Account holders acknowledge that the ACCT-RIRA mismatch (present since 2019) has been identified and corrected, and that all Covered Account designations now reflect their current estate planning intentions as discussed with Adviser and coordinated with Westfield & Baker LLP.

| ____________________________________Primary Account HolderAlex ChenDate:  September 20, 2024 | ____________________________________Co-Account HolderSam ChenDate:  September 20, 2024 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  September 20, 2024 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) ACCT-TX01, ACCT-IRA1, ACCT-RIRA, ACCT-CASH, ACCT-529A, ACCT-529B | Date Approved 2024-09-20 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-BeneficiaryAudit-2024-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
