| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2023-001  |  Review Period: January 1 – December 31, 2023  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 8, 2024 |
| --- | --- |

| Review Period | January 1 – December 31, 2023 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2023-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2023 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2023 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2020-001 |
| --- | --- |

| IPS Description | Continued — Conservative-Moderate (60/35/5) |
| --- | --- |

| Risk Questionnaire Score | 56/100 |
| --- | --- |

| Risk Profile | Conservative-Moderate (trending toward Moderate) |
| --- | --- |

| Target Allocation | 62% Equity / 33% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2020-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $1,140,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 AUM (DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $9,200 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $620,000 |
| IRA1 (Alex IRA) | $395,000 |
| RIRA (Sam Roth IRA) | $85,000 |
| CASH (Cash/Liquidity) | $25,000 |
| 529A (Alex Jr. — College) | $7,500 |
| 529B (Sam — College) | $7,500 |
| TOTAL HOUSEHOLD AUM | $1,140,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2023 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- EventID-2023-01: RSU vesting and partial sale — Alex Chen liquidity event

- RSU proceeds partially deposited to TX01; significantly boosted taxable account AUM

- DAF charitable bunching strategy implemented (DOC-DAF-2023-001)

- Net realized capital gains: approximately $87,000 (RSU sale + prior carry-forward offset)

- Strong market recovery year; AI/tech equity rally drove portfolio appreciation

- Annual suitability review: risk score improved 54 → 56; allocation rebalanced 62/33/5

- 529A and 529B contributions maintained; balances recovering with equity markets

- Estate planning review initiated following trust review with legal counsel

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. RSU proceeds deposited per client instruction. DAF strategy implemented at client direction. No third-party compensation received.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2023. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2023-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: RSU liquidity event (EventID-2023-01) represents largest single-year AUM increase in engagement history (+$250,000 net). Tax planning coordinated across TAX-2023-001 and TAX-2023-002.

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
