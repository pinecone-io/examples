| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2021-001  |  Review Period: January 1 – December 31, 2021  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 10, 2022 |
| --- | --- |

| Review Period | January 1 – December 31, 2021 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2021-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2021 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2021 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2020-001 |
| --- | --- |

| IPS Description | Continued — Conservative-Moderate (60/35/5) |
| --- | --- |

| Risk Questionnaire Score | 54/100 |
| --- | --- |

| Risk Profile | Conservative-Moderate |
| --- | --- |

| Target Allocation | 60% Equity / 35% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2020-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $952,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 AUM (effective Q3 2021 per DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $7,800 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $480,000 |
| IRA1 (Alex IRA) | $330,000 |
| RIRA (Sam Roth IRA) | $78,000 |
| CASH (Cash/Liquidity) | $50,000 |
| 529A (Alex Jr. — College) | $7,000 |
| 529B (Sam — College) | $7,000 |
| TOTAL HOUSEHOLD AUM | $952,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2021 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- EventID-2021-01: Home purchase — Alex & Sam Chen acquired primary residence

- DecisionID-2021-141: $185,000 down payment staging from TX01; executed July 10, 2021

- Fee schedule amended Q3 2021: DOC-FeeAmendment-2021-001 — tiered structure effective

- New fee: 0.85% on first $1.5M / 0.70% on next $1.5M / 0.55% above $3M

- Portfolio recovered strongly from 2020 levels; AUM grew $160,000 net of withdrawal

- Net realized capital gains: approximately $18,500 (DecisionID-2021-141 liquidation)

- 529A and 529B funded with initial contributions following home purchase settlement

- Annual suitability review: risk tolerance unchanged at 54/100

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. Fee amendment (DOC-FeeAmendment-2021-001) disclosed and executed with client consent. No third-party compensation received.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2021. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2021-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: Estimated annual fee of $7,800 reflects blended rate: 1.00% applied Q1–Q2 2021 (pre-amendment) and 0.85% applied Q3–Q4 2021 (post-amendment) on respective average AUM.

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
