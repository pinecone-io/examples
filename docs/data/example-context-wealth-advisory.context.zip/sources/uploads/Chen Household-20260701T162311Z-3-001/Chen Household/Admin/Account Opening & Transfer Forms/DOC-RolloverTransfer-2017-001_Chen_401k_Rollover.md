CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional Custodian (CUST-FI-001)

DIRECT ROLLOVER / IRA TRANSFER REQUEST

Alex Chen | Prior Employer 401(k) → ACCT-401R (Rollover IRA at Fidelity Institutional)

| Document ID DOC-RolloverTransfer-2017-001 | Date August 15, 2017 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: Alex Chen separated from prior employer; employer-sponsored 401(k) plan is eligible for direct rollover to IRA. New employment (Clearwater Technology, Inc.) commences 2017-Q3; equity compensation (RSUs) to begin under EventID-2018-01 (anticipated 2018-Q1). ACCT-401R (Rollover IRA) to be consolidated into ACCT-IRA1 by 2018-03-31 per Adviser’s tax planning recommendation.

SECTION A — TRANSFER TYPE

☒ Direct Rollover (401k/403b/457 → IRA) ☐ Trustee-to-Trustee Transfer (IRA → IRA) ☐ 60-Day Indirect Rollover ☐ In-Kind Transfer

Direct Rollover selected: Funds will be payable to Fidelity Institutional (CUST-FI-001) FBO Alex Chen IRA, avoiding any withholding obligation. No 20% mandatory withholding applies.

SECTION B — ACCOUNT HOLDER / PARTICIPANT INFORMATION

| Participant Name: | Alex Chen |
| --- | --- |

| Date of Birth: | March 22, 1981 |
| --- | --- |

| SSN / Tax ID: | XXX-XX-4444  (on file with custodian) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Phone: | (612) 555-0278 |
| --- | --- |

| Email: | alex.chen@exampledemo.com |
| --- | --- |

| Former Employer: | Prior Employer (synthetic — on file with plan administrator) |
| --- | --- |

| Plan Name: | Prior Employer 401(k) Plan (synthetic placeholder) |
| --- | --- |

| Separation Date: | August 2017  (eligible for rollover upon separation) |
| --- | --- |

SECTION C — DISTRIBUTING PLAN / INSTITUTION

| Plan Administrator: | Prior Employer Plan Administrator (synthetic) |
| --- | --- |

| Plan Type: | ☒ 401(k)   ☐ 403(b)   ☐ 457(b)   ☐ Profit Sharing   ☐ Other |
| --- | --- |

| Account Balance: | Approx. $62,000 — $68,000  (final balance as of transfer date) |
| --- | --- |

| Transfer Amount: | ☒ Full Account Balance   ☐ Partial: $___________ |
| --- | --- |

| Transfer Method: | ☒ Check payable to:  Fidelity Institutional FBO Alex Chen IRA   ☐ Wire |
| --- | --- |

| Investment Options: | Liquidate all existing plan positions prior to transfer |
| --- | --- |

| Outstanding Loans: | ☒ None   ☐ Loan balance: $__________ (must be repaid or treated as distribution) |
| --- | --- |

| After-tax Basis: | ☒ No after-tax contributions   ☐ After-tax basis: $____________ |
| --- | --- |

SECTION D — RECEIVING ACCOUNT (ACCT-401R)

| Receiving Account: | ACCT-401R — Rollover IRA  (Alex Chen, Individual) |
| --- | --- |

| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| --- | --- |

| Account Type: | Traditional IRA / Rollover IRA  (Tax-Deferred) |
| --- | --- |

| Advisory Authority: | Morgan Park, CFP® / Clearwater Wealth Partners  (ADV-PARK-001) |
| --- | --- |

| Investment Upon Receipt: | Assets to be invested per DOC-IPS-2016-001  (70/28/2 allocation; IRA sleeve: Fixed Income + TIPS) |
| --- | --- |

| Consolidation Plan: | ACCT-401R to be merged into ACCT-IRA1 by 2018-03-31 per tax planning recommendation |
| --- | --- |

SECTION E — TAX WITHHOLDING ELECTION

☒ Direct Rollover — no withholding applies (selected) ☐ Elect 10% Federal Withholding ☐ Elect additional withholding: ____%

Direct rollover to an IRA is not a taxable event. No 1099-R income required for rollover amount. Form 1099-R will be issued to the participant reflecting rollover code; no income tax liability created. Adviser (Clearwater Wealth Partners) has reviewed this election.

SECTION F — ADVISER ACKNOWLEDGEMENT & PLANNING NOTES

Adviser notes: Upon receipt of rollover assets into ACCT-401R, Adviser will allocate funds consistent with IPS-2016 (DOC-IPS-2016-001) Fixed Income / TIPS sleeve for IRA accounts. Consolidation of ACCT-401R into ACCT-IRA1 is planned by 2018-03-31 to simplify account structure. Alex’s equity compensation (RSUs) will begin under new employer per EventID-2018-01; this is expected to require IPS review and concentration monitoring in 2018-Q1. Advisory fee on ACCT-401R is covered under the existing 1.00% flat fee arrangement (DOC-AdvisoryAgreement-2016-001).

SECTION G — SIGNATURES

| ____________________________________Participant / Account HolderAlex ChenDate:  August 15, 2017 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  August 15, 2017 |
| --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) Established ACCT-401R | Date Approved 2017-08-15 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-RolloverTransfer-2017-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
