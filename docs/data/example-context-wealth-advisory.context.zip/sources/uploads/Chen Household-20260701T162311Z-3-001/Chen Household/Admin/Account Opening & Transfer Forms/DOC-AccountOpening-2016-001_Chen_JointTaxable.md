CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional Custodian (CUST-FI-001)

NEW ACCOUNT APPLICATION — TAXABLE BROKERAGE

Joint Tenants With Rights of Survivorship (JTWROS) | ACCT-TX01

| Document ID DOC-AccountOpening-2016-001 | Date February 1, 2016 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: New advisory relationship — DOC-AdvisoryAgreement-2016-001 (eff. 2016-02-01) executed concurrent with this account opening. Initial AUM contribution: $410,000 (household aggregate, 2016 inception).

SECTION A — ACCOUNT TYPE AND REGISTRATION

☐ Individual ☒ Joint JTWROS ☐ Joint TBE ☐ Joint Community Property ☐ TOD (Transfer on Death) ☐ Trust ☐ Entity

SECTION B — PRIMARY ACCOUNT HOLDER

| Full Legal Name: | Alex Chen |
| --- | --- |

| Date of Birth: | March 22, 1981 |
| --- | --- |

| SSN / Tax ID: | XXX-XX-4444  (on file with custodian) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Phone: | (612) 555-0278 |
| --- | --- |

| Email: | alex.chen@exampledemo.com |
| --- | --- |

| Employment Status: | Employed — Software Product Leader (W-2 + Equity Comp) |
| --- | --- |

| Employer: | Clearwater Technology, Inc.  (synthetic) |
| --- | --- |

| Citizenship: | U.S. Citizen |
| --- | --- |

| FINRA / Affiliated: | ☐ Yes   ☒ No |
| --- | --- |

SECTION C — JOINT ACCOUNT HOLDER

| Full Legal Name: | Sam Chen |
| --- | --- |

| Date of Birth: | November 2, 1984 |
| --- | --- |

| SSN / Tax ID: | XXX-XX-8888  (on file with custodian) |
| --- | --- |

| Relationship: | Spouse |
| --- | --- |

| Employment Status: | Employed — Marketing Director (W-2) |
| --- | --- |

| Email: | sam.chen@exampledemo.com |
| --- | --- |

SECTION D — INVESTMENT PROFILE & SUITABILITY

| Investment Objective: | Growth with Income |
| --- | --- |

| Risk Tolerance: | Moderate Growth  (DOC-RiskQuestionnaire-2016-001, score 68/100) |
| --- | --- |

| Time Horizon: | Long-term (20+ years to target retirement ~age 60) |
| --- | --- |

| Annual Income (HH): | $195,000 — $240,000 (combined W-2) |
| --- | --- |

| Net Worth (approx.): | $600,000 — $800,000 (incl. real estate, retirement) |
| --- | --- |

| Liquid Net Worth: | $380,000 — $430,000 |
| --- | --- |

| Tax Bracket: | 24% Federal (Married Filing Jointly) |
| --- | --- |

| IPS Reference: | DOC-IPS-2016-001  |  70% Equity / 28% Fixed / 2% Cash |
| --- | --- |

| Advisory Agreement: | DOC-AdvisoryAgreement-2016-001  |  1.00% annual flat fee |
| --- | --- |

SECTION E — INITIAL FUNDING

| Funding Method: | ☒ Wire Transfer   ☐ Check   ☐ ACAT Transfer   ☐ ACH |
| --- | --- |

| Initial Deposit: | $245,000  (wire from prior institution; see attached wire instructions) |
| --- | --- |

| Additional Funding: | Ongoing contributions anticipated per GoalID-2016-01 (retirement) and GoalID-2016-03 (liquidity) |
| --- | --- |

| Dividend Reinvestment: | ☒ Reinvest   ☐ Pay to Cash |
| --- | --- |

| Margin Authorization: | ☐ Margin Requested   ☒ Cash Account Only |
| --- | --- |

SECTION F — BENEFICIARY DESIGNATIONS

| Primary Beneficiary: | Sam Chen  (Spouse)  — 100% |
| --- | --- |

| Contingent Beneficiary: | Maya Chen (DOB 2011-08-19) — 50%  |  Eli Chen (DOB 2014-03-07) — 50% |
| --- | --- |

| Trust Override: | ☐ Beneficiary subject to trust provisions  ☒ Direct designation |
| --- | --- |

NOTE: Beneficiary designations to be reviewed upon creation of revocable trust (EventID-2019-01, anticipated 2019). Custodian must be notified of any trust formation.

SECTION G — SIGNATURES

| ____________________________________Primary Account HolderAlex ChenDate:  February 1, 2016 | ____________________________________Joint Account HolderSam ChenDate:  February 1, 2016 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth PartnersDate:  February 1, 2016 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) Established ACCT-TX01 | Date Approved 2016-02-01 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-AccountOpening-2016-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
