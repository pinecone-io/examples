| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2026-001  |  Review Period: January 1 – March 9, 2026 (Q1 Interim Review)  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | March 9, 2026 |
| --- | --- |

| Review Period | January 1 – March 9, 2026 (Q1 Interim Review) |
| --- | --- |

| Document ID | DOC-ComplianceAck-2026-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2026 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2026 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2025-001 |
| --- | --- |

| IPS Description | Continued — Moderate / Bucket Strategy (62/33/5) |
| --- | --- |

| Risk Questionnaire Score | 58/100 |
| --- | --- |

| Risk Profile | Moderate (bucket strategy preference) |
| --- | --- |

| Target Allocation | 61% Equity / 34% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2025-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $1,650,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 / 0.70% on next $1,500,000 AUM (DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $13,275 |
| --- | --- |

| AUM Note | Q4 2026 projection; Q1 2026 AUM as of review date approximately $1,520,000 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $850,000 |
| IRA1 (Alex IRA) | $555,000 |
| RIRA (Sam Roth IRA) | $120,000 |
| CASH (Cash/Liquidity) | $35,000 |
| 529A (Alex Jr. — College) | $45,000 |
| 529B (Sam — College) | $45,000 |
| TOTAL HOUSEHOLD AUM | $1,650,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – MARCH 9, 2026 (Q1 INTERIM REVIEW) |
| --- |

The following material changes, events, and decisions occurred during the review period:

- EventID-2026-01: Fee discrepancy identified — Q3 2022 billed at 1.00% vs. 0.85% effective rate

- Overcharge amount: approximately $1,100 (under investigation; remediation in process)

- TaskID-2026-CR-001: Compliance review initiated; client notified February 2026

- TaskID-2026-CR-002: Credit memo to be issued upon completion of internal audit

- RMD planning initiated for Alex Chen (approaching RMD age thresholds by 2029)

- TAX-2026-001 issued: Annual review, RMD planning, and portfolio rebalancing strategy

- TAX-2026-002 issued: Portfolio rebalancing and capital gains harvesting

- Annual suitability review: risk tolerance confirmed at 58/100; no IPS amendment required

- Household AUM crossed $1.5M threshold — second fee tier (0.70%) now partially applicable

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

** MATERIAL CONFLICT DISCLOSURE — SEE BELOW **

MATERIAL DISCLOSURE — EventID-2026-01: A fee billing discrepancy was identified in Q3 2022 statements. Clearwater Wealth Partners billed at 1.00% flat rate for that quarter rather than the amended 0.85% tiered rate (per DOC-FeeAmendment-2021-001, effective Q3 2021). Estimated client overcharge: approximately $1,100. A full internal audit is in progress (TaskID-2026-CR-001). Client will receive a credit memo upon completion (TaskID-2026-CR-002). We sincerely apologize for this error.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – March 9, 2026 (Q1 Interim Review). The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2026-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: 2026 year-end AUM of $1,650,000 is a projected figure per financial plan. Actual Q1 2026 AUM as of review date is approximately $1,520,000. Fee estimate of $13,275 based on projected year-end AUM applying tiered schedule: 0.85% x $1,500,000 = $12,750 + 0.70% x $150,000 = $1,050 - fee overcharge credit ~$1,100 pending. TCJA sunset provisions now in effect (post-December 31, 2025).

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
