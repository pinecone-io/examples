| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2022-001  |  Review Period: January 1 – December 31, 2022  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 9, 2023 |
| --- | --- |

| Review Period | January 1 – December 31, 2022 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2022-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2022 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2022 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2020-001 |
| --- | --- |

| IPS Description | Continued — Conservative-Moderate (60/35/5) |
| --- | --- |

| Risk Questionnaire Score | 54/100 |
| --- | --- |

| Risk Profile | Conservative-Moderate |
| --- | --- |

| Target Allocation | 58% Equity / 37% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2020-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $890,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 AUM (DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $7,900 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $450,000 |
| IRA1 (Alex IRA) | $325,000 |
| RIRA (Sam Roth IRA) | $73,000 |
| CASH (Cash/Liquidity) | $31,000 |
| 529A (Alex Jr. — College) | $5,500 |
| 529B (Sam — College) | $5,500 |
| TOTAL HOUSEHOLD AUM | $890,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2022 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- Bear market year: S&P 500 -18.1%; fixed income also declined amid Fed rate hikes

- EventID-2022-01: Tax-loss harvesting campaign executed September 2022

- DecisionID-2022-301: Systematic TLH campaign, window Sept 5–30, 2022

- Net capital losses realized: approximately -$31,000 (available for carryforward)

- Roth conversion opportunity evaluated; partial conversion executed in IRA1

- Annual suitability review: risk score 54/100 maintained; allocation drifted 58/37/5

- RSU equity compensation planning memos issued (EventID-2022-01 cross-reference)

- 529A and 529B modestly declined with equity markets; contributions continued

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. TLH campaign (DecisionID-2022-301) executed consistent with IPS objectives and client instruction. No third-party compensation received.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2022. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2022-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: Net capital loss carryforward of ~$31,000 from 2022 TLH campaign available to offset future gains. See TAX-2022-001 for full tax planning analysis. AUM decline reflects market conditions, not withdrawals.

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
