CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional Custodian (CUST-FI-001)

529 EDUCATION SAVINGS ACCOUNT — NEW ACCOUNT APPLICATION

ACCT-529A (Maya Chen) + ACCT-529B (Eli Chen) | Minnesota 529 / Fidelity Institutional

| Document ID DOC-AccountOpening-2020-001 | Date May 1, 2020 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: EventID-2020-01 — COVID-19 market volatility prompted comprehensive financial planning review (IPS amendment DOC-IPSAmendment-2020-001 executed 2020-06-15). During review, education funding for Maya (DOB 2011, ~age 9) and Eli (DOB 2014, ~age 6) was identified as a deferred priority under GoalID-2016-02. Both 529 accounts opened concurrently May 2020 to activate the education funding mandate.

SECTION A — ACCOUNT OWNER INFORMATION

| Account Owner: | Alex Chen and Sam Chen (co-owners, Household HH-CHEN-001) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Phone: | (612) 555-0278 |
| --- | --- |

| Email: | alex.chen@exampledemo.com  /  sam.chen@exampledemo.com |
| --- | --- |

| SSN (Primary): | XXX-XX-4444  (Alex Chen — on file) |
| --- | --- |

| Relationship to Beneficiary: | Parent / Guardian |
| --- | --- |

| Successor Owner: | Sam Chen  (in event of Alex’s incapacity or death) |
| --- | --- |

SECTION B — BENEFICIARY 1 — ACCT-529A

| Beneficiary Name: | Maya Chen |
| --- | --- |

| Date of Birth: | August 19, 2011  (Age: ~8 at account opening) |
| --- | --- |

| Relationship: | Child of Account Owners |
| --- | --- |

| SSN / Tax ID: | On file with custodian |
| --- | --- |

| Anticipated Use: | Undergraduate college education; target enrollment ~2029 |
| --- | --- |

| Initial Contribution: | $5,000  (wire from ACCT-TX01 / household savings) |
| --- | --- |

| Investment Option: | ☒ Age-Based Moderate Index Portfolio (529-AGE-MOD)   ☐ Custom allocation |
| --- | --- |

SECTION C — BENEFICIARY 2 — ACCT-529B

| Beneficiary Name: | Eli Chen |
| --- | --- |

| Date of Birth: | March 7, 2014  (Age: ~6 at account opening) |
| --- | --- |

| Relationship: | Child of Account Owners |
| --- | --- |

| SSN / Tax ID: | On file with custodian |
| --- | --- |

| Anticipated Use: | Undergraduate college education; target enrollment ~2032 |
| --- | --- |

| Initial Contribution: | $5,000  (wire from ACCT-TX01 / household savings) |
| --- | --- |

| Investment Option: | ☒ Age-Based Moderate Index Portfolio (529-AGE-MOD)   ☐ Custom allocation |
| --- | --- |

SECTION D — CONTRIBUTION PLAN

| Annual Contribution Target: | TBD per cash flow analysis; annual review in Q4 strategy meeting (GoalID-2016-02) |
| --- | --- |

| Funding Source: | ☒ From ACCT-TX01 (taxable brokerage)   ☒ Periodic ACH from household checking   ☐ Gift contributions |
| --- | --- |

| Gift Tax Exclusion: | ☐ 5-Year Election ($75,000 lump sum per beneficiary)   ☒ Annual exclusion ($15,000/person for 2020) |
| --- | --- |

| Superfunding Note: | Superfunding election not exercised at opening; to be revisited if liquidity event occurs |
| --- | --- |

| MN State Deduction: | Account owners eligible for MN state income tax deduction on contributions (consult Lisa Torres, EA) |
| --- | --- |

SECTION E — INVESTMENT DETAILS

Both accounts utilize 529-AGE-MOD (Age-Based Moderate Index Portfolio), automatically shifting to more conservative allocations as each beneficiary approaches college age. Adviser will review allocation and contribution targets annually per GoalID-2016-02 and in connection with the household IPS review process.

| 529-AGE-MOD (2020): | ~75% Equity / 20% Fixed / 5% Cash  (Maya, ~8 yrs to college) |
| --- | --- |

| 529-AGE-MOD (2020): | ~80% Equity / 15% Fixed / 5% Cash  (Eli, ~12 yrs to college) |
| --- | --- |

| Advisory Coverage: | Both 529 accounts covered under DOC-AdvisoryAgreement-2016-001 advisory mandate; formally included in fee base per DOC-FeeAmendment-2021-001 (eff. 2021-07-01) |
| --- | --- |

SECTION F — IPS AND EVENT-DRIVEN NOTES

These accounts are opened during the COVID-19 market environment. Household IPS amendment (DOC-IPSAmendment-2020-001) is pending execution to shift aggregate allocation to 60% Equity / 35% Fixed / 5% Cash in response to EventID-2020-01. The 529 accounts are excluded from the IPS allocation calculation as education-specific vehicles but are tracked in household AUM. Adviser to review 529 balances and age-based glide paths at each annual strategy meeting.

SECTION G — SIGNATURES

| ____________________________________Account Owner (Primary)Alex ChenDate:  May 1, 2020 | ____________________________________Account Owner (Co-Owner)Sam ChenDate:  May 1, 2020 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  May 1, 2020 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) Established ACCT-529A, ACCT-529B | Date Approved 2020-05-01 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-AccountOpening-2020-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
