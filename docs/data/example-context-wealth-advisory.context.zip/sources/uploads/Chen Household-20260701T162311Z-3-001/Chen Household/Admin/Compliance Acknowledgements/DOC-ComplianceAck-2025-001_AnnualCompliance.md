| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2025-001  |  Review Period: January 1 – December 31, 2025  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 12, 2026 |
| --- | --- |

| Review Period | January 1 – December 31, 2025 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2025-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2025 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2025 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2025-001 |
| --- | --- |

| IPS Description | Amended IPS — Moderate / Bucket Strategy (62/33/5) executed January 2025 |
| --- | --- |

| Risk Questionnaire Score | 58/100 |
| --- | --- |

| Risk Profile | Moderate (bucket strategy preference) |
| --- | --- |

| Target Allocation | 62% Equity / 33% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2025-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $1,450,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 AUM (DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $12,000 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $760,000 |
| IRA1 (Alex IRA) | $490,000 |
| RIRA (Sam Roth IRA) | $105,000 |
| CASH (Cash/Liquidity) | $45,000 |
| 529A (Alex Jr. — College) | $22,500 |
| 529B (Sam — College) | $22,500 |
| TOTAL HOUSEHOLD AUM | $1,445,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2025 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- DOC-IPSAmendment-2025-001: IPS amended to incorporate three-bucket retirement strategy

- Bucket 1 (Liquidity): 2–3 years expenses in CASH/short-term; Bucket 2 (Income); Bucket 3 (Growth)

- Risk questionnaire re-administered: score improved 56 → 58; profile updated to Moderate

- Roth conversion ladder strategy implemented (TAX-2025-001) — multi-year TCJA sunset planning

- TCJA provisions scheduled to sunset December 31, 2025; accelerated planning executed

- Alex Chen approaching pre-retirement phase; Social Security optimization modeling initiated

- 529A and 529B on track for projected education costs; equity allocation maintained

- EventID-2025-01: Bucket strategy implementation — formal annual review and IPS amendment

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. Bucket strategy implementation reflects client retirement planning objectives. No third-party compensation received. Form CRS updated to reflect revised fee structure applicability thresholds.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2025. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2025-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: Fee of $12,000 represents 0.85% on average AUM of approximately $1,368,000. TCJA sunset (December 31, 2025) drove accelerated Roth conversion and charitable strategies — see TAX-2025-001 and TAX-2025-002.

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
