CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional (CUST-FI-001)

BENEFICIARY DESIGNATION UPDATE — TRUST ALIGNMENT

ACCT-TX01 | ACCT-IRA1 — Post-Trust Formation Update (EventID-2019-01)

| Document ID DOC-BeneficiaryUpdate-2019-001 | Date March 15, 2019 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: EventID-2019-01 — Alex and Sam Chen established a revocable living trust (the “Chen Family Revocable Trust”) with estate attorney Westfield & Baker LLP in early 2019. Estate refresh required beneficiary designation review on all Covered Accounts. This form updates ACCT-TX01 and ACCT-IRA1 to align with the new trust structure.

⚠ SCOPE OF THIS FORM: This update covers ACCT-TX01 (Joint Taxable) and ACCT-IRA1 (Alex Traditional IRA) only. ACCT-RIRA (Alex Roth IRA) beneficiary review was deferred pending receipt of final trust certification documents. A separate update for ACCT-RIRA is to be completed upon receipt. See Adviser’s open action item log (ActionID-2019Q1-003).

SECTION A — ACCOUNT HOLDER & TRUST INFORMATION

| Account Holders: | Alex Chen  &  Sam Chen  (HH-CHEN-001) |
| --- | --- |

| Trust Name: | Chen Family Revocable Trust  (established March 2019) |
| --- | --- |

| Trust Date: | March 2019  (exact execution date on file with Westfield & Baker LLP) |
| --- | --- |

| Trustees: | Alex Chen and Sam Chen, Co-Trustees  (successor trustee: TBD per trust doc) |
| --- | --- |

| Trust Tax ID: | Alex Chen SSN used during grantor trust lifetime (revocable grantor trust) |
| --- | --- |

| Estate Attorney: | Westfield & Baker LLP  (estate specialist: Logan Hart, JD) |
| --- | --- |

| Accounts Updated: | ACCT-TX01, ACCT-IRA1  (ACCT-RIRA deferred — see note above) |
| --- | --- |

| Accounts Deferred: | ACCT-RIRA — pending trust certification  (action item: ActionID-2019Q1-003) |
| --- | --- |

SECTION B — PRIOR DESIGNATIONS (SUPERSEDED — ACCT-TX01 & ACCT-IRA1)

The following designations established under DOC-BeneficiaryDesig-2016-001 are superseded for ACCT-TX01 and ACCT-IRA1 only by the new designations in Section C:

| Account | Acct ID | Type | Beneficiary Name | Relationship | DOB | Share % | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Taxable Brokerage | ACCT-TX01 | Primary (OLD) | Sam Chen | Spouse | 1984-11-02 | 100% | SUPERSEDED |
| Taxable Brokerage | ACCT-TX01 | Contingent (OLD) | Maya & Eli Chen | Children | See orig. | 50/50 | SUPERSEDED |
| Alex Trad. IRA | ACCT-IRA1 | Primary (OLD) | Sam Chen | Spouse | 1984-11-02 | 100% | SUPERSEDED |
| Alex Trad. IRA | ACCT-IRA1 | Contingent (OLD) | Maya & Eli Chen | Children | See orig. | 50/50 | SUPERSEDED |

SECTION C — UPDATED BENEFICIARY DESIGNATIONS

Updated designations effective March 15, 2019 reflecting trust formation. ACCT-TX01 titling remains JTWROS; trust named as contingent to ensure assets flow through trust plan upon death of surviving spouse. ACCT-IRA1: IRA beneficiary rules require individual / eligible designated beneficiary; Sam Chen retained as primary (spousal rollover rights preserved); trust named as contingent to coordinate with overall estate plan.

| Account | Acct ID | Type | Beneficiary Name | Relationship | DOB | Share % | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Taxable Brokerage | ACCT-TX01 | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | Spousal survivorship; JTWROS |
| Taxable Brokerage | ACCT-TX01 | Contingent | Chen Family Revocable Trust | Trust (Grantors: J. & C. Chen) | Est. Mar 2019 | 100% | Trust EIN = Alex SSN (grantor) |
| Alex Trad. IRA | ACCT-IRA1 | Primary | Sam Chen | Spouse (EDB) | 1984-11-02 | 100% | Eligible Designated Beneficiary — spousal rollover rights |
| Alex Trad. IRA | ACCT-IRA1 | Contingent | Chen Family Revocable Trust | Trust | Est. Mar 2019 | 100% | See-through trust analysis req’d; coordinate w/ Logan Hart JD |

SECTION D — ACCT-RIRA STATUS (DEFERRED)

⚠ ACCT-RIRA (Alex Roth IRA) — BENEFICIARY UPDATE DEFERRED: The beneficiary designation for ACCT-RIRA established under DOC-BeneficiaryDesig-2016-001 (Sam Chen, Primary 100%; Maya & Eli Chen, Contingent 50/50, per stirpes) REMAINS IN EFFECT as of this date. The Roth IRA update was deferred pending final trust certification and Adviser’s review of see-through trust qualification for Roth IRA purposes. Open action item: ActionID-2019Q1-003. TARGET COMPLETION: 2019-Q2. NOTE: If this action item is not completed, the ACCT-RIRA designation will not reflect the trust structure and will be inconsistent with ACCT-TX01 and ACCT-IRA1.

SECTION E — ADVISER PLANNING NOTES

Adviser (Morgan Park, CFP®) notes: Trust formation (EventID-2019-01) is a key milestone in the Chen household estate plan. The revocable trust will serve as the central vehicle for asset distribution outside of IRAs. Coordination with Logan Hart, JD (estate specialist) and Westfield & Baker LLP is ongoing. The following actions remain open: (1) ACCT-RIRA beneficiary update (ActionID-2019Q1-003 — target Q2 2019); (2) confirm trustee succession provisions align with custodian requirements; (3) review titling of non-IRA assets. Annual review of all beneficiary designations will be incorporated into the Q4 strategy meeting agenda going forward.

SECTION F — SIGNATURES

| ____________________________________Primary Account HolderAlex ChenDate:  March 15, 2019 | ____________________________________Co-Account HolderSam ChenDate:  March 15, 2019 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  March 15, 2019 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) ACCT-TX01, ACCT-IRA1 | Date Approved 2019-03-15 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-BeneficiaryUpdate-2019-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
