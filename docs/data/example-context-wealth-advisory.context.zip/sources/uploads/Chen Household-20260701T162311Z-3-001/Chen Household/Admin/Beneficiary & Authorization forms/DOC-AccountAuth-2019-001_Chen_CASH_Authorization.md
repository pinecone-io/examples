CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional (CUST-FI-001)

NEW ACCOUNT AUTHORIZATION & BENEFICIARY DESIGNATION

ACCT-CASH — Cash Management / High-Yield Savings Account | Opened January 1, 2019

| Document ID DOC-AccountAuth-2019-001 | Date January 1, 2019 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: GoalID-2016-03 (Emergency Liquidity, 6–9 months expenses) identified that household emergency reserves were commingled with investable assets in ACCT-TX01. Adviser recommended a dedicated Cash Management Account (CMA/HYSA) to segregate emergency and near-term liquidity funds. Opened concurrently with 2019 estate planning review (EventID-2019-01, trust formation in progress). Account will also serve as staging for home purchase down payment (EventID-2021-01 anticipated).

SECTION A — ACCOUNT TYPE & AUTHORIZATION

| Account Type: | ☒ Cash Management Account (CMA)   ☒ High-Yield Savings (HYSA)   ☐ Money Market |
| --- | --- |

| Account ID: | ACCT-CASH |
| --- | --- |

| Registration: | Joint Tenants with Rights of Survivorship (JTWROS) |
| --- | --- |

| Account Owners: | Alex Chen  &  Sam Chen  (HH-CHEN-001) |
| --- | --- |

| Custodian: | Fidelity Institutional  (CUST-FI-001) |
| --- | --- |

| Opened: | January 1, 2019 |
| --- | --- |

| Advisory Authority: | Morgan Park, CFP®  /  Clearwater Wealth Partners  (ADV-PARK-001) |
| --- | --- |

| Advisory Coverage: | Included in advisory fee base under DOC-AdvisoryAgreement-2016-001 (1.00% flat); formally enumerated in DOC-FeeAmendment-2021-001 (eff. 2021-07-01) |
| --- | --- |

| FDIC / SIPC: | ☒ SIPC coverage applies (brokerage CMA)   ☐ FDIC insured (bank sweep) |
| --- | --- |

SECTION B — ACCOUNT PURPOSE & FUNDING PLAN

| Primary Purpose: | Emergency liquidity reserve — target balance: 6–9 months household expenses (~$60,000–$90,000) |
| --- | --- |

| Secondary Purpose: | Near-term liquidity staging (home purchase down payment anticipated 2021-Q3, EventID-2021-01) |
| --- | --- |

| Tertiary Purpose: | Pre-retirement Bucket 1 staging (anticipated 2025-Q1 per IPS-2025 bucket strategy) |
| --- | --- |

| Initial Deposit: | $37,000 — transferred from ACCT-TX01 money market sleeve |
| --- | --- |

| Target Balance: | $60,000–$90,000 (emergency fund); up to $130,000 pre-home-close (2021-Q2) |
| --- | --- |

| Investment Vehicle: | STBIX (Short-Term Bond / Cash Equivalent) and/or FDIC-insured sweep — per IPS-2016 cash sleeve |
| --- | --- |

| IPS Reference: | DOC-IPS-2016-001  |  2% Cash sleeve allocation; this account fulfills GoalID-2016-03 |
| --- | --- |

SECTION C — AUTHORIZED SIGNERS & TRADING AUTHORITY

| Authorized Signers: | Alex Chen (Primary)  |  Sam Chen (Co-Signer) |
| --- | --- |

| Adviser Authority: | ☒ Full discretionary trading authority granted to Clearwater Wealth Partners (ADV-PARK-001) |
| --- | --- |

| Wire Authorization: | ☒ Both account holders required for outbound wires > $25,000   ☒ Either signer for amounts ≤ $25,000 |
| --- | --- |

| Online Access: | ☒ Both account holders granted full online access via Fidelity Institutional portal |
| --- | --- |

| Statements: | ☒ Electronic delivery preferred   ☐ Paper statements   ☐ Both |
| --- | --- |

SECTION D — BENEFICIARY DESIGNATION

Beneficiary designations for ACCT-CASH are set concurrently with account opening. Note: Chen Family Revocable Trust is being formed in early 2019 (EventID-2019-01); contingent beneficiary will be updated to the trust once trust certification is finalized per DOC-BeneficiaryUpdate-2019-001.

| Account | Acct ID | Type | Beneficiary Name | Relationship | DOB | Share % | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- |
| Cash Mgmt | ACCT-CASH | Primary | Sam Chen | Spouse | 1984-11-02 | 100% | JTWROS — survivor takes all |
| Cash Mgmt | ACCT-CASH | Contingent | Maya Chen | Child | 2011-08-19 | 50% | Per stirpes; to be updated to trust 2019-Q2 |
| Cash Mgmt | ACCT-CASH | Contingent | Eli Chen | Child | 2014-03-07 | 50% | Per stirpes; to be updated to trust 2019-Q2 |

⚠ PENDING ACTION: Contingent beneficiary for ACCT-CASH to be updated to Chen Family Revocable Trust once trust is finalized (EventID-2019-01, target Q2 2019). See ActionID-2019Q1-003 and DOC-BeneficiaryUpdate-2019-001.

SECTION E — LINKED GOALS & PLANNING NOTES

GoalID-2016-03 (Emergency Liquidity): This account directly fulfills the household’s 6–9 month emergency fund requirement. Adviser will monitor balance quarterly against the target range and rebalance from ACCT-TX01 if balance falls below threshold. GoalID-2016-01 (Retirement): Separation of emergency funds from ACCT-TX01 reduces the risk of forced liquidation of long-term investments during a financial emergency. EventID-2021-01 (Home Purchase): Balance is expected to increase significantly in 2021-Q2 ($55,000–$65,000 staging) ahead of home purchase closing. IPS-2025 (Bucket Strategy): ACCT-CASH will be integrated into Bucket 1 (0–24 month liquidity) under the anticipated 2025 bucket framework.

SECTION F — SIGNATURES

| ____________________________________Primary Account HolderAlex ChenDate:  January 1, 2019 | ____________________________________Joint Account HolderSam ChenDate:  January 1, 2019 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth Partners  |  ADV-PARK-001Date:  January 1, 2019 |
| --- | --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) ACCT-CASH | Date Approved 2019-01-01 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-AccountAuth-2019-001 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
