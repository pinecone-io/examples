| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2024-001  |  Review Period: January 1 – December 31, 2024  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 13, 2025 |
| --- | --- |

| Review Period | January 1 – December 31, 2024 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2024-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2024 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Form CRS — March 2024 Edition

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPSAmendment-2020-001 |
| --- | --- |

| IPS Description | Continued — Conservative-Moderate (60/35/5) |
| --- | --- |

| Risk Questionnaire Score | 56/100 |
| --- | --- |

| Risk Profile | Conservative-Moderate |
| --- | --- |

| Target Allocation | 62% Equity / 33% Fixed Income / 5% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPSAmendment-2020-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $1,285,000 |
| --- | --- |

| Fee Schedule | Tiered: 0.85% on first $1,500,000 AUM (DOC-FeeAmendment-2021-001) |
| --- | --- |

| Estimated Annual Advisory Fee | $10,600 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $700,000 |
| IRA1 (Alex IRA) | $430,000 |
| RIRA (Sam Roth IRA) | $95,000 |
| CASH (Cash/Liquidity) | $25,000 |
| 529A (Alex Jr. — College) | $17,500 |
| 529B (Sam — College) | $17,500 |
| TOTAL HOUSEHOLD AUM | $1,285,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2024 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- EventID-2024-01: Family health event — Sam Chen serious medical diagnosis

- Estate planning accelerated: beneficiary designations reviewed and updated across all accounts

- Emergency liquidity review conducted; CASH account maintained at $25,000 minimum

- IPS review initiated mid-year given health event; no amendment executed pending 2025 review

- 529A and 529B contributions significantly increased given educational timeline

- Annual suitability review: risk score maintained at 56; allocation unchanged at 62/33/5

- TAX-2024-001 issued: family health event, medical expenses, and estate tax planning

- Equity markets continued strong performance; household crossed $1.25M AUM threshold

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. Estate planning coordination involved external legal counsel retained directly by clients. Adviser role limited to financial/beneficiary review. No third-party compensation received.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2024. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2024-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: Health event (EventID-2024-01) triggered accelerated beneficiary review. Per client instruction, Sam Chen designated primary beneficiary on all retirement accounts. HIPAA authorizations are client-held documents not part of this file.

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
