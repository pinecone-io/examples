CLEARWATER WEALTH PARTNERS

200 Prairie Lake Drive, Suite 300 · Wayzata, MN 55391 · (612) 555-0100 · Fidelity Institutional Custodian (CUST-FI-001)

NEW IRA ACCOUNT APPLICATION — TRADITIONAL IRA & ROTH IRA

Alex Chen | ACCT-IRA1 (Traditional IRA) + ACCT-RIRA (Roth IRA)

| Document ID DOC-AccountOpening-2016-002 | Date February 1, 2016 | Household HH-CHEN-001 | Adviser ADV-PARK-001 |
| --- | --- | --- | --- |

► TRIGGERING EVENT: Initial advisory engagement (DOC-AdvisoryAgreement-2016-001). Two IRA accounts established concurrently to support retirement goal GoalID-2016-01. ACCT-IRA1 designated to receive direct rollover of prior employer 401(k) in 2017 (ACCT-401R rollover anticipated Q3 2017).

SECTION A — ACCOUNT TYPE SELECTION

Both account types below are being established simultaneously for the same account holder. Each will receive a separate account number at the custodian.

| Account Type | Account ID | Tax Treatment | 2016 Contribution Limit |
| --- | --- | --- | --- |
| ☒ Traditional IRA | ACCT-IRA1 | Tax-Deferred (pre-tax growth) | $5,500 / $6,500 if 50+ |
| ☒ Roth IRA | ACCT-RIRA | Tax-Free (post-tax growth) | $5,500 / $6,500 if 50+  (income limits apply) |

SECTION B — ACCOUNT HOLDER INFORMATION

| Full Legal Name: | Alex Chen |
| --- | --- |

| Date of Birth: | March 22, 1981  (Age: 32 at account opening) |
| --- | --- |

| SSN / Tax ID: | XXX-XX-4444  (on file with custodian) |
| --- | --- |

| Address: | 3215 Lakeview Circle, Wayzata, MN 55391 |
| --- | --- |

| Phone: | (612) 555-0278 |
| --- | --- |

| Email: | alex.chen@exampledemo.com |
| --- | --- |

| Marital Status: | Married |
| --- | --- |

| Citizenship: | U.S. Citizen  |  U.S. Person for tax purposes |
| --- | --- |

| Roth Eligibility: | Modified AGI within Roth IRA income limits for 2016 (MFJ) |
| --- | --- |

SECTION C — INVESTMENT PROFILE

| Objective (IRA1): | Growth with Income — core bonds + TIPS + equity sleeve for rebalancing |
| --- | --- |

| Objective (RIRA): | Aggressive Growth — small cap + emerging markets tilt (long time horizon) |
| --- | --- |

| Risk Profile: | Moderate Growth (score 68/100 — DOC-RiskQuestionnaire-2016-001) |
| --- | --- |

| Time Horizon: | Long-term (25+ years); distributions expected ~age 60 |
| --- | --- |

| IPS Reference: | DOC-IPS-2016-001  |  IRA1: Fixed Income sleeve;  RIRA: Equity growth sleeve |
| --- | --- |

SECTION D — INITIAL FUNDING

| ACCT-IRA1 Initial Funding: | ☒ 2016 IRA Contribution: $5,500   ☒ Future Rollover: Prior employer 401(k) — anticipated 2017-Q3 (see DOC-RolloverTransfer-2017-001) |
| --- | --- |

| ACCT-RIRA Initial Funding: | ☒ 2016 Roth IRA Contribution: $5,500   ☐ Conversion   ☐ Rollover |
| --- | --- |

| Funding Source: | Personal checking account  (wire / ACH per attached instructions) |
| --- | --- |

| Annual Contrib Plan: | Maximum annual contributions anticipated each year subject to income and IRS limits |
| --- | --- |

SECTION E — BENEFICIARY DESIGNATIONS

Both ACCT-IRA1 and ACCT-RIRA designations below apply to each account individually:

| Account | Type | Beneficiary | Share |
| --- | --- | --- | --- |
| ACCT-IRA1 | Primary | Sam Chen (Spouse, DOB 1984-11-02) | 100% |
| ACCT-IRA1 | Contingent | Maya Chen (DOB 2011-08-19) + Eli Chen (DOB 2014-03-07) | 50% / 50% |
| ACCT-RIRA | Primary | Sam Chen (Spouse, DOB 1984-11-02) | 100% |
| ACCT-RIRA | Contingent | Maya Chen (DOB 2011-08-19) + Eli Chen (DOB 2014-03-07) | 50% / 50% |

NOTE: Beneficiary designations to be reviewed when revocable trust is established (EventID-2019-01, anticipated 2019) and again following any major life event. ACCT-IRA1 will receive direct rollover from prior employer 401(k) in 2017; a separate Rollover/Transfer form (DOC-RolloverTransfer-2017-001) will be completed at that time.

SECTION F — SIGNATURES & CERTIFICATIONS

I certify that the information provided is accurate, that I have read and understand the IRA disclosure statement, and that contributions do not exceed annual IRS limits. I authorize Clearwater Wealth Partners (ADV-PARK-001) to act as investment adviser for all IRA assets under DOC-AdvisoryAgreement-2016-001.

| ____________________________________IRA Account HolderAlex ChenDate:  February 1, 2016 | ____________________________________Adviser (IAR)Morgan Park, CFP®Clearwater Wealth PartnersDate:  February 1, 2016 |
| --- | --- |

FOR CUSTODIAN USE ONLY — Fidelity Institutional (CUST-FI-001)

| Account(s) Established ACCT-IRA1, ACCT-RIRA | Date Approved 2016-02-01 | Processing Rep NWP-OPS-001 | System ID FI-SYS-2024 |
| --- | --- | --- | --- |

SYNTHETIC DEMONSTRATION — NWP-DEMO-HH-CHEN-001 v1.2 • DOC-AccountOpening-2016-002 • NOT INVESTMENT/TAX/LEGAL ADVICE • Clearwater Wealth Partners • Minnetonka MN 55305
