| CLEARWATER WEALTH PARTNERSRegistered Investment Adviser  |  ADV-PARK-001 | ANNUAL COMPLIANCEACKNOWLEDGEMENT |
| --- | --- |

| DOC-ComplianceAck-2017-001  |  Review Period: January 1 – December 31, 2017  |  Adviser: Morgan Park, CFP(r) |
| --- |

| Client Household | Alex & Sam Chen  |  HH-CHEN-001 |
| --- | --- |

| Review Date | January 14, 2018 |
| --- | --- |

| Review Period | January 1 – December 31, 2017 |
| --- | --- |

| Document ID | DOC-ComplianceAck-2017-001 |
| --- | --- |

| Custodian | Fidelity Institutional  |  CUST-FI-001 |
| --- | --- |

| Adviser | Morgan Park, CFP(r)  |  ADV-PARK-001 |
| --- | --- |

| 1.  ANNUAL DISCLOSURE DELIVERY RECEIPT |
| --- |

The following disclosure documents were delivered to the client household for the above review period:

- Form ADV Part 2A/2B — March 2017 Edition

- Form ADV Part 2B — Brochure Supplement (Morgan Park, CFP(r))

- Privacy Policy and Notice (Reg S-P)

- Business Continuity Plan Summary

- Proxy Voting Policy Disclosure

| 2.  SUITABILITY & INVESTMENT PROFILE CONFIRMATION |
| --- |

| Active IPS Version | DOC-IPS-2016-001 |
| --- | --- |

| IPS Description | Continued — Moderate Growth (70/30) |
| --- | --- |

| Risk Questionnaire Score | 68/100 |
| --- | --- |

| Risk Profile | Moderate Growth |
| --- | --- |

| Target Allocation | 72% Equity / 26% Fixed Income / 2% Cash |
| --- | --- |

The suitability of the current investment strategy has been reviewed against the client's stated objectives, time horizon, liquidity needs, and risk tolerance. The adviser confirms that the investment programme described in the active IPS (DOC-IPS-2016-001) remains suitable for this household as of the review date.

| 3.  ACCOUNT OVERVIEW & FEE DISCLOSURE |
| --- |

| Year-End Household AUM | $595,000 |
| --- | --- |

| Fee Schedule | 1.00% flat annual advisory fee on AUM |
| --- | --- |

| Estimated Annual Advisory Fee | $5,100 |
| --- | --- |

Account balances by account as of year-end (or review date for interim reviews):

| Account | Year-End Balance |
| --- | --- |
| TX01 (Taxable Joint) | $303,000 |
| IRA1 (Alex IRA) | $224,000 |
| RIRA (Sam Roth IRA) | $68,000 |
| TOTAL HOUSEHOLD AUM | $595,000 |

Advisory fees are charged quarterly in arrears on average daily assets under management. All fees are reflected in quarterly account statements issued by Fidelity Institutional (CUST-FI-001). Clients may terminate the advisory agreement at any time with written notice.

| 4.  MATERIAL CHANGES & EVENTS — JANUARY 1 – DECEMBER 31, 2017 |
| --- |

The following material changes, events, and decisions occurred during the review period:

- No IPS amendments — Moderate Growth allocation maintained

- Equity markets performed strongly; portfolio grew $109,000 net of fees

- Annual suitability review confirmed risk tolerance unchanged at 68/100

- No new accounts opened; no accounts closed

- EventID: N/A (no material events this year)

| 5.  CONFLICT OF INTEREST & RELATED-PARTY DISCLOSURES |
| --- |

No conflicts of interest identified. Adviser compensated solely by advisory fee.

Clearwater Wealth Partners does not receive compensation from any third-party product providers, custodians, or fund companies in connection with client accounts. The firm does not engage in principal trading. No affiliated persons have a material interest in any security recommended to this client household during the review period, except as otherwise disclosed above.

| 6.  CLIENT ATTESTATION & SIGNATURES |
| --- |

CLIENT ATTESTATION

By signing below, the undersigned client(s) acknowledge receipt and review of all disclosures listed in Section 1 of this Compliance Acknowledgement for the period January 1 – December 31, 2017. The undersigned confirm that the investment objectives, risk tolerance, and account information described herein are accurate to the best of their knowledge. Any material changes to financial circumstances, objectives, or risk tolerance should be communicated to the adviser promptly.

| ________________________________Alex Chen (Client) | Date: _______________ | ________________________________Sam Chen (Client) | Date: _______________ |
| --- | --- | --- | --- |
|  |  |  |  |
| ________________________________Morgan Park, CFP® (Adviser) | Date: _______________ | ADV-PARK-001 | DOC-ComplianceAck-2017-001 |

────────────────────────────────────────────────────────────────────────────────

Footnotes: Fee of $5,100 represents 1.00% on average AUM of approximately $541,000 (blended beginning/ending balance).

This document is part of the NWP Demo Dataset (NWP-DEMO-HH-CHEN-001 v1.2). All client data is synthetic and for demonstration purposes only. Clearwater Wealth Partners | Registered Investment Adviser | CRD #999001
