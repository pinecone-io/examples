## Document Summary

This charitable tax strategy memo addresses the Chen household's significant income spike in tax year 2023, driven by a large RSU vesting event that generated $120,000 in equity compensation. Combined with a base W-2 salary of $262,000, investment income of $2,100, and net capital gains of $42,000, their estimated 2023 Adjusted Gross Income (AGI) is $426,100.

To optimize tax savings, advisor Morgan Park implemented a 'charitable bunching' strategy to maximize itemized deductions. Instead of spreading out donations, the Chens implemented **Recommendation RecID-2023-01** on May 18, 2023, by establishing a Donor-Advised Fund (DAF) called the Clearwater Giving Fund (NGF-CHEN-2023-001) with an in-kind donation of 500 NLTK shares valued at $25,000.

Donating the shares in-kind (which have a low cost basis of $2,500) avoided $22,500 in embedded long-term capital gains, yielding an immediate tax savings of approximately $5,355 in avoided capital gains taxes. Combined with an estimated $10,488 in federal and state income tax savings, the total estimated tax benefit for 2023 is approximately $15,843.

The memo also establishes a multi-year giving framework, planning for cash contributions to the DAF of $6,000 in 2024, $7,500 in 2025, and $8,000 in 2026.
