## Document Summary

### Household Context, Goals, and Risk Tolerance
Alex and Sam Chen are in the "Post-Liquidity Stewardship Phase" of their financial plan, transitioning to a structured framework designed to prepare for retirement (projected for 2043/2044) and fund college education. They have two children: Maya (age 14, college enrollment ~2029) and Eli (age 11, college enrollment ~2032). Following an updated risk questionnaire in 2025, their risk tolerance is categorized as "Moderate with bucket preference" (score 58/100).

### Current Financial Situation and Holdings
The household total assets under management (AUM) reached $1,450,000 as of December 31, 2025. Their portfolio is allocated at 62% Equities, 33% Fixed Income, and 5% Cash, distributed across the following accounts:
*   **Taxable Brokerage (ACCT-TX01):** $760,000 (Equities, MUNIX, and NLTK single-stock concentration restricted to <5%).
*   **Alex Traditional IRA (ACCT-IRA1):** $490,000 (UCBIX and UTIPX fixed income products).
*   **Alex Roth IRA (ACCT-RIRA):** $105,000 (Small cap, emerging markets, and REITX).
*   **Cash Management (ACCT-CASH):** $45,000 (Emergency liquidity serving as Bucket 1 spending reserve).
*   **College 529s:** Maya's 529 (ACCT-529A) holds $22,500 (with an age-based de-risking allocation), and Eli's 529 (ACCT-529B) holds $22,500.
*   **Charitable Giving:** $7,500 was distributed in 2025 via the Clearwater Giving Fund Donor-Advised Fund (DAF).

### Recommendations and Decisions
*   **Bucket Strategy Implementation (DecisionID-2025-112):** Implemented in Q1 2025 per IPS Amendment DOC-IPSAmendment-2025-001. Assets are divided into three buckets: Bucket 1 ($45k in cash/STBIX for near-term liquidity), Bucket 2 (~$490k in UCBIX/UTIPX for medium-term stability), and Bucket 3 (~$915k in equities/REITX for long-term growth).
*   **Social Security Claiming (RecID-2025-02):** A Q3 2025 analysis recommended that both Alex and Sam delay claiming until age 70 to maximize lifetime benefits.
*   **College Funding Analysis:** Delivered in Q2 2025. It highlighted a projected funding shortfall for Maya's college expenses, with her current 529 balance on track to cover only ~60% of the $250k target. Contributions were subsequently increased.

### Action Items and Next Steps
*   **Fee Billing Discrepancy (EventID-2026-01):** Resolve a discrepancy between billing statements and a prior strategy deck (identified as a stale draft, DOC-StrategyDeck-2022-002) in Q1 2026.
*   **Retirement Projections (TaskID-2026Q2-818):** Update long-term projections by June 15, 2026.
*   **Referral Follow-Up:** Complete the discovery and follow-up checklist for Alex's sibling, Taylor Chen (ProspectID-2025-01).
