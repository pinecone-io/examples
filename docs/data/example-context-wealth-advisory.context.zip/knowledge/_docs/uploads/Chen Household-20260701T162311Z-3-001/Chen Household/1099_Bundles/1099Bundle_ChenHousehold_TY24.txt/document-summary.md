## Document Summary

This document is a Consolidated Form 1099 Tax Bundle for the Chen Household (Alex & Sam Chen, HH-CHEN-001) for Tax Year 2024, issued by Fidelity Institutional (CUST-FI-001) for their Joint Taxable Brokerage Account (ACCT-TX01 ...7412).

### Financial Situation and Asset Activity
- **1099-DIV**: Reported $1,340.52 in Total Ordinary Dividends, of which $1,072.42 were Qualified Dividends, and $878.40 in Exempt-Interest Dividends (exempt from federal and MN state income tax via MUNIX).
- **1099-INT**: Reported $868.10 in Interest Income.
- **1099-B (Long-Term Capital Gains)**: Net long-term realized gains of $14,498.00 on total sales proceeds of $104,942.00 against a cost basis of $90,444.00. 

### Trades Executed in 2024
*   **UECIY** (2,500 shares sold on 2024-03-14): Proceeds of $37,500.00, cost basis of $32,750.00, gain of $4,750.00 (Q1 equity rebalancing — trim post-rally).
*   **IDEIY** (1,800 shares sold on 2024-05-22): Proceeds of $22,500.00, cost basis of $19,440.00, gain of $3,060.00 (Q2 international trim).
*   **UCBIX** (1,500 shares sold on 2024-08-19): Proceeds of $15,150.00, cost basis of $13,710.00, gain of $1,440.00 (Q3 bond portfolio adjustment).
*   **MUNIX** (1,200 shares sold on 2024-10-02): Proceeds of $12,360.00, cost basis of $10,872.00, gain of $1,488.00 (Q4 muni trim — estate cash planning).
*   **UTIPX** (800 shares sold on 2024-11-15): Proceeds of $8,360.00, cost basis of $5,584.00, gain of $2,776.00 (TIPS reduce — rate environment shift).
*   **STBIX** (900 shares sold on 2024-12-20): Proceeds of $9,072.00, cost basis of $8,088.00, gain of $984.00 (Year-end rebalancing).

These tax details should be shared with the household's tax professional to report the taxable income and net realized long-term capital gains of $14,498.00.
