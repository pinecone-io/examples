## Document Summary

### Document Summary

On September 15, 2024, Alex Chen and Sam Chen executed the **First Amendment to the Chen Family Revocable Living Trust** (originally established on September 10, 2019). Drafted by attorney Patricia Hawthorne (Westfield & Baker LLP) and reviewed with adviser Morgan Park, CFP® (Clearwater Wealth Partners), this amendment updates the estate plan following a family health event in Q1 2024.

#### Key Objectives and Updates
*   **Beneficiary Alignment:** A comprehensive audit resolved a prior mismatch on the household's Roth IRA (`ACCT-RIRA`), aligning all seven accounts and real property with the trust's beneficiary intent.
*   **Healthcare Directives:** Updated agents, aligned DNR orders with Northwestern Medicine Physician Orders for Life-Sustaining Treatment (POLST) forms, established a 30-day artificial life-support withdrawal preference, and added a mental health directive allowing involuntary evaluation consent under cognitive decline.
*   **Pre-Retirement Income Planning:** In anticipation of Alex Chen's retirement (target 2028–2030), the trust establishes a *Retirement Income Reserve* of up to $120,000 (Bucket 1 strategy) in cash equivalents, coordinates RMDs, plans for Social Security claiming, and outlines continuous Donor Advised Fund (DAF) distributions of $5,000–$10,000.
*   **Tax Considerations:** Current household net worth is ~$2.1M (AUM ~$1.285M), leaving no immediate federal estate tax exposure. The amendment directs a portability election (Form 706) upon the first spouse's death.

#### Scheduled Actions
*   **College Funding Review:** Scheduled for 2029 to evaluate Maya Chen’s 529 plan (`ACCT-529A`), projected to cover 65–80% of 4-year costs.
*   **Mandatory trust review:** Scheduled for 2029 to address estate tax provisions, trustee succession, and beneficiary details.
