## Document Summary

This document outlines the **2025 Donor-Advised Fund (DAF) Distribution Plan** for the Chen Family Charitable Fund (NGF-CHEN-2023-001) under the Clearwater Giving Fund. Prepared on March 15, 2025, by Morgan Park, CFP®, the plan serves to align the household's values-based giving with their nearing retirement (targeted for 2028–2030).

### Financial Situation & Holdings
* **Beginning of Year Balance (BOY 2025):** ~$21,200
* **Estimated AGI (2025):** ~$314,000 (comprising $276K W-2 income, $20K RSU, plus investment income and capital gains)
* **Tax Deductions:** A new cash top-up contribution of **$7,500** was completed on March 15, 2025. Coupled with mortgage interest ($16,250) and SALT ($10,000 cap), total itemized deductions reach $33,750, comfortably exceeding the standard Married Filing Jointly deduction of $30,000. 
* **Estimated End of Year Balance (EOY 2025):** ~$22,700 (assuming $7,500 contribution, $7,500 grant distribution, and 7% estimated market growth of ~$1,500).

### 2025 Grant Distribution Plan ($7,500 Total)
* **Evanston Community Foundation:** $3,500 (increased by $500 for retirement location development)
* **Greater Chicago Food Depository:** $2,000 (maintained)
* **Lurie Children’s Hospital Foundation:** $1,500 (increased by $500 reflecting family values post-EventID-2024-01)
* **Chicago Literacy Alliance:** $500 (new addition aligned with education values)

### Recommendations & Legacy Planning
* **Maintain DAF Reserve:** Morgan Park recommends maintaining a minimum fund balance of $15,000 to $20,000 post-retirement to support distributions when tax deductibility benefits decline.
* **Legacy Review:** Flagged for the Q2 2025 annual planning meeting:
  * Succession planning for DAF advisers (currently Alex primary, Sam secondary).
  * Aligning the DAF charitable mission with the MFRL-2019-001 trust provisions.
  * Evaluating if a Charitable Remainder Trust (CRT) could supplement retirement planning.
  * Linking DAF strategies with 529 education funding (GoalID-2016-02) for Maya (2029) and Eli (2032).
