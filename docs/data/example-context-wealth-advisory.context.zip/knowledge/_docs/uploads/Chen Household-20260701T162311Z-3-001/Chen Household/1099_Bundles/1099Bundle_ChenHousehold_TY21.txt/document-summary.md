## Document Summary

This document is a tax package containing Form 1099-DIV, 1099-INT, and 1099-B for the tax year 2021, issued by Fidelity Institutional for the Alex & Sam Chen Household (Account: ACCT-TX01 ...7412).

### Financial Situation and Holdings
- **Taxable Account (ACCT-TX01):** Joint Taxable Brokerage Account.
- **Dividends & Interest (TY21):** Recorded $918.30 in total ordinary dividends (with $734.64 qualified), $448.70 in interest income, and $446.20 in tax-exempt dividends (from MUNIX, exempt from federal and MN state income tax).
- **Underlying Positions Mentioned:** UECIX, UCBIX, UTIPX, MUNIX, STBIX, and IDEIX.

### Transactions and Recommendations
- **Long-Term Capital Gains:** Total proceeds of $122,184.00 against a cost basis of $103,682.00, resulting in a net long-term capital gain of $18,502.00.
- **Transacted Positions:**
  - **UECIX:** Sold 4,200 shares on 2021-07-12 for proceeds of $61,740.00 (gain of $12,180.00) under "Down payment staging" (DecisionID-2021-141).
  - **UCBIX:** Sold 2,200 shares on 2021-07-14 for proceeds of $22,440.00 (gain of $2,860.00) for down payment staging bond trim.
  - **MUNIX:** Sold 1,800 shares on 2021-07-15 for proceeds of $18,306.00 (gain of $1,548.00) for down payment staging muni trim.
  - **STBIX:** Sold 1,200 shares on 2021-07-19 for proceeds of $12,084.00 (gain of $120.00) for down payment staging cash sleeve.
  - **IDEIX:** Sold 600 shares on 2021-11-08 for proceeds of $7,614.00 (gain of $1,794.00) for year-end rebalancing.

### Decisions & Action Items
- **Liquidations:** The recorded transactions show that $114,570.00 of the proceeds were staged during July 2021 for a down payment, with an additional $7,614.00 liquidated in November 2021 for year-end rebalancing.
