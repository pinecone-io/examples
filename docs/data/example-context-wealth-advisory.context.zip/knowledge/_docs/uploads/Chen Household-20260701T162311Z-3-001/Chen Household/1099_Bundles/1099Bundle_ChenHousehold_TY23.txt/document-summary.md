## Document Summary

This document is a tax Form 1099 Bundle (1099-DIV, 1099-INT, and 1099-B) prepared by Fidelity Institutional for the Alex & Sam Chen Household for the tax year 2023. It records taxable activities and realized transactions within their Joint Taxable Brokerage account.

### Financial Situation and Holdings
- **Taxable Brokerage Account:** ACCT-TX01 ...7412 (Joint Taxable Brokerage)
- **Dividends & Interest:** Recorded $1,293.84 in total ordinary dividends (of which $1,035.07 were qualified), $762.00 in interest income, and $768.36 in federally tax-exempt dividends (from MUNIX - MN Municipal Bond Fund, which are exempt from federal and Minnesota state income tax).
- **Net Realized Capital Gains:** Reported total proceeds of $337,500.00 against a cost basis of $281,000.00, resulting in a net long-term capital gain of $49,000.00. No short-term net gains/losses were realized. 

### Documented Transactions (Form 1099-B)
- **NLTK (Net Gain: $53,500):** Sold 1,500 shares of NLTK (RSU vest-day shares sold) for proceeds of $105,000.00 (gain of $7,500) and 2,000 shares of NLTK (to reduce concentration, held >1yr) for proceeds of $142,000.00 (gain of $46,000). Also executed an in-kind transfer of 500 NLTK shares to the Clearwater Giving Fund (proceeds/basis of $35,750, $0 gain).
- **UECIY (Net Gain: $1,600):** Sold 2,000 shares for $26,400.00 to reinvest in diversified holdings post-NLTK concentration reduction.
- **IDEIY (Net Gain: $1,200):** Sold 1,500 shares for $18,300.00 as part of post-NLTK rebalancing.
- **UCBIX (Net Gain: $200):** Sold 1,000 shares for $10,050.00 as part of year-end bond rebalancing.
