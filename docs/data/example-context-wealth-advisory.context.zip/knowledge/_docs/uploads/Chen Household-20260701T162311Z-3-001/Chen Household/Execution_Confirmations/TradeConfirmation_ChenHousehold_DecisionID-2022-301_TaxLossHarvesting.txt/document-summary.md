## Document Summary

### Document Summary

- **Household Context**: Alex & Sam Chen (HH-CHEN-001) are in a 60/35/5 asset allocation (IPS-2020). The market downturn in 2022 following Fed interest rate hikes generated significant unrealized losses on high-basis investments purchased in March 2022.
- **Recommendations & Actions**: A tax-loss harvesting (TLH) campaign was executed in their Joint Taxable Brokerage account (ACCT-TX01) to harvest losses while maintaining equivalent market exposure and avoiding the 30-day wash-sale rule.
- **Trade Execution Details (September 2022)**:
  - **UECIX to UECIY Swap**: Sold 1,000 shares of US Equity Core Index Fund (UECIX) at $64.00/share (March 2022 cost basis: $85.00/share), realizing a short-term loss of **-$21,000**. Simultaneously bought 1,000 shares of US Equity Core Index Fund (Alt/TLH) (UECIY) at $64.00/share (total $64,000).
  - **IDEIX to IDEIY Swap**: Sold 250 shares of Intl Developed Equity Index Fund (IDEIX) at $27.00/share (March 2022 cost basis: $32.00/share), realizing a short-term loss of **-$1,250**. Simultaneously bought 250 shares of Intl Developed Equity Fund (Alt/TLH) (IDEIY) at $27.00/share (total $6,750).
  - **Net Cash Impact**: $0.00 net cash flow (total bought: $70,750; total sold: $70,750).
- **Tax Impact**: Realized total short-term capital losses of **-$22,250**. Factoring in existing long-term capital gains of ~$6,750, the net capital loss for 2022 is **-$15,500**. Of this, $3,000 is deductible against ordinary income for tax year 2022, and the remaining $12,500 will be carried forward to 2023.
- **Restricted Reinvestment/Lockout**: A 30-day lockout period is active; UECIX and IDEIX cannot be repurchased before October 7, 2022, and October 14, 2022, respectively.
