## Document Summary

This document is the Last Will and Testament of Alex Chen, executed on September 10, 2019, in Illinois. It functions as a Pour-Over Will designed to coordinate with the Chen Family Revocable Living Trust. 

### Key Elements & Context
- **Household Context**: Testator Alex Chen (b. March 22, 1981) lives in Naperville, Illinois, with spouse Sam Chen and minor children Maya Chen (b. 2011) and Eli Chen (b. 2014).
- **Structure and Strategy**: This is a companion document to Sam Chen's Will (`DOC-Will-2019-002`). It establishes a pour-over provision transferring all probate/residuary estate assets into the Chen Family Revocable Living Trust (`DOC-Trust-2019-001`, MFRL-2019-001) at death.
- **Asset Directives**:
  - **Tangible Personal Property**: Bequeathed entirely to spouse Sam Chen; if Sam does not survive Alex, it passes to their children in equal shares.
  - **Digital Assets**: Managed via the Illinois RUFADAA framework and directed to the residuary estate.
  - **Non-Probate Assets**: Clarified that retirement accounts (IRA, Roth IRA) and life insurance with Fidelity Institutional pass directly via beneficiary designations, not through this Will.
- **Appointments**:
  - **Personal Representative (Executor)**: Sam Chen is appointed as Primary Personal Representative. Maya Chen is nominated as successor upon reaching age 25.
  - **Guardian**: Sam Chen's sibling, Alex Sam, is nominated as guardian of the minor children if Sam Chen does not survive.
