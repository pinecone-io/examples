## Document Summary

### Document Summary

*   **Household Context**: Alex & Sam Chen are in their inaugural year of engagement with Clearwater Wealth Partners (onboarded during 2016).
*   **Goals & Risk Tolerance**: The household has a "Moderate Growth" risk profile (risk questionnaire score of 68/100). The active Investment Policy Statement (IPS), document `DOC-IPS-2016-001`, establishes a target allocation of 71% Equity, 27% Fixed Income, and 2% Cash (a 70/30 moderate growth strategy).
*   **Financial Situation**: Year-end Household Assets Under Management (AUM) total **$486,000**, held across three accounts at Fidelity Institutional:
    *   **TX01 (Taxable Joint)**: $246,000
    *   **IRA1 (Alex IRA)**: $183,000
    *   **RIRA (Sam Roth IRA)**: $57,000
*   **Advisory Fees**: The household has a 1.00% flat annual advisory fee on AUM, resulting in an estimated annual advisory fee of **$4,300**. Fees are charged quarterly in arrears on average daily AUM.
*   **Key Decisions & Actions**: 
    *   The adviser confirmed that the current 70/30 Moderate Growth strategy remains suitable for the household as of the January 15, 2017 review date.
    *   Delivery of standard compliance disclosures (Form ADV Part 2A/2B, Privacy Policy, Business Continuity Plan, and Proxy Voting Policy) was acknowledged.
