## Document Summary

This document records trade executions confirming a concentration reduction and Donor-Advised Fund (DAF) contribution for Alex & Sam Chen. The transactions were initiated following a liquidity event in which Alex received a large RSU vest of Clearwater Tech (NLTK) shares, creating a high concentration in their joint taxable brokerage account that deviated from their IPS guidelines.

### Financial Situation and Execution Details
* **NLTK RSU Vest:** 2,667 shares of Clearwater Tech (NLTK) vested at $45.00/share, creating $120,015 of W-2 ordinary income.
* **Concentration Reduction:** Sold 1,800 shares of NLTK at $45.00/share (gross proceeds: $81,000) with an average cost basis of $15.00, resulting in a gross long-term capital gain of $54,000 (net $41,500 after a $12,500 carryforward loss offset).
* **DAF Charitable Contribution:** Transferred out 556 shares of NLTK to the Clearwater Giving Fund (DAF), establishing a charitable deduction of $25,020 and avoiding capital gains tax on the appreciation.
* **Reinvestment & Rebalancing:** 
  * Purchased 600 shares of US Equity Core Index Fund (UECIY) for $48,000 to maintain US equity exposure.
  * Purchased 400 shares of International Developed Equity Fund (IDEIY) for $13,200.
  * Purchased 1,000 shares of US Core Bond Index Fund (UCBIX) for $9,400 in Alex's Traditional IRA to align with their target 35% bond allocation.

### Decisions & Tax Impact
* Deployed a DAF bunching strategy (TaxTopicID-2023-01) coordinated by Lisa Torres, EA, to help offset an elevated 2023 Adjusted Gross Income (AGI) of approximately $426,000.
* Total proceeds sold was $81,000 against total purchases of $70,600, resulting in a net cash flow credit of $10,400.
