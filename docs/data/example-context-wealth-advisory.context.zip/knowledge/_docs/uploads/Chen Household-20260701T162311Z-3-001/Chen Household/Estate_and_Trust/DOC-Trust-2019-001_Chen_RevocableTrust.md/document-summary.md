## Document Summary

## Document Summary

### Document Identification and Legal Context
* **Document:** Chen Family Revocable Living Trust Agreement (DOC-Trust-2019-001 / MFRL-2019-001)
* **Execution Date:** September 10, 2019 (Effective Date)
* **Governing Law:** State of Illinois (755 ILCS 5/ and 760 ILCS 5/)
* **Key Professionals:** Patricia Hawthorne, J.D., LL.M. (Westfield & Baker LLP - Drafting Attorney) and Morgan Park, CFP® (Clearwater Wealth Partners - Wealth Adviser)

### Household Context, Goals, and Trustees
* **Grantors & Initial Co-Trustees:** Alex Chen and Sam Chen (husband and wife, residing in Naperville, IL).
* **Primary Beneficiaries:** Alex and Sam Chen during their joint lifetimes.
* **Successor Trustees:** Surviving spouse upon first death. Upon the death or joint incapacity of both, successors are appointed in the following order: 
  1. Maya Chen (upon reaching age 25)
  2. Eli Chen (upon reaching age 25)
  3. First National Bank & Trust, N.A. (Corporate Trustee)
* **Secondary Beneficiaries & Distributions:** Upon the death of both Grantors, trust assets are divided equally (50% each) between Maya Chen (DOB 2011-08-19) and Eli Chen (DOB 2014-03-07), or their issue per stirpes. Distributions are held in sub-trusts until age 25, with 1/3 distributed at age 30, and the balance at age 35.

### Asset Funding and Account Status
* **Joint Taxable Brokerage Account (ACCT-TX01):** Scheduled for immediate re-titling from JTWROS into the name of the Trust.
* **Individual Retirement Accounts:** Traditional IRA (ACCT-IRA1) and Roth IRA (ACCT-RIRA) owned by Alex Chen must remain individually titled. Their beneficiary designations will be updated to align with the trust’s intent.
* **Real Property:** The document notes that as of the 2019 execution date, the Chens were renting. A prospective real property clause was established to title future primary residence acquisitions in the Trust's name.

### Recommendations & Next Steps
* **Action Item (TaskID-2019Q2-001):** File separate Beneficiary Designation Forms for ACCT-IRA1 and ACCT-RIRA with the custodian (Fidelity Institutional Custody).
* **Event-Driven Reviews:** The trust mandates reviews upon certain trigger events (e.g., purchasing real property, net worth increase > $500K, child reaches certain milestones, or tax law changes). The first mandatory scheduled review is set for September 2024.
