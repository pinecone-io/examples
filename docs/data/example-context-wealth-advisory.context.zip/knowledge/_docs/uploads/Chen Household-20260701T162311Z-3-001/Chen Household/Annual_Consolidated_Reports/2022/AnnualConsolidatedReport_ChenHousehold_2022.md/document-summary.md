## Document Summary

### Household Context, Goals, and Risk Tolerance
* **Household:** Alex and Sam Chen (HH-CHEN-001).
* **Risk Tolerance & Strategy:** The portfolio is managed under the defensive 60/35/5 asset allocation (60% Equity / 35% Fixed Income / 5% Cash) established in mid-2020 (IPS Amendment DOC-IPSAmendment-2020-001) to provide downside protection.
* **Goals:** 
  * **Retirement Readiness (GoalID-2016-01):** On track, despite 2022 market drawdowns. Confidence models were refreshed in Q4 2022.
  * **Education Funding (GoalID-2016-02):** Ongoing building phase for Maya (age 11) and Eli (age 8) in their respective 529 accounts (ACCT-529A and ACCT-529B), which hold $5,500 each in age-based moderate allocations.
  * **Emergency Liquidity (GoalID-2016-03):** Maintained with a $31,000 cash balance in ACCT-CASH, conforming to the target of 6–9 months of expenses.

### Current Financial Situation and Holdings
* **Household AUM:** Ended 2022 at $890,000 (down from $952,000 in 2021).
* **Performance:** Estimated net portfolio return of -6.5% in 2022, significantly outperforming the blended 60/40 benchmark (-14.2%) by approximately 770 bps due to defensive positioning.
* **Account Balances (as of Dec 31, 2022):**
  * ACCT-TX01 (Joint Taxable Brokerage): $450,000
  * ACCT-IRA1 (Alex Traditional IRA): $325,000
  * ACCT-RIRA (Alex Roth IRA): $73,000
  * ACCT-CASH (Cash Management): $31,000
  * ACCT-529A (Maya 529) & ACCT-529B (Eli 529): $5,500 each
* **Tax Profile:** Combined W-2 and other income of ~$268,000, itemizing deductions post-home purchase. AGI is approximately $275,000 with a federal effective tax rate of ~18.5%.

### Recommendations, Decisions, and Action Items
* **Tax-Loss Harvesting (Implemented):** In September 2022 (DecisionID-2022-301), harvested $15,500 in net capital losses in ACCT-TX01 by swapping UECIX → UECIY and IDEIX → IDEIY. This yields a $3,000 ordinary income deduction for 2022 and a $12,500 carry-forward for 2023.
* **Donor-Advised Fund (DAF):** RecID-2023-01 schedules a DAF strategy for high-income year planning in Q2 2023.
* **Fee Reconciliation:** Noted a version correction between the draft strategy deck (DOC-StrategyDeck-2022-002, showing an incorrect 1.00% fee) and the final version (DOC-StrategyDeck-2022-003, showing correct tiered fees). Internal review is scheduled for 2023.
* **529 Plan Review:** Review contribution targets in Q1 2023.
