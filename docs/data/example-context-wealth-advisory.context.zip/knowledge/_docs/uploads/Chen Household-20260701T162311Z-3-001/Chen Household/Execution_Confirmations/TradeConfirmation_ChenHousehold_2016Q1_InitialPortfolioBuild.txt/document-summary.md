## Document Summary

This trade execution confirmation details the initial portfolio construction and deployment of assets for the household of **Alex & Sam Chen** on February 10, 2016, following the engagement of advisor **Morgan Park, CFP®** of Clearwater Wealth Partners.

### Portfolio Deployment Details
*   **Total Deployed Assets:** $409,998.50 out of $410,000 total household assets.
*   **Target Asset Allocation (IPS-2016):** 70% Equity, 28% Fixed Income, and 2% Cash.
*   **Tax-Aware Allocation Strategy:**
    *   **Joint Taxable Account (ACCT-TX01):** US Equity Core and Municipal bonds.
    *   **Traditional IRA (ACCT-IRA1):** Core bonds, Treasury, and TIPS for an inflation hedge, alongside a small core equity sleeve to allow for tax-efficient rebalancing.
    *   **Roth IRA (ACCT-RIRA):** Small-cap equity to achieve long-term growth with no near-term distributions.

### Executed Trades
All trades were executed on February 10, 2016, with a settlement date of February 11, 2016. There were no capital gains or loss events recorded as all purchases established new cost basis lots.

*   **ACCT-TX01 (Joint Taxable Brokerage):**
    *   **UECIX** (US Equity Core Index Fund) – Purchased 3,125 shares at $40.00/sh ($125,000.00)
    *   **IDEIX** (Intl Developed Equity Index Fund) – Purchased 2,000 shares at $25.00/sh ($50,000.00)
    *   **EMEIX** (Emerging Markets Equity Index Fund) – Purchased 1,111 shares at $18.00/sh ($19,998.00)
    *   **MUNIX** (Municipal Bond Fund) – Purchased 4,800 shares at $10.00/sh ($48,000.00)
    *   **STBIX** (Short-Term Bond / Cash Equiv Fund) – Purchased 1,200 shares at $10.00/sh ($12,000.00)
*   **ACCT-IRA1 (Alex Traditional IRA):**
    *   **UCBIX** (US Core Bond Index Fund) – Purchased 6,000 shares at $10.00/sh ($60,000.00)
    *   **UTIPX** (US Treasury & TIPS Fund) – Purchased 1,579 shares at $9.50/sh ($15,000.50)
    *   **UECIX** (US Equity Core Index Fund) – Purchased 625 shares at $40.00/sh ($25,000.00)
*   **ACCT-RIRA (Alex Roth IRA):**
    *   **USCIX** (US Small Cap Index Fund) – Purchased 2,500 shares at $22.00/sh ($55,000.00)
