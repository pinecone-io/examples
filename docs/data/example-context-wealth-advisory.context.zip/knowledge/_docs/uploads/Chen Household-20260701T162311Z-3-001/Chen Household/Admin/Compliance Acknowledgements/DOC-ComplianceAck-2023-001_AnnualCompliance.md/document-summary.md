## Document Summary

This document is an annual compliance acknowledgement prepared by Morgan Park of Clearwater Wealth Partners for the Chen Household (Alex & Sam Chen) for the review period January 1 – December 31, 2023.

### Household Context & Risk Tolerance
* **Risk Profile:** Conservative-Moderate (trending toward Moderate) with a risk score of 56/100 (up from 54).
* **Investment Policy Statement (IPS):** Stays under active IPS amendment `DOC-IPSAmendment-2020-001` with a conservative-moderate strategy.

### Current Financial Situation & Holdings
* **Total Household AUM:** $1,140,000 as of year-end 2023.
* **Accounts and Balances:**
  * **Taxable Joint (TX01):** $620,000
  * **Alex IRA (IRA1):** $395,000
  * **Sam Roth IRA (RIRA):** $85,000
  * **Cash/Liquidity (CASH):** $25,000
  * **Alex Jr. 529 College (529A):** $7,500
  * **Sam 529 College (529B):** $7,500
* **Portfolio Allocation:** Rebalanced to 62% Equity / 33% Fixed Income / 5% Cash.
* **Key Material Events (2023):** Alex's RSU vesting and partial sale (EventID-2023-01) resulted in a net AUM increase of $250,000, deposited partially into TX01. This generated approximately $87,000 in net realized capital gains. Additionally, a Donor-Advised Fund (DAF) charitable bunching strategy (`DOC-DAF-2023-001`) was implemented.

### Recommendations & Action Items
* **Suitability:** The investment strategy is confirmed to remain suitable.
* **Fee Structure:** Managed under a tiered schedule of 0.85% on the first $1,500,000, leading to an estimated annual fee of $9,200.
* **Other Actions:** 529 plan contributions were maintained, and an estate planning review was initiated following a trust review with legal counsel.
