## Document Summary

This document is a tax year 2019 Form 1099 bundle (1099-DIV, 1099-INT, and 1099-B) issued by Fidelity Institutional for the joint taxable brokerage account (ACCT-TX01 ...7412) of Alex & Sam Chen (Household ID: HH-CHEN-001).

### Financial Summary for Tax Year 2019
* **Dividends and Interest**: The account earned $1,401.12 in total ordinary dividends (of which $1,120.90 were qualified dividends), $448.50 in taxable interest income, and $438.60 in exempt-interest dividends from MUNIX (Minnesota Municipal Bond Fund), which are exempt from federal and MN state income taxes.
* **Realized Capital Gains**: The account generated a net long-term realized capital gain of $7,501.00 from $38,224.00 in total proceeds against a cost basis of $30,723.00. No short-term transactions or wash sales were reported.

### Account Transactions & Management Decisions
Four long-term transactions were executed in 2019, reflecting active portfolio management and rebalancing:
* **NLTK**: Sold 200 shares on April 12, 2019, for proceeds of $14,800.00 (gain of $4,600.00) noted for trust planning purposes.
* **UECIX**: Sold 900 shares on June 20, 2019, for proceeds of $11,700.00 (gain of $1,350.00) as part of a mid-year equity rebalancing trim.
* **IDEIX**: Sold 450 shares on September 16, 2019, for proceeds of $5,670.00 (gain of $1,125.00) for rebalancing.
* **STBIX**: Sold 600 shares on December 10, 2019, for proceeds of $6,054.00 (gain of $426.00) as part of a year-end sweep.
