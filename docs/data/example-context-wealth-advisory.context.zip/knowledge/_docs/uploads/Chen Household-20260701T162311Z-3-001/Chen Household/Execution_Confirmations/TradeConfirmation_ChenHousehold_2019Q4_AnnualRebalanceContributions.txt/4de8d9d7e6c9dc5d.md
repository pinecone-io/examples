## Document Summary

### Executive Summary
On December 11, 2019, an annual rebalance and contribution deployment was executed for the household of Alex and Sam Chen under the direction of Advisor Morgan Park, CFP®. The rebalance was designed to correct a portfolio equity drift that had risen to approximately 75% following an exceptionally strong year in the equity markets (S&P 500 +31.5%), bringing it back in line with the IPS-2016 target allocation (70/28/2).

### Current Financial Situation & Transactions
*   **Joint Taxable Brokerage (ACCT-TX01):** 
    *   **Trims (Equity):** Sold 150 shares of US Equity Core Index Fund (UECIX) at $57.00/share (generating a long-term capital gain of $2,550 on a Feb 2016 basis) and 200 shares of Intl Developed Equity Index Fund (IDEIX) at $31.00/share (generating a long-term capital gain of $1,200 on a Feb 2016 basis).
    *   **Additions (Bonds):** Purchased 1,000 shares of Municipal Bond Fund (MUNIX) at $10.25/share ($10,250.00 total) for tax-efficient placement.
*   **Alex Traditional IRA (ACCT-IRA1):**
    *   **Trims (Equity):** Sold 100 shares of UECIX at $57.00/share ($5,700.00 total) with no tax consequences.
    *   **Additions (Bonds):** Purchased 543 shares of US Core Bond Index Fund (UCBIX) at $10.50/share ($5,701.50 total).

### Tax & Cash Flow Impact
*   **Net Cash Flow:** The net cash flow from these transactions resulted in a credit of $4,498.50 (Total Sales: $20,450.00; Total Purchases: $15,951.50).
*   **Tax Impact:** Realized approximately $3,750 in long-term capital gains from the taxable brokerage rebalance, contributing to total 2019 net capital gains of approximately $7,500.
