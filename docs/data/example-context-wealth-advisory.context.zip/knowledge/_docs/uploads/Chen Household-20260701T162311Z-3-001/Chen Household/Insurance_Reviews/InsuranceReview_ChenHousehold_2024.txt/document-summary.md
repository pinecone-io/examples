## Document Summary

This document outlines the 2024 insurance review for the Chen household, conducted by Morgan Park, CFP, of Clearwater Wealth Partners on October 22, 2024. The review was triggered by a family health event and a pre-retirement planning assessment, as Alex and Sam Chen are 19 years away from their target retirement age of 60.

### Household Context & Goals
*   **Household:** Alex (41) and Sam (40) Chen; children Maya (13) and Eli (10). They reside in Wayzata, MN.
*   **Goals:** Ensure adequate protection for their growing balance sheet (post-2023 liquidity event), plan for pre-retirement risk, and address long-term care (LTC) exposure.

### Current Financial Situation & Holdings
*   **Assets:** Net worth estimated at ~$1,550,000 (including $1,200,000 in investments and $355,000 in home equity on an $890,000 home with a ~$535,000 mortgage balance).
*   **Current Insurance Holdings:**
    *   **Life:** Alex ($2,000,000 term) and Sam ($1,500,000 term) through Protective Life Insurance Co.
    *   **Disability:** Alex ($9,000/mo individual policy) and Sam (60% salary group LTD, ~$4,600/mo) through The Standard Group and employer respectively.
    *   **P&C:** Homeowners ($725,000 dwelling), Auto (2 vehicles), and Personal Umbrella ($2,000,000 limit) through Northfield Mutual.

### Recommendations & Key Decisions
1.  **Beneficiary Correction:** Resolved an outdated contingent beneficiary designation (prior form named Alex's parent). A new form (DOC-BeneficiaryForm-2024-001) was executed to direct contingents to the Chen Family Revocable Trust.
2.  **Umbrella Coverage:** Recommended increasing the umbrella policy limit from $2,000,000 to $3,000,000 at the Q1 2025 renewal to align with their estimated $1,550,000 net worth.
3.  **Long-Term Care:** Promoted the evaluation of hybrid life/LTC policies. Pacific Life and Mutual of Omaha quotes have been requested.
4.  **Life Insurance Policy Ownership:** Suggested reviewing a potential Irrevocable Life Insurance Trust (ILIT) with estate attorney Logan Hart, JD, during the 2025 review.

### Action Items
*   **Umbrella Policy Increase:** Increase Northfield Mutual umbrella to $3,000,000 (Target: Q1 2025).
*   **LTC Quotes & Strategy:** Review hybrid carrier quotes and make a decision (Target: Q2 2025).
*   **Estate/ILIT Review:** Coordinate with estate attorney Logan Hart, JD, to evaluate policy ownership (Target: 2025).
