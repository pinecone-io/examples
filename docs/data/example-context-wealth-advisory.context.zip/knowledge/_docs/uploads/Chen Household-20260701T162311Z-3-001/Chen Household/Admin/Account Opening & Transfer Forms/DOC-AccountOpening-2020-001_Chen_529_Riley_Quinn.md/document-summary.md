## Document Summary

This document registers the establishment of two Minnesota 529 Education Savings Accounts by Clearwater Wealth Partners on May 1, 2020, to support the education planning goals of the Chen Household. Under the parent-led ownership of Alex and Sam Chen, the accounts are structured to fund future undergraduate educations for their children, Maya and Eli. 

### Goals and Risk Tolerance
*   **Goal (GoalID-2016-02):** Prioritize undergraduate college education funding for Maya (DOB August 19, 2011; target enrollment ~2029) and Eli (DOB March 7, 2014; target enrollment ~2032).
*   **Risk Profile:** Growth-oriented but transitioning. Both accounts utilize the Age-Based Moderate Index Portfolio (529-AGE-MOD), which automates a glide path to more conservative holdings as the children reach college age.

### Current Financial Situation & Account Details
*   **Accounts Opened:** 
    *   **ACCT-529A (Maya Chen):** Initial contribution of $5,000 wired from taxable savings (ACCT-TX01). Age-based asset allocation is ~75% Equity / 20% Fixed / 5% Cash (~8 years to college).
    *   **ACCT-529B (Eli Chen):** Initial contribution of $5,000 wired from taxable savings (ACCT-TX01). Age-based asset allocation is ~80% Equity / 15% Fixed / 5% Cash (~12 years to college).
*   **Triggering Event (EventID-2020-01):** COVID-19 market volatility prompted a broader financial review. These accounts are excluded from the core household Investment Policy Statement (IPS) asset allocation calculations but are included in total household Assets Under Management (AUM).

### Recommendations and Strategy
*   **Tax Strategy:** Gift tax exclusions applied annually ($15,000 per person for 2020) rather than exercising the 5-year superfunding election, which remains a contingent option upon a future liquidity event. The parents are eligible for Minnesota state income tax deductions on contributions.
*   **Advisory Status:** Formally covered under the 2016 advisory agreement (DOC-AdvisoryAgreement-2016-001) and designated for fee billing starting July 1, 2021 (DOC-FeeAmendment-2021-001).

### Action Items
*   **Annual Strategy Review:** Establish annual contribution targets based on ongoing cash flow analyses during the Q4 strategy meeting.
*   **Tax Coordination:** Account owners are advised to consult with Lisa Torres, EA, regarding state income tax deductions for their contributions.
