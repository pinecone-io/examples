## Document Summary

### Document Summary

- **Household Context, Goals, and Risk Tolerance**: Alex & Sam Chen purchased their home at 3215 Lakeview Circle in Wayzata, MN in July 2021. Their retirement goal (~20 years out) remains on track, with AUM reaching $952,000 despite home-related outflows. Education funding is in progress via age-based moderate portfolios in two 529 accounts. Following the home purchase, their emergency liquidity was partially drawn down; the goal is to rebuild it to $60,000–$70,000 by the end of 2022.
- **Current Financial Situation and Holdings**: Total portfolio assets closed 2021 at $952,000 (up from $792,000), absorbing a $55,000 down-payment outflow. Holdings are allocated at approximately 60% Equity, 35% Fixed Income, and 5% Cash, in line with their Investment Policy Statement. Key accounts include a Taxable Joint account ($480,000), Traditional IRA ($330,000), Roth IRA ($78,000), Cash Management ($50,000), and two 529 plans ($7,000 each). NLTK single stock concentration represents ~5% of the portfolio.
- **Recommendations and Action Items**:
  - Rebuild the emergency cash fund (ACCT-CASH) to $60,000–$70,000 by year-end 2022.
  - Establish and set annual targets for 2022 contributions in 529 accounts.
  - Review NLTK concentration and the annual vesting schedule to maintain the <7% limit.
  - Maintain trust alignment on beneficiary forms for IRA and Roth IRA accounts.
  - Confirm that the newly executed tiered fee schedule amendment (effective July 1, 2021) was correctly applied to H2 2021 billing.
