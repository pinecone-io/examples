## Document Summary

This document records a Fidelity Institutional trade execution confirmation dated February 18, 2025, detailing the implementation of a new Investment Policy Statement (IPS-2025) for the Alex & Sam Chen household. Initiated by Advisor Morgan Park of Clearwater Wealth Partners under DecisionID-2025-112, the trades restructure the portfolio to align with a **62% Equity / 33% Fixed Income / 5% Cash** three-bucket strategy aimed at pre-retirement income stability.

### Financial Strategy & Reallocation
- **Bucket 1 (Cash/ST Bonds - 5%):** Designed to hold ~2 years of living expenses. Seeded via a $20,800 purchase of `STBIX` (Short-Term Bond / Cash Equiv Fund) in the Cash Management Account (`ACCT-CASH`).
- **Bucket 2 (Fixed Income - 33%):** Enhanced tax-efficiently by buying $8,080 of `MUNIX` (Municipal Bond Fund) in the Joint Taxable account (`ACCT-TX01`) and $8,000 of `UCBIX` (US Core Bond Index Fund) in Alex's Traditional IRA (`ACCT-IRA1`).
- **Bucket 3 (Equity - 62%):** Slightly trimmed to fund the Bucket 1 cash seed. Sales totaled $26,080 across `UECIX` ($16,200), `IDEIX` ($8,800), and `EMEIX` ($1,080) from the Joint Taxable account.

### Tax Impact & Settlement
- **Net Cash Flow:** Net debit of $10,800 ($36,880 total purchases vs. $26,080 total sales), settling on February 19, 2025.
- **Capital Gains:** Equity sales resulted in long-term capital gains totaling $14,440 (including $10,200 from `UECIX`, $3,700 from `IDEIX`, and $540 from `EMEIX`).
