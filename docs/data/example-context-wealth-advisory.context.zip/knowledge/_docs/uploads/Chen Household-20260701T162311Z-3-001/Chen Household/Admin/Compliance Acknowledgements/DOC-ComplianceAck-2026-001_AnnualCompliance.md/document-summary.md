## Document Summary

This document is an **Annual Compliance Acknowledgement** (for the Q1 Interim Review period of January 1 – March 9, 2026) prepared by Morgan Park, CFP® of Clearwater Wealth Partners for the household of **Alex & Sam Chen**.

### Household Context & Risk Tolerance
- **Household:** Alex & Sam Chen (HH-CHEN-001)
- **Risk Profile:** Moderate (Risk Questionnaire Score: 58/100)
- **Investment Strategy:** Moderate / Bucket Strategy under the active Investment Policy Statement (DOC-IPSAmendment-2025-001)
- **Target Allocation:** 61% Equity / 34% Fixed Income / 5% Cash

### Financial Situation & Holdings
- **Current Portfolio Value:** Q1 2026 AUM as of the review date is approximately **$1,520,000** (projected to reach $1,650,000 by year-end 2026).
- **Account Balances (as of the review date/year-end projection):**
  - TX01 (Taxable Joint): $850,000
  - IRA1 (Alex IRA): $555,000
  - RIRA (Sam Roth IRA): $120,000
  - CASH (Cash/Liquidity): $35,000
  - 529A (Alex Jr. — College): $45,000
  - 529B (Sam — College): $45,000
  - **Total Household AUM:** $1,650,000
- **Advisory Fees:** Tiered schedule of 0.85% on the first $1,500,000 and 0.70% on the next $1,500,000. Household AUM crossed the $1.5M threshold, making the second fee tier partially applicable. Estimated annual advisory fee is $13,275.

### Material Events & Disclosures
- **Fee Billing Discrepancy (EventID-2026-01):** An internal audit identified a billing error from Q3 2022 where the household was charged a flat 1.00% instead of the amended 0.85% tiered rate. This resulted in an overcharge of approximately **$1,100**.
- **Tax Planning Changes:** The sunsetting provisions of the Tax Cuts and Jobs Act (TCJA) are now in effect (post-December 31, 2025). 
- **RMD Planning:** Planning has been initiated for Alex Chen, who is approaching RMD age thresholds by 2029.

### Recommendations & Action Items
- **Fee Remediation (TaskID-2026-CR-001 / TaskID-2026-CR-002):** A compliance review is active, and a credit memo for approximately $1,100 will be issued to the Chens upon completion of the internal audit.
- **Portfolio & Tax Strategies:** 
  - Implement strategies under *TAX-2026-001* (Annual review, RMD planning, and portfolio rebalancing strategy).
  - Implement strategies under *TAX-2026-002* (Portfolio rebalancing and capital gains harvesting).
