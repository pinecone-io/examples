## Document Summary

This document records the initial beneficiary designations for the Chen Household across three accounts established concurrently at Fidelity Institutional (CUST-FI-001) as part of a new advisory relationship starting February 1, 2016.

### Account Information
- **Primary Account Holder:** Alex Chen (DOB: March 22, 1981)
- **Joint Account Holder:** Sam Chen (DOB: November 2, 1984)
- **Filing Status:** Married Filing Jointly
- **Dependents:** Maya Chen (DOB: Aug 19, 2011) and Eli Chen (DOB: Mar 7, 2014)

### Beneficiary Designations
For all three accounts listed, **Sam Chen (Spouse)** is designated as the Primary Beneficiary (100% share), and children **Maya Chen** (50%) and **Eli Chen** (50%) are designated as Contingent Beneficiaries on a **per stirpes** basis. 

1. **Taxable Brokerage Account (ACCT-TX01):** Joint Tenants with Rights of Survivorship (JTWROS); beneficiary designations only take effect upon the death of both joint account holders.
2. **Alex Traditional IRA (ACCT-IRA1):** Individual retirement account; spouse is the eligible designated beneficiary.
3. **Alex Roth IRA (ACCT-RIRA):** Individual retirement account; spouse is the eligible designated beneficiary. Minor children contingent beneficiaries are subject to the SECURE Act 10-year rule upon reaching the age of majority.

### Advisory Decisions and Action Items
* **No Trust in Place:** Direct individual designations are used since no trust exists as of February 1, 2016.
* **Future Trust Review:** A revocable trust is anticipated in the future (around 2019). Advisor Morgan Park will initiate a required review and potential update of these beneficiary designations to align with the estate plan once the trust is formed.
