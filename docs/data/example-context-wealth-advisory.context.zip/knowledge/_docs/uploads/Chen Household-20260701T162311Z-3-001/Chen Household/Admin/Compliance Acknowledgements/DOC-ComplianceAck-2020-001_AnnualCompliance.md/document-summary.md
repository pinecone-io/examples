## Document Summary

This Annual Compliance Acknowledgement for the Chen household (Alex & Sam Chen) covers the review period from January 1 to December 31, 2020, and was prepared by adviser Morgan Park, CFP® on January 11, 2021.

### Household Context, Goals, and Risk Tolerance
- **Household:** Alex & Sam Chen (HH-CHEN-001)
- **Risk Profile:** Re-assessed as "Conservative-Moderate" after a COVID-19 risk review, with their Risk Questionnaire score dropping from 68 to 54 out of 100.
- **Asset Allocation:** Target allocation is set to 61% Equity / 34% Fixed Income / 5% Cash under the active IPS (DOC-IPSAmendment-2020-001).

### Current Financial Situation and Holdings
- **Total Household AUM:** $792,000 as of year-end 2020. 
- **Fee Structure:** Flat 1.00% annual advisory fee on AUM (estimated at $7,600 annually).
- **Account Balances:**
  - **TX01 (Taxable Joint):** $390,000
  - **IRA1 (Alex IRA):** $285,000
  - **RIRA (Sam Roth IRA):** $67,000
  - **CASH (Cash/Liquidity):** $50,000
  - **529A (Alex Jr. — College):** $0 (opened Q4 2020)
  - **529B (Sam — College):** $0 (opened Q4 2020)

### Key Material Events & Decisions (2020)
- **COVID-19 Market Volatility (EventID-2020-01):** Prompted an emergency risk shift meeting (DecisionID-2020-044) where the target equity allocation was reduced from 70% to 60%, formalizing a shift to a Conservative-Moderate profile.
- **IPS Amendment:** Executed on June 30, 2020 (DOC-IPSAmendment-2020-001).
- **Tax and Accounts:** Generated approximately $12,000 in net realized capital gains from a Tax-Loss Harvesting (TLH) campaign. Opened 529 college savings accounts (529A and 529B) in Q4 2020 with $0 initial balances, with contributions scheduled to commence in Q1 2021. CARES Act provisions were reviewed; no RMDs or retirement withdrawals were made in 2020.
