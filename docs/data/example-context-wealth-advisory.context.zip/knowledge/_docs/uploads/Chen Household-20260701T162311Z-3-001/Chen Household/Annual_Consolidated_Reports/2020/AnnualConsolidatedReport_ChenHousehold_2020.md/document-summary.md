## Document Summary

### Household Context, Goals, and Risk Tolerance
During the early 2020 COVID-19 market volatility, Alex and Sam Chen experienced significant anxiety, triggering an emergency portfolio review. A May 2020 risk questionnaire revealed their risk tolerance score dropped from 68 to 54 out of 100. Consequently, they executed an Investment Policy Statement amendment (IPS-2020) to transition their target asset allocation from 70/28/2 to a more defensive 60/35/5 (60% Equity, 35% Fixed Income, 5% Cash). Additionally, they successfully initiated their education funding goal by opening 529 plans for their children, Maya and Eli.

### Financial Situation and Holdings
The Chen household's total AUM ended the year at $792,000, recovering strongly from a first-quarter low of $665,000. Total net contributions for the year were $45,000. 
*   **ACCT-TX01 (Taxable Joint):** $390,000 (includes U.S. equities, NLTK single stock, and a newly expanded MUNIX muni bond sleeve).
*   **ACCT-IRA1 (Alex Trad IRA):** $285,000 (bonds, TIPS, and equity).
*   **ACCT-RIRA (Alex Roth IRA):** $67,000 (small-cap and emerging market tilt).
*   **ACCT-CASH (HYSA):** $50,000 (emergency fund/liquid cash reserve).
*   **ACCT-529A & ACCT-529B (529 College Savings):** Opened in May 2020 with minimal initial balances; invested in age-based moderate portfolios.

### Recommendations and Decisions
*   **Defensive Repositioning (DecisionID-2020-044):** Shipped equities to fixed income and cash, realizing $12,000 in long-term capital gains and resulting in an estimated $518 NIIT liability on ~$263,600 AGI.
*   **Tax-Efficient Income (RecID-2020-01):** Expanded the MUNIX sleeve in the taxable account.
*   **529 Contributions:** Set a systematic funding schedule in Q1 2021.
*   **Beneficiary Updates:** Align IRA and Roth IRA beneficiary designations with the household trust.
*   **NLTK Concentration:** Monitor vesting schedule in Q1 2021 to ensure the single stock exposure remains under the revised 7% IPS limit (currently at ~5%).
*   **Estate Review:** Conduct an annual review of their updated trust with Westfield & Baker LLP.
