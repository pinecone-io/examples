## Document Summary

This document is a tax year 2022 Form 1099 consolidated bundle prepared by Fidelity Institutional for the Joint Taxable Brokerage account (Account: ACCT-TX01 ...7412) belonging to the Alex & Sam Chen household (Household ID: HH-CHEN-001). 

### Current Financial Situation & Tax Metrics (TY2022)
* **Dividends & Interest:** The account generated $1,005.60 in total ordinary dividends (including $804.48 in qualified dividends), $612.40 in interest income, and $616.80 in tax-exempt exempt-interest dividends (derived from the Minnesota Municipal Bond Fund, MUNIX).
* **Capital Gains & Losses:** The household recorded long-term proceeds of $191,621.00 against a cost basis of $207,121.00, resulting in a net realized long-term capital loss of $15,500.00.

### Recommendations & Executed Transactions
The realized loss was primarily driven by strategic tax-loss harvesting (TLH) and rebalancing decisions executed throughout 2022:
* **Tax-Loss Harvesting (September 2022):** Sold 8,500 shares of UECIX for a loss of $11,050.00 and 5,500 shares of IDEIX for a loss of $9,900.00.
* **Rebalancing Trims:** 
  * Q1 bond trim: Sold 1,400 shares of UCBIX for a gain of $1,344.00.
  * Q2 rebalancing: Sold 900 shares of UTIPX for a gain of $945.00.
  * Mid-year muni trim: Sold 1,100 shares of MUNIX for a gain of $154.00.
  * Post rate-hike selloff trim (November 2022): Sold 650 shares of REITX for a gain of $3,007.00.
