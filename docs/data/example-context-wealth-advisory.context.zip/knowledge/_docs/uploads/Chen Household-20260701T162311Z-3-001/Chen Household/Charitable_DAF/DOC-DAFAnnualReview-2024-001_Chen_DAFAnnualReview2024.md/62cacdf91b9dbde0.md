## Document Summary

### Document Summary

This document records the **2024 Annual Review & Grant Plan** for the **Chen Family Charitable Fund** (Donor-Advised Fund or DAF, ID: NGF-CHEN-2023-001), authored by advisor Morgan Park, CFP® on November 15, 2024.

#### Household Context, Goals, and Risk Tolerance
* **Family Context:** A close family health event in Q1 2024 prompted Alex and Sam Chen to complete an estate audit in Q3 2024. This event shifted their charitable giving priorities to emphasize children's health.
* **Goals:** Ongoing values-based giving plan (GoalID-2023-01). The household is targeting retirement in 2028–2030 (GoalID-2016-01), with the DAF increasingly positioned as a long-term legacy vehicle.

#### Current Financial Situation and Holdings
* **DAF Value & History:** The DAF had an opening balance of $16,800 in 2024. Following a $6,000 cash contribution, $6,000 in grants, and estimated market growth, the closing year-end balance is projected to be **~$21,200**.
* **2024 Contribution:** A cash top-up of **$6,000** was electronically transferred from Alex's checking account on November 15, 2024. It is fully tax-deductible against their estimated 2024 Adjusted Gross Income (AGI) of $302,000.

#### Recommendations, Decisions, and Action Items
* **2024 Grant Allocations:** Approved grants total **$6,000** (lower than 2023's $9,000 to preserve capital for future growth):
  * *Evanston Community Foundation:* $3,000
  * *Greater Chicago Food Depository:* $2,000
  * *Lurie Children’s Hospital Foundation:* $1,000 (elevated priority following the family health event)
* **Advisory Recommendation:** Review the DAF's integration with the *Chen Family Revocable Living Trust* (DOC-Trust-2019-001) during the 2025 annual review, focusing on the succession of fund advisory rights and potential charitable bequests.
