## Document Summary

This document is a Consolidated Form 1099 for Tax Year 2018, issued by Fidelity Institutional for the joint taxable brokerage account (`ACCT-TX01 ...7412`) of Alex & Sam Chen (Household `HH-CHEN-001`).

### Financial Situation and Holdings
- **1099-DIV**: Total ordinary dividends of $1,066.44, of which $853.15 were qualified. Exempt-interest dividends of $362.80 were received from MUNIX (MN Municipal Bond Fund), which are exempt from federal and MN state income tax. Tax-exempt interest is noted across securities including UECIX, IDEIX, MUNIX, NLTK, and REITX.
- **1099-INT**: Interest income of $398.20 was earned.
- **1099-B**: Total long-term proceeds of $51,241.00 (corrected/detailed as $34,991.00 in the transaction table) against a cost basis of $43,344.00 (detailed as $30,969.00 in the table), resulting in a net realized long-term capital gain of $4,022.00. (Note: Page 1 summary lists Short Proceeds as $0.00 and Cost Basis as $0.00, but records a net gain or loss of $3,875.00, yielding a Grand Total net gain of $7,897.00).

### Recommendations & Decisions (Rebalancing & Concentration Management)
Several taxable sales were completed during 2018 in the Joint Taxable Brokerage account to manage concentrations and execute rebalancing:
- **NLTK**: Sold 250 shares on 2018-04-16 for $16,250.00 (gain of $3,875.00) following an RSU vest-day sale, and trimmed an additional 150 shares on 2018-06-30 for $10,050.00 (gain of $2,550.00) for concentration management.
- **UECIX**: Sold 700 shares on 2018-09-28 for $8,715.00 (gain of $315.00) for Q3 equity rebalancing.
- **UCBIX**: Sold 1,200 shares on 2018-11-20 for $12,096.00 (gain of $492.00) during rebalancing.
- **IDEIX**: Sold 350 shares on 2018-12-14 for $4,130.00 (gain of $665.00) during year-end rebalancing.
