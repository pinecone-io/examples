## Document Summary

### Executive Summary

Following the fourth-quarter 2018 equity market selloff, where the S&P 500 declined 14%, the Chen Household portfolio drifted below its target equity allocation defined in the IPS-2016 model (70/28/2). In response, Advisor Morgan Park of Clearwater Wealth Partners executed an opportunistic, year-end rebalancing trade on December 10, 2018 (settling December 11, 2018) to restore the targeted growth ballast across the household's joint taxable brokerage and traditional IRA accounts.

### Financial Strategy & Trade Execution Details

The rebalance was funded by trimming existing municipal and bond index fund positions to buy into the US Equity Core Index Fund (UECIX) at lower prices ($44.00 per share).

*   **Joint Taxable Brokerage Account (ACCT-TX01):**
    *   **Purchased:** 400 shares of US Equity Core Index Fund (UECIX) at $44.00/share, totaling $17,600.00.
    *   **Sold:** 1,200 shares of Municipal Bond Fund (MUNIX) at $10.05/share ($12,060.00 proceeds; long-term gain of ~$48 on a blended basis of ~$10.01/share).
    *   **Sold:** 550 shares of Short-Term Bond / Cash Equiv Fund (STBIX) at $10.05/share ($5,527.50 proceeds; minimal gain on a $10.00/share basis).
*   **Alex's Traditional IRA (ACCT-IRA1):**
    *   **Purchased:** 250 shares of US Equity Core Index Fund (UECIX) at $44.00/share, totaling $11,000.00 to add tax-deferred growth ballast.
    *   **Sold:** 450 shares of US Core Bond Index Fund (UCBIX) at $10.10/share ($4,545.00 proceeds; no capital gains due to tax-deferred IRA structure).

### Overall Summary & Tax Impacts

*   **Total Purchases (Debit):** $28,600.00
*   **Total Proceeds (Credit):** $22,132.50
*   **Net Settlement Flow:** Cash debit of $6,467.50 from the accounts to settle on December 11, 2018.
*   **Tax Considerations:** Sells within the taxable account (MUNIX and STBIX) generated a combined long-term gain of roughly $48. Tax-year 2018 net capital gains are projected to be approximately $6,000, which includes prior RSU-related actions and year-round rebalancing. No wash-sales were triggered.
