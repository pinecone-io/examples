## Document Summary

This trade execution confirmation records the mid-year portfolio rebalance for the **Alex & Sam Chen** household, executed on **June 14, 2024**, under the guidance of advisor **Morgan Park, CFP®** of Clearwater Wealth Partners. 

### Rationale & Context
Following a strong equity market rally in 2023 and 2024, the household's equity allocation exceeded the 60% target set in their **IPS-2020 (60/35/5)** model. To bring the portfolio back in line with targets, equities were trimmed to fund fixed-income additions, moving fixed income back toward its 35% target.

### Executed Trades
*   **Sells (Equities - Joint Taxable Brokerage, ACCT-TX01):**
    *   **UECIY (US Equity Core Index Fund, TLH alternate):** Sold 200 shares at $98.00 (Basis: $64.00, LT Gain: $6,800)
    *   **UECIX (US Equity Core Index Fund):** Sold 100 shares at $98.00 (Basis: $40.00, LT Gain: $5,800)
    *   **IDEIX (Intl Developed Equity Index Fund):** Sold 50 shares at $40.00 (Basis: $25.00, LT Gain: $750)
    *   **IDEIY (Intl Developed Equity Fund, TLH alternate):** Sold 25 shares at $40.00 (Basis: $27.00, LT Gain: $325)
*   **Buys (Fixed Income):**
    *   **MUNIX (Municipal Bond Fund - Taxable, ACCT-TX01):** Purchased 700 shares at $9.90 ($6,930.00) to rebuild fixed income within the taxable account.
    *   **UCBIX (US Core Bond Index Fund - Alex Traditional IRA, ACCT-IRA1):** Purchased 1,000 shares at $9.70 ($9,700.00) to handle a larger bond addition without tax consequences.

### Financial Summary & Tax Impact
*   **Total Sales:** $32,400.00
*   **Total Purchases:** $16,630.00
*   **Net Cash Flow:** $15,770.00 Credit
*   **Tax Impact:** The trades generated **$13,675 in long-term capital gains** in the taxable account. Total projected net capital gains for Tax Year 2024 are approximately $14,500.
