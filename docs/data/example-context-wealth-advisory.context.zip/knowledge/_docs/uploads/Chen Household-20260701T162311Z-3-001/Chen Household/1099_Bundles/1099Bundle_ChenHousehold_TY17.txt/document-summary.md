## Document Summary

This document is a tax package containing Form 1099 bundle details for the Chen Household (Alex & Sam Chen) for Tax Year 2017, issued by Fidelity Institutional (CUST-FI-001) for account ACCT-TX01.

### Current Financial Situation and Holdings
* **Joint Taxable Brokerage Account (ACCT-TX01):** Holds/held assets including UECIX, IDEIX, MUNIX, NLTK, UCBIX, and STBIX.
* **1099-DIV Summary:** Total ordinary dividends of $975.18, qualified dividends of $780.14, and tax-exempt interest dividends of $316.22 (from MN Municipal Bond Fund MUNIX, exempt from federal and MN state tax).
* **1099-INT Summary:** Interest income of $348.90.
* **1099-B Summary:** Long-term transactions resulted in total proceeds of $43,231.00 and a cost basis of $39,427.00, yielding a net realized long-term capital gain of $3,804.00. Sales occurred in UECIX, UCBIX, IDEIX, NLTK, and STBIX due to annual/year-end rebalancing, trims, and a partial RSU sale.
* **1099-R Summary:** Alex Chen executed a direct rollover of $47,250.00 (Distribution Code G) from a former employer's 401(k) plan (ACCT-401R) to a Fidelity Institutional Rollover IRA (ACCT-IRA1). No taxable income or tax withholding applied to this transaction.
