## Document Summary

### Document Summary

* **Household Context & Goals**: Alex Chen has separated from his prior employer and is starting new employment at Clearwater Technology, Inc. in Q3 2017. He expects to begin receiving equity compensation (RSUs) in Q1 2018. The goal is to safely roll over his accumulated employer 401(k) retirement funds into a consolidated wealth management structure.
* **Current Financial Situation & Holdings**: Alex Chen holds a prior employer 401(k) balance of approximately $62,000 to $68,000. These positions will be fully liquidated prior to transfer.
* **Recommendations**: 
  * Execute a direct rollover of the full 401(k) balance to a new tax-deferred Rollover IRA (**ACCT-401R**) at Fidelity Institutional, avoiding any withholding taxes.
  * Invest the received cash in ACCT-401R according to the existing investment policy statement (**DOC-IPS-2016-001**), specifically focusing on the Fixed Income and TIPS sleeve for IRA accounts.
  * Consolidate ACCT-401R into Alex's existing IRA (**ACCT-IRA1**) by March 31, 2018, to simplify his overall account structure.
* **Action Items & Decisions**:
  * **Alex Chen / Prior Plan Administrator**: Issue a direct rollover check payable to Fidelity Institutional FBO Alex Chen IRA.
  * **Morgan Park (Advisor)**: Allocate the rollover assets into the Fixed Income / TIPS sleeve upon receipt and execute the plan to merge ACCT-401R into ACCT-IRA1 by March 31, 2018.
  * **Morgan Park (Advisor)**: Monitor upcoming 2018-Q1 RSU grants to review potential concentration risks and update the IPS.
