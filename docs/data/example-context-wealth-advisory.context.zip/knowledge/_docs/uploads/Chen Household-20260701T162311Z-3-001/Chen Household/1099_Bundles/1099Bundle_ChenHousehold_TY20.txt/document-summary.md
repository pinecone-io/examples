## Document Summary

This document is a tax year 2020 Form 1099 bundle prepared by Fidelity Institutional for the Alex & Sam Chen household (Household ID: HH-CHEN-001) regarding their Joint Taxable Brokerage account (Account: ACCT-TX01 ...7412).

### Financial Situation and Holdings
* **Income Received (Tax Year 2020):** 
  * **Total Ordinary Dividends (Box 1a):** $1,104.72
  * **Qualified Dividends (Box 1b):** $883.78
  * **Exempt-Interest Dividends (Box 12):** $452.30 (from MUNIX, the MN Municipal Bond Fund, which is exempt from federal and Minnesota state income taxes).
  * **Interest Income (Box 1):** $462.88
* **Realized Gains/Losses:** The household realized a net long-term capital gain of $12,004.00 from sales proceeds of $112,312.00 against a cost basis of $100,308.00. No short-term transactions or wash sale disallowed losses were reported.

### Recommendations & Executed Decisions
The document details transaction activities executed under the IPS-2020 reallocation framework, including:
* **UECIX:** Sold 3,500 shares on June 16, 2020, for proceeds of $45,500.00 (Gain: $4,900.00) under DecisionID-2020-044.
* **IDEIX:** Sold 2,800 shares on June 18, 2020, for proceeds of $32,200.00 (Gain: $3,360.00) to reduce international equity exposure.
* **EMEIX:** Sold 1,500 shares on June 22, 2020, for proceeds of $16,500.00 (Gain: $2,850.00) to reduce emerging markets exposure.
* **UCBIX:** Sold 1,000 shares on June 24, 2020, for proceeds of $10,200.00 (Gain: $790.00) for minor bond rebalancing.
* **REITX:** Sold 800 shares on September 14, 2020, for proceeds of $7,912.00 (Gain: $104.00) as part of a "Post-COVID trim."
