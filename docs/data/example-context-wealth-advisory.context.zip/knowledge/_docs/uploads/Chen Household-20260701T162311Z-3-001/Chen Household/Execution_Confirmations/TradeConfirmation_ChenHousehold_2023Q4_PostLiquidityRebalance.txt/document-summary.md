## Document Summary

This document confirms a post-liquidity event trade execution on December 11, 2023, to rebalance the portfolio of Alex and Sam Chen back to their IPS-2020 targets (60/35/5) and deploy year-end college savings contributions.

### Portfolio Context & Rationale
Following the April 2023 concentration reduction of NLTK, proceeds were reinvested in UECIY and IDEIY, which left the household's portfolio slightly equity-overweight. This Q4 2023 trade executes a small equity trim and fixed income rebuild to restore target allocations, with no material tax impact.

### Executed Transactions
*   **Equity Trim:** Sold 100 shares of US Equity Core Index Fund (UECIY) at $80.00/share ($8,000.00 total) from the Joint Taxable Brokerage Account (ACCT-TX01). Sold at cost (April 2023 basis), resulting in $0 capital gain.
*   **Fixed Income Rebuild:** 
    *   Purchased 500 shares of Municipal Bond Fund (MUNIX) at $9.70/share ($4,850.00 total) in the Joint Taxable Brokerage Account.
    *   Purchased 500 shares of US Core Bond Index Fund (UCBIX) at $9.40/share ($4,700.00 total) in Alex's Traditional IRA (ACCT-IRA1).
*   **Education Savings:** Deployed year-end household cash contributions to the 529 plans for Maya (ACCT-529A) and Eli (ACCT-529B), purchasing 400 units of the 529 Age-Based Moderate Index Portfolio in each account at $11.20/unit ($4,480.00 per plan; $8,960.00 combined).

### Financial and Tax Summary
*   **Total Purchases:** $18,510.00
*   **Total Sales:** $8,000.00
*   **Net Cash Flow:** $10,510.00 debit
*   **Tax Impact:** Minimal to none for this transaction; total net capital gains for the Chen household in 2023 remain at approximately $42,000.
