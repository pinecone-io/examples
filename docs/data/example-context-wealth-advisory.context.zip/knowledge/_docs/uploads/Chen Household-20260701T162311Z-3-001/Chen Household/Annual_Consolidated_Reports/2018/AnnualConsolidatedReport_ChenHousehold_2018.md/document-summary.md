## Document Summary

### Year-End 2018 Portfolio Review & Household Milestones
During 2018, the Chen household achieved a major financial milestone with Alex’s promotion and the receipt of the first tranche of NLTK Restricted Stock Units (RSUs) in Q2, introducing equity compensation management into their financial plan. Despite a volatile market environment (with the S&P 500 down 6.2% and international equities down 13.4%), the household portfolio grew modestly to **$608,000** (up from $595,000), driven by $55,000 in net contributions and a defensive fixed-income sleeve that cushioned equity declines. 

Additionally, Alex's former 401(k) (ACCT-401R) was successfully consolidated into his Traditional IRA (ACCT-IRA1) in March 2018. The household's adjusted gross income (AGI) reached approximately $260,500, triggering the Net Investment Income Tax (NIIT) for the first time.

### Financial Goals & Risk Profile
*   **Retirement Readiness (GoalID-2016-01):** On track with ~22 years to retirement. AUM is resilient, with progress expected to accelerate using NLTK equity compensation.
*   **Education Funding (GoalID-2016-02):** Urgent/Pending. The 529 accounts for Maya (age 7) and Eli (age 4) remain unopened. Opening them is marked as an overdue, high priority for Q1 2019.
*   **Emergency Liquidity (GoalID-2016-03):** On track with cash reserves of ~$45,000 (about 4–5 months of expenses), with a target of 6–9 months.

### Key Recommendations and Action Items
1.  **Open 529 Accounts (Immediate Priority - Q1 2019):** Open ACCT-529A and ACCT-529B to capture tax-advantaged growth as the children's horizons shorten.
2.  **NLTK Equity Diversification:** Establish a systematic diversification plan to manage concentration risk. Currently, the 480 retained NLTK shares in ACCT-TX01 are worth ~$24,000 (~4% of total AUM), which is within the <10% IPS limit.
3.  **Estate Planning Consultation:** Initiate revocable trust formation in 2019 and realign beneficiary designations afterwards.
