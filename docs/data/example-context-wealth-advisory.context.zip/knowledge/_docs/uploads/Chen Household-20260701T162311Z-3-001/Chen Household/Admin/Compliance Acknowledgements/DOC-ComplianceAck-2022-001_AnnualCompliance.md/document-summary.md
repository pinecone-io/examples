## Document Summary

This document is an Annual Compliance Acknowledgement for the Chen Household (Alex & Sam Chen) for the review period January 1 to December 31, 2022. It lists annual disclosure deliveries (including Form ADV Part 2A/2B and Form CRS), confirms suitability, reviews account details, and documents key planning actions taken during a turbulent bear market year.

### Household Context & Risk Profile
- **Risk Score / Profile:** 54/100, which corresponds to a **Conservative-Moderate** risk tolerance.
- **Asset Allocation:** Target allocation is 58% Equity / 37% Fixed Income / 5% Cash under active Investment Policy Statement (IPS) version `DOC-IPSAmendment-2020-001`.

### Financial Situation & Holdings
Total Household AUM at year-end was **$890,000**, with the following account balances:
- **TX01 (Taxable Joint):** $450,000
- **IRA1 (Alex IRA):** $325,000
- **RIRA (Sam Roth IRA):** $73,000
- **CASH (Cash/Liquidity):** $31,000
- **529A (Alex Jr. — College):** $5,500
- **529B (Sam — College):** $5,500

The estimated annual advisory fee is $7,900, governed by a tiered fee schedule of 0.85% on the first $1,500,000 of AUM.

### Recommendations & Key Decisions (2022)
- **Tax-Loss Harvesting (TLH):** Executed a systematic TLH campaign in September 2022 (DecisionID-2022-301), realizing approximately **-$31,000 in net capital losses** available for future carryforward.
- **Roth Conversion:** Evaluated and executed a partial Roth conversion in Alex's traditional IRA (IRA1).
- **Equity Compensation:** Issued RSU equity compensation planning memos during the year.
- **Education Savings:** Continued contributions to the 529A and 529B plans despite modest market declines.
