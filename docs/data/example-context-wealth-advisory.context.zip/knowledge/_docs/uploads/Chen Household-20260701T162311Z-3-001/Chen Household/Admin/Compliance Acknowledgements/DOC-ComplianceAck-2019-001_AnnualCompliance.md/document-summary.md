## Document Summary

This document is an Annual Compliance Acknowledgement for the Chen Household (Alex & Sam Chen) for the review period January 1 to December 31, 2019, reviewed on January 12, 2020, by Morgan Park, CFP® of Clearwater Wealth Partners.

### Household Context, Goals, and Risk Tolerance
- **Household:** Alex & Sam Chen (HH-CHEN-001).
- **Risk Profile:** Moderate Growth (Investment Policy Statement DOC-IPS-2016-001 remains active).
- **Risk Score:** 68/100.
- **Target Allocation:** 71% Equity / 27% Fixed Income / 2% Cash.

### Financial Situation and Holdings
- **Total Household AUM:** $732,000 as of year-end (reflecting net growth of $124,000 during the year after a strong equity recovery).
- **Account Balances:**
  - TX01 (Taxable Joint): $350,000
  - IRA1 (Alex IRA): $270,000
  - RIRA (Sam Roth IRA): $60,000
  - CASH (Cash/Liquidity): $52,000
- **Advisory Fee:** 1.00% flat annual fee on AUM, estimated at $6,700, charged quarterly in arrears by custodian Fidelity Institutional.

### Recommendations, Decisions, and Material Events
- **Trust Establishment (EventID-2019-01):** The Chen Family Revocable Trust (DOC-Trust-2019-001) was established. The TX01 account was successfully re-registered to the trust, and a new CASH liquidity account was opened at Fidelity for trust cash management (both are titling changes only with no liquidation or tax consequences).
- **Tax-Loss Harvesting:** Assessed during the review period but not executed due to the strong market recovery.
- **Suitability:** The investment strategy under the active IPS was confirmed as remaining suitable.
