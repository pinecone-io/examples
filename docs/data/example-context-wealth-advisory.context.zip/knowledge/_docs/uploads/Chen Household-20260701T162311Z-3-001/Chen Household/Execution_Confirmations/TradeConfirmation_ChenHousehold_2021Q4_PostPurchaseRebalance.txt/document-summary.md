## Document Summary

This document records trade execution confirmations from Fidelity Institutional Wealth Services executed on December 13, 2021, and settling on December 14, 2021. The purpose of these transactions was to implement a post-home purchase portfolio rebuild and quarterly rebalance following a Q3 home purchase down payment liquidation. The trades aim to re-establish the portfolio's IPS-2020 target allocation of 60% equities, 35% fixed income, and 5% cash.

### Financial Situation and Holdings
- **Joint Taxable Brokerage (ACCT-TX01):** Sold 300 shares of IDEIX (Intl Developed Equity Index Fund) for $10,200 (realizing a long-term capital gain of $1,875) and 30 shares of EMEIX (Emerging Markets Equity Index Fund) for $870 (realizing a long-term capital gain of $330). Bought 600 shares of MUNIX (Municipal Bond Fund) for $6,180 to rebuild the fixed income allocation.
- **Alex Roth IRA (ACCT-RIRA):** Bought 500 shares of USCIX (US Small Cap Index Fund) for $20,500 to capture a growth tilt.
- **Alex Traditional IRA (ACCT-IRA1):** Bought 300 shares of UCBIX (US Core Bond Index Fund) for $3,180 to rebuild the 35% core fixed income target.

### Key Metrics
- **Total Purchased (BUY orders):** $29,860.00
- **Total Proceeds (SELL orders):** $11,070.00
- **Net Cash Flow Debit:** $18,790.00
- **Tax Impact:** Realized ~$2,205 in long-term capital gains for Q4 2021, bringing grand total 2021 net capital gains to ~$18,500 (associated with the GoalID-2016-03 home purchase year).
