## Document Summary

### Document Summary

* **Household Context, Goals, and Risk Tolerance**: Alex and Sam Chen (HH-CHEN-001) are in the process of purchasing a primary residence at 3215 Lakeview Circle, Wayzata, MN. Their goals include funding the down payment and closing costs for this property while subsequently maintaining retirement readiness (GoalID-2016-01) and emergency liquidity (GoalID-2016-03).
* **Current Financial Situation and Holdings**: The household holds a Joint Taxable Brokerage Account (ACCT-TX01) at Fidelity Institutional (CUST-FI-001) under a 60/35/5 asset allocation. To fund the home purchase, a distribution of $55,000.00 is required via wire transfer to their checking account.
* **Recommendations, Decisions, and Action Items**:
  * **Liquidation Plan**: The advisor, Morgan Park, authorized the liquidation of approximately $20,000 in MUNIX (long-term, FIFO), $20,000 in UECIX (long-term, highest cost basis), and $15,000 in STBIX (pro-rata).
  * **Post-Distribution Actions**: Monitor potential IPS drift relative to the IPS-2020 targets (60/35/5), proposing a rebalancing trade if drift exceeds ±4%. Ensure 6–9 months of expenses remain in their emergency cash fund. Coordinate with Lisa Torres, EA, regarding mortgage interest deductibility and 2021 tax itemized deductions, including AMT/NIIT implications of estimated capital gains of $4,200 to $7,500.
