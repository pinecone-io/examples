## Document Summary

This document records trade executions confirming the deployment of annual household investment contributions for Alex and Sam Chen in Q1 2022. Transactions were executed on March 15, 2022, with a settlement date of March 16, 2022, using cash from new contributions and no portfolio rebalancing.

### Financial Situation and Execution Detail
A total of $82,820.00 was deployed across three accounts managed through Fidelity Institutional Wealth Services:
- **Joint Taxable Brokerage (ACCT-TX01)**:
  - Purchased 600 shares of **US Equity Core Index Fund (UECIX)** at $85.00/share (Total: $51,000.00). This high-basis lot is specifically flagged as relevant to future Q3 2022 Tax-Loss Harvesting (TLH) planning.
  - Purchased 350 shares of **Intl Developed Equity Index Fund (IDEIX)** at $32.00/share (Total: $11,200.0).
- **Alex Traditional IRA (ACCT-IRA1)**:
  - Purchased 1,100 shares of **US Core Bond Index Fund (UCBIX)** at $9.20/share (Total: $10,120.00), acquiring bonds at a lower NAV due to rising rates.
- **Alex Roth IRA (ACCT-RIRA)**:
  - Purchased 250 shares of **US Small Cap Index Fund (USCIX)** at $42.00/share (Total: $10,500.00).

### Rationale and Future Decisions
New contributions were deployed following the market sell-off beginning in January 2022, allowing the household to establish new tax lots at lower prices than late 2021 peaks. No capital gain or loss events occurred. The newly established taxable lots (UECIX at $85.00 and IDEIX at $32.00) are noted as key components for a planned Q3 2022 Tax-Loss Harvesting campaign (DecisionID-2022-301).
