## Document Summary

### Executive Summary
The Chen household (Alex & Sam Chen) experienced strong portfolio growth in 2017, with total Assets Under Management (AUM) rising to $595,000 (up 22.4% from $486,000, supported by $52,000 in net contributions). A key milestone was completing the direct rollover of Alex's prior employer 401(k) into a Rollover IRA. Looking ahead, tax planning is a critical focus due to the newly signed Tax Cuts and Jobs Act (TCJA) and Alex's upcoming equity compensation (RSUs) starting in 2018.

### Financial Goals & Risk Tolerance
* **Retirement Readiness (GoalID-2016-01):** On track for retirement around age 60 (approx. 2043). The investment portfolio aligns with a 70% Equity / 28% Fixed / 2% Cash target allocation.
* **Education Funding (GoalID-2016-02):** Pending. Opening 529 accounts for children Maya (6) and Eli (3) is a critical priority for Q1 2018.
* **Emergency Liquidity (GoalID-2016-03):** Building. Currently holds ~$52,000 in cash, approaching the 4–5 month target with an ultimate goal of 6–9 months.

### Current Financial Situation & Holdings
* **Taxable Joint Account (ACCT-TX01):** ~$320,000
* **Alex Traditional IRA (ACCT-IRA1):** ~$215,000 (includes the recently rolled-over 401(k))
* **Alex Roth IRA (ACCT-RIRA):** ~$60,000
* **Cash Management (ACCT-CASH):** ~$52,000

### Recommendations & Key Action Items
1. **Consolidate Rollover IRA:** Fully merge ACCT-401R into ACCT-IRA1 by March 31, 2018.
2. **Open 529 Accounts:** Establish ACCT-529A and ACCT-529B in Q1 2018.
3. **TCJA Modeling:** Advisor to deliver a tax-impact planning memo in early 2018 following the tax reform.
4. **Equity Compensation Planning:** Prepare for concentration risk and tax timing of Alex's upcoming RSU vesting (NLTK) in 2018.
5. **Estate Planning & Beneficiaries:** Schedule a formal estate consultation (Westfield & Baker LLP) and complete the beneficiary review form (DOC-BeneficiaryForm-2018-001).
