## Document Summary

This document is a Tax Year 2025 Form 1099 Bundle from Fidelity Institutional for the joint taxable brokerage account (ACCT-TX01) of Alex & Sam Chen.

### Financial Situation and Holdings
* **Dividends & Interest:** The account generated $1,387.44 in total ordinary dividends (with $1,109.95 classified as qualified dividends) and $965.20 in interest income.
* **Tax-Exempt Income:** The account received $984.00 in exempt-interest dividends from MUNIX (Minnesota Municipal Bond Fund), which are exempt from both federal and Minnesota state income taxes.
* **Capital Gains:** The household realized a net long-term capital gain of $16,000.00 on total proceeds of $123,110.00 (cost basis of $107,110.00). No short-term transactions or wash sales were reported.

### Portfolio Decisions and Transactions
The realized gains stem from several strategic rebalancing and liquidity trades executed throughout 2025:
* **UECIY:** Sold 3,000 shares for $48,000.00 ($7,500.00 gain) on February 18, 2025, as a Bucket-3 equity trim.
* **UCBIX:** Sold 2,000 shares for $20,400.00 ($1,600.00 gain) on February 20, 2025, to shift assets to STBIX for Bucket-2 rebalancing.
* **IDEIY:** Sold 1,500 shares for $19,500.00 ($2,250.00 gain) on March 5, 2025, for an international equity trim.
* **UTIPX:** Sold 1,000 shares for $10,500.00 ($1,300.00 gain) on July 14, 2025, for a Bucket-2 TIPS adjustment.
* **MUNIX:** Sold 1,400 shares for $14,630.00 ($2,352.00 gain) on September 22, 2025, following a tax-efficiency review.
* **STBIX:** Sold 1,000 shares for $10,080.00 ($998.00 gain) on December 18, 2025, as a year-end liquidity adjustment.
