## Document Summary

### Document Summary

* **Household Context & Goals**: Alex & Sam Chen (Household ID: HH-CHEN-001) are working with CFP® Morgan Park of Clearwater Wealth Partners. The transaction aligns with their Investment Policy Statement (IPS-2016), which specifies an asset allocation of 70% Equity, 28% Fixed Income, and 2% Cash. Tax-deferred accounts are designed to hold bond-tilted allocations for tax-aware placement. 
* **Current Financial Situation & Holdings**: A direct trustee-to-trustee 401(k) rollover from Alex's prior employer plan was received on August 15, 2017, into a newly opened 401(k) Rollover IRA subaccount (ACCT-401R) with pre-tax cost basis. Total rollover proceeds of $91,995.60 were settled on August 16, 2017, without any tax or withholding penalties.
* **Recommendations & Decisions**: The funds were immediately deployed into two bond-tilted index funds within ACCT-401R:
  * **US Core Bond Index Fund (UCBIX)**: Purchased 6,078 shares at $10.20/share ($61,995.60 gross value).
  * **US Treasury & TIPS Fund (UTIPX)**: Purchased 3,125 shares at $9.60/share ($30,000.00 gross value).
* **Action Items**: ACCT-401R is scheduled to be consolidated into the main IRA account (ACCT-IRA1) by March 31, 2018.
