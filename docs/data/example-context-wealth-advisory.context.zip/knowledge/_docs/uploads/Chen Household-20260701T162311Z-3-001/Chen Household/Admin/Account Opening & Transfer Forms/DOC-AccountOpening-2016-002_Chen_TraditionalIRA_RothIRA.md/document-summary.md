## Document Summary

### Document Summary: New IRA Account Application

- **Household Context & Goals**: Alex Chen, a married U.S. citizen (age 32 at account opening, DOB March 22, 1981), established two IRAs on February 1, 2016, to support retirement goal `GoalID-2016-01`. Alex has a moderate growth risk profile (score 68/100) and a long-term investment horizon (25+ years, distributions expected around age 60).
- **Account Opening & Objectives**:
  - **Traditional IRA (ACCT-IRA1)**: Objective is "Growth with Income" utilizing core bonds, TIPS, and an equity sleeve for rebalancing. This account will also serve to receive a direct rollover of a prior employer 401(k) planned for Q3 2017.
  - **Roth IRA (ACCT-RIRA)**: Objective is "Aggressive Growth" utilizing a small cap and emerging markets tilt, taking advantage of a long time horizon.
- **Funding**: Each account was initially funded with a 2016 contribution of $5,500 via Alex's personal checking account. Future annual contributions will be maximized subject to income and IRS limits.
- **Beneficiary Designations**: For both accounts, spouse Sam Chen (DOB November 2, 1984) is designated as the 100% primary beneficiary. Children Maya Chen (DOB August 19, 2011) and Eli Chen (DOB March 7, 2014) are designated as contingent beneficiaries (50% each).
- **Future Planning**: Beneficiary designations will be reviewed upon the establishment of a revocable trust anticipated in 2019.
