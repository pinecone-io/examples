## Document Summary

### Document Summary

This compliance acknowledgment records the annual suitability and disclosure review for the Chen household (Alex & Sam Chen) conducted by Morgan Park, CFP® on January 14, 2018. It covers the review period of January 1 to December 31, 2017.

#### Household Context, Goals, and Risk Tolerance
- **Household**: Alex & Sam Chen (HH-CHEN-001)
- **Risk Tolerance Score**: 68/100 (Moderate Growth)
- **Investment Strategy**: Under the active IPS (DOC-IPS-2016-001), the household maintains a Moderate Growth profile designed with a target allocation of 72% Equity, 26% Fixed Income, and 2% Cash. The suitability review confirmed that this risk profile and investment strategy remain appropriate.

#### Financial Situation and Holdings
- **Total Household AUM**: $595,000 as of year-end (up $109,000 net of fees due to strong equity market performance).
- **Account Balances**:
  - **TX01 (Taxable Joint)**: $303,000
  - **IRA1 (Alex IRA)**: $224,000
  - **RIRA (Sam Roth IRA)**: $68,000
- **Custodian**: Fidelity Institutional (CUST-FI-001)
- **Advisory Fee**: 1.00% flat annual advisory fee on AUM, charged quarterly in arrears. The estimated annual advisory fee paid for the period was $5,100 (representing 1.00% on average AUM of approximately $541,000).

#### Recommendations, Decisions, and Action Items
- **Decisions**: Maintained the existing Moderate Growth allocation; no IPS amendments were made. No new accounts were opened or closed during the period.
- **Disclosures**: Handed over standard annual disclosures including Form ADV Part 2A/2B (March 2017 Edition), Morgan Park's Brochure Supplement, the Privacy Policy, the Business Continuity Plan Summary, and the Proxy Voting Policy Disclosure.
- **Conflicts of Interest**: No conflicts of interest were identified; the advisor is compensated solely by the advisory fee.
