## Document Summary

This document is an **Annual Compliance Acknowledgement** (DOC-ComplianceAck-2025-001) for the **Alex & Sam Chen** household (HH-CHEN-001) for the review period from January 1 to December 31, 2025. Prepared by financial adviser **Morgan Park, CFP®** of **Clearwater Wealth Partners**, the review took place on January 12, 2026. The document outlines delivered disclosure documents (such as Form ADV Part 2A/2B, Form CRS, and the Privacy Policy), confirms suitability of the active Investment Policy Statement (IPS), details current holdings, and reviews material plan changes made during 2025.

### Household Context, Goals, and Risk Tolerance
* **Risk Profile:** Moderate (score of 58/100, showing a slight increase from the previous score of 56).
* **Investment Strategy:** Moderate / Three-Bucket Strategy under active IPS amendment (DOC-IPSAmendment-2025-001), executed in January 2025. It targets a **62% Equity / 33% Fixed Income / 5% Cash** asset allocation.
* **Key Milestones:** Alex Chen is approaching the pre-retirement phase, triggering Social Security optimization modeling. 529 plans for college are on track.

### Financial Situation and Holdings
As of the year-end review, the total Household Assets Under Management (AUM) is **$1,445,000** (listed as $1,450,000 in summary tables), distributed as follows:
* **TX01 (Taxable Joint):** $760,000
* **IRA1 (Alex IRA):** $490,000
* **RIRA (Sam Roth IRA):** $105,000
* **CASH (Cash/Liquidity):** $45,000
* **529A (Alex Jr. — College):** $22,500
* **529B (Sam — College):** $22,500

Advisory fees are tiered at **0.85%** on the first $1,500,000 (DOC-FeeAmendment-2021-001), generating an estimated annual fee of $12,000 based on an average AUM of approximately $1,368,000.

### Material Decisions and Planning Activities
* **Three-Bucket Retirement Strategy:** Implemented in January 2025 (EventID-2025-01). Bucket 1 (Liquidity) maintains 2–3 years of expenses in cash/short-term instruments; Bucket 2 targets Income; Bucket 3 targets Growth.
* **Tax Planning:** Implemented a multi-year Roth conversion ladder (TAX-2025-001) and accelerated charitable strategies (TAX-2025-002) in response to the Tax Cuts and Jobs Act (TCJA) provisions sunsetting on December 31, 2025.
* **Education Planning:** Maintained equity allocation for the 529 college savings accounts (529A and 529B), which remain on track.
