## Document Summary

This document is the 2024 Annual Compliance Acknowledgement for the Chen Household (Alex & Sam Chen), reviewed on January 13, 2025, by advisor Morgan Park, CFP® of Clearwater Wealth Partners. 

### Household Context, Goals, and Risk Tolerance
The household has a Conservative-Moderate risk profile (Risk Questionnaire Score of 56/100) under their active Investment Policy Statement (DOC-IPSAmendment-2020-001). In 2024, the household experienced a significant life event: Sam Chen received a serious medical diagnosis. This prompted mid-year reviews of their estate planning, liquidity needs, and educational timelines, though their overall investment strategy and target asset allocation (62% Equity / 33% Fixed Income / 5% Cash) remained unchanged.

### Financial Situation and Holdings
The household's total Assets Under Management (AUM) crossed the $1.25M threshold, ending the year at $1,285,000, distributed as follows:
*   **TX01 (Taxable Joint):** $700,000
*   **IRA1 (Alex IRA):** $430,000
*   **RIRA (Sam Roth IRA):** $95,000
*   **CASH (Cash/Liquidity):** $25,000
*   **529A (Alex Jr. — College):** $17,500
*   **529B (Sam — College):** $17,500

Advisory fees are charged quarterly in arrears under a tiered schedule of 0.85% on the first $1,500,000 AUM, resulting in an estimated annual advisory fee of $10,600. Accounts are custodianed with Fidelity Institutional.

### Recommendations and Key Decisions
*   **Estate Planning Acceleration:** Beneficiary designations were fully reviewed and updated across all accounts in coordination with the clients' external legal counsel. Sam Chen was designated as the primary beneficiary on all retirement accounts.
*   **Emergency Liquidity:** Conducted an emergency liquidity review and decided to maintain the CASH account at a strict $25,000 minimum.
*   **Education Funding:** Significantly increased contributions to the 529A and 529B accounts in response to adjusted educational timelines.
*   **IPS Status:** Initiated a mid-year IPS review following the health event; however, no amendments were executed, pending the broader 2025 review.
