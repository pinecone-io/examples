## Document Summary

This document consists of the tax year 2026 Form 1099 bundle (1099-DIV, 1099-INT, and 1099-B) issued by Fidelity Institutional (CUST-FI-001) for the Joint Taxable Brokerage Account (ACCT-TX01 ending in ...7412) belonging to Alex & Sam Chen (Household ID: HH-CHEN-001).

### Financial Situation and Holdings
- **Taxable Account:** ACCT-TX01 (Joint Taxable Brokerage)
- **Dividends & Interest:** Received $1,435.56 in total ordinary dividends (of which $1,148.45 were qualified), $1,048.40 in interest income, and $1,066.80 in exempt-interest dividends from the Minnesota Municipal Bond Fund (MUNIX), which is exempt from federal and MN state income tax.
- **Sales & Realized Gains:** Six long-term sales of securities were executed throughout 2026, generating total proceeds of $123,180.00 against a cost basis of $105,180.00, resulting in a net realized long-term capital gain of $18,000.00. No short-term or wash sale transactions were recorded.

### Transactions and Rebalancing Activities
- **UECIY:** Sold 2,800 shares on 2026-02-26 for $47,600.00 (Cost basis: $39,200.00, Gain: $8,400.00) for Q1 equity rebalancing.
- **IDEIY:** Sold 1,600 shares on 2026-04-14 for $21,600.00 (Cost basis: $19,040.00, Gain: $2,560.00) for Q2 international rebalancing.
- **UCBIX:** Sold 1,800 shares on 2026-06-10 for $18,450.00 (Cost basis: $16,974.00, Gain: $1,476.00) for Q2 bond trimming.
- **MUNIX:** Sold 1,300 shares on 2026-09-08 for $13,780.00 (Cost basis: $12,038.00, Gain: $1,742.00) for Q3 muni rebalancing and Bucket 2 top-up.
- **UTIPX:** Sold 1,100 shares on 2026-10-15 for $11,660.00 (Cost basis: $8,690.00, Gain: $2,970.00) for Q4 TIPS trimming.
- **STBIX:** Sold 1,000 shares on 2026-12-10 for $10,090.00 (Cost basis: $9,238.00, Gain: $852.00) for year-end sweep and marking a 10-year relationship milestone.
