## Document Summary

This document is a New Account Application for a Taxable Brokerage Account (Joint Tenants With Rights of Survivorship) established for the Chen Household at Clearwater Wealth Partners with Fidelity Institutional as custodian. 

### Household Context, Goals, and Risk Tolerance
- **Household:** Alex Chen (Primary, b. 1981, Software Product Leader) and Sam Chen (Joint/Spouse, b. 1984, Marketing Director).
- **Investment Objective:** Growth with Income.
- **Risk Tolerance:** Moderate Growth (Risk Questionnaire score: 68/100).
- **Time Horizon:** Long-term (20+ years, targeting retirement at ~age 60).

### Financial Situation and Holdings
- **Account ID:** ACCT-TX01.
- **Combined Household Income:** $195,000 – $240,000.
- **Approximate Net Worth:** $600,000 – $800,000 ($380,000 – $430,000 liquid net worth).
- **Target Asset Allocation:** 70% Equity / 28% Fixed / 2% Cash (per Investment Policy Statement DOC-IPS-2016-001).
- **Initial Funding:** $245,000 via wire transfer.

### Recommendations & Decisions
- Opened a joint taxable account (JTWROS) managed under an Advisory Agreement (1.00% annual flat fee) concurrent with a new advisory relationship.
- Dividends are set to reinvest.
- Primary beneficiary is set to Sam Chen (100%), with children Maya Chen (50%) and Eli Chen (50%) as contingents.
- Beneficiary designations are slated to be reviewed upon the anticipated creation of a revocable trust in 2019.
