## Document Summary

### Executive Summary

* **Household Context & Goals**: Alex & Sam Chen are staging approximately $79,000 in cash to fund the down payment for a home purchase at 7841 Cedar Ridge Dr, Wayzata, MN 55391 (referred to in transaction notes as EventID-2021-01 / 3215 Lakeview Circle). This purchase is supported by a 30-year fixed mortgage at 3.10% via Lakeside Mortgage Co.
* **Financial Situation & Holdings**: The funds were raised by liquidating selected equity and bond positions within the household's Joint Taxable Brokerage Account (ACCT-TX01). A total of $78,920.00 was raised through trades executed on July 8, 2021, and settled on July 9, 2021. The positions sold include:
  * **UECIX** (US Equity Core Index Fund): 325 shares sold at $80.00/sh (Gross: $26,000.00; LT Gain: $13,000)
  * **IDEIX** (Intl Developed Equity Index Fund): 300 shares sold at $34.00/sh (Gross: $10,200.00; LT Gain: $2,700)
  * **MUNIX** (Municipal Bond Fund): 1,500 shares sold at $10.30/sh (Gross: $15,450.00; LT Gain: $450)
  * **STBIX** (Short-Term Bond / Cash Equiv Fund): 2,700 shares sold at $10.10/sh (Gross: $27,270.00; LT Gain: $270)
* **Recommendations & Tax Implications**: To minimize capital gains, a tax-efficient execution order was utilized, selecting highest-basis lots first (liquidating oldest February 2016 lots for UECIX and IDEIX). The liquidations generated a total of $16,420.00 in long-term capital gains for the 2021 tax year. This aligns with a temporary liquidity carve-out under their IPS-2020 guidelines.
* **Action Items**: 
  * Transfer the $78,920.00 in total trade proceeds to the Cash Management Account (ACCT-CASH) to facilitate the wire transfer to escrow.
  * Rebuild the portfolio toward IPS-2020 target allocations post-closing.
