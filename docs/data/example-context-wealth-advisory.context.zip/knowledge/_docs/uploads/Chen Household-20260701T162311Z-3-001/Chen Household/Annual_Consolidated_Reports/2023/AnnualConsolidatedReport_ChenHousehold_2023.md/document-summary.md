## Document Summary

### Executive Summary

2023 was a landmark year for the Chen Household, characterized by a significant liquidity event, crossing the $1,000,000 AUM milestone, and implementing complex tax-planning strategies under advisor Morgan Park, CFP®, and tax specialist Lisa Torres, EA. 

### Household Context, Goals, and Risk Tolerance
* **Retirement Readiness (GoalID-2016-01):** The retirement projection confidence level increased from ~72% to ~84% ($185k/year target over a 30-year horizon) following the year's liquidity event.
* **Education Funding (GoalID-2016-02):** Funding for Maya (age 12) and Eli (age 9) stands at $7,500 each. Current savings rates are falling short of fully funding four-year college costs.
* **Emergency Liquidity (GoalID-2016-03):** The cash balance is below the $35,000–$50,000 target range due to high spending and reallocation activities.
* **Values-Based Giving (GoalID-2023-01):** The Clearwater Giving Fund (DAF) was successfully established to fulfill charitable objectives and optimize tax deductions.

### Financial Situation and Holdings
The household total AUM ended 2023 at $1,140,000, distributed across the following accounts:
* **ACCT-TX01 (Taxable Brokerage - Joint):** $620,000 (including a reduced ~5% concentration of NLTK single stock)
* **ACCT-IRA1 (Alex Traditional IRA):** $395,000
* **ACCT-RIRA (Alex Roth IRA):** $85,000
* **ACCT-CASH (Cash Management):** $25,000 (below target)
* **ACCT-529A / B (Maya / Eli 529s):** $7,500 each
* **Clearwater Giving Fund (DAF):** ~$25,000 (not included in AUM)

### Recommendations and Tax-Planning Decisions
* **NLTK Diversification (DecisionID-2023-349):** An RSU vesting caused NLTK stock concentration to rise to ~9%, breaching the 7% Investment Policy Statement (IPS) limit. Under a three-phase plan executed from April to June 2023, ~$38,000 in NLTK was sold/transferred, reducing exposure to ~5%. 
* **DAF Bunching Strategy (TaxTopicID-2023-01):** To offset an AGI spike to ~$426,000, the household contributed $25,000 in appreciated NLTK shares to the DAF, securing a full deduction while avoiding capital gains taxes.
* **Tax Offsets:** A 2022 capital loss carryforward of $12,500 was applied against $42,000 in realized gains, resulting in net taxable gains of ~$29,500.

### Action Items for 2024
* **Rebuild Cash Buffer:** Rebuild ACCT-CASH to the target $40,000–$50,000 range in H1 2024.
* **Increase 529 Contributions:** Review and increase contributions for Maya and Eli in Q1 2024.
* **Estate Planning:** Execute an estate and beneficiary audit in Q1 2024.
