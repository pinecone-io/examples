## Document Summary

This document is an annual compliance acknowledgement for the Chen household (Alex & Sam Chen) for the review period from January 1 to December 31, 2018. Prepared by Morgan Park of Clearwater Wealth Partners, the review was conducted on January 13, 2019.

### Household Context, Goals, and Risk Tolerance
- **Household:** Alex & Sam Chen.
- **Risk Profile:** Moderate Growth, supported by a risk questionnaire score of 66/100 (a slight decline from 68/100, though the overall risk profile remains unchanged).
- **Investment Policy Statement (IPS):** The active IPS (DOC-IPS-2016-001) for a Moderate Growth (70/30) strategy was confirmed as remaining suitable for the household's objectives, liquidity needs, and risk tolerance.

### Financial Situation and Holdings
- **Total Household AUM:** $608,000 as of year-end 2018. Accounts are custodied with Fidelity Institutional (CUST-FI-001):
  - Taxable Joint (TX01): $309,000
  - Alex IRA (IRA1): $229,000
  - Sam Roth IRA (RIRA): $70,000
- **Fees:** Billed at a 1.00% flat annual advisory fee on AUM, estimated at $6,200 annually, charged quarterly in arrears.
- **Portfolio Activity & Events:** 
  - A Q4 2018 equity market drawdown (~-13%) partially offset full-year gains.
  - An RSU grant was awarded to Alex Chen (EventID-2018-01) which is being tracked for tax planning (no immediate impact on managed AUM until vest/sale).

### Recommendations & Decisions
- **Defensive Rebalance:** A defensive rebalance was executed in Q4 2018, trimming equity holdings back to their 70% target weight.
- **Asset Allocation Maintained:** 70% Equity / 28% Fixed Income / 2% Cash.
- **No changes to accounts:** No accounts were opened or closed during the review period.
