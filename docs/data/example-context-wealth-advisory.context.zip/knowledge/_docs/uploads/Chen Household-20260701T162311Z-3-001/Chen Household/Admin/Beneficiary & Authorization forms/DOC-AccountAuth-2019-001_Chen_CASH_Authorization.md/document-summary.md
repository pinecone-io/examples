## Document Summary

This document is a New Account Authorization and Beneficiary Designation form dated January 1, 2019, for the Chen household (HH-CHEN-001). It records the establishment of a Joint Tenants with Rights of Survivorship (JTWROS) Cash Management Account / High-Yield Savings Account (ACCT-CASH) at Fidelity Institutional.

### Goals and Context
- **Emergency Reserve (GoalID-2016-03):** Establish a dedicated emergency reserve of 6–9 months of household expenses (target: $60,000–$90,000) separate from the household's investable assets in ACCT-TX01.
- **Home Purchase Staging (EventID-2021-01):** Serve as a staging account for an anticipated home purchase down payment around Q3 2021 (target up to $130,000 pre-closing).
- **Bucket Strategy:** Integrate into "Bucket 1" (0–24 months liquidity) for the household's long-term retirement strategy.

### Current Financial Situation & Funding
- **Initial Funding:** $37,000 transferred from the money market sleeve of ACCT-TX01.
- **Asset Allocation:** Funded with STBIX (Short-Term Bond / Cash Equivalent) or an FDIC-insured sweep.
- **Advisory Fees:** Included in the flat 1.00% fee base under the household's 2016 advisory agreement.

### Recommendations & Authorizations
- **Advisor Authority:** Clearwater Wealth Partners (Morgan Park, CFP®) is granted full discretionary trading authority over the account.
- **Wire Transfers:** Double signatures (Alex and Sam Chen) required for outbound wires exceeding $25,000; single signature allowed for lesser amounts.
- **Primary Beneficiary:** Sam Chen (100% spouse, JTWROS).
- **Contingent Beneficiaries:** Maya Chen (50%) and Eli Chen (50%), to be updated to the Chen Family Revocable Trust once finalized.

### Decisions & Action Items
- **Contingent Beneficiary Update:** Update the contingent beneficiary to the Chen Family Revocable Trust in Q2 2019 (ActionID-2019Q1-003) once trust formation is finalized (EventID-2019-01).
