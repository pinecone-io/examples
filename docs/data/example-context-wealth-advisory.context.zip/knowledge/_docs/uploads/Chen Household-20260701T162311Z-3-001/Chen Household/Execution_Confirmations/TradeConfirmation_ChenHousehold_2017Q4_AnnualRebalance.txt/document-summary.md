## Document Summary

This document confirms the execution of trade orders on December 14, 2017, for the year-end portfolio rebalance of the **Alex & Sam Chen** household (HH-CHEN-001), managed by **Morgan Park, CFP®** of Clearwater Wealth Partners and custodianed at Fidelity Institutional Wealth Services.

### Context & Strategy
Following a strong equity market rally in 2017 (S&P 500 +19.4%), the household's equity allocation drifted above its target. The trades were executed to restore the portfolio to its **IPS-2016 target allocation of 70% equities, 28% bonds, and 2% cash**.

### Trade Executions & Holdings Impact
*   **Joint Taxable Brokerage (ACCT-TX01):**
    *   **Sold:** 150 shares of *US Equity Core Index Fund (UECIX)* at $47.00/share (totaling $7,050.00). This realized a long-term capital gain of $1,050 (cost basis of $40.00/share from a Feb 2016 lot).
    *   **Bought:** 500 shares of *Municipal Bond Fund (MUNIX)* at $10.10/share ($5,050.00) to increase tax-exempt fixed-income exposure.
    *   **Bought:** 200 shares of *Short-Term Bond / Cash Equiv Fund (STBIX)* at $10.00/share ($2,000.00) to reset the cash sleeve target.
*   **Alex Traditional IRA (ACCT-IRA1):**
    *   **Sold:** 100 shares of *US Equity Core Index Fund (UECIX)* at $47.00/share ($4,700.00) with no taxable impact.
    *   **Bought:** 460 shares of *US Core Bond Index Fund (UCBIX)* at $10.20/share ($4,692.00) to bolster core bonds within the tax-deferred account.

### Financial Summary & Tax Impact
*   **Total Purchases:** $11,742.00
*   **Total Sales:** $11,750.00
*   **Net Cash Flow:** $8.00 credit (settled on December 15, 2017).
*   **Tax Impact:** Realized $1,050 in long-term capital gains in the taxable account. Total net capital gains for the household in 2017 are estimated at approximately $4,200.
