## Document Summary

This document is an executed Durable Power of Attorney (DPOA) for Financial, Healthcare, and Asset Management, established mutually between Alex Chen and Sam Chen on September 10, 2019. The instrument is effective immediately and remains valid upon incapacity (non-springing), in accordance with the Illinois Power of Attorney Act. It links directly to the Chen family trust and wills. 

### Key Provisions
- **Part A (Alex Chen as Principal):** Appoints Sam Chen as Primary Agent. Successor agents are Maya Chen (upon turning 25), followed by Westfield & Baker LLP (Trust Dept.). Financial powers cover investment management (specifically mentioning ACCT-TX01, ACCT-IRA1, and Clearwater Wealth Partners/Fidelity accounts), banking, real property, taxes, trust administration, retirement accounts, and business interests. Healthcare powers and an advance directive authorizing comfort care (and avoiding artificial life prolongation) are included.
- **Part B (Sam Chen as Principal):** Appoints Alex Chen as Primary Agent under identical and reciprocal terms. Eli Chen is named successor agent (upon turning 25), followed by Westfield & Baker LLP.
- **Subsequent Updates:** A 2024 notice highlights that both healthcare directives were updated on September 15, 2024 (via document DOC-TrustAmendment-2024-001) to align with a Physician Orders for Life-Sustaining Treatment (POLST) and expand healthcare agent instructions following a family health event.
