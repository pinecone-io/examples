## Document Summary

This document outlines the 2019 Insurance Review for the Chen Household (Alex and Sam Chen), conducted by advisor Morgan Park, CFP® of Clearwater Wealth Partners on November 18, 2019. The review was triggered by Alex's 2018 promotion and associated income increase, as well as the recent establishment of the Chen Family Revocable Trust.

### Household Context, Goals, and Risk Tolerance
* **Household Profile:** Alex (36) and Sam (35) Chen, with children Maya (8) and Eli (5). 
* **Goals:** The couple is currently renting and actively planning to purchase a home around 2021.

### Current Financial Situation and Holdings
* **Income:** Alex's estimated 2019 W-2 income is $155,000 (including RSUs). Sam's estimated income is $80,000.
* **Insurance Policies:**
  * **Life Insurance:** Alex has $2,000,000 in coverage and Sam has $1,500,000, both through 30-year level term policies with Protective Life Ins. Co. (annual premiums of $2,400 and $1,800 respectively).
  * **Disability Insurance:** Alex holds an individual, own-occupation disability policy with The Standard Group, which has been increased to $8,000/month (annual premium $3,840). Sam has employer-paid Group LTD covering 60% of her salary ($4,050/month) with a 90-day elimination period.
  * **Property & Casualty (Northfield Mutual):** Renters policy ($150k personal property, $500k liability, $720 annual premium), auto insurance for two vehicles ($250/500/100 liability, $2,950 annual premium), and a $1,000,000 Personal Umbrella policy ($450 annual premium).
  * **Total Estimated Out-of-Pocket Premium:** $9,960 annually.

### Recommendations and Action Items
* **Beneficiary Updates (Completed):** Named the Chen Family Revocable Trust as the contingent beneficiary on both life insurance policies (concluded under TaskID-2019Q2-001).
* **Disability Benefit (Completed):** Increased Alex's disability benefit to $8,000/month effective December 2019 to match his increased income.
* **Disability Income / RSU Gap (Medium Priority):** Noted that Alex's growing RSU compensation (~$25k/yr) is excluded from his disability benefit calculation. Recommending evaluation of an equity income replacement rider or supplemental coverage in the 2021–2022 timeframe.
* **Umbrella Coverage / Home Purchase Prep (Medium Priority):** Recommend increasing the umbrella insurance limit from $1,000,000 to $2,000,000 at the time of their anticipated 2021 home purchase. A staging package has been prefilled with Northfield Mutual.
* **Supplemental Disability (Low Priority):** Recommend revisiting Sam's group LTD if her employment situation changes.
