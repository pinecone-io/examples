## Document Summary

The Clearwater Wealth Partners insurance review for the Chen household, prepared by Morgan Park, CFP®, on December 12, 2016, serves as an baseline baseline review of the family's coverage.

### Household Context, Goals, & Risk Tolerance
- **Household:** Alex Chen (33, software product leader) and Sam Chen (32, marketing director) with two young children, Maya (5) and Eli (2). They reside at 3215 Lakeview Circle, Wayzata, MN.
- **Goals:** Key planning goals include Retirement Readiness (GoalID-2016-01), Education Funding (GoalID-2016-02), and a medium-term goal of purchasing a home.
- **Risk Profile:** The dual-income couple makes approximately $205,000 annually. Their young dependents create meaningful income-replacement and survivor-needs risk.

### Financial Situation & Holdings Discussed
- **Life Insurance:** 
  - Alex: $2,000,000 30-year level term policy with Protective Life Ins. Co. (Annual premium: $2,400).
  - Sam: $1,500,000 30-year level term policy with Protective Life Ins. Co. (Annual premium: $1,800).
- **Disability Insurance:**
  - Alex: Individual own-occupation policy with The Standard Group providing $6,500/month (Annual premium: $3,120).
  - Sam: Employer Group LTD providing $3,900/month (60% of salary).
- **Property & Casualty (Northfield Mutual):**
  - Renters Insurance: $150,000 personal property, $500,000 personal liability (Annual premium: $680).
  - Auto Insurance: Two vehicles, 250/500/100 liability + comp/collision (Annual premium: $2,800).
  - Personal Umbrella: $1,000,000 excess liability (Annual premium: $450).
- **Total Out-of-Pocket Premium:** $9,250 annually.

### Recommendations & Action Items
- **Beneficiary Designations (High Priority):** Update life insurance policies to name the Chen Family Revocable Trust as the contingent beneficiary once the trust is executed (anticipated target: 2019).
- **Alex's Disability Benefit (Medium Priority):** Review and increase benefit coverage annually as income grows (Ongoing/Annual review).
- **Sam's Disability Portability (Medium Priority):** Evaluate a supplemental individual disability policy if she decides to transition employers (Ongoing).
- **Homeowners Coverage (Low Priority):** Transition to a homeowners policy and review the umbrella coverage limits at the time of a home purchase.
