## Document Summary

This document contains tax information for the Chen Household (Alex & Sam Chen) for tax year 2016, originating from Fidelity Institutional for the joint taxable brokerage account ACCT-TX01 (...7412).

### Financial Situation and Holdings
- **Taxable Brokerage Account (ACCT-TX01):** Active holdings include UECIX, IDEIX, and MUNIX.
- **Taxable Dividends & Interest:** Recorded $850.24 in total ordinary dividends (of which $680.19 were qualified), $298.56 in interest income, and $274.88 in exempt-interest dividends from the Minnesota Municipal Bond Fund (MUNIX).
- **Realized Capital Gains (Long-Term):** Realized a net capital gain of $3,515.00 from long-term asset sales. Proceeds totaled $44,915.00 against a cost basis of $41,400.00.

### Recommendations & Portfolio Decisions
Three long-term asset sales were recorded in 2016 to meet specific portfolio objectives:
1. **IDEIX Sale (1,200 shares on 2016-07-15):** Generated proceeds of $14,640.00 (gain of $1,440.00) to rebalance and shift assets to UCBIX.
2. **STBIX Sale (500 shares on 2016-09-12):** Generated proceeds of $5,025.00 (gain of $45.00) to liquidate cash for the emergency fund.
3. **UCBIX Sale (2,500 shares on 2016-11-08):** Generated proceeds of $25,250.00 (gain of $2,030.00) to trim equity exposure as part of a rebalancing strategy.
