## Document Summary

### Document Summary

This execution confirmation details the trade activity for the Alex & Sam Chen household on December 14, 2020. Managed by Advisor Morgan Park of Clearwater Wealth Partners and custodied with Fidelity Institutional, the trades were executed to complete an annual rebalance and fund initial 529 plan contributions.

#### Key Objectives & Transactions
- **Taxable Account Rebalancing:** In the Joint Taxable Brokerage account (ACCT-TX01), 30 shares of the US Equity Core Index Fund (UECIX) were sold for a total of $1,890.00 (generating a long-term capital gain of $690.00 from a February 2016 lot). The proceeds were reinvested in the Short-Term Bond / Cash Equivalent Fund (STBIX) for $1,888.70 to top up the cash sleeve and maintain the 5% cash target per IPS-2020.
- **529 Plan Funding:** Newly established 529 plan accounts for beneficiaries Maya Chen (ACCT-529A) and Eli Chen (ACCT-529B) received initial investments. Each account was funded with a $5,000.00 household cash contribution (a net debit of $10,000.00 overall, not funded from brokerage proceeds) to purchase 500 shares of the 529 Age-Based Moderate Index Portfolio (529-AGE-MOD) at $10.00/share.

#### Tax Considerations
- The UECIX sale produced a $690 long-term capital gain, contributing to approximately $12,000 of total net long-term capital gains for the household in tax year 2020.
- The 529 contributions are not federally tax-deductible, but they may qualify for a Minnesota state tax deduction of up to $3,000 per beneficiary per year. The clients were advised to consult with Lisa Torres, EA, regarding eligibility.
