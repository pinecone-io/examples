## Document Summary

### Compliance Review & Annual Acknowledgement (Review Date: January 10, 2022)

This annual compliance acknowledgement records the key milestones, disclosures, and investment profile parameters for the Chen household for the review period from January 1 through December 31, 2021.

### Household Context, Goals, and Risk Tolerance
- **Client Household:** Alex & Sam Chen (HH-CHEN-001)
- **Risk Profile:** Conservative-Moderate (Risk Questionnaire Score: 54/100).
- **Investment Strategy:** Continued adherence to the active Investment Policy Statement (IPS) amendment (DOC-IPSAmendment-2020-001) with a target allocation of 60% Equity / 35% Fixed Income / 5% Cash. The adviser confirmed this program remains suitable.

### Current Financial Situation and Holdings
At year-end 2021, the household's Assets Under Management (AUM) stood at **$952,000**, distributed as follows:
- **TX01 (Taxable Joint):** $480,000
- **IRA1 (Alex IRA):** $330,000
- **RIRA (Sam Roth IRA):** $78,000
- **CASH (Cash/Liquidity):** $50,000
- **529A (Alex Jr. — College):** $7,000
- **529B (Sam — College):** $7,000

### Material Changes & Decisions Recorded
- **Home Purchase:** Alex & Sam Chen acquired their primary residence in 2021.
- **Down Payment Funding:** Staged $185,000 from the TX01 taxable joint account (executed July 10, 2021), resulting in approximately $18,500 in net realized capital gains.
- **Education Funding:** Initial contributions were made to fund the 529A and 529B accounts following the home purchase settlement.
- **AUM Growth:** The portfolio recovered strongly from 2020 levels, growing by $160,000 net of the down payment withdrawal.
- **Fee Schedule Amendment:** Executed a tiered fee amendment (DOC-FeeAmendment-2021-001) in Q3 2021. The new rate is 0.85% on the first $1.5M AUM (resulting in an estimated annual advisory fee of $7,800 for 2021 under a blended Q1-Q2 pre-amendment/Q3-Q4 post-amendment calculation).

### Compliance Disclosures & Delivery
The following regulatory documents were delivered to the household:
- Form ADV Part 2A/2B (March 2021)
- Form CRS (March 2021)
- Privacy Policy and Notice (Reg S-P)
- Business Continuity Plan Summary
- Proxy Voting Policy Disclosure
