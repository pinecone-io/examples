## Document Summary

This document is the executed Last Will and Testament of Sam Chen, a resident of Naperville, Illinois, dated September 10, 2019. It acts as a companion pour-over will to his spouse Alex Chen's will (DOC-Will-2019-001) and coordinates directly with the Chen Family Revocable Living Trust (DOC-Trust-2019-001).

### Key Provisions and Directives
- **Personal Representative:** Appoints his spouse, Alex Chen, as Personal Representative. If Alex is unable or unwilling to serve, Maya Chen is appointed as successor (upon reaching age 25).
- **Tangible Personal Property:** All tangible personal property is left outright to Alex Chen. If Alex does not survive Sam, this property passes in equal shares to their children, Maya and Eli Chen. 
- **Specific Bequest:** A collection of heirloom jewelry (to be cataloged in Schedule B) is designated for Maya Chen when she reaches age 21, or Eli Chen if Maya has predeceased him.
- **Residuary Estate (Pour-Over):** All residuary estate assets are directed to be poured over into the Chen Family Revocable Living Trust.
- **Guardianship:** If Alex Chen does not survive Sam and the children are minors, Alex Chen's sibling is nominated as Guardian of the minor children.

### Open Decisions and Action Items
- **Roth IRA Beneficiary Coordination:** Sam's Roth IRA (`ACCT-RIRA`, at Fidelity Institutional) passes outside the will. There is an open action item (TaskID-2019Q2-001 / ActionID-2019Q1-003) to update and align the beneficiary designation (which remains as filed in 2016 under DOC-BeneficiaryDesig-2016-001) with the trust's intent.
