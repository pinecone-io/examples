## Document Summary

### Document Summary

#### Household Context, Goals, and Risk Tolerance
* **Household**: Alex & Sam Chen (Chen Household, HH-CHEN-001).
* **Goal**: Establish a values-based giving plan (GoalID-2023-01) supporting community development, food security, children's health, and education.
* **Financial Context**: Alex experienced an RSU vesting liquidity event in May 2023, creating a large NLTK concentration in ACCT-TX01 and raising their 2023 estimated AGI to approximately $426,000. This high-income year subjected them to the 37% federal marginal rate, 4.95% Illinois state tax, and the 3.8% Net Investment Income Tax (NIIT).

#### Current Financial Situation and Holdings
* **Source Account**: Brokerage account ACCT-TX01.
* **Stock Transferred**: 500 shares of NLTK (Clearwater Tech Common Stock) with a fair market value of $50.00/share ($25,000 total value) and a cost basis of $5.00/share ($2,500 total basis).
* **Embedded Capital Gain**: $22,500 of long-term capital gain (LTCG).

#### Recommendations and Decisions
* **Establishment of DAF**: A Donor-Advised Fund (DAF) named "Chen Family Charitable Fund" (NGF-CHEN-2023-001) was opened with Clearwater Giving Fund (Fidelity Charitable) on May 18, 2023.
* **Tax-Efficient Donation**: Donating the 500 NLTK shares in-kind directly to the DAF avoids approximately $5,355 in long-term capital gains tax while securing a $25,000 charitable deduction for the high-income tax year 2023 (well below the $127,800 AGI limit).
* **Investment Strategy**: DAF funds are initially allocated to the "Fidelity Charitable Balanced Pool" for moderate growth during the accumulation phase.
* **Successor Advisers**: Alex Chen (Primary) and Sam Chen, aligning with the DOC-Trust-2019-001 trust structure.

#### Anticipated Action Items
* **Q4 2023 Granting**: Anticipated annual grants from the DAF starting late Q4 2023, targeting:
  * Evanston Community Foundation ($3,000–$5,000)
  * Greater Chicago Food Depository ($2,000–$4,000)
  * Ann & Robert H. Lurie Children’s Hospital ($1,000–$2,000)
  * Chicago Literacy Alliance ($500–$1,500)
* **Future Contributions**: Annual top-up contributions planned for 2024–2026 to maintain DAF balance.
