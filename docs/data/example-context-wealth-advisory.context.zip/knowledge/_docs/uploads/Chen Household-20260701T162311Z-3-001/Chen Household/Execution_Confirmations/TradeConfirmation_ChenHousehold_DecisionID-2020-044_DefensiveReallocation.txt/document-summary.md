## Document Summary

This document records trade executions implementing a strategic defensive asset reallocation for the Chen household, following a COVID-19 risk reassessment. At their June 2020 meeting, Alex and Sam expressed heightened equity concentration concerns under their former 70/28/2 allocation. Consequently, they adopted a more conservative Investment Policy Statement (IPS-2020) target of 60% Equity / 35% Fixed Income / 5% Cash.

### Current Financial Situation & Transactions
Transactions occurred within the Joint Taxable Brokerage Account (**ACCT-TX01**) at Fidelity Institutional Wealth Services, executed in two tranches (June 15 and June 22, 2020):
- **Equity Reductions (Sells):** 
  - Sold 650 shares of US Equity Core Index Fund (**UECIX**) at $56.00/share (gross proceeds: $36,400.00).
  - Sold 400 shares of Intl Developed Equity Index Fund (**IDEIX**) at $27.00/share (gross proceeds: $10,800.00).
- **Defensive Reallocations (Buys):**
  - Bought 2,000 shares of Municipal Bond Fund (**MUNIX**) at $10.40/share (total: $20,800.00) for tax-efficient income in the taxable account.
  - Bought 2,000 shares of Short-Term Bond / Cash Equiv Fund (**STBIX**) at $10.10/share (total: $20,200.00) to increase cash buffer.
  - Bought 580 shares of US Core Bond Index Fund (**UCBIX**) at $10.80/share (total: $6,264.00) to support the core fixed-income target.

### Financial Impact & Decisions
- **Totals:** Total sold was $47,200.00, and total purchased was $47,264.00, resulting in a net cash flow debit of $64.00.
- **Tax Impact:** The UECIX sale generated a long-term capital gain of $10,400, and the IDEIX sale generated a long-term capital gain of $800, creating an aggregate estimated long-term capital gains tax impact of $11,200.
