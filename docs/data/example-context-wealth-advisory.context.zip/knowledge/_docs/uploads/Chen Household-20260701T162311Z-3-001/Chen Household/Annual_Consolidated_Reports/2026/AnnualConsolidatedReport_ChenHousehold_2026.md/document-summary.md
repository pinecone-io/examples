## Document Summary

### Executive Summary

This Annual Consolidated Report for the Chen Household (Alex & Sam Chen) marks the conclusion of "Story Arc 3," focusing on fee governance resolution, documentation integrity, and transition readiness. Administered by Morgan Park, CFP® of Clearwater Wealth Partners, and tax specialist Lisa Torres, EA, the household's total assets reached $1,650,000 at the end of 2026, showcasing a cumulative growth from $410,000 in 2016.

### Financial Situation and Portfolio Summary
As of December 31, 2026, total household assets stand at **$1,650,000** distributed across the following accounts and "buckets":
- **ACCT-TX01 (Taxable Joint Brokerage — Bucket 3):** $850,000 (Equities and MUNIX; single-stock NLTK remains under the 5% Investment Policy Statement limit).
- **ACCT-IRA1 (Alex Traditional IRA — Bucket 2):** $555,000 (Core stability holding UCBIX + UTIPX).
- **ACCT-RIRA (Alex Roth IRA — Bucket 3):** $120,000 (Allocated to small-cap, emerging markets, and REITX for tax-free long-term growth).
- **ACCT-CASH (Cash Management — Bucket 1):** $35,000 (Near-term cash reserve, supplemented by STBIX in the taxable account for a total near-term reserve of ~$40,000).
- **ACCT-529A (Maya 529):** $45,000 (Age-based; 3 years until 2029 college enrollment).
- **ACCT-529B (Eli 529):** $45,000 (Age-based moderate; 6 years until 2032 college enrollment).

### Key Advisory Events & Resolutions
- **Fee Billing Discrepancy (EventID-2026-01):** An administrative review corrected a discrepancy where a superseded draft strategy deck referenced a legacy 1.00% flat fee rather than the actual tiered schedule in effect since July 2021 (0.85% / 0.70% / 0.55%). Although historical billing was confirmed correct, Clearwater Wealth Partners issued a $1,250 goodwill credit in Q1 2026 to resolve any confusion.
- **Tax Planning TY2026:** Adjusted Gross Income is estimated at ~$330,000 (W-2 wages of $282,000 and equity comp of $20,000). The couple is using itemized deductions and a charitable bunching strategy through the Clearwater Giving Fund Donor-Advised Fund (DAF), which distributed $8,000 in grants in 2026.

### Goals & Progress
- **Retirement (GoalID-2016-01):** On track with a ~92% confidence level for a $185k/yr target. The optimal strategy remains delaying Social Security until age 70 for both Alex and Sam (~17 years out).
- **Education Funding (GoalID-2016-02):** Trajectory now covers approximately 75% of Maya's projected four-year college costs. Eli's 529 is also tracking well.
- **Emergency Liquidity (GoalID-2016-03):** Maintained within target ranges.
- **Values-Based Giving (GoalID-2023-01):** Ongoing coordination with Lisa Torres, EA, utilizing the DAF.

### Recommendations & Next Steps
1. **Maya 529 Final 3-Year Plan:** Formulate the final funding plan for college enrollment in 2029 (Due Q1 2027).
2. **2027 DAF Distribution Plan:** Structure upcoming charitable grants (Due Q1 2027).
3. **Annual IPS Review:** Complete standard annual review of current IPS-2025 guidelines (Due Q1 2027).
