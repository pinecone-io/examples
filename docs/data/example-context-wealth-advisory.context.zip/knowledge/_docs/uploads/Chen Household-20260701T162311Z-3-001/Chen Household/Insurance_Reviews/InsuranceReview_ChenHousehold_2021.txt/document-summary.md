## Document Summary

This document summarizes the 2021 insurance review for the Chen household (Alex and Sam Chen), prepared by Clearwater Wealth Partners on November 9, 2021. The review was primarily triggered by the household's purchase of a home in July 2021, necessitating a major restructuring of their insurance coverage.

### Household Context & Goals
*   **Household:** Alex (38) and Sam (37) Chen, with two children: Maya (10) and Eli (7).
*   **Key Event:** Purchased a home at 3215 Lakeview Circle, Wayzata, MN 55391 in July 2021 for approximately $740,000 (market value), financed with a $575,000, 30-year fixed mortgage at 3.10% from Lakeside Mortgage Co. 
*   **Risk Tolerance & Asset Base:** Household assets are approximately $875,000 in portfolio assets and $165,000 in home equity. Standard HO-3 coverage and a high liability umbrella are appropriate for their risk profile.

### Current Financial Situation & Holdings
*   **Total Annual Out-of-Pocket Premium:** $13,100 (estimated).
*   **Life Insurance:** 
    *   Alex: $2,000,000 30-year level term (Protective Life), primary beneficiary Sam, contingent Chen Family Rev. Trust. Premium: $2,400/yr.
    *   Sam: $1,500,000 30-year level term (Protective Life), primary beneficiary Alex, contingent Chen Family Rev. Trust. Premium: $1,800/yr.
*   **Disability Insurance:**
    *   Alex: Individual Own-Occ (The Standard Group), $8,000/month benefit with a 90-day elimination period. Premium: $3,840/yr.
    *   Sam: Group LTD (Employer Group LTD), $4,200/month benefit (60%) with a 90-day elimination period. Employer-paid.
*   **Property, Casualty & Liability:**
    *   Homeowners (HO-3): Northfield Mutual, Dwelling $650,000, Contents $175,000, Liability $500,000, plus endorsements ($25,000 sewer backup, $18,000 jewelry rider for Sam's engagement/heirloom rings). Deductible $2,500; Premium $2,200/yr.
    *   Auto (2 vehicles): Northfield Mutual, 250/500/100 liability + comp/collision. Deductible $500; Premium $3,100/yr.
    *   Personal Umbrella: Northfield Mutual, $2,000,000 excess liability. Premium $750/yr.

### Recommendations & Action Items
1.  **Alex DI Benefit Increase (High Priority):** Increase Alex's disability benefit from $8,000 to $9,000/month in Q1 2022 to rebuild a budget buffer. The current benefit covers only 31% of fixed expenses over mortgage, utilities, and childcare.
2.  **Alex DI - RSU Gap (Medium Priority):** Evaluate supplemental coverage for 2022–2023, as Alex's RSU income is currently excluded from the disability benefit base.
3.  **Life Insurance Trust Ownership (Low Priority):** Discuss the feasibility of an Irrevocable Life Insurance Trust (ILIT) with an estate attorney in 2023 to manage potential estate tax inclusion risks as their asset base grows.
4.  **Completed Actions:** Transitioned from renters to homeowners insurance (effective July 12, 2021) and increased the umbrella policy from $1,000,000 to $2,000,000 to cover homeownership liability.
